head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.59;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.59;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@
Partial Class Web_CSP_ucGDSDetail
    Inherits BaseUserControl

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
        End If
    End Sub

    Private Sub RegistScript()

    End Sub

    Private Sub LoadDataTypeList()
        Dim BLL As New BusinessLogicLayer.LineDefBLL()
        Dim dt As DataTable
        dt = BLL.GetDataTypeList()
        With Me.ddlType
            .DataTextField = "SchemaType"
            .DataValueField = "SchemaTypeID"
            .DataSource = dt
            .DataBind()
        End With
        Call Me.LoadDataCategoryList()
    End Sub

    Private Sub LoadDataCategoryList()
        Dim BLL As New BusinessLogicLayer.LineDefBLL()
        Dim dt As DataTable
        dt = BLL.GetDataCategoryList(Me.ddlType.SelectedValue)
        With Me.ddlCategory
            .DataTextField = "SchemaCategory"
            .DataValueField = "SchemaCatID"
            .DataSource = dt
            .DataBind()
        End With
        Call Me.LoadDataSchemaList()
    End Sub

    Private Sub LoadDataSchemaList()
        Dim BLL As New BusinessLogicLayer.LineDefBLL()
        Dim dt As DataTable
        dt = BLL.GetDataSchemaList(Me.ddlCategory.SelectedValue)
        With Me.ddlSchema
            .DataTextField = "SchemaName"
            .DataValueField = "SchemaID"
            .DataSource = dt
            .DataBind()
        End With
    End Sub

    Private Sub LoadDropDownList()
        Dim BLL As New BusinessLogicLayer.LineDefBLL()
        Dim dt As DataTable
        dt = BLL.GetCommandList()
        With Me.ddlCommand
            .DataTextField = "GDSFormat"
            .DataValueField = "DataTypeValue"
            .DataSource = dt
            .DataBind()
        End With
        '//
        Call Me.LoadDataTypeList()
        '//
        dt = BLL.GetLineNumber()
        With Me.ddlItemNo
            .DataTextField = "LineNumber"
            .DataValueField = "LineNumber"
            .DataSource = dt
            .DataBind()
        End With
    End Sub

    Public Sub LoadData(ByVal RecordID As String)
        Dim BLL As New BusinessLogicLayer.LineDefBLL()
        Dim dt As DataTable
        Call Me.RegistScript()
        Call Me.LoadDropDownList()
        dt = BLL.GetLienDefDetailByID(RecordID, 1)
        With Me.rptData
            .DataSource = dt
            .DataBind()
        End With
        Me.ddlItemNo.SelectedIndex = 0
        Call Me.ReLoadEditData()
    End Sub

    Public Function GetMoveType(ByVal mvType As String) As String
        Dim retVal As String = ""
        If mvType = "Y" Then
            retVal = "Y-always move"
        Else
            If mvType = "N" Then
                retVal = "N-no move"
            End If
        End If
        Return retVal
    End Function

    Private Function GetRepeaterLabel(ByVal index As Integer, ByVal id As String) As Label
        Dim lbl As Label
        lbl = New Label()
        lbl = Me.rptData.Items(index - 1).FindControl(id)
        Return lbl
    End Function

    Private Function GetCommandText(ByVal text As String) As String
        Dim list As ListItem
        list = Me.ddlCommand.Items.FindByText(text)
        If list IsNot Nothing Then
            Return list.Value
        Else
            Return ""
        End If
    End Function

    Private Sub ReLoadEditData()
        On Error Resume Next
        Dim itemindex As Integer = Util.DBNullToZero(Me.ddlItemNo.SelectedValue)
        '//
        Me.ddlMoveType.SelectedValue = Me.GetRepeaterLabel(itemindex, "hidMoveType").Text
        Me.txtSecondInd.Text = Me.GetRepeaterLabel(itemindex, "xtxtSecondInd").Text
        Me.txtThirdInd.Text = Me.GetRepeaterLabel(itemindex, "xtxtThirdInd").Text
        Me.ddlCommand.SelectedValue = Me.GetCommandText(Me.GetRepeaterLabel(itemindex, "xddlCommand").Text)
        Me.txtQualifier.Text = Me.GetRepeaterLabel(itemindex, "xtxtQualifier").Text
        Me.txtFormatString.Text = Me.GetRepeaterLabel(itemindex, "xtxtFormatString").Text
        Me.txtRemark.Text = Me.GetRepeaterLabel(itemindex, "xtxtRemark").Text
    End Sub

    Private Sub SaveData()
        Dim BLL As New BusinessLogicLayer.LineDefBLL()
        Dim info As New DataInfo.LineDefDetailInfo()
        With info
            .VersionID = 1
            .LineNumber = Me.ddlItemNo.SelectedValue
            .SecondInd = Me.txtSecondInd.Text
            .ThirdInd = Me.txtThirdInd.Text
            .Qualifier = Me.txtQualifier.Text
            .MoveType = Me.ddlMoveType.SelectedValue
            .Command = Me.ddlCommand.SelectedValue
            .FormatString = Me.txtFormatString.Text
            .Remark = Me.txtRemark.Text
        End With
        'If BLL.UpdateLineDetail(info) > 0 Then
        '    Me.lblMsgBox.Text = Util.GetAppConfig(Util.MsgType.TRANS_SUCCESS.ToString)
        '    Me.lblMsgBox.ForeColor = Drawing.Color.Green
        '    Me.ajaxMsgBox.Show()
        'Else
        '    Me.lblMsgBox.Text = Util.GetAppConfig(Util.MsgType.TRANS_ERROR.ToString)
        '    Me.lblMsgBox.ForeColor = Drawing.Color.Red
        '    Me.ajaxMsgBox.Show()
        'End If
    End Sub

    Public Sub gdData_Command(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.CommandEventArgs)
        Select Case e.CommandName
            Case "EditItem"
                Me.ddlItemNo.SelectedValue = e.CommandArgument
                Call Me.ReLoadEditData()
                '//
        End Select
    End Sub

    Protected Sub ddlItemNo_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlItemNo.SelectedIndexChanged
        Call Me.ReLoadEditData()
    End Sub

    Protected Sub ddlType_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlType.SelectedIndexChanged
        Call Me.LoadDataCategoryList()
    End Sub

    Protected Sub ddlCategory_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlCategory.SelectedIndexChanged
        Call Me.LoadDataSchemaList()
    End Sub

    Protected Sub btnTrans_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnTrans.Click
        Call Me.SaveData()
    End Sub


End Class
@


1.1.1.1
log
@no message
@
text
@@
