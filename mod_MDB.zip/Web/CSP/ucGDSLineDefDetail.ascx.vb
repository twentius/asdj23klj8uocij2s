head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.59;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.59;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@
Partial Class Web_CSP_ucGDSLineDefDetail
    Inherits BaseUserControl

    Public Property RecordID() As String
        Get
            Return Me.ViewState("_RecordID")
        End Get
        Set(ByVal value As String)
            Me.ViewState("_RecordID") = value
        End Set
    End Property

    Public Property VersionID() As String
        Get
            Return Me.ViewState("_VersionIDD")
        End Get
        Set(ByVal value As String)
            Me.ViewState("_VersionIDD") = value
        End Set
    End Property

    Public Property CurrentPage() As String
        Get
            Return Me.ViewState("_CurrentPage")
        End Get
        Set(ByVal value As String)
            Me.ViewState("_CurrentPage") = value
        End Set
    End Property

    Public Property OnEditable() As Boolean
        Get
            Return Me.ViewState("_OnEditable")
        End Get
        Set(ByVal value As Boolean)
            Me.ViewState("_OnEditable") = value
        End Set
    End Property

    Public Property CommadTable() As DataTable
        Get
            Return Me.ViewState("_CommadTable")
        End Get
        Set(ByVal value As DataTable)
            Me.ViewState("_CommadTable") = value
        End Set
    End Property

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then

        End If
    End Sub

    Private Sub LoadDataTypeList()
        Dim BLL As New BusinessLogicLayer.LineDefBLL()
        Dim dt As DataTable
        dt = BLL.GetDataTypeList()
        With Me.ddlType
            .DataTextField = "SchemaType"
            .DataValueField = "SchemaTypeID"
            .DataSource = dt
            .DataBind()
        End With
        Call Me.LoadDataCategoryList()
    End Sub

    Private Sub LoadDataCategoryList()
        Dim BLL As New BusinessLogicLayer.LineDefBLL()
        Dim dt As DataTable
        dt = BLL.GetDataCategoryList(Me.ddlType.SelectedValue)
        With Me.ddlCategory
            .DataTextField = "SchemaCategory"
            .DataValueField = "SchemaCatID"
            .DataSource = dt
            .DataBind()
        End With
        Call Me.LoadDataSchemaList()
    End Sub

    Private Sub LoadDataSchemaList()
        Dim BLL As New BusinessLogicLayer.LineDefBLL()
        Dim dt As DataTable
        dt = BLL.GetDataSchemaList(Me.ddlCategory.SelectedValue)
        With Me.ddlSchema
            .DataTextField = "SchemaName"
            .DataValueField = "SchemaName"
            .DataSource = dt
            .DataBind()
        End With
    End Sub

    Public Sub LoadDropDownList()
        Dim BLL As New BusinessLogicLayer.LineDefBLL()
        Dim sc As New StringBuilder()
        Me.CommadTable = BLL.GetCommandList()
        '//
        Call Me.LoadDataTypeList()
        Dim ddlVar As String
        Dim ddlFocus As String
        ddlVar = Me.ddlSchema.ClientID
        ddlFocus = Me.ddlType.ClientID
        sc.AppendLine("ddlVar='" + ddlVar + "';")
        sc.AppendLine("ddlFocus='" + ddlFocus + "';")
        Util.RegClientScript(sc.ToString, "RegistDDL", Util.ClientScriptRegistType.RegStartUpBlock)
    End Sub

    Public Sub LoadData()
        Dim BLL As New BusinessLogicLayer.LineDefBLL()
        Dim dt As DataTable
        If Me.CurrentPage Is Nothing OrElse Util.DBNullToZero(Me.CurrentPage) <= 0 Then
            Me.CurrentPage = 1
        End If
        Me.lnkPage1.Enabled = (Me.CurrentPage <> 1)
        Me.lnkPage2.Enabled = (Me.CurrentPage <> 2)
        Me.lnkPage3.Enabled = (Me.CurrentPage <> 3)
        Me.lnkPage4.Enabled = (Me.CurrentPage <> 4)
        Me.lnkPage5.Enabled = (Me.CurrentPage <> 5)
        Me.lnk2Page1.Enabled = (Me.CurrentPage <> 1)
        Me.lnk2Page2.Enabled = (Me.CurrentPage <> 2)
        Me.lnk2Page3.Enabled = (Me.CurrentPage <> 3)
        Me.lnk2Page4.Enabled = (Me.CurrentPage <> 4)
        Me.lnk2Page5.Enabled = (Me.CurrentPage <> 5)
        dt = BLL.GetLienDefDetailByID(Me.RecordID, Me.CurrentPage)
        With Me.rptData
            .DataSource = dt
            .DataBind()
        End With
        Call Me.ToggleControls()
    End Sub

    Public Sub ToggleControls()
        Dim ddl As CWTCustomControls.CWTDropDownList
        Dim tb As CWTCustomControls.CWTTextBox
        Dim btn As HtmlInputButton
        '//
        For index As Integer = 0 To Me.rptData.Items.Count - 1
            tb = Me.rptData.Items(index).FindControl("txtSecondInd")
            tb.Enabled = Me.OnEditable
            tb = Me.rptData.Items(index).FindControl("txtThirdInd")
            tb.Enabled = Me.OnEditable
            tb = Me.rptData.Items(index).FindControl("txtQualifier")
            tb.Enabled = Me.OnEditable
            tb = Me.rptData.Items(index).FindControl("txtFormatString")
            tb.Enabled = Me.OnEditable
            tb = Me.rptData.Items(index).FindControl("txtRemark")
            tb.Enabled = Me.OnEditable
            ddl = Me.rptData.Items(index).FindControl("ddlMoveType")
            ddl.Enabled = Me.OnEditable
            ddl = Me.rptData.Items(index).FindControl("ddlCommand")
            ddl.Enabled = Me.OnEditable
            btn = Me.rptData.Items(index).FindControl("btnAddItem")
            btn.Disabled = (Not Me.OnEditable)
        Next
        Me.btnTrans.Enabled = Me.OnEditable
        Me.btnTrans2.Enabled = Me.OnEditable
        Me.ddlType.Enabled = Me.OnEditable
        Me.ddlCategory.Enabled = Me.OnEditable
        Me.ddlSchema.Enabled = Me.OnEditable
        If Me.OnEditable Then
            'Me.lnkPage1.Attributes.Add("onclick", "return confirm('Do you want to save data?');")
            'Me.lnkPage2.Attributes.Add("onclick", "return confirm('Do you want to save data?');")
            'Me.lnkPage3.Attributes.Add("onclick", "return confirm('Do you want to save data?');")
            'Me.lnkPage4.Attributes.Add("onclick", "return confirm('Do you want to save data?');")
            'Me.lnkPage5.Attributes.Add("onclick", "return confirm('Do you want to save data?');")
            'Me.lnk2Page1.Attributes.Add("onclick", "return confirm('Do you want to save data?');")
            'Me.lnk2Page2.Attributes.Add("onclick", "return confirm('Do you want to save data?');")
            'Me.lnk2Page3.Attributes.Add("onclick", "return confirm('Do you want to save data?');")
            'Me.lnk2Page4.Attributes.Add("onclick", "return confirm('Do you want to save data?');")
            'Me.lnk2Page5.Attributes.Add("onclick", "return confirm('Do you want to save data?');")
        End If
    End Sub

    Protected Sub rptData_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.RepeaterItemEventArgs) Handles rptData.ItemDataBound
        On Error Resume Next
        If Not (e.Item.ItemType = ListItemType.Item AndAlso e.Item.ItemType = ListItemType.AlternatingItem) Then
            Dim ddl As CWTCustomControls.CWTDropDownList
            ddl = e.Item.FindControl("ddlCommand")
            If ddl IsNot Nothing Then
                With ddl
                    .DataTextField = "GDSFormat"
                    .DataValueField = "DataTypeValue"
                    .DataSource = Me.CommadTable
                    .DataBind()
                    .Items.Insert(0, "")
                    .SelectedValue = DataBinder.Eval(e.Item.DataItem, "DataTypeValue")
                End With
            End If
            ddl = e.Item.FindControl("ddlMoveType")
            If ddl IsNot Nothing Then
                ddl.SelectedValue = DataBinder.Eval(e.Item.DataItem, "MoveType")
            End If
            '// regist Script
            Dim tb As CWTCustomControls.CWTTextBox
            Dim btn As HtmlInputButton
            Dim txtCtrl As String
            Dim sc As String
            tb = e.Item.FindControl("txtFormatString")
            txtCtrl = tb.ClientID
            btn = e.Item.FindControl("btnAddItem")
            '//
            sc = "AddFomula('" + txtCtrl + "');"
            btn.Attributes.Add("onclick", sc)
        End If
    End Sub
    '//
    Private Sub SaveData()
        Dim info As New DataInfo.LineDefInfo()
        Dim line As DataInfo.LineDefDetailInfo
        Dim BLL As New BusinessLogicLayer.LineDefBLL()
        Dim tb As CWTCustomControls.CWTTextBox
        Dim ddl As CWTCustomControls.CWTDropDownList
        With info
            .MasterID = Me.RecordID
            .VersionID = Me.VersionID
            .CurrentPage = Me.CurrentPage
            For i As Integer = 0 To 39
                line = New DataInfo.LineDefDetailInfo()
                tb = Me.rptData.Items(i).FindControl("txtSecondInd")
                line.SecondInd = tb.Text
                tb = Me.rptData.Items(i).FindControl("txtThirdInd")
                line.ThirdInd = tb.Text
                tb = Me.rptData.Items(i).FindControl("txtQualifier")
                line.Qualifier = tb.Text
                tb = Me.rptData.Items(i).FindControl("txtFormatString")
                line.FormatString = tb.Text
                tb = Me.rptData.Items(i).FindControl("txtRemark")
                line.Remark = tb.Text
                ddl = Me.rptData.Items(i).FindControl("ddlMoveType")
                line.MoveType = ddl.SelectedValue
                ddl = Me.rptData.Items(i).FindControl("ddlCommand")
                line.Command = ddl.SelectedValue
                If line.MoveType = "" AndAlso line.Command = "" AndAlso line.SecondInd = "" AndAlso line.ThirdInd = "" AndAlso line.Qualifier = "" AndAlso line.FormatString = "" AndAlso line.Remark = "" Then
                    Continue For
                End If
                '//
                line.LineNumber = ((Util.DBNullToZero(Me.CurrentPage) - 1) * 40) + i + 1
                .Lines.Add(line)
            Next
        End With
        If BLL.UpdateLineDetail(info) > 0 Then
            Me.lblMsgBox.Text = Util.GetAppConfig(Util.MsgType.TRANS_SUCCESS.ToString)
            Me.lblMsgBox.ForeColor = Drawing.Color.Green
            Me.ajaxMsgBox.Show()
        Else
            Me.lblMsgBox.Text = Util.GetAppConfig(Util.MsgType.TRANS_ERROR.ToString)
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.ajaxMsgBox.Show()
        End If
    End Sub
    '//
    Protected Sub btnTrans_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnTrans.Click, btnTrans2.Click
        Call Me.SaveData()
    End Sub
    '//
    Protected Sub lnk2Page1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles lnkPage1.Click, lnk2Page1.Click

        If Me.OnEditable = True Then
            Call Me.SaveData()
        End If
        Me.CurrentPage = 1
        Call Me.LoadData()
      

    End Sub
    Protected Sub lnk2Page2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles lnkPage2.Click, lnk2Page2.Click

        If Me.OnEditable = True Then
            Call Me.SaveData()
        End If
        Me.CurrentPage = 2
        Call Me.LoadData()
     
    End Sub
    Protected Sub lnk2Page3_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles lnkPage3.Click, lnk2Page3.Click

        If Me.OnEditable = True Then
            Call Me.SaveData()
        End If
        Me.CurrentPage = 3
        Call Me.LoadData()
       
    End Sub
    Protected Sub lnk2Page4_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles lnkPage4.Click, lnk2Page4.Click

        If Me.OnEditable = True Then
            Call Me.SaveData()
        End If
        Me.CurrentPage = 4
        Call Me.LoadData()
       
    End Sub
    Protected Sub lnk2Page5_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles lnkPage5.Click, lnk2Page5.Click

        If Me.OnEditable = True Then
            Call Me.SaveData()
        End If
        Me.CurrentPage = 5
        Call Me.LoadData()
        
    End Sub
    '//
    Protected Sub ddlType_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlType.SelectedIndexChanged
        Call Me.LoadDataCategoryList()
    End Sub

    Protected Sub ddlCategory_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlCategory.SelectedIndexChanged
        Call Me.LoadDataSchemaList()
    End Sub

End Class
















@


1.1.1.1
log
@no message
@
text
@@
