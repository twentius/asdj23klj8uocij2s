head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.58;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.58;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports System.Windows.Forms

Partial Class Web_CSP_GDSLineDefUpdateManager
    Inherits BasePage

    Private BLL2 As BusinessLogicLayer.StaffBLL
    Private BLL3 As BusinessLogicLayer.tblFunctionBLL

    Public Property OnEditable() As Boolean
        Get
            Return Me.ViewState("_OnEditable")
        End Get
        Set(ByVal value As Boolean)
            Me.ViewState("_OnEditable") = value
        End Set
    End Property

    Private BLL As BusinessLogicLayer.LineDefBLL

    Public Property RecordID() As String
        Get
            Dim retVal As String = ""
            If Me.ViewState("_RecordID") IsNot Nothing Then
                retVal = Me.ViewState("_RecordID").ToString()
            End If
            Return retVal
        End Get
        Set(ByVal value As String)
            Me.ViewState("_RecordID") = value
        End Set
    End Property

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.BLL = New BusinessLogicLayer.LineDefBLL()
        Me.BLL2 = New BusinessLogicLayer.StaffBLL()
        Me.BLL3 = New BusinessLogicLayer.tblFunctionBLL()
        If Not IsPostBack Then
            If Me.Request("mode") Is Nothing Then
                Response.Redirect(Util.GetAppConfig("RootPath") + "/AirFuelManager.aspx", True)
            End If
            Call Me.LoadDropDownList()
            'Call Me.ToggleTabStyle()


            Select Case Me.Request("mode").ToString()
                Case "add"
                    Me.CurrentPageMode = CWTMasterDB.TransactionMode.AddNewMode
                    '//
                    Me.ddlGDS.Enabled = True
                    Me.txtName.Readonly = False
                    Me.tabPages.Tabs(1).Enabled = False
                    Me.lblVersion.Text = "Creating"
                    Me.btnEditVersion.Enabled = False
                Case "edit"
                    Me.CurrentPageMode = CWTMasterDB.TransactionMode.UpdateMode
                    Me.OnEditable = False
                    Me.RecordID = Me.Request("id").ToString()
                    Call Me.LoadData()
                    '//
                    Me.ddlGDS.Enabled = False
                    Me.txtName.Readonly = True
                    Me.tabPages.Tabs(1).Enabled = True
            End Select
            Call Me.AccessControl("GDS LineDef")
        End If
    End Sub

    Private Sub AccessControl(ByVal title As String)

        Dim userName As String
        Dim oDatatable As DataTable
        Dim oDataTable2 As DataTable

        Static roleID As String

        userName = ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName
        oDatatable = Me.BLL2.GetUserByID(userName)

        If oDatatable.Rows.Count > 0 Then
            roleID = oDatatable.Rows(0).Item("RoleID").ToString
        End If

        oDataTable2 = Me.BLL3.GetUserRole(roleID)
        If oDataTable2.Rows.Count > 0 Then
            For k As Integer = 0 To oDataTable2.Rows.Count - 1
                If oDataTable2.Rows(k).Item("functionGroup") = "0" Then
                    If oDataTable2.Rows(k).Item("Permission") = "V" Then
                        If oDataTable2.Rows(k).Item("functionName").ToString = title Then
                            Call Me.toggleControl2()

                        End If
                    End If
                End If

            Next

        End If


    End Sub

    Private Sub toggleControl2()

        Me.btnEditVersion.Enabled = False

    End Sub

    Private Sub LoadDropDownList()
        Dim oDataTable As DataTable
        oDataTable = Me.BLL.GetGDSList()
        With Me.ddlGDS
            .DataTextField = "GDSName"
            .DataValueField = "GDSNumber"
            .DataSource = oDataTable
            .DataBind()
        End With
    End Sub

    Private Sub ToggleControl()
        '//
        Me.txtAdminEmail.Enabled = Me.OnEditable
        Me.chkActive.Enabled = Me.OnEditable
        Me.btnTrans.Enabled = Me.OnEditable
        Me.btnNext.Enabled = Me.OnEditable
        If Me.OnEditable Then
            Me.btnCancel.Attributes.Add("onclick", "return confirm('Are you sure that you do not want to save data?');")
            If Me.chkSave.Equals(False) Then

                Me.btnNext.Attributes.Add("onclick", "return confirm('Do you want to save data?');")
                'Me.btnLineDef.Attributes.Add("onclick", "return confirm('Do you want to save data?');")

                'Me.btnDetail.Attributes.Add("onclick", "return confirm('Do you want to save data?');")

                'Me.divdetail.Attributes.Add("onclick", "return confirm('Do you want to save data?');")
                'Me.divMaster.Attributes.Add("onclick", "return confirm('Do you want to save data?');")
            End If

        End If
        '//
        Me.UcGDSLineDefDetail1.OnEditable = Me.OnEditable
        Me.UcGDSLineDefDetail1.ToggleControls()
    End Sub
  
    Private Sub LoadData()
        On Error Resume Next
        Dim oDataTable As DataTable
        Dim r As DataRow
        oDataTable = Me.BLL.GetLineDefByID(Me.RecordID)
        If oDataTable IsNot Nothing AndAlso oDataTable.Rows.Count > 0 Then
            r = oDataTable.Rows(0)
            Me.txtName.Text = r("LineDefName").ToString
            Me.ddlGDS.SelectedValue = r("GDSNumber").ToString
            Me.txtAdminEmail.Text = r("AlertEmail").ToString
            Me.chkActive.Checked = Util.DBNullToFalse(r("Active"))
            Me.hidVersionID.Value = r("LineDefVersionID").ToString
            Me.lblVersion.Text = r("VersionNumber").ToString
        End If
        '//
        Me.UcGDSLineDefDetail1.RecordID = Me.RecordID
        Me.UcGDSLineDefDetail1.VersionID = Me.hidVersionID.Value
        Me.UcGDSLineDefDetail1.LoadDropDownList()
        Me.UcGDSLineDefDetail1.LoadData()
        Call Me.ToggleControl()
    End Sub

    Public chkSave As Boolean = False
    Public shoMsg As Boolean = True

    Private Sub SaveData(ByVal shoMsg As Boolean)
        Dim info As New DataInfo.LineDefInfo()
        With info
            .PageMode = Me.CurrentPageMode
            .MasterID = Me.RecordID
            .VersionID = Me.hidVersionID.Value
            .VersionNumber = Me.lblVersion.Text
            .UserID = ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName
            .AlertEmail = Me.txtAdminEmail.Text
            .LineDefName = Me.txtName.Text
            .GDS = Me.ddlGDS.SelectedValue
            .Active = Me.chkActive.Checked
        End With
        If Me.BLL.UpdateLineDefMaster(info) > 0 Then
            If shoMsg = True Then
                Me.lblMsgBox.Text = Util.GetAppConfig(Util.MsgType.TRANS_SUCCESS.ToString)
                Me.lblMsgBox.ForeColor = Drawing.Color.Green
                Me.ajaxMsgBox.Show()
                If Me.CurrentPageMode = CWTMasterDB.TransactionMode.AddNewMode Then
                    Response.Redirect("GDSLineDefManager.aspx")
                End If
            End If
            
        Else
            Me.lblMsgBox.Text = Util.GetAppConfig(Util.MsgType.TRANS_ERROR.ToString)
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.ajaxMsgBox.Show()
        End If
    End Sub

    Protected Sub btnTrans_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnTrans.Click

        Call Me.SaveData(shoMsg)
        chkSave = True
    End Sub

    Protected Sub btnCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        Response.Redirect("GDSLineDefManager.aspx")
    End Sub

    Protected Sub btnEditVersion_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnEditVersion.Click
        Me.OnEditable = (Not Me.OnEditable)
        If Me.BLL.CreateNewVersion(Me.RecordID, Me.hidVersionID.Value, Me.lblVersion.Text, ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName) > 0 Then
            Call Me.LoadData()
            Call Me.ToggleControl()
            Me.btnEditVersion.Enabled = False
        Else
            Me.lblMsgBox.Text = "Cannot edit this record."
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.ajaxMsgBox.Show()
        End If
    End Sub

    Protected Sub btnNext_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnNext.Click

        Me.SaveData(shoMsg)
        Response.Redirect("GDSLineDefManager.aspx")
    End Sub

    Protected Sub btnLineDef_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnLineDef.Click
        If Me.OnEditable Then
            shoMsg = False
            Me.SaveData(shoMsg)
        End If
    End Sub

    Protected Sub btnDetail_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnDetail.Click

        If Me.OnEditable Then
            shoMsg = False
            Me.SaveData(shoMsg)
        End If
    End Sub
    'Protected Sub divDetail_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles 
    '    If Me.tabPages.Tabs.Item(1).ID = "TabPanel2" Then
    '        Me.Response.Write("alert('zzzzzzzzzzzzzzz');")
    '    ElseIf Me.tabPages.Tabs.Item(0).ID = "TabPanel1" Then
    '        Me.Response.Write("alert('kkkkkkkkkkkkkkkkkkkkkk');")
    '    End If

    'End Sub
End Class








@


1.1.1.1
log
@no message
@
text
@@
