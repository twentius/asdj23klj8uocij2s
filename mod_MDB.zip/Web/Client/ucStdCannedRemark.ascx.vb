head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.58;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.58;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@
Partial Class Web_Client_ucStdCannedRemark
    Inherits BaseUserControl

#Region "Page Properties & Variables"
    Private BLL As BusinessLogicLayer.CannedRemarkBLL
#End Region

#Region "Page Event Handlers & Methods"
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.BLL = New BusinessLogicLayer.CannedRemarkBLL()
        If Not IsPostBack Then
            Call Me.LoadDataFromDB()
        End If
    End Sub
#End Region

#Region "Remark Sub Routines"
    Private Sub LoadRemarkDataFromDB()
        Dim oDataTable As DataTable
        oDataTable = Me.BLL.GetCannedRemark()
        With Me.gdData
            .DataSource = oDataTable
            .DataBind()
        End With
    End Sub
#End Region

#Region "Data Binding"
    Private Sub LoadDataFromDB()
        Call Me.LoadRemarkDataFromDB()
    End Sub
#End Region

End Class
@


1.1.1.1
log
@no message
@
text
@@
