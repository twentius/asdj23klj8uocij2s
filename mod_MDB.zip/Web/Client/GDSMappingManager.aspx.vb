head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.57;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.57;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic
Imports System.Collections.Generic

Partial Class Web_Client_GDSMappingManager
    Inherits BasePage

    Private BLL As BusinessLogicLayer.LineDefBLL
    Private BLL2 As BusinessLogicLayer.StaffBLL
    Private BLL3 As BusinessLogicLayer.tblFunctionBLL


    Private ReadOnly Property KeyID() As String
        Get
            If Session("CONN_KeyID") Is Nothing Then
                Response.Redirect(Util.GetAppConfig("RootPath") + "/Login.aspx", True)
            End If
            Return Session("CONN_KeyID")
        End Get
    End Property

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.BLL = New BusinessLogicLayer.LineDefBLL()
        Me.BLL2 = New BusinessLogicLayer.StaffBLL()
        Me.BLL3 = New BusinessLogicLayer.tblFunctionBLL()
        If Not IsPostBack Then
            Call Me.LoadDropDownList()
            Call Me.LoadDataFromDB()
        End If
        Call Me.AccessControl("GDS Mapping")
    End Sub

    Private Sub AccessControl(ByVal title As String)

        Dim userName As String
        Dim oDatatable As DataTable
        Dim oDataTable2 As DataTable

        Static roleID As String

        userName = ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName
        oDatatable = Me.BLL2.GetUserByID(userName)

        If oDatatable.Rows.Count > 0 Then
            roleID = oDatatable.Rows(0).Item("RoleID").ToString
        End If

        oDataTable2 = Me.BLL3.GetUserRole(roleID)
        If oDataTable2.Rows.Count > 0 Then
            For k As Integer = 0 To oDataTable2.Rows.Count - 1
                If oDataTable2.Rows(k).Item("functionGroup") = "1" Then
                    If oDataTable2.Rows(k).Item("Permission") = "V" Then
                        If oDataTable2.Rows(k).Item("ParentID").ToString = "GN" Then
                            If oDataTable2.Rows(k).Item("functionName").ToString = title Then

                                Call Me.toggleControl()
                            End If
                        End If

                    End If
                End If

            Next

        End If


    End Sub

    Private Sub toggleControl()



        Me.txtDummybar.Readonly = True
        Me.txtProfileName1.Readonly = True
        Me.txtProfileName2.Readonly = True
        Me.txtProfileName3.Readonly = True
        Me.txtProfileName4.Readonly = True
        Me.txtProfileName5.Readonly = True
        Me.txtProfilePCC1.Readonly = True
        Me.txtProfilePCC2.Readonly = True
        Me.txtProfilePCC3.Readonly = True
        Me.txtProfilePCC4.Readonly = True
        Me.txtProfilePCC5.Readonly = True

        Me.ddlLineDef1.Enabled = False
        Me.ddlLineDef2.Enabled = False
        Me.ddlLineDef3.Enabled = False
        Me.ddlLineDef4.Enabled = False
        Me.ddlLineDef5.Enabled = False

        Me.btnTrans.ShowSaveNextButton = False
        Me.btnTrans.SaveButton.Enabled = False
    End Sub

    Private Sub LoadDropDownList()
        Dim oDataTable As DataTable
        oDataTable = Me.BLL.GetLineDefMasterList()
        With Me.ddlLineDef1
            .DataTextField = "LineDefName"
            .DataValueField = "LineDefMasterID"
            .DataSource = oDataTable
            .DataBind()
        End With
        With Me.ddlLineDef2
            .DataTextField = "LineDefName"
            .DataValueField = "LineDefMasterID"
            .DataSource = oDataTable
            .DataBind()
        End With
        With Me.ddlLineDef3
            .DataTextField = "LineDefName"
            .DataValueField = "LineDefMasterID"
            .DataSource = oDataTable
            .DataBind()
        End With
        With Me.ddlLineDef4
            .DataTextField = "LineDefName"
            .DataValueField = "LineDefMasterID"
            .DataSource = oDataTable
            .DataBind()
        End With
        With Me.ddlLineDef5
            .DataTextField = "LineDefName"
            .DataValueField = "LineDefMasterID"
            .DataSource = oDataTable
            .DataBind()
        End With
    End Sub

    Private Sub LoadDataFromDB()
        Dim r As DataRow
        Dim oDataTable As DataTable
        Dim ProfilePCCCtrl As New List(Of CWTCustomControls.CWTTextBox)
        Dim ProfileNameCtrl As New List(Of CWTCustomControls.CWTTextBox)
        Dim LineDefCtrl As New List(Of CWTCustomControls.CWTDropDownList)
        Dim rdPreferred As New List(Of CWTCustomControls.CWTRadioButton)

        rdPreferred.Add(Me.rdOperator1)
        rdPreferred.Add(Me.rdOperator2)
        rdPreferred.Add(Me.rdOperator3)
        rdPreferred.Add(Me.rdOperator4)
        rdPreferred.Add(Me.rdOperator5)
        '//
        ProfilePCCCtrl.Add(Me.txtProfilePCC1)
        ProfilePCCCtrl.Add(Me.txtProfilePCC2)
        ProfilePCCCtrl.Add(Me.txtProfilePCC3)
        ProfilePCCCtrl.Add(Me.txtProfilePCC4)
        ProfilePCCCtrl.Add(Me.txtProfilePCC5)
        '//
        ProfileNameCtrl.Add(Me.txtProfileName1)
        ProfileNameCtrl.Add(Me.txtProfileName2)
        ProfileNameCtrl.Add(Me.txtProfileName3)
        ProfileNameCtrl.Add(Me.txtProfileName4)
        ProfileNameCtrl.Add(Me.txtProfileName5)
        '//
        LineDefCtrl.Add(Me.ddlLineDef1)
        LineDefCtrl.Add(Me.ddlLineDef2)
        LineDefCtrl.Add(Me.ddlLineDef3)
        LineDefCtrl.Add(Me.ddlLineDef4)
        LineDefCtrl.Add(Me.ddlLineDef5)
        Try
            oDataTable = Me.BLL.GetGDSMappingByClientID(Me.KeyID, Me.CurrentClientID)
            If oDataTable IsNot Nothing AndAlso oDataTable.Rows.Count > 0 Then
                For i As Integer = 0 To oDataTable.Rows.Count - 1
                    If i >= 5 Then
                        Exit For
                    End If
                    r = oDataTable.Rows(i)
                    ProfilePCCCtrl(i).Text = r("ProfilePCC").ToString
                    ProfileNameCtrl(i).Text = r("ProfileName").ToString
                    LineDefCtrl(i).SelectedValue = r("LineDefMasterID").ToString
                    rdPreferred(i).Checked = r("Preferred").ToString
                    Me.txtDummybar.Text = oDataTable.Rows(0).Item("DummyBar").ToString
                Next
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Function ValidateForm() As Boolean
        If Me.txtProfilePCC1.Text.Trim = "" AndAlso Me.txtProfilePCC2.Text.Trim = "" _
             AndAlso Me.txtProfilePCC3.Text.Trim = "" _
             AndAlso Me.txtProfilePCC4.Text.Trim = "" _
             AndAlso Me.txtProfilePCC5.Text.Trim = "" _
        Then
            Return False
        Else
            Return True
        End If
    End Function

    'Protected Function checkDuplicate(ByVal info As DataInfo.GDSMappingClientInfo)
    '    Dim retVal As Boolean = False
    '    Dim oDataTable As DataTable
    '    For i As Integer = 0 To info.Profiles.Count - 1
    '        oDataTable = Me.BLL.CheckDuplicate(info.Profiles(i).ProfilePCC, info.Profiles(i).ProfileName, info.ConfigInstanceKeyID)
    '        If oDataTable IsNot Nothing AndAlso oDataTable.Rows.Count > 0 Then

    '            Me.lblMsgBox.Text = "profile name:" + info.Profiles(i).ProfileName + "or profile pcc:" + info.Profiles(i).ProfilePCC + "is duplicated!"
    '            Me.lblMsgBox.ForeColor = Drawing.Color.Red
    '            Me.ajaxMsgBox.Show()
    '            retVal = False
    '            Exit For


    'Me.lblMsgBox.Text = "profile name or profile pcc is duplicated!"
    'Me.lblMsgBox.ForeColor = Drawing.Color.Red
    'Me.ajaxMsgBox.Show()
    '        Else
    '            retVal = True
    '        End If

    '    Next

    '    Return retVal
    'End Function

    Private Sub SaveData()
        Dim info As New DataInfo.GDSMappingClientInfo()
        Dim profile As DataInfo.ProfilePCCInfo
        Dim chkDuplicate As Boolean = True
        If Not Me.ValidateForm() Then
            Me.lblMsgBox.Text = "At least one row are needed."
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.ajaxMsgBox.Show()
        End If
        With info
            .ConfigInstanceKeyID = Me.KeyID
            .ClientID = Me.CurrentClientID
            .DummyBar = Me.txtDummybar.Text
            profile = New DataInfo.ProfilePCCInfo()
            profile.ProfilePCC = Me.txtProfilePCC1.Text.Trim
            profile.ProfileName = Me.txtProfileName1.Text
            profile.LineDefID = Me.ddlLineDef1.SelectedValue
            profile.Preferred = Me.rdOperator1.Checked
            .Profiles.Add(profile)
            profile = New DataInfo.ProfilePCCInfo()
            profile.ProfilePCC = Me.txtProfilePCC2.Text.Trim
            profile.ProfileName = Me.txtProfileName2.Text
            profile.LineDefID = Me.ddlLineDef2.SelectedValue
            profile.Preferred = Me.rdOperator2.Checked
            .Profiles.Add(profile)
            profile = New DataInfo.ProfilePCCInfo()
            profile.ProfilePCC = Me.txtProfilePCC3.Text.Trim
            profile.ProfileName = Me.txtProfileName3.Text
            profile.LineDefID = Me.ddlLineDef3.SelectedValue
            profile.Preferred = Me.rdOperator3.Checked
            .Profiles.Add(profile)
            profile = New DataInfo.ProfilePCCInfo()
            profile.ProfilePCC = Me.txtProfilePCC4.Text.Trim
            profile.ProfileName = Me.txtProfileName4.Text
            profile.LineDefID = Me.ddlLineDef4.SelectedValue
            profile.Preferred = Me.rdOperator4.Checked
            .Profiles.Add(profile)
            profile = New DataInfo.ProfilePCCInfo()
            profile.ProfilePCC = Me.txtProfilePCC5.Text.Trim
            profile.ProfileName = Me.txtProfileName5.Text
            profile.LineDefID = Me.ddlLineDef5.SelectedValue
            profile.Preferred = Me.rdOperator5.Checked
            .Profiles.Add(profile)
        End With

    
        If Me.BLL.UpdateGDSMapping(info) > 0 Then
            Me.lblMsgBox.Text = Util.GetAppConfig(Util.MsgType.TRANS_SUCCESS.ToString)
            Me.lblMsgBox.ForeColor = Drawing.Color.Green
            Me.ajaxMsgBox.Show()

        ElseIf Me.BLL.UpdateGDSMapping(info) = -50 Then
            Me.lblMsgBox.Text = "profile name or profile pcc is duplicated!"
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.ajaxMsgBox.Show()

        Else

            Me.lblMsgBox.Text = Util.GetAppConfig(Util.MsgType.TRANS_ERROR.ToString)
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.ajaxMsgBox.Show()
        End If

        
    End Sub

    Protected Sub btnTrans_OnCancel(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans.OnCancel
        Response.Redirect("CompanySearch.aspx")
    End Sub

    Protected Sub btnTrans_OnSave(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans.OnSave
        Call Me.SaveData()
    End Sub

End Class















@


1.1.1.1
log
@no message
@
text
@@
