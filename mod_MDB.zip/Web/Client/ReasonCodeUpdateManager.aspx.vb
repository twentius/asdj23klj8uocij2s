head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.58;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.58;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@
Partial Class Web_Client_ReasonCodeUpdateManager
    Inherits BasePage

    Private BLL As BusinessLogicLayer.ReasonCodeBLL
    Private BLL2 As BusinessLogicLayer.StaffBLL
    Private BLL3 As BusinessLogicLayer.tblFunctionBLL
    Private ReasonCodeDT = New DataTable()

    Public Property ProductID() As String
        Get
            Return Me.ViewState("_ProductID")
        End Get
        Set(ByVal value As String)
            Me.ViewState("_ProductID") = value
        End Set
    End Property

    Public Property ReasonType() As String
        Get
            Return Me.ViewState("_ProductType")
        End Get
        Set(ByVal value As String)
            Me.ViewState("_ProductType") = value
        End Set
    End Property

    Public Property IsApplyStd() As Boolean
        Get
            Return Me.ViewState("_IsApplyStd")
        End Get
        Set(ByVal value As Boolean)
            Me.ViewState("_IsApplyStd") = value
        End Set
    End Property

    Public Property ReasonTable() As DataTable
        Get
            Dim retVal As DataTable = Nothing
            If Me.ViewState.Item("_ReasonTable") IsNot Nothing Then
                retVal = Me.ViewState.Item("_ReasonTable")
            End If
            Return retVal
        End Get
        Set(ByVal value As DataTable)
            Me.ViewState.Item("_ReasonTable") = value
        End Set
    End Property

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.BLL = New BusinessLogicLayer.ReasonCodeBLL()
        Me.BLL2 = New BusinessLogicLayer.StaffBLL()
        Me.BLL3 = New BusinessLogicLayer.tblFunctionBLL()

        If Not IsPostBack Then
            If Me.Request("prodid") Is Nothing OrElse Me.Request("typeid") Is Nothing Then
                Response.Redirect("ReasonCodeManager.aspx", True)
            End If
            Me.ProductID = Me.Request("prodid")
            Me.ReasonType = Me.Request("typeid")
            Me.lblProduct.Text = Me.ProductID
            Me.lblType.Text = Me.GetReasonTypeName(Me.ReasonType)
            Me.ReasonTable = New DataTable()
            Call Me.LoadDropDownList()
            Call Me.LoadData()
            Call Me.RefreshGrid()
            Call Me.SetMode()
        End If
        Call Me.AccessControl("ReasonCode")
    End Sub

    Private Sub AccessControl(ByVal title As String)

        Dim userName As String
        Dim oDatatable As DataTable
        Dim oDataTable2 As DataTable

        Static roleID As String

        userName = ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName
        oDatatable = Me.BLL2.GetUserByID(userName)

        If oDatatable.Rows.Count > 0 Then
            roleID = oDatatable.Rows(0).Item("RoleID").ToString
        End If

        oDataTable2 = Me.BLL3.GetUserRole(roleID)
        If oDataTable2.Rows.Count > 0 Then
            For k As Integer = 0 To oDataTable2.Rows.Count - 1
                If oDataTable2.Rows(k).Item("functionGroup") = "1" Then
                    If oDataTable2.Rows(k).Item("Permission") = "V" Then
                        If oDataTable2.Rows(k).Item("functionName").ToString = title Then

                            Call Me.toggleControl()

                        End If
                    End If
                End If

            Next

        End If


    End Sub

    Private Sub toggleControl()
        Dim btnDelete As CWTCustomControls.CWTLinkButton

        Me.chkApplyStd.Enabled = False
        Me.btnSave.Enabled = False
        Me.ddlCode.Enabled = False
        Me.txtDesc.Readonly = True
       
        For i As Integer = 0 To Me.gdData.Rows.Count - 1
            btnDelete = Me.gdData.Rows(i).FindControl("hrefDeleteItem")
            btnDelete.Enabled = False

        Next


        Me.btnTrans.ShowSaveNextButton = False
        Me.btnTrans.SaveButton.Enabled = False
    End Sub

    Private Function GetReasonTypeName(ByVal ReasonType As String) As String
        Dim retVal As String = ""
        Select Case ReasonType.ToLower()
            Case "r"
                retVal = "Realized saving"
            Case Else
                retVal = "Missed saving"
        End Select
        Return retVal
    End Function

    Private Sub SetMode()
        If Me.IsApplyStd Then
            Me.btnSave.Visible = False
            Me.btnCancel.Visible = False
        Else
            Me.btnSave.Visible = True
            Me.btnCancel.Visible = True
        End If
    End Sub

    Private Sub LoadReasonCode()
        Dim oDataTable As DataTable
        oDataTable = Me.BLL.GetReasonCodeByID(Me.ProductID, Me.ReasonType)
        With Me.ddlCode
            .DataTextField = "ReasonCode"
            .DataValueField = "CRCodeID"
            .DataSource = oDataTable
            .DataBind()
        End With
        Call Me.LoadReasonDesc()
    End Sub

    Private Sub LoadDropDownList()
        Call Me.LoadReasonCode()
    End Sub

    Private Sub LoadData()
        Me.IsApplyStd = Me.BLL.IsApplyStd(Me.CurrentClientID, Me.ProductID, Me.ReasonType)
        Me.chkApplyStd.Checked = Me.IsApplyStd
        If Not Me.IsApplyStd Then
            Call Me.LoadDataFromDB()
            Me.gdData.Visible = True
            Me.gdDataStd.Visible = False
            Me.divControl.Visible = True
        Else
            Call Me.LoadStdData()
            Me.gdData.Visible = False
            Me.gdDataStd.Visible = True
            Me.divControl.Visible = False
        End If
    End Sub

    Private Sub LoadDataFromDB()
        Me.ReasonTable = Me.BLL.GetClientReasonCode(Me.CurrentClientID, Me.ProductID, Me.ReasonType)
    End Sub

    Private Sub LoadStdData()
        Dim oDataTable As DataTable
        oDataTable = Me.BLL.GetReasonCodeByID(Me.ProductID, Me.ReasonType)
        With Me.gdDataStd
            .DataSource = oDataTable
            .DataBind()
        End With
    End Sub

    Private Sub LoadReasonDesc()
        Me.txtDesc.Text = BLL.GetReasonDescByCode(Me.ddlCode.SelectedValue)
    End Sub

    Private Sub RefreshGrid()
        If Me.IsApplyStd Then
            Exit Sub
        End If
        With Me.gdData
            .DataSource = Me.ReasonTable
            .DataBind()
        End With
    End Sub

    Private Sub AddData()
        Dim r As DataRow
        Dim oRow As DataRow()
        Dim filter As String
        Dim CRCode As String
        CRCode = Me.ddlCode.SelectedValue
        filter = "CRCodeID=" + CRCode
        oRow = Me.ReasonTable.Select(filter)
        If oRow Is Nothing OrElse oRow.Length = 0 Then
            r = Me.ReasonTable.NewRow()
            r("ClientID") = Me.CurrentClientID
            r("CRCodeID") = CRCode
            r("ReasonCode") = Me.ddlCode.SelectedItem.Text
            r("Description") = Me.txtDesc.Text
            Me.ReasonTable.Rows.Add(r)
        Else
            Me.lblMsgBox.Text = "Cannot add duplicated code."
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.ajaxMsgBox.Show()
        End If
    End Sub

    Private Sub RemoveData(ByVal CRCode As String)
        Dim oRow As DataRow()
        Dim filter As String
        filter = "CRCodeID=" + CRCode
        oRow = Me.ReasonTable.Select(filter)
        If oRow IsNot Nothing AndAlso oRow.Length > 0 Then
            Call Me.BLL.DeleteReasonCode(oRow(0).Item("ClientID"), oRow(0).Item("ProductType"), oRow(0).Item("Type"), oRow(0).Item("CRCodeID"))
            Me.ReasonTable.Rows.Remove(oRow(0))
        End If
    End Sub

    Private Sub LoadNewData()
        If Me.ddlCode.SelectedIndex <= 0 OrElse Me.ddlCode.SelectedIndex = (Me.ddlCode.Items.Count - 1) Then
            Me.ddlCode.SelectedIndex = 1
        Else
            Me.ddlCode.SelectedIndex += 1
        End If
        Call Me.LoadReasonDesc()
    End Sub

    Private Sub SaveData()
        Dim info As New DataInfo.CompanyReasonInfo()
        Dim reason As DataInfo.ReasonInfo
        Dim r As DataRow
        With info
            .ClientID = Me.CurrentClientID
            .ProductType = Me.ProductID
            .ReasonType = Me.ReasonType
            .ApplyStd = Me.chkApplyStd.Checked
            '// Policy
            For i As Integer = 0 To Me.ReasonTable.Rows.Count - 1
                r = Me.ReasonTable.Rows(i)
                reason = New DataInfo.ReasonInfo()
                reason.CRCodeID = r("CRCodeID").ToString
                reason.Description = r("Description").ToString
                .ReasonList.Add(reason)
            Next
            If Not .ApplyStd AndAlso .ReasonList.Count <= 0 Then
                Me.lblMsgBox.Text = "At least 1 reason code is needed"
                Me.lblMsgBox.ForeColor = Drawing.Color.Red
                Me.ajaxMsgBox.Show()
                Exit Sub
            End If
        End With
        If Me.BLL.UpdateReasonCode(info) > 0 Then
            Me.lblMsgBox.Text = Util.GetAppConfig(Util.MsgType.TRANS_SUCCESS.ToString)
            Me.lblMsgBox.ForeColor = Drawing.Color.Green
            Me.ajaxMsgBox.Show()
            Response.Redirect("ReasonCodeManager.aspx")
        Else
            Me.lblMsgBox.Text = Util.GetAppConfig(Util.MsgType.TRANS_ERROR.ToString)
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.ajaxMsgBox.Show()
        End If
    End Sub


    Public Sub gdData_Command(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.CommandEventArgs)
        Select Case e.CommandName
            Case "DeleteItem"
                Call Me.RemoveData(e.CommandArgument)
                Call Me.RefreshGrid()

        End Select
    End Sub

    Protected Sub ddlCode_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlCode.SelectedIndexChanged
        Call Me.LoadReasonDesc()
    End Sub

    Protected Sub btnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSave.Click
        Call Me.AddData()
        Call Me.RefreshGrid()
        Call Me.LoadNewData()
    End Sub

    Protected Sub btnCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        Call Me.LoadReasonDesc()
    End Sub

    Protected Sub chkApplyStd_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkApplyStd.CheckedChanged
        'Me.ReasonTable = New DataTable()
        Me.ReasonTable.Rows.Clear()
        If Me.chkApplyStd.Checked Then
            Me.IsApplyStd = True
            Me.gdData.Visible = False
            Me.gdDataStd.Visible = True
            Me.divControl.Visible = False
            Call Me.LoadStdData()
        Else
            Me.IsApplyStd = False
            Call Me.LoadDataFromDB()
            Me.gdData.Visible = True
            Me.gdDataStd.Visible = False
            Me.divControl.Visible = True
        End If
        Call Me.LoadDropDownList()
        Call Me.RefreshGrid()
        Call Me.SetMode()
    End Sub

    Protected Sub btnTrans_OnCancel(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans.OnCancel
        Response.Redirect("ReasonCodeManager.aspx")
    End Sub

    Protected Sub btnTrans_OnSave(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans.OnSave
        Call Me.SaveData()
    End Sub

    Protected Sub gdData_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gdData.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim hrefDeleteItem As CWTCustomControls.CWTLinkButton
            hrefDeleteItem = e.Row.FindControl("hrefDeleteItem")
            hrefDeleteItem.Visible = Not Me.IsApplyStd
        End If
    End Sub

End Class






@


1.1.1.1
log
@no message
@
text
@@
