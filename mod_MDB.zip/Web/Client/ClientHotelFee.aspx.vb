head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.56;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.56;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Public Partial Class ClientHotelFee
    Inherits BasePage

    Private BLL As BusinessLogicLayer.HotelFeeBLL
    Private BLL2 As BusinessLogicLayer.StaffBLL
    Private BLL3 As BusinessLogicLayer.tblFunctionBLL

    Private Property IsError() As Boolean
        Get
            Dim retVal As Boolean
            If Me.ViewState("_IsError") IsNot Nothing Then
                retVal = CBool(Me.ViewState("_IsError"))
            End If
            Return retVal
        End Get
        Set(ByVal value As Boolean)
            Me.ViewState("_IsError") = value
        End Set
    End Property

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.BLL = New BusinessLogicLayer.HotelFeeBLL()
        Me.BLL2 = New BusinessLogicLayer.StaffBLL()
        Me.BLL3 = New BusinessLogicLayer.tblFunctionBLL()
        If Not IsPostBack Then
            Me.setFeeName()
            GetClientFeeName()
        End If
        Me.AccessControl("Client Hotel")

    End Sub

    Private Sub AccessControl(ByVal title As String)

        Dim userName As String
        Dim oDatatable As DataTable
        Dim oDataTable2 As DataTable

        Static roleID As String

        userName = ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName
        oDatatable = Me.BLL2.GetUserByID(userName)

        If oDatatable.Rows.Count > 0 Then
            roleID = oDatatable.Rows(0).Item("RoleID").ToString
        End If

        oDataTable2 = Me.BLL3.GetUserRole(roleID)
        If oDataTable2.Rows.Count > 0 Then
            For k As Integer = 0 To oDataTable2.Rows.Count - 1
                If oDataTable2.Rows(k).Item("functionGroup") = "1" Then
                    If oDataTable2.Rows(k).Item("Permission") = "V" Then
                        If oDataTable2.Rows(k).Item("functionName").ToString = title Then
                            Call Me.toggleControl()

                        End If
                    End If
                End If

            Next

        End If


    End Sub

    Private Sub toggleControl()
        Me.ddlFeeName.Enabled = False
        Me.BtnTrans.SaveButton.Enabled = False
    End Sub

    Public Sub setFeeName()
        Dim data As DataTable
        data = Me.BLL.GetFeeName()
        With Me.ddlFeeName
            .DataTextField = "Name"
            .DataValueField = "Name"
            .DataSource = data
            .DataBind()
        End With
    End Sub

    Private Sub GetClientFeeName()
        Dim data As DataTable
        data = Me.BLL.GetClientFeeName(Me.CurrentClientID.ToString())
        If data.Rows.Count > 0 Then
            ddlFeeName.SelectedValue = data.Rows(0).Item(0)
        End If
    End Sub

    Protected Sub BtnTrans_OnSave(ByVal sender As System.Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles BtnTrans.OnSave
        Dim CID As Integer
        CID = Convert.ToInt32(Me.CurrentClientID.ToString())
        If Me.BLL.SaveData(CID, Me.ddlFeeName.SelectedValue) > 0 Then
            Me.lblMsgBox.Text = Util.GetAppConfig(Util.MsgType.TRANS_SUCCESS.ToString)
            Me.lblMsgBox.ForeColor = Drawing.Color.Green
            Me.IsError = False
            Me.ajaxMsgBox.Show()
        Else
            Me.lblMsgBox.Text = Util.GetAppConfig(Util.MsgType.TRANS_ERROR.ToString)
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.IsError = True
            Me.ajaxMsgBox.Show()
        End If
    End Sub

    Protected Sub BtnTrans_OnCancel(ByVal sender As System.Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs)
        Me.Response.Redirect("CompanyUpdateManager.aspx")
    End Sub
End Class@


1.1.1.1
log
@no message
@
text
@@
