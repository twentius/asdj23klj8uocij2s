head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.55;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.55;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic
Imports System.Collections.Generic

Partial Public Class AirPricing
    Inherits BasePage

    Private BLL As BusinessLogicLayer.ComAirPricingBLL
    Private BLL2 As BusinessLogicLayer.StaffBLL
    Private BLL3 As BusinessLogicLayer.tblFunctionBLL

    ' to do 
    ' must have viewstate to contain each tab tables after postback 

    Private Property CurrentActiveTabID() As String
        Get
            Return Me.ViewState("ID")
        End Get
        Set(ByVal value As String)
            Me.ViewState("ID") = value
        End Set
    End Property

    Private Property DictAirPricing() As IDictionary(Of String, DataInfo.ComAirPricingSettingsInfo)
        Get
            Return Me.ViewState("_DictAirPricing")
        End Get
        Set(ByVal value As IDictionary(Of String, DataInfo.ComAirPricingSettingsInfo))
            Me.ViewState("_DictAirPricing") = value
        End Set
    End Property

    Private ReadOnly Property FeeFieldID() As String
        Get
            Return Me.BLL.GetFieldIDByProgramName("Fee")
        End Get
    End Property

    Private ReadOnly Property AddOnFieldID() As String
        Get
            Return Me.BLL.GetFieldIDByProgramName("ConditionalMarkUp")
        End Get
    End Property

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.BLL = New BusinessLogicLayer.ComAirPricingBLL()
        Me.BLL2 = New BusinessLogicLayer.StaffBLL()
        Me.BLL3 = New BusinessLogicLayer.tblFunctionBLL()
        Dim a As String
        If Not IsPostBack Then
            Me.DictAirPricing = New Dictionary(Of String, DataInfo.ComAirPricingSettingsInfo)
            Me.DictAirPricing.Add(Me.TabPanel1.ID, New DataInfo.ComAirPricingSettingsInfo())
            Me.DictAirPricing.Add(Me.TabPanel2.ID, New DataInfo.ComAirPricingSettingsInfo())
            Me.DictAirPricing.Add(Me.TabPanel3.ID, New DataInfo.ComAirPricingSettingsInfo())
            Call Me.LoadDataFromDB()
            Call Me.ReloadContents()
            Call Me.InitializeControls()
        Else
            Me.txtAirCalc.Text = Me.hidAirCalcName.Value
            Me.txtFeeText.Text = Me.hidFeeName.Value
            a = Me.hidFeeType.Value
            Me.txtAddOnText.Text = Me.hidAddOnName.Value
        End If
        Call Me.AccessControl("Air")
    End Sub



    Private Sub AccessControl(ByVal title As String)

        Dim userName As String
        Dim oDatatable As DataTable
        Dim oDataTable2 As DataTable

        Static roleID As String

        userName = ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName
        oDatatable = Me.BLL2.GetUserByID(userName)

        If oDatatable.Rows.Count > 0 Then
            roleID = oDatatable.Rows(0).Item("RoleID").ToString
        End If

        oDataTable2 = Me.BLL3.GetUserRole(roleID)
        If oDataTable2.Rows.Count > 0 Then
            For k As Integer = 0 To oDataTable2.Rows.Count - 1
                If oDataTable2.Rows(k).Item("functionGroup") = "1" Then
                    If oDataTable2.Rows(k).Item("Permission") = "V" Then
                        If oDataTable2.Rows(k).Item("ParentID").ToString = "PR" Then
                            If oDataTable2.Rows(k).Item("functionName").ToString = title Then

                                Call Me.toggleControl()
                            End If
                        End If

                    End If
                End If

            Next

        End If


    End Sub

    Private Sub toggleControl()
        Dim textBox As CWTCustomControls.CWTTextBox
        Dim chkBox As CWTCustomControls.CWTCheckBox
        Me.chkAddOnOverrid.Enabled = False
        Me.chkExemptTax.Enabled = False
        Me.chkHaveAddOn.Enabled = False
        Me.chkHaveFee.Enabled = False
        Me.chkOverrid.Enabled = False
        Me.txtAddOnText.Readonly = True
        Me.txtAirCalc.Readonly = True
        Me.txtFeeText.Readonly = True
        Me.btnBrowseAirCalc.Enabled = False
        Me.btnPopup.Enabled = False
        Me.Button1.Enabled = False

        For i As Integer = 0 To Me.rptData.Items.Count - 1
            textBox = Me.rptData.Items(i).FindControl("txtFieldValue")
            chkBox = Me.rptData.Items(i).FindControl("chkOverrid")
            textBox.Readonly = True
            chkBox.Enabled = False
        Next

        Me.btnTrans.ShowSaveNextButton = False
        Me.btnTrans.SaveButton.Enabled = False
    End Sub


    Private Sub InitializeControls()
        Dim sc As New StringBuilder()
        sc.AppendLine("txtCalcID='" + Me.hidAirCalc.ClientID + "';")
        sc.AppendLine("txtCalcName='" + Me.txtAirCalc.ClientID + "';")
        sc.AppendLine("hidAirCalcName='" + Me.hidAirCalcName.ClientID + "';")
        sc.AppendLine("btnGetInfo='" + Me.btnFakeGetInfo.ClientID + "';")
        '//
        sc.AppendLine("txtFeeID='" + Me.hidFeeID.ClientID + "';")
        sc.AppendLine("txtFeeName='" + Me.txtFeeText.ClientID + "';")
        sc.AppendLine("hidFeeName='" + Me.hidFeeName.ClientID + "';")
        sc.AppendLine("txtFeeType='" + Me.hidFeeType.ClientID + "';")
        '//
        sc.AppendLine("txtAddOnID='" + Me.hidConditional.ClientID + "';")
        sc.AppendLine("txtAddOnName='" + Me.txtAddOnText.ClientID + "';")
        sc.AppendLine("hidAddOnName='" + Me.hidAddOnName.ClientID + "';")
        '//
        Util.RegClientScript(sc.ToString, "RegistScript", Util.ClientScriptRegistType.RegStartUpBlock)
        '//
        Me.CurrentActiveTabID = Me.TabPanel1.ID
    End Sub

    Private Sub AddNewData()
        Me.txtFeeText.Text = ""
        Me.txtAddOnText.Text = ""
        Me.hidFeeID.Value = ""
        Me.hidFeeType.Value = ""
        Me.hidFeeName.Value = ""
        Me.hidConditional.Value = ""
        Me.hidAddOnName.Value = ""
        '//
        Me.chkOverrid.Checked = False
        Me.chkAddOnOverrid.Checked = False
        Me.chkHaveFee.Checked = False
        Me.chkHaveAddOn.Checked = False
        Me.trFee.Visible = False
        Me.trAddOn.Visible = False
    End Sub

    Private Sub ReloadContents()
        Dim price As DataInfo.ComAirPricingSettingsInfo
        price = Me.DictAirPricing(Me.tabPages.ActiveTab.ID)
        With Me.rptData
            .DataSource = price.ToVariablesTable()
            .DataBind()
        End With
        '//
        Me.txtFeeText.Text = price.Fee.FeeName
        Me.hidFeeID.Value = price.Fee.FieldValue
        Me.hidFeeType.Value = price.Fee.FeeType
        Me.hidFeeName.Value = price.Fee.FeeName
        Me.chkOverrid.Checked = price.Fee.Override
        '//
        Me.txtAddOnText.Text = price.AddOn.FeeName
        Me.hidConditional.Value = price.AddOn.FieldValue
        Me.hidAddOnName.Value = price.AddOn.FeeName
        Me.chkAddOnOverrid.Checked = price.AddOn.Override
        '//
        Me.chkHaveFee.Checked = price.HaveFee
        Me.chkHaveAddOn.Checked = price.HaveAddOn
        '//
        Me.trFee.Visible = Me.chkHaveFee.Checked
        Me.trAddOn.Visible = Me.chkHaveAddOn.Checked
    End Sub

    Private Function GetFeeManagerType(ByVal FeeType As String) As DataInfo.AirFeeInfo.AirFeeManagerType
        Select Case FeeType
            Case "0"
                Return DataInfo.AirFeeInfo.AirFeeManagerType.FeeByPNR
            Case "1"
                Return DataInfo.AirFeeInfo.AirFeeManagerType.FeeByTicket
            Case "2"
                Return DataInfo.AirFeeInfo.AirFeeManagerType.FeeByCoupon
            Case "A"
                Return DataInfo.AirFeeInfo.AirFeeManagerType.ConditionalMarkUp
            Case Else
                Return Nothing
        End Select
    End Function

    Private Sub LoadDataByTab(ByVal TripType As String)
        Dim FeeBLL As New BusinessLogicLayer.AirFeeBLL()
        Dim oDataTable As DataTable
        Dim r As DataRow
        Dim price As DataInfo.ComAirPricingSettingsInfo
        Dim info As DataInfo.PriceVariablesInfo
        Dim FeeVarID As String = Me.FeeFieldID
        Dim AddOnVarID As String = Me.AddOnFieldID
        Dim TabID As String = ""
        Dim chkFee As Boolean = False
        Dim fee As String
        Dim type As String = ""
        Dim type2 As String = ""
        Select Case TripType
            Case "I"
                TabID = Me.TabPanel1.ID
            Case "D"
                TabID = Me.TabPanel2.ID
            Case "L"
                TabID = Me.TabPanel3.ID
        End Select
        price = Me.DictAirPricing(TabID)
        oDataTable = Me.BLL.GetClientAirPriceVariables(TripType, Me.CurrentClientID)
        If oDataTable IsNot Nothing AndAlso oDataTable.Rows.Count > 0 Then
            For i As Integer = 0 To oDataTable.Rows.Count - 1
                r = oDataTable.Rows(i)
                info = New DataInfo.PriceVariablesInfo()
                With info
                    .FieldID = r("FieldID").ToString
                    .FieldValue = r("Value").ToString
                    .FieldName = r("FieldName").ToString
                    .Override = Util.DBNullToFalse(r("Override"))
                End With
                price.Variables.Add(info)
            Next
        End If
        '// Setting
        'oDataTable = Me.BLL.GetClientMasterPricing(Me.CurrentClientID)
        oDataTable = Me.BLL.GetSettingPricing(Me.hidAirCalc.Value)
        If oDataTable IsNot Nothing AndAlso oDataTable.Rows.Count > 0 Then
            r = oDataTable.Rows(0)
            Dim PreFix As String = ""
            Select Case TripType
                Case "I"
                    PreFix = "Int"
                Case "D"
                    PreFix = "Dom"
                Case "L"
                    PreFix = "LCC"
            End Select
            fee = Util.DBNullToText(r(PreFix + "DDLFeeApply"))
            If fee = "NA" Then
                chkFee = False
            Else
                chkFee = True
            End If
            price.HaveFee = chkFee
            price.HaveAddOn = Util.DBNullToFalse(r(PreFix + "ApplyMarkUp"))
            Me.trFee.Visible = price.HaveFee
            If fee <> "NA" Then
                If fee = "TF" Then
                    Me.lblFee.Text = "Transaction Fee:"
                ElseIf fee = "MF" Then
                    Me.lblFee.Text = "Management Fee:"
                End If
            End If
            Me.trAddOn.Visible = price.HaveAddOn
        Else
            price.HaveFee = False
            price.HaveAddOn = False
            Me.trFee.Visible = False
            Me.trAddOn.Visible = False
        End If
        Dim CMPID As String = ""
        CMPID = Me.BLL.GetCMPIDByClientID(Me.CurrentClientID)
        '// Fee
        If Me.trFee.Visible Then
            oDataTable = Me.BLL.GetClientFeeData(CMPID, TripType, FeeVarID)
            If oDataTable IsNot Nothing AndAlso oDataTable.Rows.Count > 0 Then
                r = oDataTable.Rows(0)
                With price.Fee
                    .FieldID = FeeVarID
                    type2 = r("ValueOption").ToString
                    If type2 = "P" Then
                        type = "0"
                    ElseIf type2 = "T" Then
                        type = "1"
                    ElseIf type2 = "C" Then
                        type = "2"
                    Else
                        type = "A"
                    End If

                    .FeeType = type

                    .FieldValue = r("Value").ToString
                    .FeeName = FeeBLL.GetFeeNameByID(.FieldValue, Me.GetFeeManagerType(.FeeType))
                    .Override = Util.DBNullToFalse(r("Override"))
                End With
            End If
        End If
        '// Add On
        If Me.trAddOn.Visible Then
            oDataTable = Me.BLL.GetClientFeeData(CMPID, TripType, AddOnVarID)
            If oDataTable IsNot Nothing AndAlso oDataTable.Rows.Count > 0 Then
                r = oDataTable.Rows(0)
                With price.AddOn
                    .FieldID = AddOnVarID
                    .FieldValue = r("Value").ToString
                    .FeeName = FeeBLL.GetFeeNameByID(.FieldValue, Me.GetFeeManagerType(.FeeType))
                    .Override = Util.DBNullToFalse(r("Override"))
                End With
            End If
        End If
    End Sub

    Private Sub LoadDataFromDB()
        Dim oDataTable As DataTable
        oDataTable = Me.BLL.GetClientMasterAirPrice(Me.CurrentClientID)
        If oDataTable IsNot Nothing AndAlso oDataTable.Rows.Count > 0 Then
            Dim FeeBLL As New BusinessLogicLayer.AirFeeBLL()
            Me.hidAirCalc.Value = oDataTable.Rows(0).Item("PricingID").ToString
            Me.txtAirCalc.Text = FeeBLL.GetAirCalcName(Me.hidAirCalc.Value)
            Me.hidAirCalcName.Value = Me.txtAirCalc.Text
            Me.chkExemptTax.Checked = Util.DBNullToFalse(oDataTable.Rows(0).Item("ExemptTax"))
            Me.CurrentPageMode = CWTMasterDB.TransactionMode.UpdateMode
            '// Store new data
            '// INT
            Call Me.LoadDataByTab("I")
            '// DOM
            Call Me.LoadDataByTab("D")
            '// LCC
            Call Me.LoadDataByTab("L")
            '//
            Me.CurrentActiveTabID = Me.tabPages.ActiveTab.ID
        Else
            Me.CurrentPageMode = CWTMasterDB.TransactionMode.AddNewMode
            '// Change Pointer
            Me.CurrentActiveTabID = Me.tabPages.ActiveTab.ID
            '//
            Me.trFee.Visible = False
            Me.trAddOn.Visible = False
        End If
        If Me.hidAirCalc.Value = "" Then
            Me.tabPages.Visible = False
        Else
            Me.tabPages.Visible = True
        End If
    End Sub

    Private Sub LoadVariablesByTab(ByVal TripType As String)
        Dim FeeBLL As New BusinessLogicLayer.AirFeeBLL()
        Dim oDataTable As DataTable
        Dim r As DataRow
        Dim price As DataInfo.ComAirPricingSettingsInfo
        Dim info As DataInfo.PriceVariablesInfo
        Dim FeeVarID As String = Me.FeeFieldID
        Dim AddOnVarID As String = Me.AddOnFieldID
        Dim TabID As String = ""
        Dim chkFee As Boolean = False
        Dim fee As String
        Select Case TripType
            Case "I"
                TabID = Me.TabPanel1.ID
            Case "D"
                TabID = Me.TabPanel2.ID
            Case "L"
                TabID = Me.TabPanel3.ID
        End Select
        Me.DictAirPricing(TabID) = New DataInfo.ComAirPricingSettingsInfo()
        price = Me.DictAirPricing(TabID)
        oDataTable = Me.BLL.GetAirPriceVariables(TripType, Me.hidAirCalc.Value)
        If oDataTable IsNot Nothing AndAlso oDataTable.Rows.Count > 0 Then
            For i As Integer = 0 To oDataTable.Rows.Count - 1
                r = oDataTable.Rows(i)
                info = New DataInfo.PriceVariablesInfo()
                With info
                    .FieldID = r("FieldID").ToString
                    .FieldValue = r("Value").ToString
                    .FieldName = r("FieldName").ToString
                    .Override = Util.DBNullToFalse(r("Override"))
                End With
                price.Variables.Add(info)
            Next
        End If
        '// Setting
        oDataTable = Me.BLL.GetSettingPricing(Me.hidAirCalc.Value)
        If oDataTable IsNot Nothing AndAlso oDataTable.Rows.Count > 0 Then
            r = oDataTable.Rows(0)
            Dim PreFix As String = ""
            Select Case TripType
                Case "I"
                    PreFix = "Int"
                Case "D"
                    PreFix = "Dom"
                Case "L"
                    PreFix = "LCC"
            End Select
            fee = Util.DBNullToText(r(PreFix + "DDLFeeApply"))
            If fee = "NA" Then
                chkFee = False
            Else
                chkFee = True
            End If
            price.HaveFee = chkFee
            'price.HaveFee = Util.DBNullToFalse(r(PreFix + "ApplyFee"))
            price.HaveAddOn = Util.DBNullToFalse(r(PreFix + "ApplyMarkUp"))
            Me.trFee.Visible = price.HaveFee
            If fee <> "NA" Then
                If fee = "TF" Then
                    Me.lblFee.Text = "Transaction Fee:"
                ElseIf fee = "MF" Then
                    Me.lblFee.Text = "Management Fee:"
                End If
            End If
            Me.trAddOn.Visible = price.HaveAddOn
        Else
            Me.trFee.Visible = False
            Me.trAddOn.Visible = False
            price.HaveFee = False
            price.HaveAddOn = False
        End If
    End Sub

    Private Sub LoadVariables()
        Me.tabPages.Visible = True
        Call Me.LoadVariablesByTab("I")
        Call Me.LoadVariablesByTab("D")
        Call Me.LoadVariablesByTab("L")
        Call Me.ReloadContents()
    End Sub

    Private Function GetStyle(ByVal index As Integer) As String
        Dim retVal As String = ""
        Dim ActiveStyle As String = "TabHeader-Active"
        Dim ItemStyle As String = "TabHeader"
        If Me.tabPages.ActiveTab.ID = Me.tabPages.Tabs.Item(index).ID Then
            retVal = ActiveStyle
        Else
            retVal = ItemStyle
        End If
        Return retVal
    End Function

    Private Sub ToggleTabStyle()
        Me.divInt.Attributes.Add("class", Me.GetStyle(0))
        Me.divDom.Attributes.Add("class", Me.GetStyle(1))
        Me.divLCC.Attributes.Add("class", Me.GetStyle(2))
    End Sub

    Private Sub HarVestData()
        Dim price As DataInfo.ComAirPricingSettingsInfo
        price = Me.DictAirPricing(Me.CurrentActiveTabID)
        Dim info As DataInfo.PriceVariablesInfo
        Dim hid As HiddenField
        Dim tb As CWTCustomControls.CWTTextBox
        Dim cb As CWTCustomControls.CWTCheckBox
        Dim lb As CWTCustomControls.CWTLabel
        Try
            With price
                .Variables.Clear()
                For i As Integer = 0 To Me.rptData.Items.Count - 1
                    info = New DataInfo.PriceVariablesInfo()
                    '//
                    hid = Me.rptData.Items(i).FindControl("hidFieldID")
                    info.FieldID = hid.Value
                    tb = Me.rptData.Items(i).FindControl("txtFieldValue")
                    info.FieldValue = tb.Text
                    lb = Me.rptData.Items(i).FindControl("lblFieldName")
                    info.FieldName = lb.Text
                    cb = Me.rptData.Items(i).FindControl("chkOverrid")
                    info.Override = cb.Checked
                    '//
                    .Variables.Add(info)
                Next
                .HaveFee = Me.chkHaveFee.Checked
                .HaveAddOn = Me.chkHaveAddOn.Checked
                '//
                If .HaveFee Then
                    .Fee.FieldID = Me.FeeFieldID
                    .Fee.FeeType = Me.hidFeeType.Value
                    .Fee.FeeName = Me.txtFeeText.Text
                    .Fee.FieldValue = Me.hidFeeID.Value
                    .Fee.Override = Me.chkOverrid.Checked
                End If
                '//
                If .HaveAddOn Then
                    .AddOn.FieldID = Me.AddOnFieldID
                    .AddOn.FeeName = Me.txtAddOnText.Text
                    .AddOn.FieldValue = Me.hidConditional.Value
                    .AddOn.Override = Me.chkAddOnOverrid.Checked
                End If
                '//
            End With
        Catch ex As Exception
            Debug.Print(ex.ToString)
        End Try
    End Sub

    Private Function ValidateFee() As Boolean
        If (Me.DictAirPricing.Item(Me.TabPanel1.ID).HaveFee AndAlso Me.DictAirPricing.Item(Me.TabPanel1.ID).Fee.FieldValue = "") OrElse _
           (Me.DictAirPricing.Item(Me.TabPanel2.ID).HaveFee AndAlso Me.DictAirPricing.Item(Me.TabPanel2.ID).Fee.FieldValue = "") OrElse _
           (Me.DictAirPricing.Item(Me.TabPanel3.ID).HaveFee AndAlso Me.DictAirPricing.Item(Me.TabPanel3.ID).Fee.FieldValue = "") OrElse _
           (Me.DictAirPricing.Item(Me.TabPanel1.ID).HaveAddOn AndAlso Me.DictAirPricing.Item(Me.TabPanel1.ID).AddOn.FieldValue = "") OrElse _
           (Me.DictAirPricing.Item(Me.TabPanel2.ID).HaveAddOn AndAlso Me.DictAirPricing.Item(Me.TabPanel2.ID).AddOn.FieldValue = "") OrElse _
           (Me.DictAirPricing.Item(Me.TabPanel3.ID).HaveAddOn AndAlso Me.DictAirPricing.Item(Me.TabPanel3.ID).AddOn.FieldValue = "") _
        Then
            Return False
        Else
            Return True
        End If
    End Function

    Private Sub SaveData(ByVal IsNext As Boolean)
        '//
        Call Me.HarVestData()
        If Me.hidAirCalc.Value = "" Then
            Me.lblMsgBox.Text = "Need to select air fare calculation"
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.ajaxMsgBox.Show()
            Exit Sub
        End If
        If Not ValidateFee() Then
            Me.lblMsgBox.Text = "Must set all fee and conditional markup in both tab."
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.ajaxMsgBox.Show()
            Exit Sub
        End If
        '//
        Dim info As New DataInfo.ComAirPricingInfo()
        With info
            .PageMode = Me.CurrentPageMode
            .ClientID = Me.CurrentClientID
            If info.PageMode = CWTMasterDB.TransactionMode.UpdateMode Then
                .CMPID = Me.BLL.GetCMPIDByClientID(Me.CurrentClientID)
            End If
            .ID = Me.hidAirCalc.Value
            .ExemptGovTax = Me.chkExemptTax.Checked
            '// INT
            .IntSetting = Me.DictAirPricing.Item(Me.TabPanel1.ID).DeepClone()
            '// DOM
            .DomSetting = Me.DictAirPricing.Item(Me.TabPanel2.ID).DeepClone()
            '// LCC
            .LccSetting = Me.DictAirPricing.Item(Me.TabPanel3.ID).DeepClone()
        End With
        If Me.BLL.UpdateComAirPricing(info) > 0 Then
            Me.lblMsgBox.Text = Util.GetAppConfig(Util.MsgType.TRANS_SUCCESS.ToString)
            Me.lblMsgBox.ForeColor = Drawing.Color.Green
            Me.ajaxMsgBox.Show()
            If IsNext Then
                Response.Redirect("AuxPricing.aspx")
            End If
        Else
            Me.lblMsgBox.Text = Util.GetAppConfig(Util.MsgType.TRANS_ERROR.ToString)
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.ajaxMsgBox.Show()
        End If
    End Sub

    Protected Sub btnTrans_OnCancel(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans.OnCancel
        Response.Redirect("CompanySearch.aspx")
    End Sub

    Protected Sub btnTrans_OnSave(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans.OnSave
        Call Me.SaveData(False)
    End Sub

    Protected Sub btnTrans_OnSaveNext(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans.OnSaveNext
        Call Me.SaveData(True)
    End Sub

    Protected Sub btnFakeGetInfo_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnFakeGetInfo.Click
        Call Me.AddNewData()
        Call Me.LoadVariables()
    End Sub

    Private Sub rptData_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.RepeaterItemEventArgs) Handles rptData.ItemDataBound
        If e.Item.ItemType <> ListItemType.Item AndAlso e.Item.ItemType <> ListItemType.AlternatingItem Then
            Exit Sub
        End If
        Dim isOverride As Boolean = False
        Dim isBrowsable As Boolean = False
        Dim cb As CWTCustomControls.CWTCheckBox
        Try
            ' todo
            ' - set up Override checkbox
            isOverride = Util.DBNullToFalse(DataBinder.Eval(e.Item.DataItem, "Override"))
            cb = e.Item.FindControl("chkOverrid")
            cb.Checked = isOverride
        Catch ex As Exception
            Debug.Print(e.ToString)
        End Try
    End Sub

    Private Sub tabPages_ActiveTabChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles tabPages.ActiveTabChanged
        If Me.CurrentActiveTabID = Me.tabPages.ActiveTab.ID Then
            Exit Sub
        End If
        Call Me.ToggleTabStyle()
        '// Store Old Data
        Call Me.HarVestData()
        '// Cleans Up Data
        Call Me.AddNewData()
        '// Load 
        Me.CurrentActiveTabID = Me.tabPages.ActiveTab.ID
        Call Me.ReloadContents()
        Call Me.AccessControl("Air")
    End Sub

End Class














@


1.1.1.1
log
@no message
@
text
@@
