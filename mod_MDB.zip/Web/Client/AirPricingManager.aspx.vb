head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.55;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.55;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@
Partial Class Web_Client_AirPricingManager
    Inherits BasePage

    Private BLL As BusinessLogicLayer.ComAirPricingBLL

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.BLL = New BusinessLogicLayer.ComAirPricingBLL()
        If Not IsPostBack Then
            Call Me.LoadDataFromDB()
            Call Me.InitializeControls()
        Else
            Me.txtAirCalc.Text = Me.hidAirCalcName.Value
            Me.txtIntDefVal7.Text = Me.hidFeeName.Value
            Me.txtDomDefVal7.Text = Me.hidFeeDomName.Value
            Me.txtIntDefVal8.Text = Me.hidAddOnName.Value
            Me.txtDomDefVal8.Text = Me.hidAddOnDomName.Value
        End If
    End Sub

    Private Sub InitializeControls()
        Dim sc As New StringBuilder()
        sc.AppendLine("txtCalcID='" + Me.hidAirCalc.ClientID + "';")
        sc.AppendLine("txtCalcName='" + Me.txtAirCalc.ClientID + "';")
        sc.AppendLine("hidAirCalcName='" + Me.hidAirCalcName.ClientID + "';")
        sc.AppendLine("btnGetInfo='" + Me.btnFakeGetInfo.ClientID + "';")
        '//
        sc.AppendLine("txtFeeID='" + Me.hidIntFee.ClientID + "';")
        sc.AppendLine("txtFeeName='" + Me.txtIntDefVal7.ClientID + "';")
        sc.AppendLine("hidFeeName='" + Me.hidFeeName.ClientID + "';")
        sc.AppendLine("txtFeeType='" + Me.hidIntFeeType.ClientID + "';")
        '//
        sc.AppendLine("txtFeeDomID='" + Me.hidDomFee.ClientID + "';")
        sc.AppendLine("txtFeeDomName='" + Me.txtDomDefVal7.ClientID + "';")
        sc.AppendLine("hidFeeDomName='" + Me.hidFeeDomName.ClientID + "';")
        sc.AppendLine("txtFeeDomType='" + Me.hidDomFeeType.ClientID + "';")
        '//
        sc.AppendLine("txtAddOnID='" + Me.hidIntConditional.ClientID + "';")
        sc.AppendLine("txtAddOnName='" + Me.txtIntDefVal8.ClientID + "';")
        sc.AppendLine("hidAddOnName='" + Me.hidAddOnName.ClientID + "';")
        '//
        sc.AppendLine("txtAddOnDomID='" + Me.hidDomConditional.ClientID + "';")
        sc.AppendLine("txtAddOnDomName='" + Me.txtDomDefVal8.ClientID + "';")
        sc.AppendLine("hidAddOnDomName='" + Me.hidAddOnDomName.ClientID + "';")
        '//
        Util.RegClientScript(sc.ToString, "RegistScript", Util.ClientScriptRegistType.RegStartUpBlock)
    End Sub

    Private Sub LoadDataFromDB()
        Dim FeeBLL As New BusinessLogicLayer.AirFeeBLL()
        Dim r As DataRow
        Dim oDataTable As DataTable
        oDataTable = Me.BLL.GetComAirPricingData(Me.CurrentClientID)
        If oDataTable IsNot Nothing AndAlso oDataTable.Rows.Count > 0 Then
            r = oDataTable.Rows(0)
            Me.hidAirCalc.Value = r("AirPricingID").ToString
            Me.txtAirCalc.Text = FeeBLL.GetAirCalcName(Me.hidAirCalc.Value)
            Me.hidIntFee.Value = r("TransFeeIDInt").ToString
            Me.hidDomFee.Value = r("TransFeeIDDom").ToString
            Me.hidIntFeeType.Value = Util.DBNullToZero(r("TransFeeOptionInt"))
            Me.hidDomFeeType.Value = Util.DBNullToZero(r("TransFeeOptionDom"))
            Me.hidIntConditional.Value = r("AddOnMarkupIDInt").ToString
            Me.hidDomConditional.Value = r("AddOnMarkupIDDom").ToString
            Me.chkExemptTax.Checked = Util.DBNullToFalse(r("ExemptGovTax"))
            '// Set Name
            Me.txtIntDefVal7.Text = FeeBLL.GetFeeNameByID(Me.hidIntFee.Value, Me.hidIntFeeType.Value)
            Me.txtDomDefVal7.Text = FeeBLL.GetFeeNameByID(Me.hidDomFee.Value, Me.hidDomFeeType.Value)
            Me.txtIntDefVal8.Text = FeeBLL.GetFeeNameByID(Me.hidIntConditional.Value, DataInfo.AirFeeInfo.AirFeeManagerType.ConditionalMarkUp)
            Me.txtDomDefVal8.Text = FeeBLL.GetFeeNameByID(Me.hidDomConditional.Value, DataInfo.AirFeeInfo.AirFeeManagerType.ConditionalMarkUp)
            '// INT
            Me.txtIntDefVal1.Text = r("DiscountInt").ToString
            Me.txtIntDefVal2.Text = r("DiscountIntDollar").ToString
            Me.txtIntDefVal3.Text = r("GSTInt").ToString
            Me.txtIntDefVal4.Text = r("MarkUpInt").ToString
            Me.txtIntDefVal5.Text = r("MarkUpIntDollar").ToString
            Me.txtIntDefVal6.Text = r("FuelChargeInt").ToString
            '//
            'Me.chkIntDC1.Checked = Util.DBNullToFalse(r("UsedDiscountInt"))
            'Me.chkIntDC2.Checked = Util.DBNullToFalse(r("UsedDiscountIntDollar"))
            'Me.chkIntDC3.Checked = Util.DBNullToFalse(r("UsedGSTInt"))
            'Me.chkIntDC4.Checked = Util.DBNullToFalse(r("UsedMarkUpInt"))
            'Me.chkIntDC5.Checked = Util.DBNullToFalse(r("UsedMarkUpIntDollar"))
            'Me.chkIntDC6.Checked = Util.DBNullToFalse(r("UsedFuelChargeInt"))
            '//
            Me.chkIntOverride1.Checked = Util.DBNullToFalse(r("OverrideDiscountInt"))
            Me.chkIntOverride2.Checked = Util.DBNullToFalse(r("OverrideDiscountIntDollar"))
            Me.chkIntOverride3.Checked = Util.DBNullToFalse(r("OverrideGSTInt"))
            Me.chkIntOverride4.Checked = Util.DBNullToFalse(r("OverrideMarkUpInt"))
            Me.chkIntOverride5.Checked = Util.DBNullToFalse(r("OverrideMarkUpIntDollar"))
            Me.chkIntOverride6.Checked = Util.DBNullToFalse(r("OverrideFuelChargeInt"))
            Me.chkIntOverride7.Checked = Util.DBNullToFalse(r("OverrideFeeInt"))
            Me.chkIntOverride8.Checked = Util.DBNullToFalse(r("OverrideCondInt"))
            '// DOM
            Me.txtDomDefVal1.Text = r("DiscountDom").ToString
            Me.txtDomDefVal2.Text = r("DiscountDomDollar").ToString
            Me.txtDomDefVal3.Text = r("GSTDom").ToString
            Me.txtDomDefVal4.Text = r("MarkUpDom").ToString
            Me.txtDomDefVal5.Text = r("MarkUpDomDollar").ToString
            Me.txtDomDefVal6.Text = r("FuelChargeDom").ToString
            '//
            'Me.chkDomDC1.Checked = Util.DBNullToFalse(r("UsedDiscountDom"))
            'Me.chkDomDC2.Checked = Util.DBNullToFalse(r("UsedDiscountDomDollar"))
            'Me.chkDomDC3.Checked = Util.DBNullToFalse(r("UsedGSTDom"))
            'Me.chkDomDC4.Checked = Util.DBNullToFalse(r("UsedMarkUpDom"))
            'Me.chkDomDC5.Checked = Util.DBNullToFalse(r("UsedMarkUpDomDollar"))
            'Me.chkDomDC6.Checked = Util.DBNullToFalse(r("UsedFuelChargeDom"))
            '//
            Me.chkDomOverride1.Checked = Util.DBNullToFalse(r("OverrideDiscountDom"))
            Me.chkDomOverride2.Checked = Util.DBNullToFalse(r("OverrideDiscountDomDollar"))
            Me.chkDomOverride3.Checked = Util.DBNullToFalse(r("OverrideGSTDom"))
            Me.chkDomOverride4.Checked = Util.DBNullToFalse(r("OverrideMarkUpDom"))
            Me.chkDomOverride5.Checked = Util.DBNullToFalse(r("OverrideMarkUpDomDollar"))
            Me.chkDomOverride6.Checked = Util.DBNullToFalse(r("OverrideFuelChargeDom"))
            Me.chkDomOverride7.Checked = Util.DBNullToFalse(r("OverrideFeeDom"))
            Me.chkDomOverride8.Checked = Util.DBNullToFalse(r("OverrideCondDom"))
            '//
            Me.CurrentPageMode = CWTMasterDB.TransactionMode.UpdateMode
            Call Me.SetUsageVariables()
        Else
            Me.hidIntFeeType.Value = 0
            Me.hidDomFeeType.Value = 0
            '//
            Me.CurrentPageMode = CWTMasterDB.TransactionMode.AddNewMode
            Call Me.SetNewUsageVariables()
        End If
    End Sub

    Private Sub SetNewUsageVariables()
        Me.chkIntDC1.Checked = False
        Me.chkIntDC2.Checked = False
        Me.chkIntDC3.Checked = False
        Me.chkIntDC4.Checked = False
        Me.chkIntDC5.Checked = False
        Me.chkIntDC6.Checked = False
        Me.chkIntDC7.Checked = False
        Me.chkIntDC8.Checked = False
        '
        Me.chkIntOverride1.Enabled = False
        Me.chkIntOverride2.Enabled = False
        Me.chkIntOverride3.Enabled = False
        Me.chkIntOverride4.Enabled = False
        Me.chkIntOverride5.Enabled = False
        Me.chkIntOverride6.Enabled = False
        Me.Button1.Enabled = False
        Me.Button3.Enabled = False
        '
        Me.txtIntDefVal1.Enabled = False
        Me.txtIntDefVal2.Enabled = False
        Me.txtIntDefVal3.Enabled = False
        Me.txtIntDefVal4.Enabled = False
        Me.txtIntDefVal5.Enabled = False
        Me.txtIntDefVal6.Enabled = False
        Me.txtIntDefVal7.Enabled = False
        Me.txtIntDefVal8.Enabled = False
        '//
        Me.chkDomDC1.Checked = False
        Me.chkDomDC2.Checked = False
        Me.chkDomDC3.Checked = False
        Me.chkDomDC4.Checked = False
        Me.chkDomDC5.Checked = False
        Me.chkDomDC6.Checked = False
        Me.chkDomDC7.Checked = False
        Me.chkDomDC8.Checked = False
        '
        Me.chkDomOverride1.Enabled = False
        Me.chkDomOverride2.Enabled = False
        Me.chkDomOverride3.Enabled = False
        Me.chkDomOverride4.Enabled = False
        Me.chkDomOverride5.Enabled = False
        Me.chkDomOverride6.Enabled = False
        Me.Button2.Enabled = False
        Me.Button4.Enabled = False
        '
        Me.txtDomDefVal1.Enabled = False
        Me.txtDomDefVal2.Enabled = False
        Me.txtDomDefVal3.Enabled = False
        Me.txtDomDefVal4.Enabled = False
        Me.txtDomDefVal5.Enabled = False
        Me.txtDomDefVal6.Enabled = False
        Me.txtDomDefVal7.Enabled = False
        Me.txtDomDefVal8.Enabled = False
    End Sub

    Private Sub SetUsageVariables()
        Dim AirPricingID As String
        AirPricingID = Me.hidAirCalc.Value
        If AirPricingID = "" Then
            Exit Sub
        End If
        Dim oDataTable As DataTable
        Dim r As DataRow
        Dim FieldID As String = ""
        Dim UseInt1 As Boolean = False
        Dim UseInt2 As Boolean = False
        Dim UseInt3 As Boolean = False
        Dim UseInt4 As Boolean = False
        Dim UseInt5 As Boolean = False
        Dim UseInt6 As Boolean = False
        Dim UseInt7 As Boolean = False
        Dim UseInt8 As Boolean = False
        Dim UseDom1 As Boolean = False
        Dim UseDom2 As Boolean = False
        Dim UseDom3 As Boolean = False
        Dim UseDom4 As Boolean = False
        Dim UseDom5 As Boolean = False
        Dim UseDom6 As Boolean = False
        Dim UseDom7 As Boolean = False
        Dim UseDom8 As Boolean = False
        oDataTable = Me.BLL.GetUsageVariables(AirPricingID)
        If oDataTable IsNot Nothing AndAlso oDataTable.Rows.Count > 0 Then
            For i As Integer = 0 To oDataTable.Rows.Count - 1
                r = oDataTable.Rows(i)
                FieldID = r("FieldID").ToString
                If Util.DBNullToFalse(r("IsInt")) Then
                    If FieldID = "3" Then UseInt1 = True
                    If FieldID = "4" Then UseInt2 = True
                    If FieldID = "7" Then UseInt3 = True
                    If FieldID = "9" Then UseInt4 = True
                    If FieldID = "10" Then UseInt5 = True
                    If FieldID = "6" Then UseInt6 = True
                    If FieldID = "5" Then UseInt7 = True
                    If FieldID = "11" Then UseInt8 = True
                Else
                    If FieldID = "3" Then UseDom1 = True
                    If FieldID = "4" Then UseDom2 = True
                    If FieldID = "7" Then UseDom3 = True
                    If FieldID = "9" Then UseDom4 = True
                    If FieldID = "10" Then UseDom5 = True
                    If FieldID = "6" Then UseDom6 = True
                    If FieldID = "5" Then UseDom7 = True
                    If FieldID = "11" Then UseDom8 = True
                End If
            Next
        End If
        Me.chkIntDC1.Checked = UseInt1
        Me.chkIntDC2.Checked = UseInt2
        Me.chkIntDC3.Checked = UseInt3
        Me.chkIntDC4.Checked = UseInt4
        Me.chkIntDC5.Checked = UseInt5
        Me.chkIntDC6.Checked = UseInt6
        Me.chkIntDC7.Checked = UseInt7
        Me.chkIntDC8.Checked = UseInt8
        '
        Me.chkIntOverride1.Enabled = UseInt1
        Me.chkIntOverride2.Enabled = UseInt2
        Me.chkIntOverride3.Enabled = UseInt3
        Me.chkIntOverride4.Enabled = UseInt4
        Me.chkIntOverride5.Enabled = UseInt5
        Me.chkIntOverride6.Enabled = UseInt6
        Me.Button1.Enabled = UseInt7
        Me.Button3.Enabled = UseInt8
        '
        Me.txtIntDefVal1.Enabled = UseInt1
        Me.txtIntDefVal2.Enabled = UseInt2
        Me.txtIntDefVal3.Enabled = UseInt3
        Me.txtIntDefVal4.Enabled = UseInt4
        Me.txtIntDefVal5.Enabled = UseInt5
        Me.txtIntDefVal6.Enabled = UseInt6
        Me.txtIntDefVal7.Enabled = UseInt7
        Me.txtIntDefVal8.Enabled = UseInt8
        '//
        Me.chkDomDC1.Checked = UseDom1
        Me.chkDomDC2.Checked = UseDom2
        Me.chkDomDC3.Checked = UseDom3
        Me.chkDomDC4.Checked = UseDom4
        Me.chkDomDC5.Checked = UseDom5
        Me.chkDomDC6.Checked = UseDom6
        Me.chkDomDC7.Checked = UseDom7
        Me.chkDomDC8.Checked = UseDom8
        '
        Me.chkDomOverride1.Enabled = UseDom1
        Me.chkDomOverride2.Enabled = UseDom2
        Me.chkDomOverride3.Enabled = UseDom3
        Me.chkDomOverride4.Enabled = UseDom4
        Me.chkDomOverride5.Enabled = UseDom5
        Me.chkDomOverride6.Enabled = UseDom6
        Me.Button2.Enabled = UseDom7
        Me.Button4.Enabled = UseDom8
        '
        Me.txtDomDefVal1.Enabled = UseDom1
        Me.txtDomDefVal2.Enabled = UseDom2
        Me.txtDomDefVal3.Enabled = UseDom3
        Me.txtDomDefVal4.Enabled = UseDom4
        Me.txtDomDefVal5.Enabled = UseDom5
        Me.txtDomDefVal6.Enabled = UseDom6
        Me.txtDomDefVal7.Enabled = UseDom7
        Me.txtDomDefVal8.Enabled = UseDom8
    End Sub

    Private Sub SaveData(ByVal IsNext As Boolean)
        Dim info As New DataInfo.ComAirPricingInfo()
        With info
            .PageMode = Me.CurrentPageMode
            .ClientID = Me.CurrentClientID
            .ID = Me.hidAirCalc.Value
            .ExemptGovTax = Me.chkExemptTax.Checked
            .FeeIDInt = Me.hidIntFee.Value
            .FeeIDDom = Me.hidDomFee.Value
            .FeeIntType = Util.DBNullToZero(Me.hidIntFeeType.Value)
            .FeeDomType = Util.DBNullToZero(Me.hidDomFeeType.Value)
            .AddOnIDInt = Me.hidIntConditional.Value
            .AddOnIDDom = Me.hidDomConditional.Value
            '//
            .DCInt = Util.DBNullToZero(Me.txtIntDefVal1.Text)
            .DCIntDollar = Util.DBNullToZero(Me.txtIntDefVal2.Text)
            .GSTInt = Util.DBNullToZero(Me.txtIntDefVal3.Text)
            .MarkUpInt = Util.DBNullToZero(Me.txtIntDefVal4.Text)
            .MarkUpIntDollar = Util.DBNullToZero(Me.txtIntDefVal5.Text)
            .FuelInt = Util.DBNullToZero(Me.txtIntDefVal6.Text)
            '//
            .UsedDCInt = Me.chkIntDC1.Checked
            .UsedDCIntDollar = Me.chkIntDC2.Checked
            .UsedGSTInt = Me.chkIntDC3.Checked
            .UsedMarkUpInt = Me.chkIntDC4.Checked
            .UsedMarkUpIntDollar = Me.chkIntDC5.Checked
            .UsedFuelInt = Me.chkIntDC6.Checked
            .UsedFeeInt = Me.chkIntDC7.Checked
            .UsedConditionInt = Me.chkIntDC8.Checked
            '//
            .OverrideDCInt = Me.chkIntOverride1.Checked
            .OverrideDCIntDollar = Me.chkIntOverride2.Checked
            .OverrideGSTInt = Me.chkIntOverride3.Checked
            .OverrideMarkUpInt = Me.chkIntOverride4.Checked
            .OverrideMarkUpIntDollar = Me.chkIntOverride5.Checked
            .OverrideFuelInt = Me.chkIntOverride6.Checked
            .OverrideFeeInt = Me.chkIntOverride7.Checked
            .OverrideConditionInt = Me.chkIntOverride8.Checked
            '//
            .DCDom = Util.DBNullToZero(Me.txtDomDefVal1.Text)
            .DCDomDollar = Util.DBNullToZero(Me.txtDomDefVal2.Text)
            .GSTDom = Util.DBNullToZero(Me.txtDomDefVal3.Text)
            .MarkUpDom = Util.DBNullToZero(Me.txtDomDefVal4.Text)
            .MarkUpDomDollar = Util.DBNullToZero(Me.txtDomDefVal5.Text)
            .FuelDom = Util.DBNullToZero(Me.txtDomDefVal6.Text)
            '//
            .UsedDCDom = Me.chkDomDC1.Checked
            .UsedDCDomDollar = Me.chkDomDC2.Checked
            .UsedGSTDom = Me.chkDomDC3.Checked
            .UsedMarkUpDom = Me.chkDomDC4.Checked
            .UsedMarkUpDomDollar = Me.chkDomDC5.Checked
            .UsedFuelDom = Me.chkDomDC6.Checked
            .UsedFeeDom = Me.chkDomDC7.Checked
            .UsedConditionDom = Me.chkDomDC8.Checked
            '//
            .OverrideDCDom = Me.chkDomOverride1.Checked
            .OverrideDCDomDollar = Me.chkDomOverride2.Checked
            .OverrideGSTDom = Me.chkDomOverride3.Checked
            .OverrideMarkUpDom = Me.chkDomOverride4.Checked
            .OverrideMarkUpDomDollar = Me.chkDomOverride5.Checked
            .OverrideFuelDom = Me.chkDomOverride6.Checked
            .OverrideFeeDom = Me.chkDomOverride7.Checked
            .OverrideConditionDom = Me.chkDomOverride8.Checked
        End With
        If Me.BLL.UpdateComAirPricing(info) > 0 Then
            Me.lblMsgBox.Text = Util.GetAppConfig(Util.MsgType.TRANS_SUCCESS.ToString)
            Me.lblMsgBox.ForeColor = Drawing.Color.Green
            Me.ajaxMsgBox.Show()
            If IsNext Then
                Response.Redirect("AuxPricing.aspx")
            End If
        Else
            Me.lblMsgBox.Text = Util.GetAppConfig(Util.MsgType.TRANS_ERROR.ToString)
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.ajaxMsgBox.Show()
        End If
    End Sub

    Protected Sub btnTrans_OnCancel(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans.OnCancel
        Response.Redirect("CompanySearch.aspx")
    End Sub

    Protected Sub btnTrans_OnSave(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans.OnSave
        Call Me.SaveData(False)
    End Sub

    Protected Sub btnTrans_OnSaveNext(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans.OnSaveNext
        Call Me.SaveData(True)
    End Sub

    Protected Sub btnFakeGetInfo_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnFakeGetInfo.Click
        Call Me.SetUsageVariables()
    End Sub

End Class
@


1.1.1.1
log
@no message
@
text
@@
