head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.57;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.57;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@
Partial Class Web_Client_PopupAirFee
    Inherits BasePage

    Private BLL As BusinessLogicLayer.AirFeeBLL

    Public Property IsInt() As String
        Get
            Return Me.ViewState("IsInt").ToString
        End Get
        Set(ByVal value As String)
            Me.ViewState("IsInt") = value
        End Set
    End Property

    Public ReadOnly Property RequestIsInt() As String
        Get
            Dim retVal As String = ""
            If Me.Request("IsInt") IsNot Nothing Then
                retVal = Me.Request("IsInt")
            End If
            Return retVal
        End Get
    End Property

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.BLL = New BusinessLogicLayer.AirFeeBLL()
        If Not IsPostBack Then
            Me.IsInt = Me.RequestIsInt
            Call Me.LoadDataGrid()
        End If
    End Sub

    Private Sub LoadDataGrid()
        Dim oDataTable As DataTable
        Dim FieldType As DataInfo.AirFeeInfo.AirFeeManagerType
        If Me.ddlField.SelectedValue = "P" Then
            FieldType = DataInfo.AirFeeInfo.AirFeeManagerType.FeeByPNR
        ElseIf Me.ddlField.SelectedValue = "T" Then
            FieldType = DataInfo.AirFeeInfo.AirFeeManagerType.FeeByTicket
        Else
            FieldType = DataInfo.AirFeeInfo.AirFeeManagerType.FeeByCoupon
        End If
        oDataTable = Me.BLL.GetFeeList("", FieldType)
        With Me.gdData
            .DataSource = oDataTable
            .DataBind()
        End With
        With Me.pgControl
            .GridID = Me.gdData.UniqueID
            .PageDataTable = oDataTable.Copy()
            .SetBindGrid()
        End With
    End Sub

    Public Function GetURL(ByVal FeeID As String) As String
        Dim url As String
        Dim FieldType As DataInfo.AirFeeInfo.AirFeeManagerType
        If Me.ddlField.SelectedValue = "P" Then
            FieldType = DataInfo.AirFeeInfo.AirFeeManagerType.FeeByPNR
        ElseIf Me.ddlField.SelectedValue = "T" Then
            FieldType = DataInfo.AirFeeInfo.AirFeeManagerType.FeeByTicket
        Else
            FieldType = DataInfo.AirFeeInfo.AirFeeManagerType.FeeByCoupon
        End If
        Select Case FieldType
            Case DataInfo.AirFeeInfo.AirFeeManagerType.FeeByPNR
                url = "~/Web/CWT/AirFeeByPNR.aspx?mode=edit&id=" + FeeID
            Case DataInfo.AirFeeInfo.AirFeeManagerType.FeeByTicket
                url = "~/Web/CWT/AirFeeByTicket.aspx?mode=edit&id=" + FeeID
            Case DataInfo.AirFeeInfo.AirFeeManagerType.FeeByCoupon
                url = "~/Web/CWT/AirFeeByCoupon.aspx?mode=edit&id=" + FeeID
            Case DataInfo.AirFeeInfo.AirFeeManagerType.ConditionalMarkUp
                url = "~/Web/CWT/AirFeeByConditional.aspx?mode=edit&id=" + FeeID
            Case Else
                url = ""
        End Select
        Return url
    End Function

    Protected Sub ddlField_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlField.SelectedIndexChanged
        Call Me.LoadDataGrid()
    End Sub

    Protected Sub gdData_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles gdData.SelectedIndexChanged
        Dim sc As New StringBuilder()
        Dim id As String
        Dim name As String
        Dim xtype As String
        'Dim isint As String
        Dim hid As HiddenField
        hid = Me.gdData.Rows(Me.gdData.SelectedIndex).FindControl("hidItemID")
        id = hid.Value
        name = Me.gdData.SelectedRow.Cells(0).Text
        If Me.ddlField.SelectedValue = "P" Then
            xtype = DataInfo.AirFeeInfo.AirFeeManagerType.FeeByPNR
        ElseIf Me.ddlField.SelectedValue = "T" Then
            xtype = DataInfo.AirFeeInfo.AirFeeManagerType.FeeByTicket
        Else
            xtype = DataInfo.AirFeeInfo.AirFeeManagerType.FeeByCoupon
        End If
        'xtype = Util.DBNullToZero(Me.ddlField.SelectedValue)
        sc.AppendLine("setText('" + Util.JSEncode(id) + "','" + Util.JSEncode(name) + "','" + Util.JSEncode(xtype) + "','" + Me.IsInt + "');")
        Util.RegClientScript(sc.ToString, "AddValueFromPopup", Util.ClientScriptRegistType.RegStartUpBlock)
    End Sub

End Class
@


1.1.1.1
log
@no message
@
text
@@
