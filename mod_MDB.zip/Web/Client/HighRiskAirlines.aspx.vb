head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.57;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.57;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@
Partial Class Web_Client_HighRiskAirlines
    Inherits BasePage

    Private BLL As BusinessLogicLayer.HighRiskDestBLL
    Private BLL2 As BusinessLogicLayer.StaffBLL
    Private BLL3 As BusinessLogicLayer.tblFunctionBLL


    Public Property DestinationTable() As DataTable
        Get
            Dim retVal As DataTable = Nothing
            If Me.ViewState.Item("_DestinationTable") IsNot Nothing Then
                retVal = Me.ViewState.Item("_DestinationTable")
            End If
            Return retVal
        End Get
        Set(ByVal value As DataTable)
            Me.ViewState.Item("_DestinationTable") = value
        End Set
    End Property

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.BLL = New BusinessLogicLayer.HighRiskDestBLL()
        Me.BLL2 = New BusinessLogicLayer.StaffBLL()
        Me.BLL3 = New BusinessLogicLayer.tblFunctionBLL()


        If Not IsPostBack Then
            Call Me.LoadDropdownList()
        End If
        Call Me.AccessControl("High Risk Airlines")
    End Sub

    Private Sub AccessControl(ByVal title As String)

        Dim userName As String
        Dim oDatatable As DataTable
        Dim oDataTable2 As DataTable

        Static roleID As String

        userName = ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName
        oDatatable = Me.BLL2.GetUserByID(userName)

        If oDatatable.Rows.Count > 0 Then
            roleID = oDatatable.Rows(0).Item("RoleID").ToString
        End If

        oDataTable2 = Me.BLL3.GetUserRole(roleID)
        If oDataTable2.Rows.Count > 0 Then
            For k As Integer = 0 To oDataTable2.Rows.Count - 1
                If oDataTable2.Rows(k).Item("functionGroup") = "1" Then
                    If oDataTable2.Rows(k).Item("Permission") = "V" Then
                        If oDataTable2.Rows(k).Item("functionName").ToString = title Then

                            Call Me.toggleControl()

                        End If
                    End If
                End If

            Next

        End If


    End Sub

    Private Sub toggleControl()
        Me.ddlAirlines.Enabled = False
        Me.ddlDestination.Enabled = False
        Me.btnAdd.Enabled = False
        Me.btnRemove.Enabled = False
        Me.btnRemoveAll.Enabled = False
        Me.btnSelAll.Enabled = False

        Me.btnTrans.ShowSaveNextButton = False
        Me.btnTrans.SaveButton.Enabled = False
    End Sub


    Private Sub LoadAirline()
        Me.DestinationTable = New DataTable()
        Me.DestinationTable = Me.BLL.GetAirlineList()
        Me.DestinationTable.TableName = "dtAirlines"
        If Me.DestinationTable IsNot Nothing AndAlso Me.DestinationTable.Rows.Count > 0 Then
            Call Me.LoadAirlineFromDB()
        End If
    End Sub

    Private Sub LoadDropdownList()
        Call Me.LoadAirline()
    End Sub

    Private Sub LoadAirlineFromDB()
        Dim oDataTable As DataTable
        Dim filter As New StringBuilder()
        Dim oRow As DataRow()
        oDataTable = Me.BLL.GetHighRiskAirline(Me.CurrentClientID)
        If oDataTable IsNot Nothing AndAlso oDataTable.Rows.Count > 0 Then
            For i As Integer = 0 To oDataTable.Rows.Count - 1
                If i > 0 Then
                    filter.Append(" OR ")
                End If
                filter.Append("AirlineCode=" + Util.LimitTheString(oDataTable.Rows(i).Item("AirlineCode").ToString))
            Next
            oRow = Me.DestinationTable.Select(filter.ToString)
            If oRow IsNot Nothing AndAlso oRow.Length > 0 Then
                For i As Integer = 0 To oRow.Length - 1
                    oRow(i).Item("IsRisk") = 1
                Next
            End If
        End If
        Call Me.ReLoadAirlineList()
        Call Me.ReloadDestinationList()
    End Sub

    Private Sub ReLoadAirlineList()
        Dim dv As New DataView()
        Dim filter As String = ""
        filter = "IsRisk=0"
        With dv
            .Table = Me.DestinationTable
            .RowFilter = filter
            .Sort = "AirlineDescription"
        End With
        With Me.ddlAirlines
            .DataTextField = "AirlineDescription"
            .DataValueField = "AirlineCode"
            .DataSource = dv.ToTable
            .DataBind()
        End With
    End Sub

    Private Sub ReloadDestinationList()
        Dim dv As New DataView()
        Dim filter As String = ""
        filter = "IsRisk=1"
        With dv
            .Table = Me.DestinationTable
            .RowFilter = filter
            .Sort = "AirlineDescription"
        End With
        With Me.ddlDestination
            .DataTextField = "AirlineDescription"
            .DataValueField = "AirlineCode"
            .DataSource = dv.ToTable
            .DataBind()
        End With
    End Sub

    Private Sub AddDestination()
        Dim SelectedIndex() As Integer
        SelectedIndex = Me.ddlAirlines.GetSelectedIndices
        If SelectedIndex.Length <= 0 Then
            Exit Sub
        End If
        If SelectedIndex.Length = Me.DestinationTable.Rows.Count Then
            Call Me.AddAllDestination()
            Exit Sub
        End If
        Dim filter As New StringBuilder()
        Dim oRow As DataRow()
        For i As Integer = 0 To SelectedIndex.Length - 1
            If i > 0 Then
                filter.Append(" OR ")
            End If
            filter.Append("AirlineCode=" + Util.LimitTheString(Me.ddlAirlines.Items(SelectedIndex(i)).Value.ToString))
        Next
        oRow = Me.DestinationTable.Select(filter.ToString)
        If oRow IsNot Nothing AndAlso oRow.Length > 0 Then
            For i As Integer = 0 To oRow.Length - 1
                oRow(i).Item("IsRisk") = 1
            Next
        End If
        Call Me.ReLoadAirlineList()
        Call Me.ReloadDestinationList()
    End Sub

    Private Sub AddAllDestination()
        If Me.DestinationTable Is Nothing Then
            Exit Sub
        End If
        For Each r As DataRow In Me.DestinationTable.Rows
            r.Item("IsRisk") = 1
        Next
        Call Me.ReloadDestinationList()
        Call Me.ReLoadAirlineList()
    End Sub

    Private Sub RemoveDestination()
        Dim SelectedIndex() As Integer
        Dim filter As New StringBuilder()
        Dim oRow As DataRow()
        SelectedIndex = Me.ddlDestination.GetSelectedIndices
        If SelectedIndex.Length <= 0 Then
            Exit Sub
        End If
        For i As Integer = 0 To SelectedIndex.Length - 1
            If i > 0 Then
                filter.Append(" OR ")
            End If
            filter.Append("AirlineCode=" + Util.LimitTheString(Me.ddlDestination.Items(SelectedIndex(i)).Value.ToString))
        Next
        oRow = Me.DestinationTable.Select(filter.ToString)
        If oRow IsNot Nothing AndAlso oRow.Length > 0 Then
            For i As Integer = 0 To oRow.Length - 1
                oRow(i).Item("IsRisk") = 0
            Next
        End If
        Call Me.ReloadDestinationList()
        Call Me.ReLoadAirlineList()
    End Sub

    Private Sub RemoveAllDestination()
        If Me.DestinationTable Is Nothing Then
            Exit Sub
        End If
        For Each r As DataRow In Me.DestinationTable.Rows
            r.Item("IsRisk") = 0
        Next
        Call Me.ReloadDestinationList()
        Call Me.ReLoadAirlineList()
    End Sub

    Protected Sub btnSelAll_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSelAll.Click
        Call Me.AddAllDestination()
    End Sub

    Protected Sub btnAdd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnAdd.Click
        Call Me.AddDestination()
    End Sub

    Protected Sub btnRemove_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnRemove.Click
        Call Me.RemoveDestination()
    End Sub

    Protected Sub btnRemoveAll_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnRemoveAll.Click
        Call Me.RemoveAllDestination()
    End Sub

    Private Sub SaveData(ByVal IsNext As Boolean)
        Dim info As New DataInfo.HighRiskInfo()
        Dim oRow As DataRow()
        Dim filter As String = ""
        filter = "IsRisk=1"
        With info
            .ClientID = Me.CurrentClientID
            oRow = Me.DestinationTable.Select(filter)
            If oRow IsNot Nothing AndAlso oRow.Length > 0 Then
                For i As Integer = 0 To oRow.Length - 1
                    .HighRiskAirList.Add(oRow(i).Item("AirlineCode").ToString)
                Next
            End If
        End With
        If Me.BLL.UpdateHighRiskAir(info) > 0 Then
            Me.lblMsgBox.Text = Util.GetAppConfig(Util.MsgType.TRANS_SUCCESS.ToString)
            Me.lblMsgBox.ForeColor = Drawing.Color.Green
            Me.ajaxMsgBox.Show()
            If IsNext Then
                Response.Redirect("HighRiskDestination.aspx")
            End If
        Else
            Me.lblMsgBox.Text = Util.GetAppConfig(Util.MsgType.TRANS_ERROR.ToString)
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.ajaxMsgBox.Show()
        End If
    End Sub

    Protected Sub btnTrans_OnCancel(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans.OnCancel
        Response.Redirect("CompanySearch.aspx")
    End Sub

    Protected Sub btnTrans_OnSave(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans.OnSave
        Call Me.SaveData(False)
    End Sub

    Protected Sub btnTrans_OnSaveNext(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans.OnSaveNext
        Call Me.SaveData(True)
    End Sub

End Class
@


1.1.1.1
log
@no message
@
text
@@
