head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.57;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.57;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports System.Web.Services
Imports System.Web.Script.Services

Partial Class Web_Client_CompanySearch
    Inherits BasePage

    Private BLL As BusinessLogicLayer.CompanyBLL

#Region "Page Load Event"
    Protected Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init
    End Sub
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.BLL = New BusinessLogicLayer.CompanyBLL()
        If Not IsPostBack Then
            Call Me.LoadDataGrid()
        Else

        End If
    End Sub
#End Region

#Region "Control Event"
    Protected Sub btnSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSearch.Click
        Call Me.LoadDataGrid()
    End Sub
#End Region

#Region "Methods"
    Private Sub LoadDataGrid()
        Dim configKey As String

        configKey = Session("CONN_KeyID").ToString

        Dim oDataTable As DataTable
        oDataTable = Me.BLL.GetCompanyList(Me.txtClientName.Text, Me.txtAffName.Text, Me.chkIncInactive.Checked, Me.txtBarName.Text, Me.txtClientNo.Text, configKey)
        With Me.gdData
            .DataSource = oDataTable
            .DataBind()
        End With
        With Me.pgControl
            .GridID = Me.gdData.UniqueID
            .SetBindGrid()
        End With
    End Sub
#End Region

#Region "Webservices Methods"
    <WebMethod(), ScriptMethod()> _
    Public Shared Function GetClientName(ByVal prefixText As String, ByVal count As Integer) As String()
        Dim CompBLL As New BusinessLogicLayer.CompanyBLL()
        Return CompBLL.GetClientName(prefixText)
    End Function

    <WebMethod(), ScriptMethod()> _
    Public Shared Function GetAffName(ByVal prefixText As String, ByVal count As Integer) As String()
        Dim CompBLL As New BusinessLogicLayer.CompanyBLL()
        Return CompBLL.GetAffiliateName(prefixText)
    End Function
#End Region

End Class
@


1.1.1.1
log
@no message
@
text
@@
