head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.58;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.58;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@
Partial Class Web_Client_ucStandardMCFee
    Inherits BaseUserControl

    Private BLL As BusinessLogicLayer.CompanyMFBLL
    Private BLL2 As BusinessLogicLayer.StaffBLL
    Private BLL3 As BusinessLogicLayer.tblFunctionBLL

    Public Event OnSaveSuccess(ByVal sender As Object, ByVal e As BaseEventArgs)
    Public Event OnSaveFailed(ByVal sender As Object, ByVal e As BaseEventArgs)

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.BLL = New BusinessLogicLayer.CompanyMFBLL()
        Me.BLL2 = New BusinessLogicLayer.StaffBLL()
        Me.BLL3 = New BusinessLogicLayer.tblFunctionBLL()
        If Not IsPostBack Then
            Call Me.LoadData()
        End If
        Call Me.AccessControl("Merchant Fee/Application")
    End Sub

    Private Sub AccessControl(ByVal title As String)

        Dim userName As String
        Dim oDatatable As DataTable
        Dim oDataTable2 As DataTable

        Static roleID As String

        userName = ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName
        oDatatable = Me.BLL2.GetUserByID(userName)

        If oDatatable.Rows.Count > 0 Then
            roleID = oDatatable.Rows(0).Item("RoleID").ToString
        End If

        oDataTable2 = Me.BLL3.GetUserRole(roleID)
        If oDataTable2.Rows.Count > 0 Then
            For k As Integer = 0 To oDataTable2.Rows.Count - 1
                If oDataTable2.Rows(k).Item("functionGroup") = "1" Then
                    If oDataTable2.Rows(k).Item("Permission") = "V" Then
                        If oDataTable2.Rows(k).Item("functionName").ToString = title Then

                            Call Me.toggleControl()

                        End If
                    End If
                End If

            Next

        End If


    End Sub

    Private Sub toggleControl()
        Me.txtFee.Readonly = True

        Me.btnTrans.ShowSaveNextButton = False
        Me.btnTrans.SaveButton.Enabled = False
    End Sub

    Private Sub LoadData()
        Dim MF As Double = 0
        MF = Me.BLL.GetStandardMF(Me.CurrentClientID)
        Me.txtFee.Text = MF
        'Me.txtFee.Text = Format(CWTMasterDB.Util.DBNullToZero(MF), "G2")
    End Sub

    Private Sub SaveData()
        Dim MF As Double = 0
        MF = Util.DBNullToZero(Me.txtFee.Text)
        Dim args As New BaseEventArgs()
        If Me.BLL.SaveStandardMF(Me.CurrentClientID, MF) > 0 Then
            args.EventMessage = Util.GetAppConfig(Util.MsgType.TRANS_SUCCESS.ToString)
            RaiseEvent OnSaveSuccess(Me, args)
        Else
            args.EventMessage = Util.GetAppConfig(Util.MsgType.TRANS_ERROR.ToString)
            RaiseEvent OnSaveFailed(Me, args)
        End If
    End Sub

    Protected Sub btnTrans_OnCancel(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans.OnCancel
        Call Me.LoadData()
    End Sub

    Protected Sub btnTrans_OnSave(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans.OnSave
        Call Me.SaveData()
    End Sub

End Class
@


1.1.1.1
log
@no message
@
text
@@
