head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.55;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.55;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@
Partial Class Web_Client_AirPolicyManager
    Inherits BasePage

#Region "Page Properties & Variables"
    Private BLL As BusinessLogicLayer.CompanyPolicyBLL
    Private BLL2 As BusinessLogicLayer.StaffBLL
    Private BLL3 As BusinessLogicLayer.tblFunctionBLL

    Private Property PolicyTable() As DataTable
        Get
            Return Me.ViewState("_PolicyTable")
        End Get
        Set(ByVal value As DataTable)
            Me.ViewState("_PolicyTable") = value
        End Set
    End Property

    Private Property ClassTable() As DataTable
        Get
            Return Me.ViewState("_ClassTable")
        End Get
        Set(ByVal value As DataTable)
            Me.ViewState("_ClassTable") = value
        End Set
    End Property

    Public Property CurentWebMode() As DataInfo.CompanyPolicyInfo.WebMode
        Get
            Dim retVal As DataInfo.CompanyInfo.WebMode = DataInfo.CompanyInfo.WebMode.GeneralInfo
            If Me.ViewState("_CurentWebMode") IsNot Nothing Then
                retVal = Me.ViewState("_CurentWebMode")
            End If
            Return retVal
        End Get
        Set(ByVal value As DataInfo.CompanyPolicyInfo.WebMode)
            Me.ViewState("_CurentWebMode") = value
        End Set
    End Property

    Public ReadOnly Property RequestWebMode() As String
        Get
            Dim retVal As String = ""
            If Me.Request("wmode") IsNot Nothing Then
                retVal = Me.Request("wmode")
            End If
            Return retVal
        End Get
    End Property
#End Region

#Region "Page Event Handlers & Methods"
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.BLL = New BusinessLogicLayer.CompanyPolicyBLL()
        Me.BLL2 = New BusinessLogicLayer.StaffBLL()
        Me.BLL3 = New BusinessLogicLayer.tblFunctionBLL()

       

        Select Case Me.RequestWebMode.ToLower()
            Case "class"
                Me.CurentWebMode = DataInfo.CompanyPolicyInfo.WebMode.ClassPolicy
                'Call Me.CreateTable()
                Call Me.AccessControl("Class")
            Case Else
                Me.CurentWebMode = DataInfo.CompanyPolicyInfo.WebMode.PolicyLine
                ' Call Me.CreateTable()
                Call Me.AccessControl("General")
        End Select
        If Not IsPostBack Then
            Call Me.CreateTable()
            '    'Me.RegularExpressionValidator1.ValidationExpression = "^[^'""\[\]]+$"

        End If

    End Sub


    Private Sub AccessControl(ByVal title As String)

        Dim userName As String
        Dim oDatatable As DataTable
        Dim oDataTable2 As DataTable

        Static roleID As String

        userName = ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName
        oDatatable = Me.BLL2.GetUserByID(userName)

        If oDatatable.Rows.Count > 0 Then
            roleID = oDatatable.Rows(0).Item("RoleID").ToString
        End If

        oDataTable2 = Me.BLL3.GetUserRole(roleID)
        If oDataTable2.Rows.Count > 0 Then
            For k As Integer = 0 To oDataTable2.Rows.Count - 1
                If oDataTable2.Rows(k).Item("functionGroup") = "1" Then
                    If oDataTable2.Rows(k).Item("Permission") = "V" Then
                        If oDataTable2.Rows(k).Item("ParentID").ToString = "PA" Then
                            If oDataTable2.Rows(k).Item("functionName").ToString = title Then
                                If title = "Class" Then
                                    Call Me.toggleControl2()
                                Else
                                    Call Me.toggleControl()
                                End If



                            End If
                        End If

                    End If
                End If

            Next

        End If


    End Sub

    Private Sub toggleControl()

        Me.txtPolicyLine.Readonly = True
        Me.btnSave.Enabled = False

        Me.gdData.Visible = False
        Me.tblPg.Visible = False

        Me.gdDataView.Visible = True

        Me.tblPg2.Visible = True

        


        Me.btnTrans.ShowSaveNextButton = False
        Me.btnTrans.SaveButton.Enabled = False
    End Sub

    Private Sub toggleControl2()
        'Dim btnDelete As CWTCustomControls.CWTLinkButton
        Me.txtRemark.Readonly = True
        Me.btnAdd2.Enabled = False
        Me.ddlClass.Enabled = False
        Me.ddlMathOperator.Enabled = False
        Me.txtTravelerType.Readonly = True
        Me.txtStFlyTime.Readonly = True
        Me.txtEndFlyTime.Readonly = True
        Me.gdDataClass.Visible = False
        Me.tblPg3.Visible = False
        Me.gdDataView2.Visible = True
        Me.tblPg4.Visible = True
        'For i As Integer = 0 To Me.gdDataClass.Rows.Count - 1
        '    btnDelete = Me.gdDataClass.Rows(i).FindControl("hrefDeleteItem")
        '    btnDelete.Enabled = False

        'Next


        Me.btnTrans.ShowSaveNextButton = False
        Me.btnTrans.SaveButton.Enabled = False
    End Sub

    Private Sub CreateTable()
        If Me.CurentWebMode = DataInfo.CompanyPolicyInfo.WebMode.PolicyLine Then
            Me.tblPolicy.Visible = True
            Me.tblClassPolicy.Visible = False
            Call Me.CreatePolicyTable()
            Call Me.LoadPolicyDataFromDB()
        Else
            Me.tblPolicy.Visible = False
            Me.tblClassPolicy.Visible = True
            Call Me.CreateClassTable()
            Call Me.LoadDropDownList()
            Call Me.LoadClassDataFromDB()
        End If
        Call Me.LoadNewData()
    End Sub
#End Region

#Region "Policy Sub Routines"
    Private Sub CreatePolicyTable()
        Me.PolicyTable = New DataTable("PolicyTable")
        With Me.PolicyTable
            .Columns.Add(New DataColumn("ItemNo", GetType(Integer)))
            .Columns.Add(New DataColumn("PolicyLine"))
        End With
    End Sub

    Private Sub AddPolicyData()
        Dim dr As DataRow
        dr = Me.PolicyTable.NewRow()
        If Me.PolicyTable.Rows.Count > 0 Then
            dr("ItemNo") = Util.DBNullToZero(Me.PolicyTable.Rows(Me.PolicyTable.Rows.Count - 1).Item("ItemNo") + 1)
        Else
            dr("ItemNo") = 1
        End If
        dr("PolicyLine") = Me.txtPolicyLine.Text
        Me.PolicyTable.Rows.Add(dr)
    End Sub

    Private Sub LoadPolicyData(ByVal ItemNo As String)
        Dim dr As DataRow()
        Dim filter As String = ""
        filter = "ItemNo=" + Util.LimitTheString(ItemNo)
        dr = Me.PolicyTable.Select(filter)
        If dr IsNot Nothing AndAlso dr.Length > 0 Then
            Me.txtItemNo.Value = ItemNo
            Me.txtPolicyLine.Text = dr(0).Item("PolicyLine").ToString
        End If
    End Sub

    Private Sub LoadPolicyDataFromDB()
        Dim oDataTable As DataTable
        Dim oRow As DataRow
        Dim dr As DataRow
        oDataTable = Me.BLL.GetAirPolicyData(Me.CurrentClientID)
        If oDataTable IsNot Nothing Then
            For i As Integer = 0 To oDataTable.Rows.Count - 1
                oRow = oDataTable.Rows(i)
                dr = Me.PolicyTable.NewRow()
                If Me.PolicyTable.Rows.Count > 0 Then
                    dr("ItemNo") = Util.DBNullToZero(Me.PolicyTable.Rows(Me.PolicyTable.Rows.Count - 1).Item("ItemNo") + 1)
                Else
                    dr("ItemNo") = 1
                End If
                dr("PolicyLine") = oRow("PolicyLine").ToString
                Me.PolicyTable.Rows.Add(dr)
            Next
            Call Me.RefreshPolicyGrid()
        End If
    End Sub

    Private Sub RemovePolicyData(ByVal ItemNo As String)
        Dim dr As DataRow()
        Dim filter As String = ""
        filter = "ItemNo=" + Util.LimitTheString(ItemNo)
        dr = Me.PolicyTable.Select(filter)
        If dr IsNot Nothing AndAlso dr.Length > 0 Then
            Me.PolicyTable.Rows.Remove(dr(0))
        End If
    End Sub

    Private Sub UpdatePolicyData(ByVal ItemNo As String)
        Dim dr As DataRow()
        Dim filter As String = ""
        filter = "ItemNo=" + Util.LimitTheString(ItemNo)
        dr = Me.PolicyTable.Select(filter)
        If dr IsNot Nothing AndAlso dr.Length > 0 Then
            dr(0).Item("PolicyLine") = Me.txtPolicyLine.Text
        End If
    End Sub

    Private Sub RefreshPolicyGrid()
        Dim dv As New DataView()
        With dv
            .Table = Me.PolicyTable
            .Sort = "ItemNo"
        End With
        With Me.gdData
            .DataSource = dv.ToTable()
            .DataBind()
        End With
        With Me.pgControl
            .GridID = Me.gdData.UniqueID
            .SetBindGrid()
        End With

        With dv
            .Table = Me.PolicyTable
            .Sort = "ItemNo"
        End With
        With Me.gdDataView
            .DataSource = dv.ToTable()
            .DataBind()
        End With
        With Me.pgControlView
            .GridID = Me.gdDataView.UniqueID
            .SetBindGrid()
        End With
    End Sub

    Public Sub gdData_Command(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.CommandEventArgs)
        Select Case e.CommandName
            Case "delete"
                Call Me.RemovePolicyData(Util.DBNullToZero(e.CommandArgument))
            Case "edit"
                Call Me.LoadPolicyData(Util.DBNullToZero(e.CommandArgument))
                Me.btnSave.Text = "Update"
        End Select
        Call Me.RefreshPolicyGrid()
        Call Me.AccessControl("General")
    End Sub

    Protected Sub btnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSave.Click
        Dim ItemNo As String = ""
        ItemNo = Me.txtItemNo.Value
        If ItemNo = "" Then
            Call Me.AddPolicyData()
        Else
            Call Me.UpdatePolicyData(ItemNo)
        End If
        Call Me.RefreshPolicyGrid()
        Call Me.LoadNewData()
    End Sub

    Protected Sub btnCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        Call Me.LoadNewData()
    End Sub
#End Region

#Region "Class sub routine"
    Private Sub CreateClassTable()
        Me.ClassTable = New DataTable("ClassTable")
        With Me.ClassTable
            .Columns.Add(New DataColumn("ItemNo", GetType(Integer)))
            .Columns.Add(New DataColumn("TravelerType"))
            .Columns.Add(New DataColumn("StFlyTime"))
            .Columns.Add(New DataColumn("EndFlyTime"))
            .Columns.Add(New DataColumn("MathOperator"))
            .Columns.Add(New DataColumn("PreferredClass"))
            .Columns.Add(New DataColumn("Remark"))
        End With
    End Sub

    Private Sub AddClassData()
        Dim dr As DataRow
        dr = Me.ClassTable.NewRow()
        If Me.ClassTable.Rows.Count > 0 Then
            dr("ItemNo") = Util.DBNullToZero(Me.ClassTable.Rows(Me.ClassTable.Rows.Count - 1).Item("ItemNo") + 1)
        Else
            dr("ItemNo") = 1
        End If
        dr("TravelerType") = Me.txtTravelerType.Text
        dr("StFlyTime") = Me.txtStFlyTime.Text
        dr("EndFlyTime") = Me.txtEndFlyTime.Text
        dr("MathOperator") = Me.ddlMathOperator.SelectedValue
        dr("PreferredClass") = Me.ddlClass.SelectedValue
        dr("Remark") = Me.txtRemark.Text
        Me.ClassTable.Rows.Add(dr)
    End Sub

    Private Sub LoadClassData(ByVal ItemNo As String)
        On Error Resume Next
        Dim dr As DataRow()
        Dim filter As String = ""
        filter = "ItemNo=" + Util.LimitTheString(ItemNo)
        dr = Me.ClassTable.Select(filter)
        If dr IsNot Nothing AndAlso dr.Length > 0 Then
            Me.txtItemNo2.Value = ItemNo
            Me.txtTravelerType.Text = dr(0).Item("TravelerType").ToString
            Me.txtStFlyTime.Text = dr(0).Item("StFlyTime").ToString
            Me.txtEndFlyTime.Text = dr(0).Item("EndFlyTime").ToString
            Me.ddlMathOperator.SelectedValue = dr(0).Item("MathOperator").ToString
            Me.ddlClass.SelectedValue = dr(0).Item("PreferredClass").ToString
            Me.txtRemark.Text = dr(0).Item("Remark").ToString
            Call Me.SetMathMode()
        End If
    End Sub

    Private Sub LoadClassDataFromDB()
        Dim oDataTable As DataTable
        Dim oRow As DataRow
        Dim dr As DataRow
        Try
            oDataTable = Me.BLL.GetAirClassData(Me.CurrentClientID)
            If oDataTable IsNot Nothing Then
                For i As Integer = 0 To oDataTable.Rows.Count - 1
                    oRow = oDataTable.Rows(i)
                    dr = Me.ClassTable.NewRow()
                    If Me.ClassTable.Rows.Count > 0 Then
                        dr("ItemNo") = Util.DBNullToZero(Me.ClassTable.Rows(Me.ClassTable.Rows.Count - 1).Item("ItemNo") + 1)
                    Else
                        dr("ItemNo") = 1
                    End If
                    dr("TravelerType") = oRow("TravelerType").ToString
                    dr("StFlyTime") = oRow("FlyingTime").ToString
                    dr("EndFlyTime") = oRow("FlyingEndTime").ToString
                    Select Case oRow("FlyingTimeType").ToString
                        Case "Between"
                            dr("MathOperator") = DataInfo.CompanyPolicyInfo.MathOperator.Between.ToString
                        Case "<="
                            dr("MathOperator") = DataInfo.CompanyPolicyInfo.MathOperator.lteq.ToString
                        Case "<"
                            dr("MathOperator") = DataInfo.CompanyPolicyInfo.MathOperator.lt.ToString
                        Case ">"
                            dr("MathOperator") = DataInfo.CompanyPolicyInfo.MathOperator.gt.ToString
                        Case ">="
                            dr("MathOperator") = DataInfo.CompanyPolicyInfo.MathOperator.gteq.ToString
                        Case Else
                            dr("MathOperator") = DataInfo.CompanyPolicyInfo.MathOperator.eq.ToString
                    End Select
                    dr("PreferredClass") = oRow("AirClass").ToString
                    dr("Remark") = oRow("Remarks").ToString
                    Me.ClassTable.Rows.Add(dr)
                Next
                Call Me.RefreshClassGrid()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub RemoveClassData(ByVal ItemNo As String)
        Dim dr As DataRow()
        Dim filter As String = ""
        filter = "ItemNo=" + Util.LimitTheString(ItemNo)
        dr = Me.ClassTable.Select(filter)
        If dr IsNot Nothing AndAlso dr.Length > 0 Then
            Me.ClassTable.Rows.Remove(dr(0))
        End If
    End Sub

    Private Sub UpdateClassData(ByVal ItemNo As String)
        Dim dr As DataRow()
        Dim filter As String = ""
        filter = "ItemNo=" + Util.LimitTheString(ItemNo)
        dr = Me.ClassTable.Select(filter)
        If dr IsNot Nothing AndAlso dr.Length > 0 Then
            dr(0).Item("TravelerType") = Me.txtTravelerType.Text
            dr(0).Item("StFlyTime") = Me.txtStFlyTime.Text
            dr(0).Item("EndFlyTime") = Me.txtEndFlyTime.Text
            dr(0).Item("MathOperator") = Me.ddlMathOperator.SelectedValue
            dr(0).Item("PreferredClass") = Me.ddlClass.SelectedValue
            dr(0).Item("Remark") = Me.txtRemark.Text
        End If
    End Sub

    Private Sub RefreshClassGrid()
        Dim dv As New DataView()
        With dv
            .Table = Me.ClassTable
            .Sort = "ItemNo"
        End With
        With Me.gdDataClass
            .DataSource = dv.ToTable()
            .DataBind()
        End With
        With Me.pgControl2
            .GridID = Me.gdDataClass.UniqueID
            .SetBindGrid()
        End With

        With dv
            .Table = Me.ClassTable
            .Sort = "ItemNo"
        End With
        With Me.gdDataView2
            .DataSource = dv.ToTable()
            .DataBind()
        End With
        With Me.pgControlView2
            .GridID = Me.gdDataView2.UniqueID
            .SetBindGrid()
        End With
    End Sub

    Public Sub gdDataClass_Command(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.CommandEventArgs)
        Select Case e.CommandName
            Case "delete"
                Call Me.RemoveClassData(Util.DBNullToZero(e.CommandArgument))
            Case "edit"
                Call Me.LoadClassData(Util.DBNullToZero(e.CommandArgument))
                Me.btnAdd2.Text = "Update"
        End Select
        Call Me.RefreshClassGrid()
        Call Me.AccessControl("Class")
    End Sub

    Protected Sub btnAdd2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnAdd2.Click
        Dim ItemNo As String = ""
        ItemNo = Me.txtItemNo2.Value
        If ItemNo = "" Then
            Call Me.AddClassData()
        Else
            Call Me.UpdateClassData(ItemNo)
        End If
        Call Me.RefreshClassGrid()
        Call Me.LoadNewData()
    End Sub

    Protected Sub btnCancel2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnCancel2.Click
        Call Me.LoadNewData()
    End Sub

    Public Function GetOperatorCaption(ByVal op As String) As String
        'Dim retVal As String = ""
        Dim retVal As String = ""
        Dim li As ListItem
        If op = "Between" Then
            retVal = " to "
        Else
            li = Me.ddlMathOperator.Items.FindByValue(op)
            If li IsNot Nothing Then
                retVal = li.Text
            End If
        End If
        Return retVal
    End Function

    Public Function GetClassText(ByVal val As String) As String
        Dim retVal As String = ""
        Dim li As ListItem
        li = Me.ddlClass.Items.FindByValue(val)
        If li IsNot Nothing Then
            retVal = li.Text
        End If
        Return retVal
    End Function
#End Region

#Region "Data Binding"
    Private Sub LoadClass()
        Dim BLL As New BusinessLogicLayer.CompanyPolicyBLL()
        Dim oDataTable As DataTable
        oDataTable = BLL.GetAirClassList()
        With Me.ddlClass
            .DataTextField = "ClassDescription"
            .DataValueField = "ClassID"
            .DataSource = oDataTable
            .DataBind()
        End With
    End Sub

    Private Sub LoadDropDownList()
        Call Me.LoadClass()
    End Sub

    Private Sub LoadNewData()
        Me.txtPolicyLine.Text = ""
        '//
        Me.txtItemNo.Value = ""
        Me.txtItemNo2.Value = ""
        Me.txtTravelerType.Text = ""
        Me.txtStFlyTime.Text = ""
        Me.txtEndFlyTime.Text = ""
        Me.ddlMathOperator.SelectedValue = DataInfo.CompanyPolicyInfo.MathOperator.eq.ToString
        Me.ddlClass.SelectedIndex = -1
        Me.txtRemark.Text = ""
        Me.btnSave.Text = "Add"
        Me.btnAdd2.Text = "Add"
        '//
        Call Me.SetMathMode()
    End Sub
#End Region

#Region "Data Transaction"
    Private Sub SaveData(ByVal IsNext As Boolean)
        Dim info As New DataInfo.CompanyPolicyInfo()
        Dim air As DataInfo.AirClassInfo
        Dim r As DataRow
        With info
            .PageMode = Me.CurrentPageMode
            .ClientID = Me.CurrentClientID
            .CurrentWebMode = Me.CurentWebMode
            If Me.CurentWebMode = DataInfo.CompanyPolicyInfo.WebMode.PolicyLine Then
                For i As Integer = 0 To Me.PolicyTable.Rows.Count - 1
                    .PolicyLines.Add(Me.PolicyTable.Rows(i).Item("PolicyLine").ToString)
                Next
            Else
                For i As Integer = 0 To Me.ClassTable.Rows.Count - 1
                    r = Me.ClassTable.Rows(i)
                    air = New DataInfo.AirClassInfo()
                    With air
                        .TravellerType = r("TravelerType")
                        .StFlyTime = r("StFlyTime")
                        .EndFlyTime = r("EndFlyTime")
                        Select Case r("MathOperator").ToString
                            Case DataInfo.CompanyPolicyInfo.MathOperator.Between.ToString
                                .TimeOperator = "Between"
                            Case DataInfo.CompanyPolicyInfo.MathOperator.lteq.ToString
                                .TimeOperator = "<="
                            Case DataInfo.CompanyPolicyInfo.MathOperator.lt.ToString
                                .TimeOperator = "<"
                            Case DataInfo.CompanyPolicyInfo.MathOperator.gt.ToString
                                .TimeOperator = ">"
                            Case DataInfo.CompanyPolicyInfo.MathOperator.gteq.ToString
                                .TimeOperator = ">="
                            Case Else
                                .TimeOperator = "="
                        End Select
                        .PreferredClass = r("PreferredClass")
                        .Remark = r("Remark")
                    End With
                    .AirClassList.Add(air)
                Next
            End If
        End With
        If Me.BLL.UpdateAirPolicy(info) > 0 Then
            Me.lblMsgBox.Text = Util.GetAppConfig(Util.MsgType.TRANS_SUCCESS.ToString)
            Me.lblMsgBox.ForeColor = Drawing.Color.Green
            Me.ajaxMsgBox.Show()
            If IsNext Then
                If Me.CurentWebMode = DataInfo.CompanyPolicyInfo.WebMode.PolicyLine Then
                    Response.Redirect("AirPolicyManager.aspx?wmode=class")
                Else
                    Response.Redirect("HighRiskAirlines.aspx")
                End If
            End If
        Else
            Me.lblMsgBox.Text = Util.GetAppConfig(Util.MsgType.TRANS_ERROR.ToString)
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.ajaxMsgBox.Show()
        End If
    End Sub
#End Region

#Region "Page Control Event Handlers"
    Protected Sub btnTrans_OnCancel(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans.OnCancel
        Response.Redirect("CompanySearch.aspx")
    End Sub

    Protected Sub btnTrans_OnSave(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans.OnSave
        Call Me.SaveData(False)
    End Sub

    Protected Sub btnTrans_OnSaveNext(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans.OnSaveNext
        Call Me.SaveData(True)
    End Sub

    Protected Sub ddlMathOperator_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlMathOperator.SelectedIndexChanged
        Call Me.SetMathMode()
    End Sub
#End Region

#Region "Misc"
    Private Sub SetMathMode()
        Me.txtStFlyTime.Visible = (Me.ddlMathOperator.SelectedValue = "Between")
        Me.txtEndFlyTime.Visible = (Me.ddlMathOperator.SelectedValue <> "")
        'Me.valFlyTime.Visible = (Me.ddlMathOperator.SelectedValue = "Between")
        Me.valCmpTime.Visible = (Me.ddlMathOperator.SelectedValue = "Between")
        Me.valRegTime.Visible = (Me.ddlMathOperator.SelectedValue = "Between")
    End Sub
#End Region

End Class
@


1.1.1.1
log
@no message
@
text
@@
