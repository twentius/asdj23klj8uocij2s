head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.58;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.58;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@
Partial Class Web_Client_ucBankMCFee
    Inherits BaseUserControl

    Private BLL As BusinessLogicLayer.CompanyMFBLL
    Private BLL2 As BusinessLogicLayer.StaffBLL
    Private BLL3 As BusinessLogicLayer.tblFunctionBLL

    Public Property IsApplyStd() As Boolean
        Get
            Return Me.ViewState("_IsApplyStd")
        End Get
        Set(ByVal value As Boolean)
            Me.ViewState("_IsApplyStd") = value
        End Set
    End Property

    Public Event OnSaveSuccess(ByVal sender As Object, ByVal e As BaseEventArgs)
    Public Event OnSaveFailed(ByVal sender As Object, ByVal e As BaseEventArgs)

    Public Property RecordID() As String
        Get
            Dim retVal As String = ""
            If Me.ViewState("_RecordID") IsNot Nothing Then
                retVal = Me.ViewState("_RecordID").ToString
            End If
            Return retVal
        End Get
        Set(ByVal value As String)
            Me.ViewState("_RecordID") = value
        End Set
    End Property

    Public ReadOnly Property RequestMode() As String
        Get
            Dim retVal As String = ""
            If Me.Request("mode") IsNot Nothing Then
                retVal = Me.Request("mode")
            End If
            Return retVal
        End Get
    End Property

    Private Property CreditCardTable() As DataTable
        Get
            Return Me.ViewState("_CreditCardTable")
        End Get
        Set(ByVal value As DataTable)
            Me.ViewState("_CreditCardTable") = value
        End Set
    End Property

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.BLL = New BusinessLogicLayer.CompanyMFBLL()
        Me.BLL2 = New BusinessLogicLayer.StaffBLL()
        Me.BLL3 = New BusinessLogicLayer.tblFunctionBLL()

        If Not IsPostBack Then
            Me.gdData.AllowPaging = False
            Call Me.CreateCreditCardTable()
            Call Me.PreLoadFromDB()
        End If
        Call Me.AccessControl("Merchant Fee/Application")
    End Sub

    Private Sub AccessControl(ByVal title As String)

        Dim userName As String
        Dim oDatatable As DataTable
        Dim oDataTable2 As DataTable

        Static roleID As String

        userName = ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName
        oDatatable = Me.BLL2.GetUserByID(userName)

        If oDatatable.Rows.Count > 0 Then
            roleID = oDatatable.Rows(0).Item("RoleID").ToString
        End If

        oDataTable2 = Me.BLL3.GetUserRole(roleID)
        If oDataTable2.Rows.Count > 0 Then
            For k As Integer = 0 To oDataTable2.Rows.Count - 1
                If oDataTable2.Rows(k).Item("functionGroup") = "1" Then
                    If oDataTable2.Rows(k).Item("Permission") = "V" Then
                        If oDataTable2.Rows(k).Item("functionName").ToString = title Then

                            Call Me.toggleControl()

                        End If
                    End If
                End If

            Next

        End If


    End Sub

    Private Sub toggleControl()
        'Dim btnDelete As CWTCustomControls.CWTLinkButton

        Me.chkApplyStd.Enabled = False
        Me.btnSave.Enabled = False
        Me.txtCreditCard.Readonly = True
        Me.txtMCFee.Readonly = True
        Me.gdData.Visible = False
        Me.tblPg.Visible = False
        Me.gdDataView.Visible = True
        Me.tblPg2.Visible = True
        'For i As Integer = 0 To Me.gdData.Rows.Count - 1
        '    btnDelete = Me.gdData.Rows(i).FindControl("hrefDeleteItem")
        '    btnDelete.Enabled = False

        'Next


        Me.btnTrans.ShowSaveNextButton = False
        Me.btnTrans.SaveButton.Enabled = False
    End Sub

    Private Sub SetPageData()
        Me.IsApplyStd = Me.chkApplyStd.Checked
        If Not Me.chkApplyStd.Checked Then
            Call Me.LoadDataFromDB()
        Else
            Call Me.LoadDefaultData()
        End If
    End Sub

    Private Sub CreateCreditCardTable()
        Me.CreditCardTable = New DataTable("CreditCardTable")
        With Me.CreditCardTable
            .Columns.Add(New DataColumn("MFBankID", GetType(Integer)))
            .Columns.Add(New DataColumn("CCNumber"))
            .Columns.Add(New DataColumn("Percentage", GetType(Double)))
        End With
    End Sub

    Private Sub AddCreditCardData()
        Dim dr As DataRow

        Dim filter As String = ""
        Dim val As String
        Dim FoundRow As DataRow()
        val = Me.txtCreditCard.Text
        filter = "CCNumber=" + Util.LimitTheString(val)
        FoundRow = Me.CreditCardTable.Select(filter)
        If FoundRow IsNot Nothing AndAlso FoundRow.Length > 0 Then
            Me.lblMsgBox.Text = "Cannot add duplicated card."
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.ajaxMsgBox.Show()
            Exit Sub
        End If

        dr = Me.CreditCardTable.NewRow()
        If Me.CreditCardTable.Rows.Count > 0 Then
            dr("MFBankID") = Util.DBNullToZero(Me.CreditCardTable.Rows(Me.CreditCardTable.Rows.Count - 1).Item("MFBankID") + 1)
        Else
            dr("MFBankID") = 1
        End If
        dr("CCNumber") = Me.txtCreditCard.Text
        dr("Percentage") = Util.DBNullToZero(Me.txtMCFee.Text)
        Me.CreditCardTable.Rows.Add(dr)
    End Sub

    Private Sub LoadNewData()
        Me.txtItemNo.Value = ""
        Me.txtCreditCard.Text = ""
        Me.txtMCFee.Text = ""
        Me.btnSave.Text = "Add"
    End Sub

    Private Sub LoadDefaultData()
        Me.CreditCardTable = Me.BLL.GetMFBankList()
        Me.CreditCardTable.TableName = "CreditCardTable"
        Call Me.RefreshGrid()
    End Sub

    Private Sub LoadDataFromDB()
        Me.CreditCardTable = Me.BLL.GetClientMFBank(Me.CurrentClientID)
        Me.CreditCardTable.TableName = "CreditCardTable"
        Call Me.RefreshGrid()
    End Sub

    Private Sub PreLoadFromDB()
        Dim IsApplyStd As Boolean = False
        IsApplyStd = Me.BLL.IsApplyStdMFBank(Me.CurrentClientID)
        Me.chkApplyStd.Checked = IsApplyStd
        Call Me.SetPageData()
    End Sub

    Private Sub LoadData(ByVal MFBankID As String)
        Dim dr As DataRow()
        Dim filter As String = ""
        filter = "MFBankID=" + Util.LimitTheString(MFBankID)
        dr = Me.CreditCardTable.Select(filter)
        If dr IsNot Nothing AndAlso dr.Length > 0 Then
            Me.txtItemNo.Value = MFBankID
            Me.txtCreditCard.Text = dr(0).Item("CCNumber").ToString
            Me.txtMCFee.Text = dr(0).Item("Percentage").ToString
        End If
    End Sub

    Private Sub RemoveCreditCardData(ByVal MFBankID As String)
        Dim dr As DataRow()
        Dim filter As String = ""
        filter = "MFBankID=" + Util.LimitTheString(MFBankID)
        dr = Me.CreditCardTable.Select(filter)
        If dr IsNot Nothing AndAlso dr.Length > 0 Then
            Me.CreditCardTable.Rows.Remove(dr(0))
        End If
    End Sub

    Private Sub UpdateData(ByVal MFBankID As String)
        Dim dr As DataRow()
        Dim filter As String = ""
        Dim val As String
        Dim FoundRow As DataRow()
        val = Me.txtCreditCard.Text
        filter = "CCNumber=" + Util.LimitTheString(val) + " and MFBankID<>" + Util.LimitTheString(MFBankID)
        FoundRow = Me.CreditCardTable.Select(filter)
        If FoundRow IsNot Nothing AndAlso FoundRow.Length > 0 Then
            Me.lblMsgBox.Text = "Cannot add duplicated card."
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.ajaxMsgBox.Show()
            Exit Sub
        End If
        filter = "MFBankID=" + Util.LimitTheString(MFBankID)
        dr = Me.CreditCardTable.Select(filter)
        If dr IsNot Nothing AndAlso dr.Length > 0 Then
            dr(0).Item("CCNumber") = Me.txtCreditCard.Text
            dr(0).Item("Percentage") = Util.DBNullToZero(Me.txtMCFee.Text)
        End If
    End Sub

    Private Sub RefreshGrid()
        Dim dv As New DataView()
        With dv
            .Table = Me.CreditCardTable
            .Sort = "MFBankID"
        End With
        With Me.gdData
            .DataSource = dv.ToTable()
            .DataBind()
        End With
        With Me.pgControl
            .GridID = Me.gdData.UniqueID
            .SetBindGrid()
        End With


        With dv
            .Table = Me.CreditCardTable
            .Sort = "MFBankID"
        End With
        With Me.gdDataView
            .DataSource = dv.ToTable()
            .DataBind()
        End With
        With Me.pgControl2
            .GridID = Me.gdDataView.UniqueID
            .SetBindGrid()
        End With


    End Sub

    Public Sub gdData_Command(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.CommandEventArgs)
        Select Case e.CommandName
            Case "delete"
                Call Me.RemoveCreditCardData(Util.DBNullToZero(e.CommandArgument))
            Case "edit"
                Call Me.LoadData(Util.DBNullToZero(e.CommandArgument))
                Me.btnSave.Text = "Update"
        End Select
        Call Me.RefreshGrid()
        Call Me.AccessControl("Merchant Fee/Application")
    End Sub

    Protected Sub btnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSave.Click
        Dim MFBankID As String = ""
        MFBankID = Me.txtItemNo.Value
        If MFBankID = "" Then
            Call Me.AddCreditCardData()
        Else
            Call Me.UpdateData(MFBankID)
        End If
        Call Me.RefreshGrid()
        Call Me.LoadNewData()
    End Sub

    Protected Sub gdData_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gdData.RowDataBound
        e.Row.Cells(2).Visible = Not Me.IsApplyStd
        If Me.IsApplyStd Then
            Exit Sub
        End If
        Dim cwtLinkBtn As CWTCustomControls.CWTLinkButton
        cwtLinkBtn = TryCast(e.Row.FindControl("hrefDeleteItem"), CWTCustomControls.CWTLinkButton)
        If cwtLinkBtn IsNot Nothing Then
            cwtLinkBtn.Attributes.Add("onclick", "return confirm('This item will delete, continue?');")
        End If
    End Sub

    Private Sub SaveData()
        Dim info As New DataInfo.CompanyMFInfo()
        Dim cc As DataInfo.BankCardInfo
        Dim r As DataRow
        With info
            .ClientID = Me.CurrentClientID
            .ApplyStdBank = Me.chkApplyStd.Checked
            For i As Integer = 0 To Me.CreditCardTable.Rows.Count - 1
                r = Me.CreditCardTable.Rows(i)
                cc = New DataInfo.BankCardInfo()
                cc.CCnumber = r("CCNumber").ToString
                cc.MFFee = Util.DBNullToZero(r("Percentage"))
                .BankCards.Add(cc)
            Next
        End With
        Dim args As New BaseEventArgs()
        If Me.BLL.SaveMFBank(info) > -1 Then
            Call Me.PreLoadFromDB()
            args.EventMessage = Util.GetAppConfig(Util.MsgType.TRANS_SUCCESS.ToString)
            RaiseEvent OnSaveSuccess(Me, args)
        Else
            args.EventMessage = Util.GetAppConfig(Util.MsgType.TRANS_ERROR.ToString)
            RaiseEvent OnSaveFailed(Me, args)
        End If
    End Sub

    Protected Sub btnTrans_OnSave(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans.OnSave
        Call Me.SaveData()
    End Sub

    Protected Sub btnTrans_OnCancel(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans.OnCancel
        Call Me.PreLoadFromDB()
    End Sub

    Protected Sub chkApplyStd_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkApplyStd.CheckedChanged
        Call Me.SetPageData()
    End Sub

    Private Sub btnCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        Call Me.LoadNewData()
    End Sub

End Class
@


1.1.1.1
log
@no message
@
text
@@
