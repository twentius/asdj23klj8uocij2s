head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.58;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.58;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@
Partial Class Web_Client_ucBillingAddress
    Inherits BaseUserControl

    Private BLL2 As BusinessLogicLayer.StaffBLL
    Private BLL3 As BusinessLogicLayer.tblFunctionBLL

    Public Property RecordID() As String
        Get
            Dim retVal As String = ""
            If Me.ViewState("_RecordID") IsNot Nothing Then
                retVal = Me.ViewState("_RecordID").ToString
            End If
            Return retVal
        End Get
        Set(ByVal value As String)
            Me.ViewState("_RecordID") = value
        End Set
    End Property

    Public ReadOnly Property RequestMode() As String
        Get
            Dim retVal As String = ""
            If Me.Request("mode") IsNot Nothing Then
                retVal = Me.Request("mode")
            End If
            Return retVal
        End Get
    End Property

    Public Property UcTable() As DataTable
        Get
            Return Me.ViewState("_TitleTable")
        End Get
        Set(ByVal value As DataTable)
            Me.ViewState("_TitleTable") = value
        End Set
    End Property

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.BLL2 = New BusinessLogicLayer.StaffBLL()
        Me.BLL3 = New BusinessLogicLayer.tblFunctionBLL()


        If Not IsPostBack Then
            'Call Me.CreateTitleTable()
        Else
            Me.RefreshGrid()
        End If
        Call Me.AccessControl("Billing")
    End Sub


    Private Sub AccessControl(ByVal title As String)

        Dim userName As String
        Dim oDatatable As DataTable
        Dim oDataTable2 As DataTable

        Static roleID As String

        userName = ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName
        oDatatable = Me.BLL2.GetUserByID(userName)

        If oDatatable.Rows.Count > 0 Then
            roleID = oDatatable.Rows(0).Item("RoleID").ToString
        End If

        oDataTable2 = Me.BLL3.GetUserRole(roleID)
        If oDataTable2.Rows.Count > 0 Then
            For k As Integer = 0 To oDataTable2.Rows.Count - 1
                If oDataTable2.Rows(k).Item("functionGroup") = "1" Then
                    If oDataTable2.Rows(k).Item("Permission") = "V" Then
                        If oDataTable2.Rows(k).Item("functionName").ToString = title Then

                            Call Me.toggleControl()

                        End If
                    End If
                End If

            Next

        End If


    End Sub


    Private Sub toggleControl()
        'Dim btnDelete As CWTCustomControls.CWTLinkButton
        Me.txtTitle1.Readonly = True
        Me.txtTitle2.Readonly = True
        Me.txtTitle3.Readonly = True
        Me.txtTitle4.Readonly = True
        Me.txtTitle5.Readonly = True
        Me.txtTitle6.Readonly = True
        Me.txtClientNum.Readonly = True
        'Me.chkPrefered.Enabled = False
        Me.btnSave.Enabled = False
        Me.gdData.Visible = False
        Me.tblPg.Visible = False
        Me.gdDataView.Visible = True
        Me.tblPg2.Visible = True

        'For i As Integer = 0 To Me.gdData.Rows.Count - 1
        '    btnDelete = Me.gdData.Rows(i).FindControl("hrefDeleteItem")
        '    btnDelete.Enabled = False

        'Next
    End Sub

    Public Sub CreateTitleTable()
        Me.UcTable = New DataTable("UcTitleTable")
        With Me.UcTable
            .Columns.Add(New DataColumn("ItemNo", GetType(Integer)))
            .Columns.Add(New DataColumn("Title1"))
            .Columns.Add(New DataColumn("Title2"))
            .Columns.Add(New DataColumn("Title3"))
            .Columns.Add(New DataColumn("Title4"))
            .Columns.Add(New DataColumn("Title5"))
            .Columns.Add(New DataColumn("Title6"))
            .Columns.Add(New DataColumn("ClientNumber"))
            .Columns.Add(New DataColumn("Prefered", GetType(Boolean)))
        End With
    End Sub

    Public Sub AddTitleData()
        Dim dr As DataRow
        Dim filter As String = ""
        Dim val1, val2, val3, val4, val5, val6, clientNum As String
        Dim FoundRow As DataRow()
        val1 = Me.txtTitle1.Text
        val2 = Me.txtTitle2.Text
        val3 = Me.txtTitle3.Text
        val4 = Me.txtTitle4.Text
        val5 = Me.txtTitle5.Text
        val6 = Me.txtTitle6.Text
        clientNum = Me.txtClientNum.Text
        If val1 = "" AndAlso val2 = "" AndAlso val3 = "" AndAlso val4 = "" AndAlso val5 = "" AndAlso val6 = "" AndAlso clientNum = "" Then
            Me.lblMsgBox.Text = "Cannot put empty value."
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.ajaxMsgBox.Show()
            Exit Sub
        End If
        filter = "Title1=" + Util.LimitTheString(val1) + " and " + _
                 "Title2=" + Util.LimitTheString(val2) + " and " + _
                 "Title3=" + Util.LimitTheString(val3) + " and " + _
                 "Title4=" + Util.LimitTheString(val4) + " and " + _
                 "Title5=" + Util.LimitTheString(val5) + " and " + _
                 "Title6=" + Util.LimitTheString(val6) + " and " + _
                 "ClientNumber=" + Util.LimitTheString(clientNum)
        FoundRow = Me.UcTable.Select(Filter)
        If FoundRow IsNot Nothing AndAlso FoundRow.Length > 0 Then
            Me.lblMsgBox.Text = "Cannot add duplicated value."
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.ajaxMsgBox.Show()
            Exit Sub
        End If
        dr = Me.UcTable.NewRow()
        If Me.UcTable.Rows.Count > 0 Then
            dr("ItemNo") = Util.DBNullToZero(Me.UcTable.Rows(Me.UcTable.Rows.Count - 1).Item("ItemNo") + 1)
        Else
            dr("ItemNo") = 1
        End If
        dr("Title1") = Me.txtTitle1.Text
        dr("Title2") = Me.txtTitle2.Text
        dr("Title3") = Me.txtTitle3.Text
        dr("Title4") = Me.txtTitle4.Text
        dr("Title5") = Me.txtTitle5.Text
        dr("Title6") = "P/" + Me.txtTitle6.Text
        dr("ClientNumber") = Me.txtClientNum.Text
        'dr("Prefered") = Me.chkPrefered.Checked
        Me.UcTable.Rows.Add(dr)
    End Sub

    Private Sub LoadNewData()
        Me.txtItemNo.Value = ""
        Me.txtTitle1.Text = ""
        Me.txtTitle2.Text = ""
        Me.txtTitle3.Text = ""
        Me.txtTitle4.Text = ""
        Me.txtTitle5.Text = ""
        Me.txtTitle6.Text = ""
        Me.txtClientNum.Text = ""
        'Me.chkPrefered.Checked = False
        Me.btnSave.Text = "Add"
    End Sub

    Private Sub LoadData(ByVal ItemNo As String)
        Dim dr As DataRow()
        Dim str1, str2 As String()
        Dim filter As String = ""
        Me.btnSave.Text = "Update"
        filter = "ItemNo=" + Util.LimitTheString(ItemNo)
        dr = Me.UcTable.Select(filter)
        If dr IsNot Nothing AndAlso dr.Length > 0 Then
            Me.txtItemNo.Value = ItemNo
            Me.txtTitle1.Text = dr(0).Item("Title1").ToString
            Me.txtTitle2.Text = dr(0).Item("Title2").ToString
            Me.txtTitle3.Text = dr(0).Item("Title3").ToString
            Me.txtTitle4.Text = dr(0).Item("Title4").ToString
            Me.txtTitle5.Text = dr(0).Item("Title5").ToString
            str1 = Util.DBNullToText(dr(0).Item("Title6")).Split("P"c)
            If str1.Length > 1 Then
                str2 = Util.DBNullToText(str1.GetValue(1)).Split("/"c)
                If str2.Length > 1 Then
                    Me.txtTitle6.Text = str2.GetValue(1)
                Else
                    Me.txtTitle6.Text = str2.GetValue(0)
                End If

            Else
                str2 = Util.DBNullToText(str1.GetValue(0)).Split("/"c)
                Me.txtTitle6.Text = str2.GetValue(0)
            End If
           
            Me.txtClientNum.Text = dr(0).Item("ClientNumber").ToString
            ' Me.chkPrefered.Checked = CBool(dr(0).Item("Prefered"))
        End If
    End Sub

    Public Sub LoadDataFromDB(ByVal dt As DataTable, ByVal IsDelivery As Boolean, ByVal ClientID As String, Optional ByVal SameAsBilling As Boolean = False)
        Dim pxName As String
        Dim r As DataRow

        If dt.Rows.Count <= 0 Then
            Exit Sub
        End If
        If Not IsDelivery Then
            pxName = "BillingAddr"
        Else
            pxName = "DeliveryAddr"
            r = dt.Rows(0)
            If SameAsBilling Then
                Exit Sub
            End If
        End If
        If Me.UcTable Is Nothing Then
            Call Me.CreateTitleTable()
        End If
        Dim dr As DataRow
        For i As Integer = 0 To dt.Rows.Count - 1
            r = dt.Rows(i)
            dr = Me.UcTable.NewRow()
            If Me.UcTable.Rows.Count > 0 Then
                dr("ItemNo") = Util.DBNullToZero(Me.UcTable.Rows(Me.UcTable.Rows.Count - 1).Item("ItemNo") + 1)
            Else
                dr("ItemNo") = 1
            End If
            If pxName.Equals("BillingAddr") Then
                dr("Title1") = r("Title").ToString
                dr("Title2") = r(pxName + "1").ToString
                dr("Title3") = r(pxName + "2").ToString
                dr("Title4") = r(pxName + "3").ToString
                dr("Title5") = r(pxName + "4").ToString
                dr("Title6") = r(pxName + "5").ToString
                dr("ClientNumber") = r("ClientNumber").ToString
                '  dr("Prefered") = IIf(IsDBNull(r("Preferred")), False, CBool(r("Preferred")))
            Else
                dr("Title1") = r(pxName + "1").ToString
                dr("Title2") = r(pxName + "2").ToString
                dr("Title3") = r(pxName + "3").ToString
                dr("Title4") = r(pxName + "4").ToString
                dr("Title5") = r(pxName + "5").ToString
                dr("Title6") = r(pxName + "6").ToString
                dr("ClientNumber") = r("ClientNumber").ToString
                ' dr("Prefered") = IIf(IsDBNull(r("Preferred")), False, CBool(r("Preferred")))
            End If

            'Me.txtClientNum.Text = ClientID.ToString
            Me.UcTable.Rows.Add(dr)
        Next
        Call Me.RefreshGrid()
    End Sub

    Private Sub RemoveTitle1Data(ByVal ItemNo As String)
        Dim dr As DataRow()
        Dim filter As String = ""
        filter = "ItemNo=" + Util.LimitTheString(ItemNo)
        dr = Me.UcTable.Select(filter)
        If dr IsNot Nothing AndAlso dr.Length > 0 Then
            Me.UcTable.Rows.Remove(dr(0))
        End If
    End Sub

    Private Sub UpdateData(ByVal ItemNo As String)
        Dim dr As DataRow()
        Dim filter As String = ""
        Dim val1, val2, val3, val4, val5, val6, clientNum As String
        Dim FoundRow As DataRow()
        val1 = Me.txtTitle1.Text
        val2 = Me.txtTitle2.Text
        val3 = Me.txtTitle3.Text
        val4 = Me.txtTitle4.Text
        val5 = Me.txtTitle5.Text
        val6 = Me.txtTitle6.Text
        clientNum = Me.txtClientNum.Text
        If val1 = "" AndAlso val2 = "" AndAlso val3 = "" AndAlso val4 = "" AndAlso val5 = "" AndAlso val6 = "" AndAlso clientNum = "" Then
            Me.lblMsgBox.Text = "Cannot put empty value."
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.ajaxMsgBox.Show()
            Exit Sub
        End If
        filter = "Title1=" + Util.LimitTheString(val1) + " and " + _
                 "Title2=" + Util.LimitTheString(val2) + " and " + _
                 "Title3=" + Util.LimitTheString(val3) + " and " + _
                 "Title4=" + Util.LimitTheString(val4) + " and " + _
                 "Title5=" + Util.LimitTheString(val5) + " and " + _
                 "Title6=" + Util.LimitTheString(val6) + " and " + _
                 "ClientNumber=" + Util.LimitTheString(clientNum) + " and ItemNo<>" + Util.LimitTheString(ItemNo)
        FoundRow = Me.UcTable.Select(filter)
        If FoundRow IsNot Nothing AndAlso FoundRow.Length > 0 Then
            Me.lblMsgBox.Text = "Cannot add duplicated value."
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.ajaxMsgBox.Show()
            Exit Sub
        End If
        filter = "ItemNo=" + Util.LimitTheString(ItemNo)
        dr = Me.UcTable.Select(filter)
        If dr IsNot Nothing AndAlso dr.Length > 0 Then
            dr(0).Item("Title1") = Me.txtTitle1.Text
            dr(0).Item("Title1") = Me.txtTitle1.Text
            dr(0).Item("Title2") = Me.txtTitle2.Text
            dr(0).Item("Title3") = Me.txtTitle3.Text
            dr(0).Item("Title4") = Me.txtTitle4.Text
            dr(0).Item("Title5") = Me.txtTitle5.Text
            dr(0).Item("Title6") = "P/" + Me.txtTitle6.Text
            dr(0).Item("ClientNumber") = Me.txtClientNum.Text
            ' dr(0).Item("Prefered") = Me.chkPrefered.Checked
        End If
    End Sub

    Private Sub RefreshGrid()
        Dim dv As New DataView()
        If Me.UcTable Is Nothing Then
            Call Me.CreateTitleTable()
        End If
        With dv
            .Table = Me.UcTable
            .Sort = "ItemNo"
        End With
        With Me.gdData
            .DataSource = Me.UcTable
            .DataBind()
        End With
        With Me.pgControl
            .GridID = Me.gdData.UniqueID
            .SetBindGrid()
        End With

        With dv
            .Table = Me.UcTable
            .Sort = "ItemNo"
        End With
        With Me.gdDataView
            .DataSource = Me.UcTable
            .DataBind()
        End With
        With Me.pgControl2
            .GridID = Me.gdDataView.UniqueID
            .SetBindGrid()
        End With
    End Sub

    Public Sub gdData_Command(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.CommandEventArgs)
        Select Case e.CommandName
            Case "delete"
                Call Me.RemoveTitle1Data(Util.DBNullToZero(e.CommandArgument))
            Case "edit"
                Call Me.LoadData(Util.DBNullToZero(e.CommandArgument))
        End Select
        Call Me.RefreshGrid()
        Call Me.AccessControl("Billing")
    End Sub

    Protected Sub btnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSave.Click
        Dim ItemNo As String = ""
        ItemNo = Me.txtItemNo.Value
        If ItemNo = "" Then
            Call Me.AddTitleData()
        Else
            Call Me.UpdateData(ItemNo)
        End If
        Call Me.RefreshGrid()
        Call Me.LoadNewData()
    End Sub

    Protected Sub btnCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        Call Me.LoadNewData()
    End Sub

    Protected Sub gdData_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gdData.RowDataBound
        Dim cwtLinkBtn As CWTCustomControls.CWTLinkButton
        cwtLinkBtn = TryCast(e.Row.FindControl("hrefDeleteItem"), CWTCustomControls.CWTLinkButton)
        If cwtLinkBtn IsNot Nothing Then
            cwtLinkBtn.Attributes.Add("onclick", "return confirm('This item will delete, continue?');")
        End If
    End Sub

End Class
@


1.1.1.1
log
@no message
@
text
@@
