head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.58;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.58;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@
Partial Class Web_Client_ucProductMF
    Inherits BaseUserControl

    Private BLL As BusinessLogicLayer.CompanyMFBLL
    Private BLL2 As BusinessLogicLayer.StaffBLL
    Private BLL3 As BusinessLogicLayer.tblFunctionBLL

    Public Property IsApplyStd() As Boolean
        Get
            Return Me.ViewState("_IsApplyStd")
        End Get
        Set(ByVal value As Boolean)
            Me.ViewState("_IsApplyStd") = value
        End Set
    End Property

    Public Event OnSaveSuccess(ByVal sender As Object, ByVal e As BaseEventArgs)
    Public Event OnSaveFailed(ByVal sender As Object, ByVal e As BaseEventArgs)

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.BLL = New BusinessLogicLayer.CompanyMFBLL()
        Me.BLL2 = New BusinessLogicLayer.StaffBLL()
        Me.BLL3 = New BusinessLogicLayer.tblFunctionBLL()
        If Not IsPostBack Then
            Me.gdData.AllowPaging = False
            Call Me.PreLoadFromDB()
        End If
        Call Me.AccessControl("Merchant Fee/Product")
    End Sub

    Private Sub AccessControl(ByVal title As String)

        Dim userName As String
        Dim oDatatable As DataTable
        Dim oDataTable2 As DataTable

        Static roleID As String

        userName = ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName
        oDatatable = Me.BLL2.GetUserByID(userName)

        If oDatatable.Rows.Count > 0 Then
            roleID = oDatatable.Rows(0).Item("RoleID").ToString
        End If

        oDataTable2 = Me.BLL3.GetUserRole(roleID)
        If oDataTable2.Rows.Count > 0 Then
            For k As Integer = 0 To oDataTable2.Rows.Count - 1
                If oDataTable2.Rows(k).Item("functionGroup") = "1" Then
                    If oDataTable2.Rows(k).Item("Permission") = "V" Then
                        If oDataTable2.Rows(k).Item("functionName").ToString = title Then

                            Call Me.toggleControl()

                        End If
                    End If
                End If

            Next

        End If


    End Sub

    Private Sub toggleControl()
        
        Me.chkApplyStd.Enabled = False
       


        Me.btnTrans.ShowSaveNextButton = False
        Me.btnTrans.SaveButton.Enabled = False
    End Sub

    Private Sub SetPageData()
        Me.IsApplyStd = Me.chkApplyStd.Checked
        If Not Me.chkApplyStd.Checked Then
            Call Me.LoadDataFromDB()
        Else
            Call Me.LoadDefaultData()
        End If
    End Sub

    Private Sub LoadDefaultData()
        Dim oDataTable As DataTable
        oDataTable = Me.BLL.GetMFProductList()
        With Me.gdData
            .DataSource = oDataTable
            .DataBind()
        End With
    End Sub

    'Private Sub LoadDataFromDB()
    '    Dim oDataTable As DataTable
    '    oDataTable = Me.BLL.GetProduct()
    '    oDataTable.Columns.Add("SubjectToMF")
    '    For i As Integer = 0 To oDataTable.Rows.Count - 1
    '        oDataTable.Rows(i).Item("SubjectToMF") = False
    '    Next
    '    With Me.gdData
    '        .DataSource = oDataTable
    '        .DataBind()
    '    End With
    'End Sub
    Private Sub LoadDataFromDB()
        Dim oDataTable As DataTable
        oDataTable = Me.BLL.GetClientMFProduct(Me.CurrentClientID)
        With Me.gdData
            .DataSource = oDataTable
            .DataBind()
        End With
    End Sub

    Private Sub PreLoadFromDB()
        Dim IsApplyStd As Boolean = False
        IsApplyStd = Me.BLL.IsApplyStdMFProduct(Me.CurrentClientID)
        Me.chkApplyStd.Checked = IsApplyStd
        Call Me.SetPageData()
    End Sub

    Private Sub SaveData()
        Dim info As New DataInfo.CompanyMFInfo()
        Dim prod As DataInfo.ProductMFInfo
        Dim lb As CWTCustomControls.CWTLabel
        Dim cb As CWTCustomControls.CWTCheckBox
        With info
            .ClientID = Me.CurrentClientID
            .ApplyStdProduct = Me.chkApplyStd.Checked
            For i As Integer = 0 To Me.gdData.Rows.Count - 1
                prod = New DataInfo.ProductMFInfo()
                lb = Me.gdData.Rows(i).FindControl("lblProductCode")
                cb = Me.gdData.Rows(i).FindControl("chkSubjectToMF")
                prod.ProductCode = lb.Text
                prod.SubjectToMF = cb.Checked
                .ProductMF.Add(prod)
            Next
        End With
        Dim args As New BaseEventArgs()
        If Me.BLL.SaveMFProduct(info) > 0 Then
            Call Me.PreLoadFromDB()
            args.EventMessage = Util.GetAppConfig(Util.MsgType.TRANS_SUCCESS.ToString)
            RaiseEvent OnSaveSuccess(Me, args)
        Else
            args.EventMessage = Util.GetAppConfig(Util.MsgType.TRANS_ERROR.ToString)
            RaiseEvent OnSaveFailed(Me, args)
        End If
    End Sub

    Protected Sub btnTrans_OnSave(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans.OnSave
        Call Me.SaveData()
    End Sub

    Protected Sub btnTrans_OnCancel(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans.OnCancel
        Call Me.PreLoadFromDB()
    End Sub

    Protected Sub chkApplyStd_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkApplyStd.CheckedChanged
        Call Me.SetPageData()
    End Sub

    Protected Sub gdData_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gdData.RowDataBound
        Dim cb As CWTCustomControls.CWTCheckBox
        cb = e.Row.FindControl("chkSubjectToMF")
        If cb IsNot Nothing Then
            cb.Enabled = Not Me.IsApplyStd
        End If
    End Sub

End Class
@


1.1.1.1
log
@no message
@
text
@@
