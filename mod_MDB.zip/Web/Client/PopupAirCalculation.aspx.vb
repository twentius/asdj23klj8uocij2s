head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.57;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.57;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@
Partial Class Web_PopupAirCalculation
    Inherits BasePage

    Private BLL As BusinessLogicLayer.AirPricingBLL

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.BLL = New BusinessLogicLayer.AirPricingBLL()
        If Not IsPostBack Then
            Call Me.LoadDataGrid()
        End If
    End Sub

    Private Sub LoadDataGrid()
        Dim oDataTable As DataTable
        oDataTable = Me.BLL.GetAirPriceList()
        With Me.gdData
            .DataSource = oDataTable
            .DataBind()
        End With
        With Me.pgControl
            .GridID = Me.gdData.UniqueID
            .PageDataTable = oDataTable.Copy()
            .SetBindGrid()
        End With
    End Sub

    Protected Sub gdData_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles gdData.SelectedIndexChanged
        Dim sc As New StringBuilder()
        Dim id As String
        Dim name As String
        Dim hid As HiddenField
        hid = Me.gdData.SelectedRow.FindControl("hidItemID")
        id = hid.Value
        name = Me.gdData.SelectedRow.Cells(0).Text
        sc.AppendLine("setText('" + Util.JSEncode(id) + "','" + Util.JSEncode(name) + "');")
        Util.RegClientScript(sc.ToString, "AddValueFromPopup", Util.ClientScriptRegistType.RegStartUpBlock)
    End Sub

End Class








@


1.1.1.1
log
@no message
@
text
@@
