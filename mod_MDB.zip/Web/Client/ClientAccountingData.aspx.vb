head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.56;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.56;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@
Partial Class Web_Client_ClientAccountingData
    Inherits BasePage

    Private BLL As BusinessLogicLayer.CompanyAccountingBLL
    Private BLL2 As BusinessLogicLayer.StaffBLL
    Private BLL3 As BusinessLogicLayer.tblFunctionBLL


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.BLL = New BusinessLogicLayer.CompanyAccountingBLL()
        Me.BLL2 = New BusinessLogicLayer.StaffBLL()
        Me.BLL3 = New BusinessLogicLayer.tblFunctionBLL()
        If Not IsPostBack Then
            Call Me.LoadDivisionList()
            Call Me.LoadDataFromDB()
        End If
        Call Me.AccessControl("Accounting Data")
    End Sub

    Private Sub AccessControl(ByVal title As String)

        Dim userName As String
        Dim oDatatable As DataTable
        Dim oDataTable2 As DataTable

        Static roleID As String

        userName = ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName
        oDatatable = Me.BLL2.GetUserByID(userName)

        If oDatatable.Rows.Count > 0 Then
            roleID = oDatatable.Rows(0).Item("RoleID").ToString
        End If

        oDataTable2 = Me.BLL3.GetUserRole(roleID)
        If oDataTable2.Rows.Count > 0 Then
            For k As Integer = 0 To oDataTable2.Rows.Count - 1
                If oDataTable2.Rows(k).Item("functionGroup") = "1" Then
                    If oDataTable2.Rows(k).Item("Permission") = "V" Then
                        If oDataTable2.Rows(k).Item("functionName").ToString = title Then

                            Call Me.toggleControl()

                        End If
                    End If
                End If

            Next

        End If


    End Sub

    Private Sub toggleControl()
        Me.txtAccNoBiz.Readonly = True
        Me.txtAccNoLeisure.Readonly = True
        Me.txtAccNoMice.Readonly = True
        Me.ddlDivision.Enabled = False
        Me.txtFieldName1.Readonly = True
        Me.txtFieldName2.Readonly = True
        Me.txtFieldName3.Readonly = True
        Me.txtFieldName4.Readonly = True
        Me.txtFieldName5.Readonly = True
        Me.txtValue1.Readonly = True
        Me.txtValue2.Readonly = True
        Me.txtValue3.Readonly = True
        Me.txtValue4.Readonly = True
        Me.txtValue5.Readonly = True
        Me.rdAccNoBiz.Enabled = False
        Me.rdAccNoMice.Enabled = False
        Me.rdLeisure.Enabled = False


        Me.btnTrans.ShowSaveNextButton = False
        Me.btnTrans.SaveButton.Enabled = False
    End Sub

    Private Sub LoadDivisionList()
        Dim DivBLL As New BusinessLogicLayer.DivisionBLL()
        

        Dim oDataTable As DataTable
        oDataTable = DivBLL.GetDivisionList()
        With Me.ddlDivision
            .DataTextField = "DivisionDesc"
            .DataValueField = "DivisionID"
            .DataSource = oDataTable
            .DataBind()
            .Items.Insert(0, New ListItem(" ", ""))
        End With

    End Sub

    Private Sub LoadDataFromDB()
        Dim r As DataRow
        Dim pref As String = ""
        Dim oDataTable As DataTable
        oDataTable = Me.BLL.GetCompanyAccountingData(Me.CurrentClientID)
        If oDataTable IsNot Nothing AndAlso oDataTable.Rows.Count > 0 Then
            r = oDataTable.Rows(0)
            pref = r("PreferredAccountingNo").ToString
            Select Case pref
                Case "M"
                    Me.rdAccNoMice.Checked = True
                Case "L"
                    Me.rdLeisure.Checked = True
                Case Else
                    Me.rdAccNoBiz.Checked = True
            End Select
            Me.txtAccNoBiz.Text = r("ClientNumber").ToString
            Me.txtAccNoLeisure.Text = r("LeisureClientNo").ToString
            Me.txtAccNoMice.Text = r("MICEClientNo").ToString
            Me.ddlDivision.SelectedValue = r("DivisionNo").ToString
            Me.txtFieldName1.Text = r("AccountingField1").ToString
            Me.txtFieldName2.Text = r("AccountingField2").ToString
            Me.txtFieldName3.Text = r("AccountingField3").ToString
            Me.txtFieldName4.Text = r("AccountingField4").ToString
            Me.txtFieldName5.Text = r("AccountingField5").ToString
            Me.txtValue1.Text = r("AccountingValue1").ToString
            Me.txtValue2.Text = r("AccountingValue2").ToString
            Me.txtValue3.Text = r("AccountingValue3").ToString
            Me.txtValue4.Text = r("AccountingValue4").ToString
            Me.txtValue5.Text = r("AccountingValue5").ToString
        End If
    End Sub

    Private Sub SaveData(ByVal IsNext As Boolean)
        Dim info As New DataInfo.CompanyAccountingInfo()
        With info
            .PageMode = Me.CurrentPageMode
            .ClientID = Me.CurrentClientID
            If Me.rdAccNoBiz.Checked Then
                .PreferedAccType = DataInfo.CompanyAccountingInfo.AccountType.Business
            ElseIf Me.rdLeisure.Checked Then
                .PreferedAccType = DataInfo.CompanyAccountingInfo.AccountType.Leisure
            Else
                .PreferedAccType = DataInfo.CompanyAccountingInfo.AccountType.MICE
            End If
            .AccNoBiz = Me.txtAccNoBiz.Text
            .AccNoLeisure = Me.txtAccNoLeisure.Text
            .AccNoMice = Me.txtAccNoMice.Text
            .DivNo = Me.ddlDivision.SelectedValue
            .FieldName1 = Me.txtFieldName1.Text
            .FieldName2 = Me.txtFieldName2.Text
            .FieldName3 = Me.txtFieldName3.Text
            .FieldName4 = Me.txtFieldName4.Text
            .FieldName5 = Me.txtFieldName5.Text
            .FieldValue1 = Me.txtValue1.Text
            .FieldValue2 = Me.txtValue2.Text
            .FieldValue3 = Me.txtValue3.Text
            .FieldValue4 = Me.txtValue4.Text
            .FieldValue5 = Me.txtValue5.Text
        End With
        If Me.BLL.UpdateCompanyAccounting(info) > 0 Then
            Me.lblMsgBox.Text = Util.GetAppConfig(Util.MsgType.TRANS_SUCCESS.ToString)
            Me.lblMsgBox.ForeColor = Drawing.Color.Green
            Me.ajaxMsgBox.Show()
            If IsNext Then
                Response.Redirect("ReportConfigManager.aspx")
            End If
        Else
            Me.lblMsgBox.Text = Util.GetAppConfig(Util.MsgType.TRANS_ERROR.ToString)
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.ajaxMsgBox.Show()
        End If
    End Sub

    Protected Sub btnTrans_OnCancel(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans.OnCancel
        Response.Redirect("CompanySearch.aspx")
    End Sub

    Protected Sub btnTrans_OnSave(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans.OnSave
        Call Me.SaveData(False)
    End Sub

    Protected Sub btnTrans_OnSaveNext(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans.OnSaveNext
        Call Me.SaveData(True)
    End Sub

End Class
@


1.1.1.1
log
@no message
@
text
@@
