head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.57;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.57;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports System.Collections.Generic

Partial Class Web_Client_HighRiskDestination
    Inherits BasePage

    Private BLL As BusinessLogicLayer.HighRiskDestBLL
    Private BLL2 As BusinessLogicLayer.StaffBLL
    Private BLL3 As BusinessLogicLayer.tblFunctionBLL


    Public Property CityInfo() As DataInfo.PNRItemInfo
        Get
            Return Me.ViewState("_CityInfo")
        End Get
        Set(ByVal value As DataInfo.PNRItemInfo)
            Me.ViewState("_CityInfo") = value
        End Set
    End Property

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        BLL = New BusinessLogicLayer.HighRiskDestBLL()
        Me.BLL2 = New BusinessLogicLayer.StaffBLL()
        Me.BLL3 = New BusinessLogicLayer.tblFunctionBLL()
        If Not IsPostBack Then
            Me.CityInfo = New DataInfo.PNRItemInfo()
            Call Me.LoadDataFromDB()
            Call Me.RefreshGrid()
            Call Me.LoadDropdownList()
        End If
        Call Me.AccessControl("High Risk Cities")
    End Sub

    Private Sub AccessControl(ByVal title As String)

        Dim userName As String
        Dim oDatatable As DataTable
        Dim oDataTable2 As DataTable

        Static roleID As String

        userName = ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName
        oDatatable = Me.BLL2.GetUserByID(userName)

        If oDatatable.Rows.Count > 0 Then
            roleID = oDatatable.Rows(0).Item("RoleID").ToString
        End If

        oDataTable2 = Me.BLL3.GetUserRole(roleID)
        If oDataTable2.Rows.Count > 0 Then
            For k As Integer = 0 To oDataTable2.Rows.Count - 1
                If oDataTable2.Rows(k).Item("functionGroup") = "1" Then
                    If oDataTable2.Rows(k).Item("Permission") = "V" Then
                        If oDataTable2.Rows(k).Item("functionName").ToString = title Then

                            Call Me.toggleControl()

                        End If
                    End If
                End If

            Next

        End If


    End Sub

    Private Sub toggleControl()
        Me.ddlCities.Enabled = False
        Me.ddlCities2.Enabled = False
        Me.ddlCountry.Enabled = False
        Me.ddlCountry2.Enabled = False

        Me.btnAdd.Enabled = False
        Me.btnRemove.Enabled = False
        Me.btnRemoveAll.Enabled = False
        Me.btnSelAll.Enabled = False

        Me.btnTrans.ShowSaveNextButton = False
        Me.btnTrans.SaveButton.Enabled = False
    End Sub

    Private Sub LoadCountry()
        Dim BLL As New BusinessLogicLayer.ConfigurationBLL()
        Dim oDataTable As DataTable
        oDataTable = BLL.GetCountry()
        With Me.ddlCountry
            .DataTextField = "CountryName"
            .DataValueField = "CountryCode"
            .DataSource = oDataTable
            .DataBind()
        End With
        If Me.ddlCountry.Items.Count > 0 Then
            Call Me.LoadCity()
        End If
    End Sub

    Private Sub LoadCity()
        Dim BLL As New BusinessLogicLayer.ConfigurationBLL()
        Dim oDataTable As DataTable
        Dim CountryCode As String

        CountryCode = Me.ddlCountry.SelectedValue
        oDataTable = New DataTable()
        oDataTable = BLL.GetCity(CountryCode, "")
        With Me.ddlCities
            .DataTextField = "City"
            .DataValueField = "CityCode"
            If Me.CityInfo.CityString <> "" Then
                Dim vFilter As DataView
                vFilter = New DataView(oDataTable, "CityCode not in (" + Me.CityInfo.CityString + ")", "", DataViewRowState.CurrentRows)
                .DataSource = vFilter.ToTable()
            Else
                .DataSource = oDataTable
            End If
            .DataBind()
        End With
    End Sub

    Private Sub LoadDropdownList()
        Call Me.LoadCountry()
    End Sub

    Private Sub LoadDataFromDB()
        Dim dt As DataTable
        Dim r As DataRow
        Dim city As DataInfo.CityDataInfo
        dt = Me.BLL.GetHighRiskDestination(Me.CurrentClientID)
        If dt IsNot Nothing AndAlso dt.Rows.Count > 0 Then
            For i As Integer = 0 To dt.Rows.Count - 1
                r = dt.Rows(i)
                city = New DataInfo.CityDataInfo()
                city.LinkCountry.CountryCode = r("CountryCode").ToString()
                city.LinkCountry.CountryName = r("CountryName").ToString()
                city.CityCode = r("CityCode").ToString()
                city.CityName = r("City").ToString()
                Me.CityInfo.CitySelectedItems.Add(city)
            Next
        End If
    End Sub

    Private Sub RefreshGrid()
        Dim dt As DataTable
        Dim hash As New SortedList()
        Dim key As String = ""
        Dim val As String = ""
        For i As Integer = 0 To Me.CityInfo.CitySelectedItems.Count - 1
            key = Me.CityInfo.CitySelectedItems(i).LinkCountry.CountryName
            val = Me.CityInfo.CitySelectedItems(i).LinkCountry.CountryCode
            If hash.ContainsKey(key) Then
                Continue For
            End If
            hash.Add(key, val)
        Next
        Me.ddlCountry2.Items.Clear()
        Me.ddlCities2.Items.Clear()

        With Me.ddlCountry2
            .DataTextField = "Key"
            .DataValueField = "Value"
            .DataSource = hash
            .DataBind()
        End With
        dt = Me.CityInfo.ToCityTable(Me.ddlCountry2.SelectedValue)
        With Me.ddlCities2
            .DataTextField = "City"
            .DataValueField = "CityCode"
            .DataSource = dt
            .DataBind()
        End With
        If Me.ddlCountry2.Items.Count <= 0 Then
            Me.divCity.Visible = False
            Me.divEmpty.Visible = True
        Else
            Me.divCity.Visible = True
            Me.divEmpty.Visible = False
        End If
    End Sub

    Private Sub AddData()
        Dim RegionList As New List(Of String)
        Dim SelectedIndex() As Integer
        Dim itm As DataInfo.CityDataInfo
        SelectedIndex = Me.ddlCities.GetSelectedIndices
        If SelectedIndex.Length <= 0 Then
            Exit Sub
        End If
        For i As Integer = 0 To SelectedIndex.Length - 1
            itm = New DataInfo.CityDataInfo()
            With itm
                .LinkCountry.CountryCode = Me.ddlCountry.SelectedValue
                .LinkCountry.CountryName = Me.ddlCountry.SelectedItem.Text
                .CityCode = Me.ddlCities.Items(SelectedIndex(i)).Value
                .CityName = Me.ddlCities.Items(SelectedIndex(i)).Text
            End With
            Me.CityInfo.CitySelectedItems.Add(itm)
        Next
    End Sub

    Private Sub AddAllData()
        Dim CityList As New List(Of String)
        Dim itm As DataInfo.CityDataInfo
        If Me.ddlCities.Items.Count <= 0 Then
            Exit Sub
        End If
        For i As Integer = 0 To Me.ddlCities.Items.Count - 1
            itm = New DataInfo.CityDataInfo()
            With itm
                .LinkCountry.CountryCode = Me.ddlCountry.SelectedValue
                .LinkCountry.CountryName = Me.ddlCountry.SelectedItem.Text
                .CityCode = Me.ddlCities.Items(i).Value
                .CityName = Me.ddlCities.Items(i).Text
            End With
            Me.CityInfo.CitySelectedItems.Add(itm)
        Next
    End Sub

    Private Sub RemoveData()
        Dim RegionList As New List(Of String)
        Dim SelectedIndex() As Integer
        Dim index As Integer
        Dim CityCode As String
        SelectedIndex = Me.ddlCities2.GetSelectedIndices
        If SelectedIndex.Length <= 0 Then
            Exit Sub
        End If
        For i As Integer = 0 To SelectedIndex.Length - 1
            CityCode = Me.ddlCities2.Items(SelectedIndex(i)).Value
            index = Me.CityInfo.CityIndexOf(CityCode)
            Me.CityInfo.CitySelectedItems.RemoveAt(index)
        Next
    End Sub

    Private Sub RemoveAllData()
        Dim RegionList As New List(Of String)
        Dim index As Integer
        Dim CityCode As String
        If Me.ddlCities2.Items.Count <= 0 Then
            Exit Sub
        End If
        For i As Integer = 0 To Me.ddlCities2.Items.Count - 1
            CityCode = Me.ddlCities2.Items(i).Value
            index = Me.CityInfo.CityIndexOf(CityCode)
            Me.CityInfo.CitySelectedItems.RemoveAt(index)
        Next
    End Sub

    Private Sub UpdateData(ByVal IsNext As Boolean)
        Dim info As New DataInfo.HighRiskInfo()
        Dim des As DataInfo.DestinationInfo
        Dim r As DataRow
        Dim dt As DataTable
        dt = Me.CityInfo.ToCityTable
        With info
            .ClientID = Me.CurrentClientID
            For i As Integer = 0 To dt.Rows.Count - 1
                r = dt.Rows(i)
                des = New DataInfo.DestinationInfo()
                des.CityCode = r("CityCode").ToString
                des.CountryCode = r("CountryCode").ToString
                info.HighRiskDest.Add(des)
            Next
        End With
        If Me.BLL.UpdateHighRiskDest(info) > 0 Then
            Me.lblMsgBox.Text = Util.GetAppConfig(Util.MsgType.TRANS_SUCCESS.ToString)
            Me.lblMsgBox.ForeColor = Drawing.Color.Green
            Me.ajaxMsgBox.Show()
            If IsNext Then
                Response.Redirect("HotelPolicyManager.aspx")
            End If
        Else
            Me.lblMsgBox.Text = Util.GetAppConfig(Util.MsgType.TRANS_ERROR.ToString)
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.ajaxMsgBox.Show()
        End If
    End Sub

    Protected Sub ddlCountry_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlCountry.SelectedIndexChanged
        Call Me.LoadCity()
    End Sub

    Protected Sub ddlCountry2_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlCountry2.SelectedIndexChanged
        Dim dt As DataTable
        dt = Me.CityInfo.ToCityTable(Me.ddlCountry2.SelectedValue)
        With Me.ddlCities2
            .DataTextField = "City"
            .DataValueField = "CityCode"
            .DataSource = dt
            .DataBind()
        End With
    End Sub

    Protected Sub btnSelAll_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSelAll.Click
        Call Me.AddAllData()
        Call Me.RefreshGrid()
        Call Me.LoadCity()
    End Sub

    Protected Sub btnAdd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnAdd.Click
        Call Me.AddData()
        Call Me.RefreshGrid()
        Call Me.LoadCity()
    End Sub

    Protected Sub btnRemove_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnRemove.Click
        Call Me.RemoveData()
        Call Me.RefreshGrid()
        Call Me.LoadCity()
    End Sub

    Protected Sub btnRemoveAll_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnRemoveAll.Click
        Call Me.RemoveAllData()
        Call Me.RefreshGrid()
        Call Me.LoadCity()
    End Sub

    Protected Sub btnTrans_OnCancel(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans.OnCancel
        Response.Redirect("CompanySearch.aspx")
    End Sub

    Protected Sub btnTrans_OnSave(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans.OnSave
        Call Me.UpdateData(False)
    End Sub

    Protected Sub btnTrans_OnSaveNext(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans.OnSaveNext
        Call Me.UpdateData(True)
    End Sub

End Class












@


1.1.1.1
log
@no message
@
text
@@
