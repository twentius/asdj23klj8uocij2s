head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.55;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.55;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@
Partial Class Web_Client_AuxPricingManager
    Inherits BasePage

#Region "Page Properties & Variables"
    Private BLL As BusinessLogicLayer.ClientAuxPricingBLL

    Private Property ClassTable() As DataTable
        Get
            Return Me.ViewState("_ClassTable")
        End Get
        Set(ByVal value As DataTable)
            Me.ViewState("_ClassTable") = value
        End Set
    End Property
#End Region

#Region "Page Event Handlers & Methods"
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.BLL = New BusinessLogicLayer.ClientAuxPricingBLL()
        If Not IsPostBack Then
            Call Me.LoadProductList()
            Call Me.CreateTable()
            Call Me.LoadDataFromDB()
            Call Me.LoadNewData()
        End If
    End Sub

    Private Sub CreateTable()
        Call Me.CreateClassTable()
    End Sub
#End Region

#Region "Class sub routine"
    Private Sub CreateClassTable()
        Me.ClassTable = New DataTable("ClassTable")
        With Me.ClassTable
            .Columns.Add(New DataColumn("ItemNo", GetType(Integer)))
            .Columns.Add(New DataColumn("AuxFeeID"))
            .Columns.Add(New DataColumn("ApplytoProduct"))
            .Columns.Add(New DataColumn("ApplytoProductName"))
            .Columns.Add(New DataColumn("FeeName"))
            .Columns.Add(New DataColumn("FeeAmount"))
            .Columns.Add(New DataColumn("FeeProductName"))
        End With
    End Sub

    Private Sub LoadProductList()
        Dim oDataTable As DataTable
        oDataTable = Me.BLL.GetProductList()
        If oDataTable Is Nothing OrElse oDataTable.Rows.Count <= 0 Then
            Me.lblMsgBox.Text = "Must create at least one aux fee."
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.ajaxMsgBox.Show()
            Me.tblAuxPricing.Visible = False
            'Response.Redirect(Util.GetAppConfig("RootPath") + "/CWT/AuxFeeUpdateManager.aspx?mode=add", True)
            Exit Sub
        End If
        With Me.ddlProduct
            .DataTextField = "Name"
            .DataValueField = "Number"
            .DataSource = oDataTable
            .DataBind()
        End With
        Call Me.LoadFeeList()
    End Sub

    Private Sub LoadFeeList()
        Dim oDataTable As DataTable
        Dim ProductID As String
        ProductID = Me.ddlProduct.SelectedValue
        oDataTable = Me.BLL.GetAuxPricingList(ProductID)
        With Me.ddlFeeName
            .DataTextField = "FeeName"
            .DataValueField = "AuxFeeID"
            .DataSource = oDataTable
            .DataBind()
        End With
        Call Me.LoadFeeData()
    End Sub

    Private Sub LoadFeeData()
        Dim oDataTable As DataTable
        Dim FeeID As String
        FeeID = Me.ddlFeeName.SelectedValue
        oDataTable = Me.BLL.GetAuxPricingByID(FeeID)
        If oDataTable IsNot Nothing AndAlso oDataTable.Rows.Count > 0 Then
            Me.lblFeeAmount.Text = Util.DBNullToZero(oDataTable.Rows(0).Item("FeeAmount"))
            Me.lblFeeProduct.Text = oDataTable.Rows(0).Item("FeeProductName").ToString
        End If
    End Sub

    Private Sub AddClassData()
        Dim dr As DataRow
        Dim oRow As DataRow()
        Dim filter As String
        Dim FeeID As String
        FeeID = Me.ddlFeeName.SelectedValue
        filter = "AuxFeeID=" + FeeID
        oRow = Me.ClassTable.Select(filter)
        If oRow Is Nothing OrElse oRow.Length = 0 Then
            dr = Me.ClassTable.NewRow()
            If Me.ClassTable.Rows.Count > 0 Then
                dr("ItemNo") = Util.DBNullToZero(Me.ClassTable.Rows(Me.ClassTable.Rows.Count - 1).Item("ItemNo") + 1)
            Else
                dr("ItemNo") = 1
            End If
            dr("AuxFeeID") = Me.ddlFeeName.SelectedValue
            dr("ApplytoProduct") = Me.ddlProduct.SelectedValue
            dr("ApplytoProductName") = Me.ddlProduct.SelectedItem.Text
            dr("FeeName") = Me.ddlFeeName.SelectedItem.Text
            dr("FeeAmount") = Me.lblFeeAmount.Text
            dr("FeeProductName") = Me.lblFeeProduct.Text
            Me.ClassTable.Rows.Add(dr)
        Else
            Me.lblMsgBox.Text = "Cannot add duplicated fee."
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.ajaxMsgBox.Show()
        End If
    End Sub

    Private Sub LoadClassData(ByVal ItemNo As String)
        On Error Resume Next
        Dim dr As DataRow()
        Dim filter As String = ""
        filter = "ItemNo=" + Util.LimitTheString(ItemNo)
        dr = Me.ClassTable.Select(filter)
        If dr IsNot Nothing AndAlso dr.Length > 0 Then
            Me.txtItemNo.Value = ItemNo
            Me.ddlProduct.SelectedValue = dr(0).Item("ApplytoProduct").ToString
            Me.ddlFeeName.SelectedValue = dr(0).Item("AuxFeeID").ToString
            Call Me.LoadFeeData()
        End If
    End Sub

    Private Sub LoadClassDataFromDB()
        Dim oDataTable As DataTable
        Dim oRow As DataRow
        Dim dr As DataRow
        Try
            oDataTable = Me.BLL.GetAuxClientFee(Me.CurrentClientID)
            If oDataTable IsNot Nothing Then
                For i As Integer = 0 To oDataTable.Rows.Count - 1
                    oRow = oDataTable.Rows(i)
                    dr = Me.ClassTable.NewRow()
                    If Me.ClassTable.Rows.Count > 0 Then
                        dr("ItemNo") = Util.DBNullToZero(Me.ClassTable.Rows(Me.ClassTable.Rows.Count - 1).Item("ItemNo") + 1)
                    Else
                        dr("ItemNo") = 1
                    End If

                    dr("AuxFeeID") = oRow("AuxFeeID").ToString
                    dr("ApplytoProduct") = oRow("ApplytoProduct").ToString
                    dr("ApplytoProductName") = oRow("ProductName").ToString
                    dr("FeeName") = oRow("FeeName").ToString
                    dr("FeeAmount") = oRow("FeeAmount").ToString
                    dr("FeeProductName") = oRow("FeeProductName").ToString

                    Me.ClassTable.Rows.Add(dr)
                Next
                Call Me.RefreshClassGrid()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub RemoveClassData(ByVal ItemNo As String)
        Dim dr As DataRow()
        Dim filter As String = ""
        filter = "ItemNo=" + Util.LimitTheString(ItemNo)
        dr = Me.ClassTable.Select(filter)
        If dr IsNot Nothing AndAlso dr.Length > 0 Then
            Me.ClassTable.Rows.Remove(dr(0))
        End If
    End Sub

    Private Sub UpdateClassData(ByVal ItemNo As String)
        Dim dr As DataRow()
        Dim filter As String = ""
        filter = "ItemNo=" + Util.LimitTheString(ItemNo)
        dr = Me.ClassTable.Select(filter)
        If dr IsNot Nothing AndAlso dr.Length > 0 Then
            dr(0).Item("AuxFeeID") = Me.ddlFeeName.SelectedValue
            dr(0).Item("ApplytoProduct") = Me.ddlProduct.SelectedValue
            dr(0).Item("ApplytoProductName") = Me.ddlProduct.SelectedItem.Text
            dr(0).Item("FeeName") = Me.ddlFeeName.SelectedItem.Text
            dr(0).Item("FeeAmount") = Me.lblFeeAmount.Text
            dr(0).Item("FeeProductName") = Me.lblFeeProduct.Text
        End If
    End Sub

    Private Sub RefreshClassGrid()
        Dim dv As New DataView()
        With dv
            .Table = Me.ClassTable
            .Sort = "ItemNo"
        End With
        With Me.gdDataClass
            .DataSource = dv.ToTable()
            .DataBind()
        End With
    End Sub

    Public Sub gdDataClass_Command(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.CommandEventArgs)
        Select Case e.CommandName
            Case "delete"
                Call Me.RemoveClassData(Util.DBNullToZero(e.CommandArgument))
            Case "edit"
                Call Me.LoadClassData(Util.DBNullToZero(e.CommandArgument))
                Me.btnSave.Text = "Update"
        End Select
        Call Me.RefreshClassGrid()
    End Sub

    Protected Sub btnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSave.Click
        Dim ItemNo As String = ""
        ItemNo = Me.txtItemNo.Value
        If ItemNo = "" Then
            Call Me.AddClassData()
        Else
            Call Me.UpdateClassData(ItemNo)
        End If
        Call Me.RefreshClassGrid()
        Call Me.LoadNewData()
    End Sub

    Protected Sub btnCancel2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        Call Me.LoadNewData()
    End Sub
#End Region

#Region "Data Binding"
    Private Sub LoadNewData()
        Me.txtItemNo.Value = ""
        Me.lblFeeProduct.Text = ""
        Me.lblFeeAmount.Text = ""
        Me.ddlProduct.SelectedIndex = -1
        Call Me.LoadFeeList()
        Me.btnSave.Text = "Add"
    End Sub

    Private Sub LoadDataFromDB()
        Call Me.LoadClassDataFromDB()
    End Sub
#End Region

#Region "Data Transaction"
    Private Sub SaveData(ByVal IsNext As Boolean)
        Dim info As New DataInfo.ClientAuxPricingInfo()
        Dim r As DataRow
        With info
            .ClientID = Me.CurrentClientID
            For i As Integer = 0 To Me.ClassTable.Rows.Count - 1
                r = Me.ClassTable.Rows(i)
                .AuxFeeList.Add(r("AuxFeeID").ToString)
            Next
        End With
        If Me.BLL.UpdateAuxClientFee(info) > 0 Then
            Me.lblMsgBox.Text = Util.GetAppConfig(Util.MsgType.TRANS_SUCCESS.ToString)
            Me.lblMsgBox.ForeColor = Drawing.Color.Green
            Me.ajaxMsgBox.Show()
            If IsNext Then
                Response.Redirect("SLAManager.aspx")
            End If
        Else
            Me.lblMsgBox.Text = Util.GetAppConfig(Util.MsgType.TRANS_ERROR.ToString)
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.ajaxMsgBox.Show()
        End If
    End Sub
#End Region

#Region "Page Control Event Handlers"
    Protected Sub ddlProduct_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlProduct.SelectedIndexChanged
        Call Me.LoadFeeList()
    End Sub

    Protected Sub ddlFeeName_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlFeeName.SelectedIndexChanged
        Call Me.LoadFeeData()
    End Sub

    Protected Sub btnTrans_OnCancel(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans.OnCancel
        Response.Redirect("CompanySearch.aspx")
    End Sub

    Protected Sub btnTrans_OnSave(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans.OnSave
        Call Me.SaveData(False)
    End Sub

    Protected Sub btnTrans_OnSaveNext(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans.OnSaveNext
        Call Me.SaveData(True)
    End Sub
#End Region

End Class
@


1.1.1.1
log
@no message
@
text
@@
