head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.56;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.56;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Partial Public Class CompanyAuxFee
    Inherits BasePage

    Private BLL As BusinessLogicLayer.CompanyAuxPriceBLL
    Private AuxPriceBLL As BusinessLogicLayer.AuxPricingBLL
    Private BLL2 As BusinessLogicLayer.StaffBLL
    Private BLL3 As BusinessLogicLayer.tblFunctionBLL

    'Private Property PageDataSet() As DataSet
    '    Get
    '        Return Me.ViewState("PageDataSet")
    '    End Get
    '    Set(ByVal value As DataSet)
    '        Me.ViewState("PageDataSet") = value
    '    End Set
    'End Property

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.BLL = New BusinessLogicLayer.CompanyAuxPriceBLL()
        Me.AuxPriceBLL = New BusinessLogicLayer.AuxPricingBLL()
        Me.BLL2 = New BusinessLogicLayer.StaffBLL()
        Me.BLL3 = New BusinessLogicLayer.tblFunctionBLL()
        If Not IsPostBack Then
            'Me.PageDataSet = New DataSet("PageDataSet")
            Call Me.LoadDropDownList()
            '//
            'Call Me.LoadAllFee()
            'Call Me.LoadItemList()
            '//
            Call Me.LoadDataGrid()
            Call Me.LoadSelectedGrid()
        End If
        Call Me.AccessControl("Aux")
    End Sub

    Private Sub AccessControl(ByVal title As String)

        Dim userName As String
        Dim oDatatable As DataTable
        Dim oDataTable2 As DataTable

        Static roleID As String

        userName = ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName
        oDatatable = Me.BLL2.GetUserByID(userName)

        If oDatatable.Rows.Count > 0 Then
            roleID = oDatatable.Rows(0).Item("RoleID").ToString
        End If

        oDataTable2 = Me.BLL3.GetUserRole(roleID)
        If oDataTable2.Rows.Count > 0 Then
            For k As Integer = 0 To oDataTable2.Rows.Count - 1
                If oDataTable2.Rows(k).Item("functionGroup") = "1" Then
                    If oDataTable2.Rows(k).Item("Permission") = "V" Then
                        If oDataTable2.Rows(k).Item("ParentID").ToString = "PR" Then
                            If oDataTable2.Rows(k).Item("functionName").ToString = title Then

                                Call Me.toggleControl()
                            End If
                        End If

                    End If
                End If

            Next

        End If


    End Sub

    Private Sub toggleControl()
        

        'Dim btnDelete As CWTCustomControls.CWTLinkButton
        Me.gdData.Visible = False
        Me.tblPgPro.Visible = False
        Me.gdView.Visible = True
        Me.tblPgPro2.Visible = True
        
        Me.gdDataClass.Visible = False
        Me.tblPg.Visible = False
        Me.gdDataView.Visible = True
        Me.tblPg2.Visible = True
        'For i As Integer = 0 To Me.gdDataClass.Rows.Count - 1
        '    btnDelete = Me.gdDataClass.Rows(i).FindControl("hrefDeleteItem")
        '    btnDelete.Enabled = False

        'Next

        Me.btnAdd2.Enabled = False

    End Sub

    Private Sub LoadDropDownList()
        Dim oDataTable As DataTable
        oDataTable = Me.AuxPriceBLL.GetProductList()
        With Me.ddlProduct
            .DataTextField = "Name"
            .DataValueField = "Number"
            .DataSource = oDataTable
            .DataBind()
            .Items.Insert(0, New ListItem("All", ""))
            .SelectedIndex = 0
        End With
    End Sub

    Private Sub LoadDataGrid()
        Dim oDataTable As DataTable
        oDataTable = Me.BLL.GetAuxPricingList(Me.CurrentClientID, Me.txtFeeName.Text, Me.ddlProduct.SelectedValue)
        With Me.gdData
            .DataSource = oDataTable
            .DataBind()
        End With
        With Me.pgControl
            .GridID = Me.gdData.UniqueID
            .SetBindGrid()
        End With
    End Sub

    Private Sub LoadSelectedGrid()
        Dim oDataTable As DataTable
        oDataTable = Me.BLL.GetSelectedAuxPricingByID(Me.CurrentClientID)
        With Me.gdDataClass
            .DataSource = oDataTable
            .DataBind()
        End With
        With Me.pgControl2
            .GridID = Me.gdDataClass.UniqueID
            .SetBindGrid()
        End With

        With Me.gdDataView
            .DataSource = oDataTable
            .DataBind()
        End With
        With Me.pgControlCL
            .GridID = Me.gdDataView.UniqueID
            .SetBindGrid()
        End With
    End Sub

    'Private Sub LoadAllFee()
    '    Dim oDataTable As DataTable
    '    oDataTable = Me.AuxPriceBLL.GetAuxPricingList("", "")
    '    oDataTable.TableName = "AllFee"
    '    Me.PageDataSet.Tables.Add(oDataTable)
    'End Sub

    'Private Sub LoadItemList()
    '    '//
    '    Dim oDataTable As DataTable
    '    oDataTable = Me.BLL.GetSelectedAuxPricingByID(Me.CurrentClientID)
    '    'If oDataTable IsNot Nothing AndAlso oDataTable.Rows.Count > 0 Then
    '    oDataTable.TableName = "ItemList"
    '    'Me.PageDataSet.Tables.Add(oDataTable)
    '    'Else
    '    '    Call Me.CreateChildTable()
    '    'End If
    'End Sub

    'Private Sub CreateChildTable()
    '    Dim oDataTable As DataTable = New DataTable("ItemList")
    '    With oDataTable
    '        .Columns.Add(New DataColumn("AuxClientFeeID", GetType(Integer)))
    '        .Columns.Add(New DataColumn("AuxFeeID", GetType(Integer)))
    '    End With
    '    Me.PageDataSet.Tables.Add(oDataTable)
    'End Sub

    'Private Sub AddSelectedItems()
    '    Dim dt As DataTable
    '    Dim dr As DataRow
    '    Dim chk As CWTCustomControls.CWTCheckBox
    '    dt = Me.PageDataSet.Tables("ItemList")
    '    For i As Integer = 0 To Me.gdDataClass.Rows.Count - 1
    '        chk = Me.gdDataClass.Rows(i).FindControl("chkSelect")
    '        If chk.Checked = False Then
    '            Continue For
    '        End If
    '        dr = dt.NewRow()
    '        If dt.Rows.Count > 0 Then
    '            dr("AuxClientFeeID") = Util.DBNullToZero(dt.Rows(dt.Rows.Count - 1).Item("AuxClientFeeID") + 1)
    '        Else
    '            dr("AuxClientFeeID") = 1
    '        End If
    '        dr("AuxFeeID") = Util.DBNullToZero(Me.gdDataClass.Rows(i).Cells(0).Text)
    '        dt.Rows.Add(dr)
    '    Next
    'End Sub

    'Private Sub RemoveItemData(ByVal AuxFeeID As String)
    '    Dim dt As DataTable
    '    Dim dr As DataRow()
    '    Dim filter As String = ""
    '    dt = Me.PageDataSet.Tables("ItemList")
    '    filter = "AuxFeeID=" + Util.LimitTheString(AuxFeeID)
    '    dr = dt.Select(filter)
    '    If dr IsNot Nothing AndAlso dr.Length > 0 Then
    '        dt.Rows.Remove(dr(0))
    '    End If

    'End Sub

    'Private Function GetJoinTable() As DataTable
    '    Dim dt As DataTable = Nothing
    '    Dim parentTbl As DataTable
    '    Dim childTbl As DataTable
    '    Dim pr As DataRow
    '    Dim JoinName As String
    '    JoinName = "InnerJoin"
    '    parentTbl = Me.PageDataSet.Tables("AllFee")
    '    childTbl = Me.PageDataSet.Tables("ItemList")
    '    Dim dr As DataRow
    '    Dim relate As DataRelation
    '    relate = New DataRelation(JoinName, parentTbl.Columns("AuxFeeID"), childTbl.Columns("AuxFeeID"))
    '    '//
    '    dt = childTbl.Clone()
    '    dt.Columns.Add(New DataColumn("FeeName", parentTbl.Columns("FeeName").DataType))
    '    For i As Integer = 0 To childTbl.Rows.Count - 1
    '        pr = childTbl.Rows(i).GetParentRow(JoinName)
    '        dr = dt.NewRow()
    '        For j As Integer = 0 To childTbl.Columns.Count - 1
    '            dr(j) = childTbl.Rows(i).Item(j)
    '        Next
    '        '//
    '        dr("FeeName") = pr("FeeName")
    '        '//
    '        dt.Rows.Add(dr)
    '    Next
    '    Return dt
    'End Function

    Private Sub AddItems()
        Dim hid As HiddenField
        Dim chk As CWTCustomControls.CWTCheckBox
        Dim ItemList As New List(Of String)
        For i As Integer = 0 To Me.gdData.Rows.Count - 1
            chk = Me.gdData.Rows(i).FindControl("chkSelect")
            If chk.Checked = False Then
                Continue For
            End If
            hid = Me.gdData.Rows(i).FindControl("hidAuxFeeID")
            ItemList.Add(hid.Value)
        Next
        '//
        Call Me.BLL.UpdateSelectedItem(Me.CurrentClientID, ItemList)
        '//
        Call Me.LoadDataGrid()
        Call Me.LoadSelectedGrid()
    End Sub

    Private Sub DeleteItem(ByVal AuxFeeID As String)
        Call Me.BLL.DeleteItem(Me.CurrentClientID, AuxFeeID)
        '//
        Call Me.LoadDataGrid()
        Call Me.LoadSelectedGrid()
    End Sub

    Protected Sub btnSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSearch.Click
        Call Me.LoadDataGrid()
        Call Me.AccessControl("Aux")
    End Sub

    Private Sub btnAdd2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnAdd2.Click
        'Call Me.AddSelectedItems()
        Call Me.AddItems()
        Call Me.LoadSelectedGrid()
    End Sub

    Public Sub gdDataClass_Command(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.CommandEventArgs)
        Select Case e.CommandName
            Case "delete"
                Call Me.DeleteItem(Util.DBNullToZero(e.CommandArgument))
                'Call Me.RemoveItemData(Util.DBNullToZero(e.CommandArgument))
        End Select
        Call Me.LoadSelectedGrid()
    End Sub

    Protected Sub btnNextStep_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnNextStep.Click
        Response.Redirect("SLAManager.aspx", True)
    End Sub

    Private Sub gdDataClass_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gdDataClass.RowDataBound
        Dim cwtLinkBtn As CWTCustomControls.CWTLinkButton
        cwtLinkBtn = TryCast(e.Row.FindControl("hrefDeleteItem"), CWTCustomControls.CWTLinkButton)
        If cwtLinkBtn IsNot Nothing Then
            cwtLinkBtn.Attributes.Add("onclick", "return confirm('Item will delete, continue?');")
        End If
    End Sub

End Class

























@


1.1.1.1
log
@no message
@
text
@@
