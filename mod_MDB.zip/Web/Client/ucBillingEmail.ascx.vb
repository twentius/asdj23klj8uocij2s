head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.58;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.58;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@
Partial Class Web_Client_ucBillingEmail
    Inherits BaseUserControl

    Private BLL2 As BusinessLogicLayer.StaffBLL
    Private BLL3 As BusinessLogicLayer.tblFunctionBLL

    Public Property RecordID() As String
        Get
            Dim retVal As String = ""
            If Me.ViewState("_RecordID") IsNot Nothing Then
                retVal = Me.ViewState("_RecordID").ToString
            End If
            Return retVal
        End Get
        Set(ByVal value As String)
            Me.ViewState("_RecordID") = value
        End Set
    End Property

    Public ReadOnly Property RequestMode() As String
        Get
            Dim retVal As String = ""
            If Me.Request("mode") IsNot Nothing Then
                retVal = Me.Request("mode")
            End If
            Return retVal
        End Get
    End Property

    Public Property UcTable() As DataTable
        Get
            Return Me.ViewState("_EmailTable")
        End Get
        Set(ByVal value As DataTable)
            Me.ViewState("_EmailTable") = value
        End Set
    End Property

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.BLL2 = New BusinessLogicLayer.StaffBLL()
        Me.BLL3 = New BusinessLogicLayer.tblFunctionBLL()
        If Not IsPostBack Then
            'Call Me.CreateEmailTable()
        Else
            Me.RefreshGrid()
        End If
        Call Me.AccessControl("Billing")
    End Sub

    Private Sub AccessControl(ByVal title As String)

        Dim userName As String
        Dim oDatatable As DataTable
        Dim oDataTable2 As DataTable

        Static roleID As String

        userName = ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName
        oDatatable = Me.BLL2.GetUserByID(userName)

        If oDatatable.Rows.Count > 0 Then
            roleID = oDatatable.Rows(0).Item("RoleID").ToString
        End If

        oDataTable2 = Me.BLL3.GetUserRole(roleID)
        If oDataTable2.Rows.Count > 0 Then
            For k As Integer = 0 To oDataTable2.Rows.Count - 1
                If oDataTable2.Rows(k).Item("functionGroup") = "1" Then
                    If oDataTable2.Rows(k).Item("Permission") = "V" Then
                        If oDataTable2.Rows(k).Item("functionName").ToString = title Then

                            Call Me.toggleControl()

                        End If
                    End If
                End If

            Next

        End If


    End Sub


    Private Sub toggleControl()
        'Dim btnDelete As CWTCustomControls.CWTLinkButton
        Me.txtEmail.Readonly = True
        ' Me.chkPrefered.Enabled = False
        Me.btnSave.Enabled = False

        Me.gdData.Visible = False
        Me.tblPg.Visible = False
        Me.gdDataView.Visible = True
        Me.tblPg2.Visible = True

        'For i As Integer = 0 To Me.gdData.Rows.Count - 1
        '    btnDelete = Me.gdData.Rows(i).FindControl("hrefDeleteItem")
        '    btnDelete.Enabled = False

        'Next
    End Sub


    Public Sub CreateEmailTable()
        Me.UcTable = New DataTable("UcEMailTable")
        With Me.UcTable
            .Columns.Add(New DataColumn("ItemNo", GetType(Integer)))
            .Columns.Add(New DataColumn("Email"))
            ' .Columns.Add(New DataColumn("Prefered", GetType(Boolean)))
        End With
    End Sub

    Public Sub AddEmailData()
        Dim dr As DataRow
        Dim filter As String = ""
        Dim val As String = ""
        Dim FoundRow As DataRow()
        val = Me.txtEmail.Text
        filter = "Email=" + Util.LimitTheString(val)
        FoundRow = Me.UcTable.Select(filter)
        If FoundRow IsNot Nothing AndAlso FoundRow.Length > 0 Then
            Me.lblMsgBox.Text = "Cannot add duplicated value."
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.ajaxMsgBox.Show()
            Exit Sub
        End If
        dr = Me.UcTable.NewRow()
        If Me.UcTable.Rows.Count > 0 Then
            dr("ItemNo") = Util.DBNullToZero(Me.UcTable.Rows(Me.UcTable.Rows.Count - 1).Item("ItemNo") + 1)
        Else
            dr("ItemNo") = 1
        End If
        dr("Email") = Me.txtEmail.Text
        ' dr("Prefered") = Me.chkPrefered.Checked
        Me.UcTable.Rows.Add(dr)
    End Sub
    Public Sub AddEmailData(ByVal Email As String, ByVal Prefered As Boolean)
        Dim dr As DataRow
        Dim filter As String = ""
        Dim val As String = ""
        Dim FoundRow As DataRow()
        val = Me.txtEmail.Text
        filter = "Email=" + Util.LimitTheString(val)
        FoundRow = Me.UcTable.Select(filter)
        If FoundRow IsNot Nothing AndAlso FoundRow.Length > 0 Then
            Me.lblMsgBox.Text = "Cannot add duplicated value."
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.ajaxMsgBox.Show()
            Exit Sub
        End If
        dr = Me.UcTable.NewRow()
        If Me.UcTable.Rows.Count > 0 Then
            dr("ItemNo") = Util.DBNullToZero(Me.UcTable.Rows(Me.UcTable.Rows.Count - 1).Item("ItemNo") + 1)
        Else
            dr("ItemNo") = 1
        End If
        dr("Email") = Email
        'dr("Prefered") = Prefered
        Me.UcTable.Rows.Add(dr)
    End Sub

    Private Sub LoadNewData()
        Me.txtItemNo.Value = ""
        Me.txtEmail.Text = ""
        ' Me.chkPrefered.Checked = False
    End Sub

    Private Sub LoadData(ByVal ItemNo As String)
        Dim dr As DataRow()
        Dim filter As String = ""
        filter = "ItemNo=" + Util.LimitTheString(ItemNo)
        dr = Me.UcTable.Select(filter)
        If dr IsNot Nothing AndAlso dr.Length > 0 Then
            Me.txtItemNo.Value = ItemNo
            Me.txtEmail.Text = dr(0).Item("Email").ToString
            'Me.chkPrefered.Checked = CBool(dr(0).Item("Prefered"))
        End If
    End Sub

    Public Sub LoadDataFromDB(ByVal dt As DataTable)
        Dim r As DataRow
        Dim dr As DataRow
        If Me.UcTable Is Nothing Then
            Call Me.CreateEmailTable()
        End If
        For i As Integer = 0 To dt.Rows.Count - 1
            r = dt.Rows(i)
            dr = Me.UcTable.NewRow()
            If Me.UcTable.Rows.Count > 0 Then
                dr("ItemNo") = Util.DBNullToZero(Me.UcTable.Rows(Me.UcTable.Rows.Count - 1).Item("ItemNo") + 1)
            Else
                dr("ItemNo") = 1
            End If
            dr("Email") = r("BillingEmail").ToString
            'dr("Prefered") = IIf(IsDBNull(r("Preferred")), False, CBool(r("Preferred")))
            Me.UcTable.Rows.Add(dr)
        Next
        Call Me.RefreshGrid()
    End Sub

    Private Sub RemoveEmailData(ByVal ItemNo As String)
        Dim dr As DataRow()
        Dim filter As String = ""
        filter = "ItemNo=" + Util.LimitTheString(ItemNo)
        dr = Me.UcTable.Select(filter)
        If dr IsNot Nothing AndAlso dr.Length > 0 Then
            Me.UcTable.Rows.Remove(dr(0))
        End If
    End Sub

    Private Sub UpdateData(ByVal ItemNo As String)
        Dim dr As DataRow()
        Dim filter As String = ""
        Dim val As String = ""
        Dim FoundRow As DataRow()
        val = Me.txtEmail.Text
        filter = "Email=" + Util.LimitTheString(val) + " and ItemNo<>" + Util.LimitTheString(ItemNo)
        FoundRow = Me.UcTable.Select(filter)
        If FoundRow IsNot Nothing AndAlso FoundRow.Length > 0 Then
            Me.lblMsgBox.Text = "Cannot add duplicated value."
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.ajaxMsgBox.Show()
            Exit Sub
        End If
        filter = "ItemNo=" + Util.LimitTheString(ItemNo)
        dr = Me.UcTable.Select(filter)
        If dr IsNot Nothing AndAlso dr.Length > 0 Then
            dr(0).Item("Email") = Me.txtEmail.Text
            'dr(0).Item("Prefered") = Me.chkPrefered.Checked
        End If
    End Sub

    Private Sub RefreshGrid()
        Dim dv As New DataView()
        With dv
            .Table = Me.UcTable
            .Sort = "ItemNo"
        End With
        With Me.gdData
            .DataSource = dv.ToTable()
            .DataBind()
        End With
        With Me.pgControl
            .GridID = Me.gdData.UniqueID
            .SetBindGrid()
        End With

        With dv
            .Table = Me.UcTable
            .Sort = "ItemNo"
        End With
        With Me.gdDataView
            .DataSource = dv.ToTable()
            .DataBind()
        End With
        With Me.pgControl2
            .GridID = Me.gdDataView.UniqueID
            .SetBindGrid()
        End With
    End Sub

    Public Sub gdData_Command(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.CommandEventArgs)
        Select Case e.CommandName
            Case "delete"
                Call Me.RemoveEmailData(Util.DBNullToZero(e.CommandArgument))
            Case "edit"
                Call Me.LoadData(Util.DBNullToZero(e.CommandArgument))
        End Select
        Call Me.RefreshGrid()
        Call Me.AccessControl("Billing")
    End Sub

    Protected Sub btnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSave.Click
        Dim ItemNo As String = ""
        ItemNo = Me.txtItemNo.Value
        If ItemNo = "" Then
            Call Me.AddEmailData()
        Else
            Call Me.UpdateData(ItemNo)
        End If
        Call Me.RefreshGrid()
        Call Me.LoadNewData()
    End Sub

    Protected Sub gdData_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gdData.RowDataBound
        Dim cwtLinkBtn As CWTCustomControls.CWTLinkButton
        cwtLinkBtn = TryCast(e.Row.FindControl("hrefDeleteItem"), CWTCustomControls.CWTLinkButton)
        If cwtLinkBtn IsNot Nothing Then
            cwtLinkBtn.Attributes.Add("onclick", "return confirm('This item will delete, continue?');")
        End If
    End Sub

End Class
@


1.1.1.1
log
@no message
@
text
@@
