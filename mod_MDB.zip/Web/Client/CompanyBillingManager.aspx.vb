head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.56;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.56;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@
Partial Class Web_Client_CompanyBillingManager
    Inherits BasePage

    Private BLL As BusinessLogicLayer.CompanyBLL
    Private BLL2 As BusinessLogicLayer.StaffBLL
    Private BLL3 As BusinessLogicLayer.tblFunctionBLL


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.BLL = New BusinessLogicLayer.CompanyBLL()
        Me.BLL2 = New BusinessLogicLayer.StaffBLL()
        Me.BLL3 = New BusinessLogicLayer.tblFunctionBLL()

        If Not IsPostBack Then
            Call Me.LoadDataFromDB()
            Call Me.SetBillingMode()
        End If
        Call Me.AccessControl("Billing")
    End Sub

    Private Sub AccessControl(ByVal title As String)

        Dim userName As String
        Dim oDatatable As DataTable
        Dim oDataTable2 As DataTable

        Static roleID As String

        userName = ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName
        oDatatable = Me.BLL2.GetUserByID(userName)

        If oDatatable.Rows.Count > 0 Then
            roleID = oDatatable.Rows(0).Item("RoleID").ToString
        End If

        oDataTable2 = Me.BLL3.GetUserRole(roleID)
        If oDataTable2.Rows.Count > 0 Then
            For k As Integer = 0 To oDataTable2.Rows.Count - 1
                If oDataTable2.Rows(k).Item("functionGroup") = "1" Then
                    If oDataTable2.Rows(k).Item("Permission") = "V" Then
                        If oDataTable2.Rows(k).Item("functionName").ToString = title Then

                            Call Me.toggleControl()

                        End If
                    End If
                End If

            Next

        End If


    End Sub

    Private Sub toggleControl()
        Me.ddlBillingMode.Enabled = False
        Me.chkReferToProfile.Enabled = False
        Me.chkReferToProfile3.Enabled = False
        Me.chkSameAddress.Enabled = False
        Me.btnTrans.ShowSaveNextButton = False
        Me.btnTrans.SaveButton.Enabled = False
    End Sub


    Private Sub LoadDataFromDB()
        Dim ds As DataSet
        Dim r As DataRow
        ds = Me.BLL.GetBillingData(Me.CurrentClientID)
        If ds.Tables.Contains("Company") AndAlso ds.Tables("Company").Rows.Count > 0 Then
            r = ds.Tables("Company").Rows(0)
            Me.ddlBillingMode.SelectedValue = r("BillingMode").ToString
            Me.chkSameAddress.Checked = Util.DBNullToFalse(r("SameasBilling"))
            Me.chkReferToProfile.Checked = Util.DBNullToFalse(r("InvEmailToTraveler"))
            Me.chkReferToProfile3.Checked = Util.DBNullToFalse(r("InvDelAddrToTraveler"))
            '//
            If ds.Tables.Contains("Email") Then
                Me.UcBillingEmail1.LoadDataFromDB(ds.Tables("Email"))
            Else
                Call Me.UcBillingEmail1.CreateEmailTable()
            End If
            If ds.Tables.Contains("Billing") Then
                Me.UcBillingAddress1.LoadDataFromDB(ds.Tables("Billing"), False, Me.CurrentClientID)
            Else
                Call Me.UcBillingAddress1.CreateTitleTable()
            End If
            If ds.Tables.Contains("Delivery") AndAlso ds.Tables("Delivery").Rows.Count > 0 Then
                r = ds.Tables("Delivery").Rows(0)
                Me.UcBillingAddress2.LoadDataFromDB(ds.Tables("Delivery"), True, Me.CurrentClientID, Me.chkSameAddress.Checked)
            Else
                Call Me.UcBillingAddress2.CreateTitleTable()
            End If

            'Call Me.SetBillingMode()
        End If
    End Sub

    Private Sub SaveData(ByVal isNext As Boolean)
        Dim info As New DataInfo.BillingAddressDataInfo()
        Dim email As DataInfo.BillingEmailData
        Dim bill As DataInfo.BillingAddressData
        Dim dell As DataInfo.BillingAddressData
        Dim isError As Boolean = False
        Dim msg As New StringBuilder()
        Dim ds As New DataSet()
        With info
            .ClientID = Me.CurrentClientID
            .BillMode = Me.ddlBillingMode.SelectedValue
            .DelAddrReferToProfile = Me.chkReferToProfile3.Checked
            If .BillMode = DataInfo.BillingAddressDataInfo.BillingMode.eInvoice Then
                .EmailReferToProfile = Me.chkReferToProfile.Checked
                If Not Me.chkReferToProfile.Checked Then
                    For i As Integer = 0 To Me.UcBillingEmail1.UcTable.Rows.Count - 1
                        email = New DataInfo.BillingEmailData()
                        email.Email = Me.UcBillingEmail1.UcTable.Rows(i).Item("Email").ToString
                        'email.Prefered = Util.DBNullToFalse(Me.UcBillingEmail1.UcTable.Rows(i).Item("Prefered"))
                        .EmailList.Add(email)
                    Next
                End If
            End If
            If .BillMode = DataInfo.BillingAddressDataInfo.BillingMode.eInvoice OrElse DataInfo.BillingAddressDataInfo.BillingMode.pInvoice Then
                If Me.UcBillingAddress1.UcTable.Rows.Count <= 0 Then
                    isError = True
                    msg.AppendLine("At least one billing address is needed")
                End If
                For i As Integer = 0 To Me.UcBillingAddress1.UcTable.Rows.Count - 1
                    bill = New DataInfo.BillingAddressData()
                    bill.Address1 = Me.UcBillingAddress1.UcTable.Rows(i).Item("Title1").ToString
                    bill.Address2 = Me.UcBillingAddress1.UcTable.Rows(i).Item("Title2").ToString
                    bill.Address3 = Me.UcBillingAddress1.UcTable.Rows(i).Item("Title3").ToString
                    bill.Address4 = Me.UcBillingAddress1.UcTable.Rows(i).Item("Title4").ToString
                    bill.Address5 = Me.UcBillingAddress1.UcTable.Rows(i).Item("Title5").ToString
                    bill.Address6 = Me.UcBillingAddress1.UcTable.Rows(i).Item("Title6").ToString
                    bill.ClientNumber = Me.UcBillingAddress1.UcTable.Rows(i).Item("ClientNumber").ToString
                    ' bill.Prefered = Util.DBNullToFalse(Me.UcBillingAddress1.UcTable.Rows(i).Item("Prefered"))
                    .BillingAddrList.Add(bill)
                Next
            End If
            If Me.chkReferToProfile3.Checked Then
                .SameAsBillAddress = False
            Else
                .SameAsBillAddress = Me.chkSameAddress.Checked
                If Not .SameAsBillAddress Then
                    If Me.UcBillingAddress2.UcTable.Rows.Count <= 0 Then
                        isError = True
                        msg.AppendLine("At least one delivery address is needed")
                    End If
                End If
                For i As Integer = 0 To Me.UcBillingAddress2.UcTable.Rows.Count - 1
                    dell = New DataInfo.BillingAddressData()
                    dell.Address1 = Me.UcBillingAddress2.UcTable.Rows(i).Item("Title1").ToString
                    dell.Address2 = Me.UcBillingAddress2.UcTable.Rows(i).Item("Title2").ToString
                    dell.Address3 = Me.UcBillingAddress2.UcTable.Rows(i).Item("Title3").ToString
                    dell.Address4 = Me.UcBillingAddress2.UcTable.Rows(i).Item("Title4").ToString
                    dell.Address5 = Me.UcBillingAddress2.UcTable.Rows(i).Item("Title5").ToString
                    dell.Address6 = Me.UcBillingAddress2.UcTable.Rows(i).Item("Title6").ToString
                    dell.ClientNumber = Me.UcBillingAddress1.UcTable.Rows(i).Item("ClientNumber").ToString
                    ' dell.Prefered = Util.DBNullToFalse(Me.UcBillingAddress2.UcTable.Rows(i).Item("Prefered"))
                    .DelAddrList.Add(dell)
                Next
            End If
        End With
        If isError Then
            Me.lblMsgBox.Text = msg.ToString
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.ajaxMsgBox.Show()
            Exit Sub
        End If
        ds = DiffRecords(info)
        Me.BLL.UpdateTempBillingAddress(ds.Tables("Email"), ds.Tables("Billing"), ds.Tables("Delivery"), ds.Tables("Company"))
        If Me.BLL.UpdateBillingAddress(info) > 0 Then
            Me.lblMsgBox.Text = Util.GetAppConfig(Util.MsgType.TRANS_SUCCESS.ToString)
            Me.lblMsgBox.ForeColor = Drawing.Color.Green
            Me.ajaxMsgBox.Show()
            If isNext Then
                Response.Redirect("CompanyPaymentCard.aspx")
            End If
        Else
            Me.lblMsgBox.Text = Util.GetAppConfig(Util.MsgType.TRANS_ERROR.ToString)
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.ajaxMsgBox.Show()
        End If
    End Sub

    Private Function DiffRecords(ByVal info As DataInfo.BillingAddressDataInfo) As DataSet
        Dim ClientDT As New DataTable()
        Dim EmailDT As New DataTable()
        Dim AddrDT As New DataTable()
        Dim DeliveryDT As New DataTable()
        Dim countClientDT As Integer
        Dim countRow As Integer
        Dim countEmaillst As Integer
        Dim countAddlst As Integer
        Dim countDevlst As Integer
        Dim countRow2 As Integer
        Dim checkExists As Boolean
        Dim dr As DataRow
        Dim ds As New DataSet()

        ds = Me.BLL.GetBillingData(Me.CurrentClientID)

        If ds.Tables.Contains("Company") Then
            ClientDT = ds.Tables("Company")
            ClientDT.Columns.Add("StatusClient")
            If ClientDT.Rows.Count > 0 Then
                For countClientDT = 0 To ClientDT.Rows.Count - 1
                    If info.ClientID = ClientDT.Rows(countClientDT).Item("ClientID") And ClientDT.Rows(countClientDT).Item("InvEmailToTraveler").ToString() <> "" And ClientDT.Rows(countClientDT).Item("InvDelAddrToTraveler").ToString() <> "" And ClientDT.Rows(countClientDT).Item("BillingMode").ToString() <> "" And ClientDT.Rows(countClientDT).Item("SameasBilling").ToString() <> "" Then
                        If ClientDT.Rows(countClientDT).Item("InvEmailToTraveler").ToString() <> info.EmailReferToProfile Or ClientDT.Rows(countClientDT).Item("InvDelAddrToTraveler").ToString() <> info.DelAddrReferToProfile Or ClientDT.Rows(countClientDT).Item("BillingMode").ToString() <> info.BillMode Or ClientDT.Rows(countClientDT).Item("SameasBilling").ToString() <> info.SameAsBillAddress Then
                            dr = ClientDT.Rows(countClientDT)
                            dr.Item("InvEmailToTraveler") = ClientDT.Rows(countClientDT).Item("InvEmailToTraveler").ToString()
                            dr.Item("InvDelAddrToTraveler") = ClientDT.Rows(countClientDT).Item("InvDelAddrToTraveler").ToString()
                            If ClientDT.Rows(countClientDT).Item("BillingMode").ToString() = "0" Then
                                dr.Item("BillingMode") = "eInvoice"
                            ElseIf ClientDT.Rows(countClientDT).Item("BillingMode").ToString() = "1" Then
                                dr.Item("BillingMode") = "pInvoice"
                            Else
                                dr.Item("BillingMode") = "noInvoice"
                            End If
                            dr.Item("SameasBilling") = ClientDT.Rows(countClientDT).Item("SameasBilling").ToString()
                            dr.Item("StatusClient") = "Update"
                        Else
                            dr = ClientDT.Rows(countClientDT)
                            dr.Item("StatusClient") = "Completed"
                        End If
                    Else
                        dr = ClientDT.NewRow()
                        dr.Item("ClientID") = info.ClientID
                        dr.Item("InvEmailToTraveler") = info.EmailReferToProfile
                        dr.Item("InvDelAddrToTraveler") = info.DelAddrReferToProfile
                        dr.Item("BillingMode") = info.BillMode
                        dr.Item("SameasBilling") = info.SameAsBillAddress
                        dr.Item("StatusClient") = "Insert"
                    End If
                Next
            ElseIf info.ClientID <> "" Then
                dr = ClientDT.NewRow()
                dr.Item("ClientID") = info.ClientID
                dr.Item("InvEmailToTraveler") = info.EmailReferToProfile
                dr.Item("InvDelAddrToTraveler") = info.DelAddrReferToProfile
                dr.Item("BillingMode") = info.BillMode
                dr.Item("SameasBilling") = info.SameAsBillAddress
                dr.Item("StatusClient") = "Insert"
            End If
        End If

        If ds.Tables.Contains("Email") Then
            EmailDT = ds.Tables("Email")
            EmailDT.Columns.Add("Status")
            For countEmaillst = 0 To info.EmailList.Count - 1
                'check if info.emaillst more than emaildt,and countEmaillst set to <1 
                'because no need to loop second time, direct skip the looping
                If countEmaillst < EmailDT.Rows.Count And countEmaillst < 1 Then
                    For countRow = 0 To EmailDT.Rows.Count - 1
                        If EmailDT.Rows(countRow).Item("Status").ToString() = "" Then
                            checkExists = CheckMatchRecords(EmailDT.Rows(countRow), info, "Email")
                            If checkExists Then
                                dr = EmailDT.Rows(countRow)
                                dr.Item("Status") = "Completed"
                            Else
                                If info.EmailList.Count > 0 Then
                                    If countEmaillst + 1 = EmailDT.Rows(countRow).Item("BillingID") Then
                                        dr = EmailDT.Rows(countRow)
                                        dr.Item("BillingID") = EmailDT.Rows(countRow).Item("BillingID").ToString()
                                        dr.Item("ClientID") = Me.CurrentClientID
                                        dr.Item("BillingEmail") = EmailDT.Rows(countRow).Item("BillingEmail").ToString()

                                        dr.Item("Status") = "Update"

                                    ElseIf Convert.ToInt32(EmailDT.Rows(countRow).Item("BillingID")) > countRow2 + 1 Then
                                        dr = EmailDT.Rows(countRow)
                                        dr.Item("Status") = "Delete"
                                    End If
                                End If
                            End If
                        End If
                    Next
                ElseIf countEmaillst > EmailDT.Rows.Count - 1 Then
                    dr = EmailDT.NewRow
                    dr.Item("BillingID") = countEmaillst + 1
                    dr.Item("ClientID") = Me.CurrentClientID
                    dr.Item("BillingEmail") = info.EmailList(countEmaillst).Email
                    dr.Item("Status") = "Insert"
                    EmailDT.Rows.Add(dr)
                End If
            Next
        Else
            For countEmaillst = 0 To info.EmailList.Count - 1
                dr = EmailDT.NewRow
                dr.Item("BillingID") = countEmaillst + 1
                dr.Item("ClientID") = Me.CurrentClientID
                dr.Item("BillingEmail") = info.EmailList(countEmaillst).Email
                dr.Item("Status") = "Insert"
                EmailDT.Rows.Add(dr)
            Next
        End If
        EmailDT.AcceptChanges()

        If ds.Tables.Contains("Billing") Then
            AddrDT = ds.Tables("Billing")
            AddrDT.Columns.Add("Status")
            For countAddlst = 0 To info.BillingAddrList.Count - 1
                If countAddlst < AddrDT.Rows.Count And countAddlst < 1 Then
                    For countRow = 0 To AddrDT.Rows.Count - 1
                        checkExists = CheckMatchRecords(AddrDT.Rows(countRow), info, "Address")
                        If checkExists Then
                            dr = AddrDT.Rows(countRow)
                            dr.Item("Status") = "Completed"
                        Else
                            If info.BillingAddrList.Count > 0 Then
                                If countAddlst + 1 = AddrDT.Rows(countRow).Item("BillingID") Then
                                    dr = AddrDT.Rows(countRow)
                                    dr.Item("BillingID") = AddrDT.Rows(countRow).Item("BillingID").ToString()
                                    dr.Item("ClientID") = Me.CurrentClientID
                                    dr.Item("Title") = AddrDT.Rows(countRow).Item("Title").ToString()
                                    dr.Item("BillingAddr1") = AddrDT.Rows(countRow).Item("BillingAddr1").ToString()
                                    dr.Item("BillingAddr2") = AddrDT.Rows(countRow).Item("BillingAddr2").ToString()
                                    dr.Item("BillingAddr3") = AddrDT.Rows(countRow).Item("BillingAddr3").ToString()
                                    dr.Item("BillingAddr4") = AddrDT.Rows(countRow).Item("BillingAddr4").ToString()
                                    dr.Item("BillingAddr5") = AddrDT.Rows(countRow).Item("BillingAddr5").ToString()
                                    dr.Item("ClientNumber") = AddrDT.Rows(countRow).Item("ClientNumber").ToString()
                                    dr.Item("Status") = "Update"

                                ElseIf Convert.ToInt32(AddrDT.Rows(countRow).Item("BillingID")) > countRow2 + 1 Then
                                    dr = AddrDT.Rows(countRow)
                                    dr.Item("Status") = "Delete"
                                End If
                            End If
                        End If
                    Next
                ElseIf countAddlst > AddrDT.Rows.Count - 1 Then
                    dr = AddrDT.NewRow()
                    dr.Item("BillingID") = countAddlst + 1
                    dr.Item("ClientID") = Me.CurrentClientID
                    dr.Item("Title") = info.BillingAddrList(countAddlst).Address1
                    dr.Item("BillingAddr1") = info.BillingAddrList(countAddlst).Address2
                    dr.Item("BillingAddr2") = info.BillingAddrList(countAddlst).Address3
                    dr.Item("BillingAddr3") = info.BillingAddrList(countAddlst).Address4
                    dr.Item("BillingAddr4") = info.BillingAddrList(countAddlst).Address5
                    dr.Item("BillingAddr5") = info.BillingAddrList(countAddlst).Address6
                    dr.Item("ClientNumber") = info.BillingAddrList(countAddlst).ClientNumber
                    dr.Item("Status") = "Insert"
                    AddrDT.Rows.Add(dr)
                End If
            Next
        Else
            For countAddlst = 0 To info.BillingAddrList.Count - 1
                dr = AddrDT.NewRow()
                dr.Item("BillingID") = countAddlst + 1
                dr.Item("ClientID") = Me.CurrentClientID
                dr.Item("Title") = info.BillingAddrList(countAddlst).Address1
                dr.Item("BillingAddr1") = info.BillingAddrList(countAddlst).Address2
                dr.Item("BillingAddr2") = info.BillingAddrList(countAddlst).Address3
                dr.Item("BillingAddr3") = info.BillingAddrList(countAddlst).Address4
                dr.Item("BillingAddr4") = info.BillingAddrList(countAddlst).Address5
                dr.Item("BillingAddr5") = info.BillingAddrList(countAddlst).Address6
                dr.Item("ClientNumber") = info.BillingAddrList(countAddlst).ClientNumber
                dr.Item("Status") = "Insert"
                AddrDT.Rows.Add(dr)
            Next
        End If
        AddrDT.AcceptChanges()

        If ds.Tables.Contains("Delivery") Then
            DeliveryDT = ds.Tables("Delivery")
            DeliveryDT.Columns.Add("Status")
            For countDevlst = 0 To info.DelAddrList.Count - 1
                If countDevlst < info.DelAddrList.Count And countDevlst < 1 Then
                    For countRow = 0 To DeliveryDT.Rows.Count - 1
                        checkExists = CheckMatchRecords(DeliveryDT.Rows(countRow), info, "Delivery")
                        If checkExists Then
                            dr = DeliveryDT.Rows(countRow)
                            dr.Item("Status") = "Completed"
                        Else
                            If info.DelAddrList.Count > 0 Then
                                If countDevlst + 1 = DeliveryDT.Rows(countRow).Item("DeliveryID") Then
                                    dr = DeliveryDT.Rows(countRow)
                                    dr.Item("DeliveryID") = DeliveryDT.Rows(countRow).Item("DeliveryID").ToString()
                                    dr.Item("ClientID") = Me.CurrentClientID
                                    dr.Item("ReferToTravelerProfile") = DeliveryDT.Rows(countRow).Item("ReferToTravelerProfile").ToString()
                                    dr.Item("SameAsBilling") = DeliveryDT.Rows(countRow).Item("SameAsBilling").ToString()
                                    dr.Item("DeliveryAddr1") = DeliveryDT.Rows(countRow).Item("DeliveryAddr1").ToString()
                                    dr.Item("DeliveryAddr2") = DeliveryDT.Rows(countRow).Item("DeliveryAddr2").ToString()
                                    dr.Item("DeliveryAddr3") = DeliveryDT.Rows(countRow).Item("DeliveryAddr3").ToString()
                                    dr.Item("DeliveryAddr4") = DeliveryDT.Rows(countRow).Item("DeliveryAddr4").ToString()
                                    dr.Item("DeliveryAddr5") = DeliveryDT.Rows(countRow).Item("DeliveryAddr5").ToString()
                                    dr.Item("DeliveryAddr6") = DeliveryDT.Rows(countRow).Item("DeliveryAddr6").ToString()
                                    dr.Item("ClientNumber") = DeliveryDT.Rows(countRow).Item("ClientNumber").ToString()
                                    dr.Item("Status") = "Update"

                                ElseIf Convert.ToInt32(DeliveryDT.Rows(countRow).Item("DeliveryID")) > countRow2 + 1 Then
                                    dr = DeliveryDT.Rows(countRow)
                                    dr.Item("Status") = "Delete"
                                End If
                            End If
                        End If
                    Next

                ElseIf countDevlst > DeliveryDT.Rows.Count - 1 Then
                    dr = DeliveryDT.NewRow()
                    dr.Item("DeliveryID") = countDevlst + 1
                    dr.Item("ClientID") = Me.CurrentClientID
                    dr.Item("DeliveryAddr1") = info.DelAddrList(countDevlst).Address1
                    dr.Item("DeliveryAddr2") = info.DelAddrList(countDevlst).Address2
                    dr.Item("DeliveryAddr3") = info.DelAddrList(countDevlst).Address3
                    dr.Item("DeliveryAddr4") = info.DelAddrList(countDevlst).Address4
                    dr.Item("DeliveryAddr5") = info.DelAddrList(countDevlst).Address5
                    dr.Item("DeliveryAddr6") = info.DelAddrList(countDevlst).Address6
                    dr.Item("ClientNumber") = info.DelAddrList(countDevlst).ClientNumber
                    dr.Item("Status") = "Insert"
                    DeliveryDT.Rows.Add(dr)
                End If
            Next
        Else
            For countDevlst = 0 To info.DelAddrList.Count - 1
                dr = DeliveryDT.NewRow()
                dr.Item("DeliveryID") = countDevlst + 1
                dr.Item("ClientID") = Me.CurrentClientID
                dr.Item("DeliveryAddr1") = info.DelAddrList(countDevlst).Address1
                dr.Item("DeliveryAddr2") = info.DelAddrList(countDevlst).Address2
                dr.Item("DeliveryAddr3") = info.DelAddrList(countDevlst).Address3
                dr.Item("DeliveryAddr4") = info.DelAddrList(countDevlst).Address4
                dr.Item("DeliveryAddr5") = info.DelAddrList(countDevlst).Address5
                dr.Item("DeliveryAddr6") = info.DelAddrList(countDevlst).Address6
                dr.Item("ClientNumber") = info.DelAddrList(countDevlst).ClientNumber
                dr.Item("Status") = "Insert"
                DeliveryDT.Rows.Add(dr)
            Next
        End If
        DeliveryDT.AcceptChanges()
        Return ds
    End Function

    Private Function CheckMatchRecords(ByRef InfoRow As DataRow, ByVal info As DataInfo.BillingAddressDataInfo, ByVal Type As String) As Boolean
        'Dim countInfo As Integer
        Dim countInfo2 As Integer
        Dim checkMatch As Boolean = False

        Select Case Type
            Case "Email"
                For countInfo2 = 0 To info.EmailList.Count - 1
                    If InfoRow.Item("BillingID") = countInfo2 + 1 Then
                        If InfoRow.Item("BillingEmail").ToString() = info.EmailList(countInfo2).Email Then ' And InfoRow.Item("Preferred") = info.EmailList(countInfo2).Prefered 
                            checkMatch = True
                            'InfoTable.Rows.RemoveAt(countInfo)
                            'InfoTable.Rows(countInfo).Item("Status") = "Match"
                            'InfoTable.AcceptChanges()
                            Exit For
                            Exit Select
                        End If
                    End If
                Next

            Case "Address"
                For countInfo2 = 0 To info.BillingAddrList.Count - 1
                    If InfoRow.Item("BillingID") = countInfo2 + 1 Then
                        If InfoRow.Item("Title").ToString() = info.BillingAddrList(countInfo2).Address1 AndAlso InfoRow.Item("BillingAddr1").ToString() = info.BillingAddrList(countInfo2).Address2 AndAlso InfoRow.Item("BillingAddr2").ToString() = info.BillingAddrList(countInfo2).Address3 AndAlso InfoRow.Item("BillingAddr3").ToString() = info.BillingAddrList(countInfo2).Address4 AndAlso InfoRow.Item("BillingAddr4").ToString() = info.BillingAddrList(countInfo2).Address5 AndAlso InfoRow.Item("BillingAddr5").ToString() = info.BillingAddrList(countInfo2).Address6 AndAlso InfoRow.Item("ClientNumber").ToString() = info.BillingAddrList(countInfo2).ClientNumber Then 'AndAlso InfoTable.Rows(countInfo).Item("Preferred") = info.BillingAddrList(countInfo2).Prefered Then
                            checkMatch = True
                            'InfoTable.Rows.RemoveAt(countInfo)
                            ' InfoTable.Rows(countInfo).Item("Status") = "Match"
                            'InfoTable.AcceptChanges()
                            Exit For
                            Exit Select
                        End If
                    End If
                Next


            Case "Delivery"
                For countInfo2 = 0 To info.DelAddrList.Count - 1
                    If InfoRow.Item("DeliveryID") = countInfo2 + 1 Then
                        If InfoRow.Item("DeliveryAddr1").ToString() = info.DelAddrList(countInfo2).Address1 AndAlso InfoRow.Item("DeliveryAddr2").ToString() = info.DelAddrList(countInfo2).Address2 AndAlso InfoRow.Item("DeliveryAddr3").ToString() = info.DelAddrList(countInfo2).Address3 AndAlso InfoRow.Item("DeliveryAddr4").ToString() = info.DelAddrList(countInfo2).Address4 AndAlso InfoRow.Item("DeliveryAddr5").ToString() = info.DelAddrList(countInfo2).Address5 AndAlso InfoRow.Item("DeliveryAddr6").ToString() = info.DelAddrList(countInfo2).Address6 AndAlso InfoRow.Item("ClientNumber").ToString() = info.BillingAddrList(countInfo2).ClientNumber Then 'AndAlso InfoTable.Rows(countInfo).Item("Preferred") = info.DelAddrList(countInfo2).Prefered Then
                            checkMatch = True
                            ' InfoTable.Rows.RemoveAt(countInfo)
                            'InfoTable.Rows(countInfo).Item("Status") = "Match"
                            'InfoTable.AcceptChanges()
                            Exit For
                            Exit Select
                        End If
                    End If
                Next
        End Select
        Return checkMatch
    End Function

    Private Sub SetBillingMode()
        Dim BillMode As DataInfo.BillingAddressDataInfo.BillingMode
        Dim IsReferToProfile As Boolean = False
        'Dim IsReferToProfile2 As Boolean = False
        Dim IsReferToProfile3 As Boolean = False
        Dim SameAsBilling As Boolean = False
        BillMode = Util.DBNullToZero(Me.ddlBillingMode.SelectedValue)
        IsReferToProfile = Me.chkReferToProfile.Checked
        'IsReferToProfile2 = Me.chkReferToProfile2.Checked
        IsReferToProfile3 = Me.chkReferToProfile3.Checked
        SameAsBilling = Me.chkSameAddress.Checked
        Select Case BillMode
            Case DataInfo.BillingAddressDataInfo.BillingMode.eInvoice
                Me.trEmail.Visible = Not IsReferToProfile
                Me.trEmailHead.Visible = Not IsReferToProfile
                Me.chkReferToProfile.Visible = True
                '//
                Me.trBillAddress.Visible = True
                Me.trBillAddressHeader.Visible = True
                'Me.trBillAddress.Visible = Not IsReferToProfile2
            Case DataInfo.BillingAddressDataInfo.BillingMode.pInvoice
                Me.trEmail.Visible = False
                Me.trEmailHead.Visible = False
                Me.chkReferToProfile.Visible = False
                '//
                Me.trBillAddress.Visible = True
                Me.trBillAddressHeader.Visible = True
                'Me.trBillAddress.Visible = Not IsReferToProfile2
            Case DataInfo.BillingAddressDataInfo.BillingMode.noInvoice
                Me.trEmail.Visible = False
                Me.trEmailHead.Visible = False
                Me.chkReferToProfile.Visible = False
                '//
                Me.trBillAddress.Visible = False
                Me.trBillAddressHeader.Visible = False
                'Me.chkReferToProfile2.Visible = False
        End Select
        Me.chkSameAddress.Visible = Not IsReferToProfile3
        Me.trDeliveryAddress.Visible = (Not IsReferToProfile3 AndAlso Not SameAsBilling)
    End Sub

    Protected Sub ddlBillingMode_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlBillingMode.SelectedIndexChanged
        Call Me.SetBillingMode()
    End Sub

    Protected Sub chkReferToProfile_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkReferToProfile.CheckedChanged
        Call Me.SetBillingMode()
    End Sub

    Protected Sub chkSameAddress_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkSameAddress.CheckedChanged
        Call Me.SetBillingMode()
    End Sub

    'Protected Sub chkReferToProfile2_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkReferToProfile2.CheckedChanged
    '    Call Me.SetBillingMode()
    'End Sub

    Protected Sub chkReferToProfile3_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkReferToProfile3.CheckedChanged
        Call Me.SetBillingMode()
    End Sub

    Protected Sub btnTrans_OnCancel(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans.OnCancel
        Response.Redirect("CompanySearch.aspx")
    End Sub

    Protected Sub btnTrans_OnSave(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans.OnSave
        Call Me.SaveData(False)
    End Sub

    Protected Sub btnTrans_OnSaveNext(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans.OnSaveNext
        Call Me.SaveData(True)
    End Sub

End Class
@


1.1.1.1
log
@no message
@
text
@@
