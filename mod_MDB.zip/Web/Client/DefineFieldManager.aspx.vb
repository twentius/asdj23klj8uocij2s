head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.57;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.57;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@
Partial Class Web_Client_DefineFieldManager
    Inherits BasePage

    Private BLL As BusinessLogicLayer.CompanyReportBLL
    Private BLL2 As BusinessLogicLayer.StaffBLL
    Private BLL3 As BusinessLogicLayer.tblFunctionBLL

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.BLL = New BusinessLogicLayer.CompanyReportBLL()
        Me.BLL2 = New BusinessLogicLayer.StaffBLL()
        Me.BLL3 = New BusinessLogicLayer.tblFunctionBLL()

        If Not Me.BLL.GetClientDefineReport(Me.CurrentClientID) Then
            Response.Redirect("CompanySearch.aspx", True)
        End If
        If Not IsPostBack Then
            Call Me.LoadDataGrid()
        End If
        Call Me.AccessControl("Client Reporting")
    End Sub

    Private Sub AccessControl(ByVal title As String)

        Dim userName As String
        Dim oDatatable As DataTable
        Dim oDataTable2 As DataTable

        Static roleID As String

        userName = ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName
        oDatatable = Me.BLL2.GetUserByID(userName)

        If oDatatable.Rows.Count > 0 Then
            roleID = oDatatable.Rows(0).Item("RoleID").ToString
        End If

        oDataTable2 = Me.BLL3.GetUserRole(roleID)
        If oDataTable2.Rows.Count > 0 Then
            For k As Integer = 0 To oDataTable2.Rows.Count - 1
                If oDataTable2.Rows(k).Item("functionGroup") = "1" Then
                    If oDataTable2.Rows(k).Item("Permission") = "V" Then
                        If oDataTable2.Rows(k).Item("functionName").ToString = title Then

                            Call Me.toggleControl()

                        End If
                    End If
                End If

            Next

        End If


    End Sub

    Private Sub toggleControl()
        'Dim btnDelete As CWTCustomControls.CWTLinkButton

        Me.hrefAdd.Enabled = False

        Me.gdData.Visible = False
        Me.tblPg.Visible = False
        Me.gdDataView.Visible = True
        Me.tblPg2.Visible = True
        'For i As Integer = 0 To Me.gdData.Rows.Count - 1
        '    btnDelete = Me.gdData.Rows(i).FindControl("hrefDelete")
        '    btnDelete.Enabled = False

        'Next


       
    End Sub

    Private Sub LoadDataGrid()
        Dim oDataTable As DataTable
        oDataTable = Me.BLL.GetUDFReportList(Me.CurrentClientID, "")
        With Me.gdData
            .DataSource = oDataTable
            .DataBind()
        End With
        With Me.pgControl
            .GridID = Me.gdData.UniqueID
            .SetBindGrid()
        End With

        With Me.gdDataView
            .DataSource = oDataTable
            .DataBind()
        End With
        With Me.pgControl2
            .GridID = Me.gdDataView.UniqueID
            .SetBindGrid()
        End With
    End Sub

    Private Sub DeleteItem(ByVal ItemID As String)
        Me.BLL.DeleteUDFReport(Me.CurrentClientID, ItemID)
    End Sub

    Public Sub gdData_Command(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.CommandEventArgs)
        Select Case e.CommandName
            Case "DeleteItem"
                Call Me.DeleteItem(Util.DBNullToZero(e.CommandArgument))
        End Select
        Call Me.LoadDataGrid()
    End Sub

    Public Function GetTypeText(ByVal Type As String) As String
        Dim retVal As String = ""
        Select Case Type
            Case "1"
                retVal = "pre trip"
            Case "2"
                retVal = "pre trip ?company static"
            Case "3"
                retVal = "post trip ?traveler static"
            Case "4"
                retVal = "post trip ?transactional all products"
            Case "5"
                retVal = "post trip ?transactional air only"
            Case "6"
                retVal = "post trip ?transactional hotel only"
            Case "7"
                retVal = "post trip ?transactional rental only"
            Case "8"
                retVal = "post trip ?transactional auxiliary only"
        End Select
        Return retVal
    End Function

    Protected Sub gdData_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gdData.RowDataBound
        Dim cwtLinkBtn As CWTCustomControls.CWTLinkButton
        cwtLinkBtn = TryCast(e.Row.FindControl("hrefDelete"), CWTCustomControls.CWTLinkButton)
        If cwtLinkBtn IsNot Nothing Then
            cwtLinkBtn.Attributes.Add("onclick", "return confirm('This item will delete, continue?');")
        End If
    End Sub

    Protected Sub btnNextStep_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnNextStep.Click
        Me.BLL = New BusinessLogicLayer.CompanyReportBLL()
        Response.Redirect("AirPolicyManager.aspx", True)
    End Sub

End Class
@


1.1.1.1
log
@no message
@
text
@@
