head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.57;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.57;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@
Partial Class Web_Client_DropListUpdateManager
    Inherits BasePage

    Private BLL As BusinessLogicLayer.CompanyReportBLL
    Private BLL2 As BusinessLogicLayer.StaffBLL
    Private BLL3 As BusinessLogicLayer.tblFunctionBLL

    Public Property RecordID() As String
        Get
            Dim retVal As String = ""
            If Me.ViewState("_RecordID") IsNot Nothing Then
                retVal = Me.ViewState("_RecordID").ToString
            End If
            Return retVal
        End Get
        Set(ByVal value As String)
            Me.ViewState("_RecordID") = value
        End Set
    End Property

    Public ReadOnly Property RequestID() As String
        Get
            Dim retVal As String = ""
            If Me.Request("id") IsNot Nothing Then
                retVal = Me.Request("id")
            End If
            Return retVal
        End Get
    End Property

    Public ReadOnly Property RequestMode() As String
        Get
            Dim retVal As String = ""
            If Me.Request("mode") IsNot Nothing Then
                retVal = Me.Request("mode")
            End If
            Return retVal
        End Get
    End Property

    Private Property DropListTable() As DataTable
        Get
            Return Me.ViewState("_DropListTable")
        End Get
        Set(ByVal value As DataTable)
            Me.ViewState("_DropListTable") = value
        End Set
    End Property

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.BLL = New BusinessLogicLayer.CompanyReportBLL()
        Me.BLL2 = New BusinessLogicLayer.StaffBLL()
        Me.BLL3 = New BusinessLogicLayer.tblFunctionBLL()
        If Not IsPostBack Then
            Call Me.CreateDropListTable()
            Me.RecordID = Me.RequestID
            Call Me.LoadDataFromDB()
            Call Me.LoadNewData()
        End If
        Call Me.AccessControl("Client Reporting")
    End Sub

    Private Sub AccessControl(ByVal title As String)

        Dim userName As String
        Dim oDatatable As DataTable
        Dim oDataTable2 As DataTable

        Static roleID As String

        userName = ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName
        oDatatable = Me.BLL2.GetUserByID(userName)

        If oDatatable.Rows.Count > 0 Then
            roleID = oDatatable.Rows(0).Item("RoleID").ToString
        End If

        oDataTable2 = Me.BLL3.GetUserRole(roleID)
        If oDataTable2.Rows.Count > 0 Then
            For k As Integer = 0 To oDataTable2.Rows.Count - 1
                If oDataTable2.Rows(k).Item("functionGroup") = "1" Then
                    If oDataTable2.Rows(k).Item("Permission") = "V" Then
                        If oDataTable2.Rows(k).Item("functionName").ToString = title Then

                            Call Me.toggleControl()

                        End If
                    End If
                End If

            Next

        End If


    End Sub

    Private Sub toggleControl()
        'Dim btnDelete As CWTCustomControls.CWTLinkButton
        Me.txtDescription.Readonly = True
        Me.txtValue.Readonly = True
        Me.btnSave.Enabled = False
        'For i As Integer = 0 To Me.gdData.Rows.Count - 1
        '    btnDelete = Me.gdData.Rows(i).FindControl("hrefDeleteItem")
        '    btnDelete.Enabled = False

        'Next
        Me.gdData.Visible = False
        Me.tblPg.Visible = False
        Me.gdDataView.Visible = True
        Me.tblPg2.Visible = True

        Me.btnTrans.ShowSaveNextButton = False
        Me.btnTrans.SaveButton.Enabled = False
    End Sub

    Private Sub CreateDropListTable()
        Me.DropListTable = New DataTable("DropListTable")
        With Me.DropListTable
            .Columns.Add(New DataColumn("ItemNo", GetType(Integer)))
            .Columns.Add(New DataColumn("ItemValue"))
            .Columns.Add(New DataColumn("ItemDesc"))
        End With
    End Sub

    Private Sub AddGDSData()
        Dim dr As DataRow
        Dim filter As String = ""
        Dim val As String = ""
        Dim FoundRow As DataRow()
        val = Me.txtValue.Text
        filter = "ItemValue=" + Util.LimitTheString(val)
        FoundRow = Me.DropListTable.Select(filter)
        If FoundRow IsNot Nothing AndAlso FoundRow.Length > 0 Then
            Me.lblMsgBox.Text = "Cannot add duplicated value."
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.ajaxMsgBox.Show()
            Exit Sub
        End If
        dr = Me.DropListTable.NewRow()
        If Me.DropListTable.Rows.Count > 0 Then
            dr("ItemNo") = Util.DBNullToZero(Me.DropListTable.Rows(Me.DropListTable.Rows.Count - 1).Item("ItemNo") + 1)
        Else
            dr("ItemNo") = 1
        End If
        dr("ItemValue") = val
        dr("ItemDesc") = Me.txtDescription.Text
        Me.DropListTable.Rows.Add(dr)
    End Sub

    Private Sub LoadNewData()
        Me.txtItemNo.Value = ""
        Me.txtValue.Text = ""
        Me.txtDescription.Text = ""
        Me.btnSave.Text = "Add"
    End Sub

    Private Sub LoadData(ByVal ItemNo As String)
        Dim dr As DataRow()
        Dim filter As String = ""
        filter = "ItemNo=" + Util.LimitTheString(ItemNo)
        dr = Me.DropListTable.Select(filter)
        If dr IsNot Nothing AndAlso dr.Length > 0 Then
            Me.txtItemNo.Value = ItemNo
            Me.txtValue.Text = dr(0).Item("ItemValue").ToString
            Me.txtDescription.Text = dr(0).Item("ItemDesc").ToString
        End If
    End Sub

    Private Sub RemoveGDSData(ByVal ItemNo As String)
        Dim dr As DataRow()
        Dim filter As String = ""
        filter = "ItemNo=" + Util.LimitTheString(ItemNo)
        dr = Me.DropListTable.Select(filter)
        If dr IsNot Nothing AndAlso dr.Length > 0 Then
            Me.DropListTable.Rows.Remove(dr(0))
        End If
    End Sub

    Private Sub UpdateData(ByVal ItemNo As String)
        Dim dr As DataRow()
        Dim filter As String = ""
        Dim val As String = ""
        Dim FoundRow As DataRow()
        val = Me.txtValue.Text
        filter = "ItemValue=" + Util.LimitTheString(val) + " and ItemNo<>" + Util.LimitTheString(ItemNo)
        FoundRow = Me.DropListTable.Select(filter)
        If FoundRow IsNot Nothing AndAlso FoundRow.Length > 0 Then
            Me.lblMsgBox.Text = "Cannot add duplicated value."
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.ajaxMsgBox.Show()
            Exit Sub
        End If
        filter = "ItemNo=" + Util.LimitTheString(ItemNo)
        dr = Me.DropListTable.Select(filter)
        If dr IsNot Nothing AndAlso dr.Length > 0 Then
            dr(0).Item("ItemValue") = Me.txtValue.Text
            dr(0).Item("ItemDesc") = Me.txtDescription.Text
        End If
    End Sub

    Private Sub RefreshGrid()
        Dim dv As New DataView()
        With dv
            .Table = Me.DropListTable
            .Sort = "ItemNo"
        End With
        With Me.gdData
            .DataSource = dv.ToTable()
            .DataBind()
        End With
        With Me.pgControl
            .GridID = Me.gdData.UniqueID
            .SetBindGrid()
        End With


        With dv
            .Table = Me.DropListTable
            .Sort = "ItemNo"
        End With
        With Me.gdDataView
            .DataSource = dv.ToTable()
            .DataBind()
        End With
        With Me.pgControl2
            .GridID = Me.gdDataView.UniqueID
            .SetBindGrid()
        End With

    End Sub

    Private Sub LoadDataFromDB()
        Dim oDataTable As DataTable
        Dim oRow As DataRow
        Dim dr As DataRow
        Dim Min As Integer
        Dim Max As Integer
        oDataTable = Me.BLL.GetUDFReportDropList(Me.RecordID)
        If oDataTable IsNot Nothing Then
            For i As Integer = 0 To oDataTable.Rows.Count - 1
                oRow = oDataTable.Rows(i)
                dr = Me.DropListTable.NewRow()
                If Me.DropListTable.Rows.Count > 0 Then
                    dr("ItemNo") = Util.DBNullToZero(Me.DropListTable.Rows(Me.DropListTable.Rows.Count - 1).Item("ItemNo") + 1)
                Else
                    dr("ItemNo") = 1
                End If
                dr("ItemValue") = oRow("Value").ToString
                dr("ItemDesc") = oRow("Description").ToString
                Me.DropListTable.Rows.Add(dr)
            Next
            Call Me.RefreshGrid()
        End If
        Dim swap As Integer
        Min = Util.DBNullToZero(Me.BLL.GetMinValue(Me.RecordID))
        Max = Util.DBNullToZero(Me.BLL.GetMaxValue(Me.RecordID))
        If Min < 0 Then
            Min = 0
        End If
        If Min > 100 Then
            Min = 100
        End If
        If Max <= 0 Then
            Max = 100
        End If
        If Max > 100 Then
            Max = 100
        End If
        If Min > Max Then
            swap = Max
            Max = Min
            Min = swap
        End If
        Dim sc As New StringBuilder()
        sc.AppendLine("min=" + Min.ToString + ";")
        sc.AppendLine("max=" + Max.ToString + ";")
        Call Util.RegClientScript(sc.ToString, "SetMaxMin", Util.ClientScriptRegistType.RegStartUpBlock)
        Me.lblMinValue.Text = Min.ToString
        Me.lblMaxValue.Text = Max.ToString
    End Sub

    Private Sub SaveData()
        Dim info As New DataInfo.UDFReportInfo
        Dim droplist As DataInfo.DroplistInfo
        With info
            .ID = Me.RecordID
            '// GDS Mapping
            For i As Integer = 0 To Me.DropListTable.Rows.Count - 1
                droplist = New DataInfo.DroplistInfo()
                droplist.Value = Me.DropListTable.Rows(i).Item("ItemValue").ToString
                droplist.Description = Me.DropListTable.Rows(i).Item("ItemDesc").ToString
                .Droplist.Add(droplist)
            Next
        End With
        If Me.BLL.UpdateUDFDropList(info) > 0 Then
            Me.lblMsgBox.Text = Util.GetAppConfig(Util.MsgType.TRANS_SUCCESS.ToString)
            Me.lblMsgBox.ForeColor = Drawing.Color.Green
            Me.ajaxMsgBox.Show()
            Response.Redirect("DefineFieldManager.aspx")
        Else
            Me.lblMsgBox.Text = Util.GetAppConfig(Util.MsgType.TRANS_ERROR.ToString)
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.ajaxMsgBox.Show()
        End If
    End Sub

    Public Sub gdData_Command(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.CommandEventArgs)
        Select Case e.CommandName
            Case "delete"
                Call Me.RemoveGDSData(Util.DBNullToZero(e.CommandArgument))
            Case "edit"
                Call Me.LoadData(Util.DBNullToZero(e.CommandArgument))
                Me.btnSave.Text = "Update"
        End Select
        Call Me.RefreshGrid()
        Call Me.AccessControl("Client Reporting")
    End Sub

    Protected Sub btnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSave.Click
        Dim ItemNo As String = ""
        ItemNo = Me.txtItemNo.Value
        If ItemNo = "" Then
            Call Me.AddGDSData()
        Else
            Call Me.UpdateData(ItemNo)
        End If
        Call Me.RefreshGrid()
        Call Me.LoadNewData()
    End Sub

    Protected Sub gdData_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gdData.RowDataBound
        Dim cwtLinkBtn As CWTCustomControls.CWTLinkButton
        cwtLinkBtn = TryCast(e.Row.FindControl("hrefDeleteItem"), CWTCustomControls.CWTLinkButton)
        If cwtLinkBtn IsNot Nothing Then
            cwtLinkBtn.PermissionInfo = Me.usrInfo
            cwtLinkBtn.Attributes.Add("onclick", "return confirm('This item will delete, continue?');")
        End If
    End Sub

    Protected Sub btnTrans_OnCancel(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans.OnCancel
        Response.Redirect("DefineFieldManager.aspx")
    End Sub

    Protected Sub btnTrans_OnSave(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans.OnSave
        Call Me.SaveData()
    End Sub

End Class
@


1.1.1.1
log
@no message
@
text
@@
