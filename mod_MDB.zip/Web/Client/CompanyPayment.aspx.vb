head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.56;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.56;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@
Partial Class Web_Client_CompanyPayment
    Inherits BasePage

   

    Private Sub ShowMessage(ByVal msg As String, ByVal IsError As Boolean)
        If Not IsError Then
            Me.lblMsgBox.Text = msg
            Me.lblMsgBox.ForeColor = Drawing.Color.Green
            Me.ajaxMsgBox.Show()
        Else
            Me.lblMsgBox.Text = msg
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.ajaxMsgBox.Show()
        End If
    End Sub

    Protected Sub btnNextStep_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnNextStep.Click

    End Sub

    Protected Sub UcStandardMCFee1_OnSaveSuccess(ByVal sender As Object, ByVal e As BaseEventArgs) Handles UcStandardMCFee1.OnSaveSuccess
        Call Me.ShowMessage(e.EventMessage, False)
    End Sub
    Protected Sub UcStandardMCFee1_OnSaveFailed(ByVal sender As Object, ByVal e As BaseEventArgs) Handles UcStandardMCFee1.OnSaveFailed
        Call Me.ShowMessage(e.EventMessage, True)
    End Sub

    Protected Sub UcCreditcardMCFee1_OnSaveSuccess(ByVal sender As Object, ByVal e As BaseEventArgs) Handles UcCreditcardMCFee1.OnSaveSuccess
        Call Me.ShowMessage(e.EventMessage, False)
    End Sub
    Protected Sub UcCreditcardMCFee1_OnSaveFailed(ByVal sender As Object, ByVal e As BaseEventArgs) Handles UcCreditcardMCFee1.OnSaveFailed
        Call Me.ShowMessage(e.EventMessage, True)
    End Sub

    Protected Sub UcBankMCFee1_OnSaveSuccess(ByVal sender As Object, ByVal e As BaseEventArgs) Handles UcBankMCFee1.OnSaveSuccess
        Call Me.ShowMessage(e.EventMessage, False)
    End Sub
    Protected Sub UcBankMCFee1_OnSaveFailed(ByVal sender As Object, ByVal e As BaseEventArgs) Handles UcBankMCFee1.OnSaveFailed
        Call Me.ShowMessage(e.EventMessage, True)
    End Sub

    Protected Sub UcProductMF1_OnSaveSuccess(ByVal sender As Object, ByVal e As BaseEventArgs) Handles UcProductMF1.OnSaveSuccess
        Call Me.ShowMessage(e.EventMessage, False)
    End Sub
    Protected Sub UcProductMF1_OnSaveFailed(ByVal sender As Object, ByVal e As BaseEventArgs) Handles UcProductMF1.OnSaveFailed
        Call Me.ShowMessage(e.EventMessage, True)
    End Sub

End Class
@


1.1.1.1
log
@no message
@
text
@@
