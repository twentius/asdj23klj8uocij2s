head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.57;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.57;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@
Partial Class Web_Client_CompanyUpdateManager
    Inherits BasePage

#Region "Page Properties & Variables"
    Private BLL As BusinessLogicLayer.CompanyBLL
    Private BLL2 As BusinessLogicLayer.StaffBLL
    Private BLL3 As BusinessLogicLayer.tblFunctionBLL

    Public ReadOnly Property RequestMode() As String
        Get
            Dim retVal As String = ""
            If Me.Request("mode") IsNot Nothing Then
                retVal = Me.Request("mode")
            End If
            Return retVal
        End Get
    End Property


    Private Property IsError() As Boolean
        Get
            Dim retVal As Boolean
            If Me.ViewState("_IsError") IsNot Nothing Then
                retVal = CBool(Me.ViewState("_IsError"))
            End If
            Return retVal
        End Get
        Set(ByVal value As Boolean)
            Me.ViewState("_IsError") = value
        End Set
    End Property

    Public Property RecordID() As String
        Get
            Dim retVal As String = ""
            If Me.ViewState("_RecordID") IsNot Nothing Then
                retVal = Me.ViewState("_RecordID").ToString
            End If
            Return retVal
        End Get
        Set(ByVal value As String)
            Me.ViewState("_RecordID") = value
        End Set
    End Property
    Public Property CurentWebMode() As DataInfo.CompanyInfo.WebMode
        Get
            Dim retVal As DataInfo.CompanyInfo.WebMode = DataInfo.CompanyInfo.WebMode.GeneralInfo
            If Me.ViewState("_CurentWebMode") IsNot Nothing Then
                retVal = Me.ViewState("_CurentWebMode")
            End If
            Return retVal
        End Get
        Set(ByVal value As DataInfo.CompanyInfo.WebMode)
            Me.ViewState("_CurentWebMode") = value
        End Set
    End Property

    Public ReadOnly Property RequestID() As String
        Get
            Dim retVal As String = ""
            If Me.Request("id") IsNot Nothing Then
                retVal = Me.Request("id")
            End If
            Return retVal
        End Get
    End Property
    Public ReadOnly Property RequestWebMode() As String
        Get
            Dim retVal As String = ""
            If Me.Request("wmode") IsNot Nothing Then
                retVal = Me.Request("wmode")
            End If
            Return retVal
        End Get
    End Property
#End Region

#Region "Page Event Handlers & Methods"
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.BLL = New BusinessLogicLayer.CompanyBLL()
        Me.BLL2 = New BusinessLogicLayer.StaffBLL()
        Me.BLL3 = New BusinessLogicLayer.tblFunctionBLL()
        If Not IsPostBack Then
            Select Case Me.RequestWebMode.ToLower()
                Case "cwt"
                    Me.tblGeneralInfo.Visible = False
                    Me.tblCWT.Visible = True
                    Me.tblClient.Visible = False
                    Me.CurentWebMode = DataInfo.CompanyInfo.WebMode.CWTContact
                    Me.btnTrans.CausesValidation = True
                    Me.btnTrans.ValidationGroup = "CWT"
                    Me.ValidationSummary2.Visible = True
                    Me.ValidationSummary2.ValidationGroup = "CWT"
                    Call Me.AccessControl("CWT contact")
                Case "client"
                    Me.tblGeneralInfo.Visible = False
                    Me.tblCWT.Visible = False
                    Me.tblClient.Visible = True
                    Me.CurentWebMode = DataInfo.CompanyInfo.WebMode.ClientContact
                    Me.btnTrans.CausesValidation = True
                    Me.btnTrans.ValidationGroup = "client"
                    Me.ValidationSummary2.Visible = True
                    Me.ValidationSummary2.ValidationGroup = "client"
                    Call Me.AccessControl("Client Contact")
                Case Else
                    Me.tblGeneralInfo.Visible = True
                    Me.tblCWT.Visible = False
                    Me.tblClient.Visible = False
                    Me.CurentWebMode = DataInfo.CompanyInfo.WebMode.GeneralInfo
                    Me.btnTrans.CausesValidation = True
                    Me.btnTrans.ValidationGroup = "com"
                    Me.ValidationSummary2.Visible = True
                    Me.ValidationSummary2.ValidationGroup = "com"
            End Select
            Select Case Me.RequestMode.ToLower()
                Case "add"
                    Me.CurrentPageMode = CWTMasterDB.TransactionMode.AddNewMode
                    Me.btnUpdateGDS.Visible = False
                Case "edit"
                    Me.CurrentPageMode = CWTMasterDB.TransactionMode.UpdateMode
                    Me.RecordID = Me.RequestID
                    ServiceLogicLayer.CompanySLL.SetCurrentCompany(Me.RequestID)
                    Call Me.LoadData()
                    Me.btnUpdateGDS.Visible = True
                    Call Me.AccessControl("General Info")
                Case Else
                    Me.RecordID = Me.CurrentClientID
                    Me.CurrentPageMode = CWTMasterDB.TransactionMode.UpdateMode
                    Call Me.LoadData()
                    Me.btnUpdateGDS.Visible = True
                    If RequestWebMode.ToLower = "cwt" Then
                        Exit Sub
                    ElseIf RequestWebMode.ToLower = "client" Then
                        Exit Sub
                    Else
                        Call Me.AccessControl("General Info")
                    End If

            End Select
            Call Me.InitialControls()

        End If
    End Sub

    Private Sub InitialControls()
        If Me.CurentWebMode = DataInfo.CompanyInfo.WebMode.ClientContact Then
            Me.UcContactNoLookup1.SetValidateMessage(1)
            Me.UcContactNoLookup2.SetValidateMessage(2)
            Me.UcContactNoLookup3.SetValidateMessage(3)
        End If

        If Me.CurentWebMode = DataInfo.CompanyInfo.WebMode.CWTContact Then
            Me.UcContact1.SetValidateMessage2(1)
            Me.UcContact2.SetValidateMessage2(2)
            Me.UcContact3.SetValidateMessage2(3)
        End If
    End Sub

    Private Sub AccessControl(ByVal title As String)

        Dim userName As String
        Dim oDatatable As DataTable
        Dim oDataTable2 As DataTable

        Static roleID As String

        userName = ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName
        oDatatable = Me.BLL2.GetUserByID(userName)

        If oDatatable.Rows.Count > 0 Then
            roleID = oDatatable.Rows(0).Item("RoleID").ToString
        End If

        oDataTable2 = Me.BLL3.GetUserRole(roleID)
        If oDataTable2.Rows.Count > 0 Then
            For k As Integer = 0 To oDataTable2.Rows.Count - 1
                If oDataTable2.Rows(k).Item("functionGroup") = "1" Then
                    If oDataTable2.Rows(k).Item("Permission") = "V" Then
                        If oDataTable2.Rows(k).Item("functionName").ToString = title Then
                            If title = "General Info" Then
                                If RequestMode.ToLower.ToString = "edit" Or RequestMode.ToLower.ToString = "" Then
                                    Call Me.toggleControl()
                                End If
                            ElseIf title = "Client Contact" Then
                                If RequestWebMode.ToLower.ToString = "client" Then
                                    Call Me.toggleControl2()
                                End If
                            ElseIf title = "CWT contact" Then
                                If RequestWebMode.ToLower.ToString = "cwt" Then
                                    Call Me.toggleControl3()
                                End If
                            End If




                        End If
                    End If
                End If

            Next

        End If


    End Sub
    Private Sub toggleControl4()
        Me.btnTrans.SaveButton.Enabled = True
        Me.btnTrans.ShowSaveNextButton = True
    End Sub
    Private Sub toggleControl()

        Me.txtCompanyName.Readonly = True
        Me.txtSubUnitName.Readonly = True
        Me.txtEntityName.Readonly = True
        Me.txtActiveDate.Enabled = False
        Me.txtPhoneCode.Readonly = True
        Me.txtPhoneNo.Readonly = True
        Me.txtFaxCode.Readonly = True
        Me.txtFaxNo.Readonly = True
        Me.txtEmail.Readonly = True

        Me.txtAddress1.Readonly = True
        Me.txtAddress2.Readonly = True
        Me.txtAddress3.Readonly = True
        Me.txtAddress4.Readonly = True
        Me.txtAddress5.Readonly = True
        Me.chkStatus.Enabled = False
        Me.txtTeamEmail.Readonly = True
        Me.txtVendorReplyEmail.Readonly = True
        Me.btnTrans.SaveButton.Enabled = False
        Me.btnTrans.ShowSaveNextButton = False
        Me.btnUpdateGDS.Enabled = False

    End Sub

    Private Sub toggleControl2()
        Me.btnAddClient.Enabled = False
        Me.btnDelClient2.Enabled = False
        Me.btnDelClient3.Enabled = False
        Me.btnTrans.SaveButton.Enabled = False
        Me.btnTrans.ShowSaveNextButton = False
    End Sub

    Private Sub toggleControl3()
        Me.btnAddCWT.Enabled = False
        Me.btnDelCWT2.Enabled = False
        Me.btnDelCWT3.Enabled = False
        Me.btnTrans.SaveButton.Enabled = False
        Me.btnTrans.ShowSaveNextButton = False
    End Sub
    Private Sub AddCWT()
        If Not Me.trCT2.Visible Then
            Me.trCT2.Visible = True
            Me.trUCCT2.Visible = True
        Else
            If Not Me.trCT3.Visible Then
                Me.trCT3.Visible = True
                Me.trUCCT3.Visible = True
            End If
        End If
    End Sub

    Private Sub AddClient()
        If Not Me.trT2.Visible Then
            Me.trT2.Visible = True
            Me.trUCT2.Visible = True
        Else
            If Not Me.trT3.Visible Then
                Me.trT3.Visible = True
                Me.trUCT3.Visible = True
            End If
        End If
    End Sub

    Private Sub DelCWT(ByVal index As Integer)
        Select Case index
            Case 2
                Me.trCT2.Visible = False
                Me.trUCCT2.Visible = False
                Me.UcContact2.ClearData()
            Case 3
                Me.trCT3.Visible = False
                Me.trUCCT3.Visible = False
                Me.UcContact3.ClearData()
        End Select
    End Sub

    Private Sub DelClient(ByVal index As Integer)
        Select Case index
            Case 2
                Me.trT2.Visible = False
                Me.trUCT2.Visible = False
                Me.UcContactNoLookup2.ClearData()
            Case 3
                Me.trT3.Visible = False
                Me.trUCT3.Visible = False
                Me.UcContactNoLookup3.ClearData()
        End Select
    End Sub
#End Region

#Region "Data Binding"
    Private Sub LoadData()
        Dim ds As DataSet
        Dim r As DataRow
        Dim rCount As Integer
        ds = Me.BLL.GetCompayInfo(Me.RecordID)
        If ds Is Nothing Then
            Exit Sub
        End If
        If Me.CurentWebMode = DataInfo.CompanyInfo.WebMode.GeneralInfo AndAlso ds.Tables.Contains("Company") AndAlso ds.Tables("Company").Rows.Count > 0 Then
            r = ds.Tables("Company").Rows(0)
            Me.txtCompanyName.Text = r("GroupName").ToString
            Me.txtSubUnitName.Text = r("SubUnit").ToString
            Me.txtEntityName.Text = r("Name").ToString
            Me.txtActiveDate.Text = Format(r("ActivateDate"), "MM/dd/yyyy")
            Me.txtPhoneCode.Text = r("BizPhoneLocalCode").ToString
            Me.txtPhoneNo.Text = r("BizPhoneNumber").ToString
            Me.txtFaxCode.Text = r("BizFaxLocalCode").ToString
            Me.txtFaxNo.Text = r("BizFaxNumber").ToString
            Me.txtEmail.Text = r("Email").ToString
            Me.txtAddress1.Text = r("Address1").ToString
            Me.txtAddress2.Text = r("Address2").ToString
            Me.txtAddress3.Text = r("Address3").ToString
            Me.txtAddress4.Text = r("Address4").ToString
            Me.txtAddress5.Text = r("Address5").ToString 'Replace(r("Address5").ToString, "P/", "", , 1)
            Me.chkStatus.Checked = Util.DBNullToFalse(r("Status"))
            Me.txtTeamEmail.Text = r("TeamEmail").ToString
            Me.txtVendorReplyEmail.Text = r("VendorReplyEmail").ToString
        End If
        If Me.CurentWebMode = DataInfo.CompanyInfo.WebMode.CWTContact AndAlso ds.Tables.Contains("CWT") Then
            rCount = ds.Tables("CWT").Rows.Count
            If rCount > 0 Then
                r = ds.Tables("CWT").Rows(0)
                Me.UcContact1.SetUserInfo(r("UserID").ToString, Me.RecordID)
            End If
            If rCount > 1 Then
                r = ds.Tables("CWT").Rows(1)
                Me.UcContact2.SetUserInfo(r("UserID").ToString, Me.RecordID)
                Me.trCT2.Visible = True
                Me.trUCCT2.Visible = True
            Else
                Me.trCT2.Visible = False
                Me.trUCCT2.Visible = False
            End If
            If rCount > 2 Then
                r = ds.Tables("CWT").Rows(2)
                Me.UcContact3.SetUserInfo(r("UserID").ToString, Me.RecordID)
                Me.trCT3.Visible = True
                Me.trUCCT3.Visible = True
            Else
                Me.trCT3.Visible = False
                Me.trUCCT3.Visible = False
            End If
        End If
        If Me.CurentWebMode = DataInfo.CompanyInfo.WebMode.ClientContact AndAlso ds.Tables.Contains("Client") Then
            rCount = ds.Tables("Client").Rows.Count
            If rCount > 0 Then
                r = ds.Tables("Client").Rows(0)
                Me.UcContactNoLookup1.Title.SelectedValue = r("Title").ToString
                Me.UcContactNoLookup1.FirstName.Text = r("FirstName").ToString
                Me.UcContactNoLookup1.LastName.Text = r("LastName").ToString
                Me.UcContactNoLookup1.PhoneCode.Text = r("LocalCode").ToString
                Me.UcContactNoLookup1.HPCode.Text = r("LocalCodeMobile").ToString
                Me.UcContactNoLookup1.FaxCode.Text = r("LocalCodeFax").ToString
                Me.UcContactNoLookup1.Phone.Text = r("Phone").ToString
                Me.UcContactNoLookup1.HP.Text = r("Mobile").ToString
                Me.UcContactNoLookup1.Fax.Text = r("Fax").ToString
                Me.UcContactNoLookup1.Email.Text = r("Email").ToString
                Me.UcContactNoLookup1.JobTitle.Text = r("JobTitle").ToString
            End If
            If rCount > 1 Then
                r = ds.Tables("Client").Rows(1)
                Me.UcContactNoLookup2.Title.SelectedValue = r("Title").ToString
                Me.UcContactNoLookup2.FirstName.Text = r("FirstName").ToString
                Me.UcContactNoLookup2.LastName.Text = r("LastName").ToString
                Me.UcContactNoLookup2.PhoneCode.Text = r("LocalCode").ToString
                Me.UcContactNoLookup2.HPCode.Text = r("LocalCodeMobile").ToString
                Me.UcContactNoLookup2.Phone.Text = r("Phone").ToString
                Me.UcContactNoLookup2.HP.Text = r("Mobile").ToString
                Me.UcContactNoLookup2.Email.Text = r("Email").ToString
                Me.UcContactNoLookup2.JobTitle.Text = r("JobTitle").ToString
                Me.trT2.Visible = True
                Me.trUCT2.Visible = True
            Else
                Me.trT2.Visible = False
                Me.trUCT2.Visible = False
            End If
            If rCount > 2 Then
                r = ds.Tables("Client").Rows(2)
                Me.UcContactNoLookup3.Title.SelectedValue = r("Title").ToString
                Me.UcContactNoLookup3.FirstName.Text = r("FirstName").ToString
                Me.UcContactNoLookup3.LastName.Text = r("LastName").ToString
                Me.UcContactNoLookup3.PhoneCode.Text = r("LocalCode").ToString
                Me.UcContactNoLookup3.HPCode.Text = r("LocalCodeMobile").ToString
                Me.UcContactNoLookup3.Phone.Text = r("Phone").ToString
                Me.UcContactNoLookup3.HP.Text = r("Mobile").ToString
                Me.UcContactNoLookup3.Email.Text = r("Email").ToString
                Me.UcContactNoLookup3.JobTitle.Text = r("JobTitle").ToString
                Me.trT3.Visible = True
                Me.trUCT3.Visible = True
            Else
                Me.trT3.Visible = False
                Me.trUCT3.Visible = False
            End If
        End If
    End Sub
#End Region

#Region "Page Validations"
    Public Function ValidateForm() As Boolean
        Dim retVal As Boolean = True
        Return retVal
    End Function
#End Region

#Region "Data Transaction"
    Private Sub DeleteData()

    End Sub

    Private Sub SaveData(ByVal isNext As Boolean)
        Dim Info As New DataInfo.CompanyInfo()
        With Info
            .PageMode = Me.CurrentPageMode
            .ID = Me.RecordID
            .CurrentWebMode = Me.CurentWebMode
            If .CurrentWebMode = DataInfo.CompanyInfo.WebMode.GeneralInfo Then
                .Name = Me.txtCompanyName.Text
                .AffName = Me.txtSubUnitName.Text
                .EntityName = Me.txtEntityName.Text
                .ActivateDate = Me.txtActiveDate.Text
                .BizPhoneCode = Me.txtPhoneCode.Text
                .BizPhoneNo = Me.txtPhoneNo.Text
                .FaxPhoneCode = Me.txtFaxCode.Text
                .FaxPhoneNo = Me.txtFaxNo.Text
                .Email = Me.txtEmail.Text
                .Address1 = Me.txtAddress1.Text
                .Address2 = Me.txtAddress2.Text
                .Address3 = Me.txtAddress3.Text
                .Address4 = Me.txtAddress4.Text
                .Address5 = Me.txtAddress5.Text
                .Status = Me.chkStatus.Checked
                .TeamEmail = Me.txtTeamEmail.Text
                .VendorReplyEmail = Me.txtVendorReplyEmail.Text
                If Me.BLL.IsExistName(.Name, Me.RecordID) Then
                    Me.lblMsgBox.Text = "Company name is exist."
                    Me.lblMsgBox.ForeColor = Drawing.Color.Red
                    Me.ajaxMsgBox.Show()
                    Exit Sub
                End If
            End If
            If .CurrentWebMode = DataInfo.CompanyInfo.WebMode.CWTContact Then
                If Me.UcContact1.UserID <> "" Then .CWTContact.Add(Me.UcContact1.GetCWTContact)
                If Me.UcContact2.UserID <> "" Then .CWTContact.Add(Me.UcContact2.GetCWTContact)
                If Me.UcContact3.UserID <> "" Then .CWTContact.Add(Me.UcContact3.GetCWTContact)
                '// Validation
                If .CWTContact.Count <= 0 Then
                    Me.lblMsgBox.Text = "At least one contact are needed."
                    Me.lblMsgBox.ForeColor = Drawing.Color.Red
                    Me.ajaxMsgBox.Show()
                    Exit Sub
                End If
            End If
            If .CurrentWebMode = DataInfo.CompanyInfo.WebMode.ClientContact Then
                If Me.UcContactNoLookup1.ValidateForm Then .ClientContact.Add(Me.UcContactNoLookup1.GetUserInfo)
                If Me.UcContactNoLookup2.ValidateForm Then .ClientContact.Add(Me.UcContactNoLookup2.GetUserInfo)
                If Me.UcContactNoLookup3.ValidateForm Then .ClientContact.Add(Me.UcContactNoLookup3.GetUserInfo)
                '// Validation
                If .ClientContact.Count <= 0 Then
                    Me.lblMsgBox.Text = "At least one contact are needed."
                    Me.lblMsgBox.ForeColor = Drawing.Color.Red
                    Me.ajaxMsgBox.Show()
                    Exit Sub
                End If
            End If
        End With
        '//
        If Me.BLL.UpdateCompany(Info) > 0 Then
            Me.lblMsgBox.Text = Util.GetAppConfig(Util.MsgType.TRANS_SUCCESS.ToString)
            Me.lblMsgBox.ForeColor = Drawing.Color.Green
            ServiceLogicLayer.CompanySLL.SetCurrentCompany(Info.ID)
            If Info.CurrentWebMode = DataInfo.CompanyInfo.WebMode.GeneralInfo Then
                Me.btnUpdateGDS.Visible = True
            Else
                Me.btnUpdateGDS.Visible = False
            End If
            Me.ajaxMsgBox.Show()
            If isNext Then
                Select Case Me.CurentWebMode
                    Case DataInfo.CompanyInfo.WebMode.ClientContact
                        Response.Redirect("CompanyUpdateManager.aspx?wmode=cwt")
                    Case DataInfo.CompanyInfo.WebMode.CWTContact
                        Response.Redirect("CompanyBillingManager.aspx")
                    Case Else
                        Response.Redirect("CompanyUpdateManager.aspx?wmode=client")
                End Select
            End If
        Else
            Me.lblMsgBox.Text = Util.GetAppConfig(Util.MsgType.TRANS_ERROR.ToString)
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.ajaxMsgBox.Show()
        End If
    End Sub
#End Region

#Region "Page Control Event Handlers"
    Protected Sub btnTrans_OnDelete(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans.OnDelete
        Call Me.DeleteData()
    End Sub

    Protected Sub btnTrans_OnSave(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans.OnSave
        Call Me.SaveData(False)
    End Sub

    Protected Sub btnTrans_OnSaveNext(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans.OnSaveNext
        Call Me.SaveData(True)
    End Sub

    Protected Sub btnTrans_OnCancel(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans.OnCancel
        Response.Redirect("CompanySearch.aspx", True)
    End Sub

    Protected Sub btnAddCWT_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnAddCWT.Click
        Call Me.AddCWT()
    End Sub

    Protected Sub btnAddClient_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnAddClient.Click
        Call Me.AddClient()
    End Sub

    Protected Sub btnDelClient2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnDelClient2.Click
        Call Me.DelClient(2)
    End Sub

    Protected Sub btnDelClient3_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnDelClient3.Click
        Call Me.DelClient(3)
    End Sub

    Protected Sub btnDelCWT2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnDelCWT2.Click
        Call Me.DelCWT(2)
    End Sub

    Protected Sub btnDelCWT3_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnDelCWT3.Click
        Call Me.DelCWT(3)
    End Sub
#End Region

#Region "Misc"

#End Region

#Region "uc events"
    Protected Sub UcContact1_PreUserDataBind(ByVal sender As Object, ByVal e As System.EventArgs) Handles UcContact1.PreUserDataBind
        If Me.UcContact1.UserID <> "" AndAlso (Me.UcContact1.UserID = Me.UcContact2.UserID OrElse Me.UcContact1.UserID = Me.UcContact3.UserID) Then
            Me.lblMsgBox.Text = "user already exist in contact"
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.ajaxMsgBox.Show()
            Me.UcContact1.ClearData()
        End If
    End Sub

    Protected Sub UcContact2_PreUserDataBind(ByVal sender As Object, ByVal e As System.EventArgs) Handles UcContact2.PreUserDataBind
        If Me.UcContact2.UserID <> "" AndAlso (Me.UcContact2.UserID = Me.UcContact1.UserID OrElse Me.UcContact2.UserID = Me.UcContact3.UserID) Then
            Me.lblMsgBox.Text = "user already exist in contact"
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.ajaxMsgBox.Show()
            Me.UcContact2.ClearData()
        End If
    End Sub

    Protected Sub UcContact3_PreUserDataBind(ByVal sender As Object, ByVal e As System.EventArgs) Handles UcContact3.PreUserDataBind
        If Me.UcContact3.UserID <> "" AndAlso (Me.UcContact3.UserID = Me.UcContact1.UserID OrElse Me.UcContact3.UserID = Me.UcContact2.UserID) Then
            Me.lblMsgBox.Text = "user already exist in contact"
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.ajaxMsgBox.Show()
            Me.UcContact3.ClearData()
        End If
    End Sub
#End Region

#Region "Update GDS"
    Private Sub UpdateGDS()
        Dim Info As New DataInfo.CompanyUpdateGDSInfo()
        Dim oDataTable As DataTable
        Dim oDataTable2 As DataTable
        oDataTable = Me.BLL.GetGDSNumberList(Me.RecordID)


        If oDataTable IsNot Nothing AndAlso oDataTable.Rows.Count > 0 Then
            With Info
                .PageMode = Me.CurrentPageMode
                .ClientID = Me.RecordID
                For i As Integer = 0 To oDataTable.Rows.Count - 1
                    .GDSNumber.Add(oDataTable.Rows(i).Item("GDSNumber").ToString)
                    .ProfilPCC.Add(oDataTable.Rows(i).Item("ProfilePCC").ToString)
                    .ProfileName.Add(oDataTable.Rows(i).Item("ProfileName").ToString)
                    .LineDefMasterID.Add(oDataTable.Rows(i).Item("LineDefMasterID").ToString)
                Next


            End With
            '//
            If Me.BLL.UpdateGDS(Info) > 0 Then
                Me.lblMsgBox.Text = "Successfully updated GDS."
                Me.lblMsgBox.ForeColor = Drawing.Color.Green
                Me.ajaxMsgBox.Show()
            Else
                Me.lblMsgBox.Text = Util.GetAppConfig(Util.MsgType.TRANS_ERROR.ToString)
                Me.lblMsgBox.ForeColor = Drawing.Color.Red
                Me.ajaxMsgBox.Show()
            End If
        Else
            Me.lblMsgBox.Text = "Please set up GDS Mapping before update!"
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.IsError = True
            Me.ajaxMsgBox.Show()

        End If
    End Sub

    Private Sub btnUpdateGDS_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnUpdateGDS.Click
        Call Me.UpdateGDS()
    End Sub

    Protected Sub btnClose_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Me.ajaxMsgBox.Hide()
        If Not Me.IsError Then

        Else
            Response.Redirect("GDSMappingManager.aspx")
        End If
    End Sub

#End Region

End Class









@


1.1.1.1
log
@no message
@
text
@@
