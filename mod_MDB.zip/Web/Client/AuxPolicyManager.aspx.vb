head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.55;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.55;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@
Partial Class Web_Client_AuxPolicyManager
    Inherits BasePage

    Private BLL As BusinessLogicLayer.CompanyPolicyBLL
    Private BLL2 As BusinessLogicLayer.StaffBLL
    Private BLL3 As BusinessLogicLayer.tblFunctionBLL

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.BLL = New BusinessLogicLayer.CompanyPolicyBLL()
        Me.BLL2 = New BusinessLogicLayer.StaffBLL()
        Me.BLL3 = New BusinessLogicLayer.tblFunctionBLL()
        If Not IsPostBack Then
            Call Me.LoadDataFromDB()
        End If
        Call Me.AccessControl("Auxiliary")
    End Sub


    Private Sub AccessControl(ByVal title As String)

        Dim userName As String
        Dim oDatatable As DataTable
        Dim oDataTable2 As DataTable

        Static roleID As String

        userName = ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName
        oDatatable = Me.BLL2.GetUserByID(userName)

        If oDatatable.Rows.Count > 0 Then
            roleID = oDatatable.Rows(0).Item("RoleID").ToString
        End If

        oDataTable2 = Me.BLL3.GetUserRole(roleID)
        If oDataTable2.Rows.Count > 0 Then
            For k As Integer = 0 To oDataTable2.Rows.Count - 1
                If oDataTable2.Rows(k).Item("functionGroup") = "1" Then
                    If oDataTable2.Rows(k).Item("Permission") = "V" Then
                        If oDataTable2.Rows(k).Item("ParentID").ToString = "PAUX" Then
                            If oDataTable2.Rows(k).Item("functionName").ToString = title Then

                                Call Me.toggleControl()
                            End If
                        End If

                    End If
                End If

            Next

        End If


    End Sub

    Private Sub toggleControl()
        Me.txtPolicyLine1.Readonly = True
        Me.txtPolicyLine2.Readonly = True
        Me.txtPolicyLine3.Readonly = True
        Me.txtPolicyLine4.Readonly = True
        Me.txtPolicyLine5.Readonly = True
        Me.txtPolicyLine6.Readonly = True
        Me.txtPolicyLine7.Readonly = True
        Me.txtPolicyLine8.Readonly = True
        Me.txtPolicyLine9.Readonly = True
        Me.txtPolicyLine10.Readonly = True

        Me.btnTrans.ShowSaveNextButton = False
        Me.btnTrans.SaveButton.Enabled = False
    End Sub


    Private Sub LoadDataFromDB()
        On Error Resume Next
        'Dim r As DataRow
        Dim oDataTable As DataTable
        'Dim txt As CWTCustomControls.CWTTextBox
        'Dim Index As String
        'Dim ctrlName As String
        oDataTable = Me.BLL.GetAuxPolicyData(Me.CurrentClientID)
        If oDataTable IsNot Nothing AndAlso oDataTable.Rows.Count > 0 Then
            Me.txtPolicyLine1.Text = oDataTable.Rows(0).Item("PolicyLine").ToString
            Me.txtPolicyLine2.Text = oDataTable.Rows(1).Item("PolicyLine").ToString
            Me.txtPolicyLine3.Text = oDataTable.Rows(2).Item("PolicyLine").ToString
            Me.txtPolicyLine4.Text = oDataTable.Rows(3).Item("PolicyLine").ToString
            Me.txtPolicyLine5.Text = oDataTable.Rows(4).Item("PolicyLine").ToString
            Me.txtPolicyLine6.Text = oDataTable.Rows(5).Item("PolicyLine").ToString
            Me.txtPolicyLine7.Text = oDataTable.Rows(6).Item("PolicyLine").ToString
            Me.txtPolicyLine8.Text = oDataTable.Rows(7).Item("PolicyLine").ToString
            Me.txtPolicyLine9.Text = oDataTable.Rows(8).Item("PolicyLine").ToString
            Me.txtPolicyLine10.Text = oDataTable.Rows(9).Item("PolicyLine").ToString
            'For i As Integer = 0 To oDataTable.Rows.Count - 1
            '    r = oDataTable.Rows(i)
            '    Index = r("AuxClientPolicyID").ToString
            '    ctrlName = "txtPolicyLine" + Index
            '    'txt = Me.Page.Controls(0).Controls(3).Controls(3).Controls(0).Controls(1).FindControl(ctrlName)

            '    If txt IsNot Nothing Then
            '        txt.Text = r("PolicyLine").ToString
            '    End If
            'Next
        End If
    End Sub

    Private Sub SaveData(ByVal IsNext As Boolean)
        Dim info As New DataInfo.CompanyPolicyInfo()
        With info
            .PageMode = Me.CurrentPageMode
            .ClientID = Me.CurrentClientID
            '// Policy
            .PolicyLines.Add(Me.txtPolicyLine1.Text)
            .PolicyLines.Add(Me.txtPolicyLine2.Text)
            .PolicyLines.Add(Me.txtPolicyLine3.Text)
            .PolicyLines.Add(Me.txtPolicyLine4.Text)
            .PolicyLines.Add(Me.txtPolicyLine5.Text)
            .PolicyLines.Add(Me.txtPolicyLine6.Text)
            .PolicyLines.Add(Me.txtPolicyLine7.Text)
            .PolicyLines.Add(Me.txtPolicyLine8.Text)
            .PolicyLines.Add(Me.txtPolicyLine9.Text)
            .PolicyLines.Add(Me.txtPolicyLine10.Text)
        End With
        If Me.BLL.UpdateAuxPolicy(info) > 0 Then
            Me.lblMsgBox.Text = Util.GetAppConfig(Util.MsgType.TRANS_SUCCESS.ToString)
            Me.lblMsgBox.ForeColor = Drawing.Color.Green
            Me.ajaxMsgBox.Show()
            If IsNext Then
                Response.Redirect("AirPricing.aspx")
            End If
        Else
            Me.lblMsgBox.Text = Util.GetAppConfig(Util.MsgType.TRANS_ERROR.ToString)
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.ajaxMsgBox.Show()
        End If
    End Sub

    Protected Sub btnTrans_OnCancel(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans.OnCancel
        Response.Redirect("CompanySearch.aspx")
    End Sub

    Protected Sub btnTrans_OnSave(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans.OnSave
        Call Me.SaveData(False)
    End Sub

    Protected Sub btnTrans_OnSaveNext(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans.OnSaveNext
        Call Me.SaveData(True)
    End Sub

End Class
@


1.1.1.1
log
@no message
@
text
@@
