head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.56;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.56;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@
Partial Class Web_Client_CompanyPaymentCard
    Inherits BasePage

    Private BLL As BusinessLogicLayer.ComPaymentCardBLL
    Private BLL2 As BusinessLogicLayer.StaffBLL
    Private BLL3 As BusinessLogicLayer.tblFunctionBLL


    Public Property RecordID() As String
        Get
            Dim retVal As String = ""
            If Me.ViewState("_RecordID") IsNot Nothing Then
                retVal = Me.ViewState("_RecordID").ToString
            End If
            Return retVal
        End Get
        Set(ByVal value As String)
            Me.ViewState("_RecordID") = value
        End Set
    End Property

    Public ReadOnly Property RequestMode() As String
        Get
            Dim retVal As String = ""
            If Me.Request("mode") IsNot Nothing Then
                retVal = Me.Request("mode")
            End If
            Return retVal
        End Get
    End Property

    Private Property AirIntDataTable() As DataTable
        Get
            Return Me.ViewState("_AirIntDataTable")
        End Get
        Set(ByVal value As DataTable)
            Me.ViewState("_AirIntDataTable") = value
        End Set
    End Property

    Private Property AirDomDataTable() As DataTable
        Get
            Return Me.ViewState("AirDomDataTable")
        End Get
        Set(ByVal value As DataTable)
            Me.ViewState("AirDomDataTable") = value
        End Set
    End Property

    Private Property AirLccDataTable() As DataTable
        Get
            Return Me.ViewState("AirLccDataTable")
        End Get
        Set(ByVal value As DataTable)
            Me.ViewState("AirLccDataTable") = value
        End Set
    End Property

    Private Property HotelDataTable() As DataTable
        Get
            Return Me.ViewState("HotelDataTable")
        End Get
        Set(ByVal value As DataTable)
            Me.ViewState("HotelDataTable") = value
        End Set
    End Property


    Private Property CarDataTable() As DataTable
        Get
            Return Me.ViewState("CarDataTable")
        End Get
        Set(ByVal value As DataTable)
            Me.ViewState("CarDataTable") = value
        End Set
    End Property


    Private Property AuxDataTable() As DataTable
        Get
            Return Me.ViewState("AuxDataTable")
        End Get
        Set(ByVal value As DataTable)
            Me.ViewState("AuxDataTable") = value
        End Set
    End Property


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.BLL = New BusinessLogicLayer.ComPaymentCardBLL()
        Me.BLL2 = New BusinessLogicLayer.StaffBLL()
        Me.BLL3 = New BusinessLogicLayer.tblFunctionBLL()

        If Not IsPostBack Then
            Call Me.LoadDropDownList()
            'Call Me.CreatePaymentCardTable()
            Call Me.CreateAirIntDataTable()
            Call Me.CreateAirDomDataTable()
            Call Me.CreateAirLccDataTable()
            Call Me.CreateHotelDataTable()
            Call Me.CreateCarDataTable()
            Call Me.CreateAuxDataTable()


            Call Me.LoadAirIntDataFromDB()
            Call Me.LoadAirDomDataFromDB()
            Call Me.LoadAirLccDataFromDB()
            Call Me.LoadHotelDataFromDB()
            Call Me.LoadCarDataFromDB()
            Call Me.LoadAuxDataFromDB()
            'Call Me.LoadDataFromDB()
            Call Me.SetTableMode()

           

            Me.RangeValidator2.MinimumValue = Year(Now.AddYears(-10)).ToString + "-01-01"
            Me.RangeValidator2.MaximumValue = Year(Now.AddYears(10)).ToString + "-01-01"

            Me.RangeValidator1.MinimumValue = Year(Now.AddYears(-10)).ToString + "-01-01"
            Me.RangeValidator1.MaximumValue = Year(Now.AddYears(10)).ToString + "-01-01"

            Me.RangeValidator3.MinimumValue = Year(Now.AddYears(-10)).ToString + "-01-01"
            Me.RangeValidator3.MaximumValue = Year(Now.AddYears(10)).ToString + "-01-01"

            Me.RangeValidator4.MinimumValue = Year(Now.AddYears(-10)).ToString + "-01-01"
            Me.RangeValidator4.MaximumValue = Year(Now.AddYears(10)).ToString + "-01-01"

            Me.RangeValidator5.MinimumValue = Year(Now.AddYears(-10)).ToString + "-01-01"
            Me.RangeValidator5.MaximumValue = Year(Now.AddYears(10)).ToString + "-01-01"

            Me.RangeValidator6.MinimumValue = Year(Now.AddYears(-10)).ToString + "-01-01"
            Me.RangeValidator6.MaximumValue = Year(Now.AddYears(10)).ToString + "-01-01"
        End If
        Call Me.AccessControl("Payment")
    End Sub


    Private Sub AccessControl(ByVal title As String)

        Dim userName As String
        Dim oDatatable As DataTable
        Dim oDataTable2 As DataTable

        Static roleID As String

        userName = ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName
        oDatatable = Me.BLL2.GetUserByID(userName)

        If oDatatable.Rows.Count > 0 Then
            roleID = oDatatable.Rows(0).Item("RoleID").ToString
        End If

        oDataTable2 = Me.BLL3.GetUserRole(roleID)
        If oDataTable2.Rows.Count > 0 Then
            For k As Integer = 0 To oDataTable2.Rows.Count - 1
                If oDataTable2.Rows(k).Item("functionGroup") = "1" Then
                    If oDataTable2.Rows(k).Item("Permission") = "V" Then
                        If oDataTable2.Rows(k).Item("functionName").ToString = title Then

                            Call Me.toggleControl()

                        End If
                    End If
                End If

            Next

        End If


    End Sub

    Private Sub toggleControl()
       

        'Air - Int
        Me.ddlAirIntCC.Enabled = False
        Me.ddlAirIntMode.Enabled = False
        Me.txtAirIntCardName.Readonly = True
        Me.txtAirIntCardNum.Readonly = True
        Me.txtAirIntExp.Enabled = False
        Me.btnAirIntAdd.Enabled = False
        Me.ddlAirIntCC.Enabled = False
        Me.gdAirIntData.Visible = False
        Me.tblIntPg.Visible = False
        Me.gdAirIntView.Visible = True
        Me.tblIntPg2.Visible = True

       
        'Air - Dom
        Me.ddlAirDomCC.Enabled = False
        Me.ddlAirDomMode.Enabled = False
        Me.txtAirDomCardName.Readonly = True
        Me.txtAirDomCardNum.Readonly = True
        Me.txtAirDomExp.Enabled = False
        Me.btnAirDomAdd.Enabled = False
        Me.ddlAirDomCC.Enabled = False
        Me.gdAirDomData.Visible = False
        Me.tblDomPg.Visible = False
        Me.gdDomView.Visible = True
        Me.tblDomPg2.Visible = True
       
        'Air - LCC
        Me.ddlAirLccCC.Enabled = False
        Me.ddlAirLccMode.Enabled = False
        Me.txtAirLccCardName.Readonly = True
        Me.txtAirLccCardNum.Readonly = True
        Me.txtAirLccExp.Enabled = False
        Me.btnAirLccAdd.Enabled = False
        Me.ddlAirLccCC.Enabled = False
        Me.gdAirLccData.Visible = False
        Me.tblLccPg.Visible = False
        Me.gdLccView.Visible = True
        Me.tblLccPg2.Visible = True
        
        'Hotel
        Me.ddlHotelCC.Enabled = False
        Me.ddlHotelMode.Enabled = False
        Me.txtHotelCardName.Readonly = True
        Me.txtHotelCardNum.Readonly = True
        Me.txtHotelExpDate.Enabled = False
        Me.btnHotelAdd.Enabled = False
        Me.ddlHotelCC.Enabled = False
        Me.gdHotelData.Visible = False
        Me.tblHotelPg.Visible = False
        Me.gdHotelView.Visible = True
        Me.tblHotelPg2.Visible = True
      
        'Car
        Me.ddlCarCC.Enabled = False
        Me.ddlCarPayMode.Enabled = False
        Me.txtCarCardName.Readonly = True
        Me.txtCarCardNum.Readonly = True
        Me.txtCarExp.Enabled = False
        Me.btnCarAdd.Enabled = False
        Me.ddlCarCC.Enabled = False
        Me.gdCarData.Visible = False
        Me.tblCarPg.Visible = False
        Me.gdCarView.Visible = True
        Me.tblCarPg2.Visible = True
        
        'AUX
        Me.ddlAuxCC.Enabled = False
        Me.ddlAuxPayMode.Enabled = False
        Me.txtAuxCardName.Readonly = True
        Me.txtAuxCardNum.Readonly = True
        Me.txtAuxExp.Enabled = False
        Me.btnAuxAdd.Enabled = False
        Me.ddlAuxCC.Enabled = False
        Me.gdAuxData.Visible = False
        Me.tblAuxPg.Visible = False
        Me.gdAuxView.Visible = True
        Me.tblAuxPg2.Visible = True


        Me.btnTrans.ShowSaveNextButton = False
        Me.btnTrans.SaveButton.Enabled = False
    End Sub

    Private Sub LoadPaymentCard()
        Dim PayBLL As New BusinessLogicLayer.ComPaymentCardBLL()
        Dim oDataTable As DataTable
        oDataTable = PayBLL.GetCardList()
        With Me.ddlAirDomCC
            .DataTextField = "CCDescription"
            .DataValueField = "CCCode"
            .DataSource = oDataTable
            .DataBind()
        End With
        With Me.ddlAirIntCC
            .DataTextField = "CCDescription"
            .DataValueField = "CCCode"
            .DataSource = oDataTable
            .DataBind()
        End With
        With Me.ddlAirLccCC
            .DataTextField = "CCDescription"
            .DataValueField = "CCCode"
            .DataSource = oDataTable
            .DataBind()
        End With
        With Me.ddlHotelCC
            .DataTextField = "CCDescription"
            .DataValueField = "CCCode"
            .DataSource = oDataTable
            .DataBind()
        End With
        With Me.ddlCarCC
            .DataTextField = "CCDescription"
            .DataValueField = "CCCode"
            .DataSource = oDataTable
            .DataBind()
        End With
        With Me.ddlAuxCC
            .DataTextField = "CCDescription"
            .DataValueField = "CCCode"
            .DataSource = oDataTable
            .DataBind()
        End With
    End Sub

    Private Sub LoadDropDownList()
        Call Me.LoadPaymentCard()
    End Sub

    Private Sub CreateAirDomDataTable()
        Me.AirDomDataTable = New DataTable("AirDomDataTable")
        With Me.AirDomDataTable
            .Columns.Add(New DataColumn("ItemNo", GetType(Integer)))
            .Columns.Add(New DataColumn("Name"))
            .Columns.Add(New DataColumn("CCVendor"))
            .Columns.Add(New DataColumn("CCNum"))
            .Columns.Add(New DataColumn("ExpDate"))

        End With
    End Sub


    Private Sub CreateAirIntDataTable()
        Me.AirIntDataTable = New DataTable("AirIntDataTable")
        With Me.AirIntDataTable
            .Columns.Add(New DataColumn("ItemNo", GetType(Integer)))
            .Columns.Add(New DataColumn("Name"))
            .Columns.Add(New DataColumn("CCVendor"))
            .Columns.Add(New DataColumn("CCNum"))
            .Columns.Add(New DataColumn("ExpDate"))

        End With
    End Sub

    Private Sub CreateAirLccDataTable()
        Me.AirLccDataTable = New DataTable("AirLccDataTable")
        With Me.AirLccDataTable
            .Columns.Add(New DataColumn("ItemNo", GetType(Integer)))
            .Columns.Add(New DataColumn("Name"))
            .Columns.Add(New DataColumn("CCVendor"))
            .Columns.Add(New DataColumn("CCNum"))
            .Columns.Add(New DataColumn("ExpDate"))

        End With
    End Sub

    Private Sub CreateHotelDataTable()
        Me.HotelDataTable = New DataTable("HotelDataTable")
        With Me.HotelDataTable
            .Columns.Add(New DataColumn("ItemNo", GetType(Integer)))
            .Columns.Add(New DataColumn("Name"))
            .Columns.Add(New DataColumn("CCVendor"))
            .Columns.Add(New DataColumn("CCNum"))
            .Columns.Add(New DataColumn("ExpDate"))

        End With
    End Sub

    Private Sub CreateCarDataTable()
        Me.CarDataTable = New DataTable("CarDataTable")
        With Me.CarDataTable
            .Columns.Add(New DataColumn("ItemNo", GetType(Integer)))
            .Columns.Add(New DataColumn("Name"))
            .Columns.Add(New DataColumn("CCVendor"))
            .Columns.Add(New DataColumn("CCNum"))
            .Columns.Add(New DataColumn("ExpDate"))

        End With
    End Sub

    Private Sub CreateAuxDataTable()
        Me.AuxDataTable = New DataTable("AuxDataTable")
        With Me.AuxDataTable
            .Columns.Add(New DataColumn("ItemNo", GetType(Integer)))
            .Columns.Add(New DataColumn("Name"))
            .Columns.Add(New DataColumn("CCVendor"))
            .Columns.Add(New DataColumn("CCNum"))
            .Columns.Add(New DataColumn("ExpDate"))

        End With
    End Sub

    Private Function ValidateCard1() As Boolean
        Dim oDataTable As DataTable
        Dim r As DataRow
        Dim CardNo As String
        Dim Vendor As String
        Dim NumLength As Integer = 0
        Dim CardPattern As String = ""
        Dim retVal As Boolean = False
        Dim reg As Regex
        Dim ValidateNo As String = ""
        Dim ModNumber As Integer = 10
        Dim SumDigit As Integer = 0
        Dim tempNo As Integer
        Dim isEven As Boolean = False
        CardNo = Me.txtAirIntCardNum.Text
        Vendor = Me.ddlAirIntCC.SelectedValue
        oDataTable = Me.BLL.GetCardValidateFormat(Vendor)
        If oDataTable IsNot Nothing AndAlso oDataTable.Rows.Count > 0 Then
            '// Check format
            For i As Integer = 0 To oDataTable.Rows.Count - 1
                r = oDataTable.Rows(i)
                CardPattern = r("RegExpFormat").ToString
                NumLength = Util.DBNullToZero(r("NumberLength"))
                If CardNo.Length = NumLength Then
                    reg = New Regex(CardPattern)
                    If reg.IsMatch(CardNo) Then
                        retVal = True
                        Exit For
                    End If
                End If
            Next
            If retVal Then
                '// Do Mod
                ValidateNo = Format(CLng(CardNo), "00000000000000000000")
                For i As Integer = ValidateNo.Length - 1 To 0 Step -1
                    tempNo = Util.DBNullToZero(ValidateNo(i).ToString)
                    If isEven Then
                        tempNo = (tempNo * 2)
                        If tempNo >= 10 Then
                            tempNo = (tempNo \ ModNumber) + (tempNo Mod ModNumber)
                        End If
                    End If
                    Debug.Print(tempNo.ToString)
                    SumDigit += tempNo
                    Debug.Print("===" + SumDigit.ToString)
                    isEven = Not isEven
                Next
                retVal = ((SumDigit Mod ModNumber) = 0)
            End If
        End If
        Return retVal
    End Function

    Private Function ValidateCard2() As Boolean
        Dim oDataTable As DataTable
        Dim r As DataRow
        Dim CardNo As String
        Dim Vendor As String
        Dim NumLength As Integer = 0
        Dim CardPattern As String = ""
        Dim retVal As Boolean = False
        Dim reg As Regex
        Dim ValidateNo As String = ""
        Dim ModNumber As Integer = 10
        Dim SumDigit As Integer = 0
        Dim tempNo As Integer
        Dim isEven As Boolean = False
        CardNo = Me.txtAirDomCardNum.Text
        Vendor = Me.ddlAirDomCC.SelectedValue
        oDataTable = Me.BLL.GetCardValidateFormat(Vendor)
        If oDataTable IsNot Nothing AndAlso oDataTable.Rows.Count > 0 Then
            '// Check format
            For i As Integer = 0 To oDataTable.Rows.Count - 1
                r = oDataTable.Rows(i)
                CardPattern = r("RegExpFormat").ToString
                NumLength = Util.DBNullToZero(r("NumberLength"))
                If CardNo.Length = NumLength Then
                    reg = New Regex(CardPattern)
                    If reg.IsMatch(CardNo) Then
                        retVal = True
                        Exit For
                    End If
                End If
            Next
            If retVal Then
                '// Do Mod
                ValidateNo = Format(CLng(CardNo), "00000000000000000000")
                For i As Integer = ValidateNo.Length - 1 To 0 Step -1
                    tempNo = Util.DBNullToZero(ValidateNo(i).ToString)
                    If isEven Then
                        tempNo = (tempNo * 2)
                        If tempNo >= 10 Then
                            tempNo = (tempNo \ ModNumber) + (tempNo Mod ModNumber)
                        End If
                    End If
                    Debug.Print(tempNo.ToString)
                    SumDigit += tempNo
                    Debug.Print("===" + SumDigit.ToString)
                    isEven = Not isEven
                Next
                retVal = ((SumDigit Mod ModNumber) = 0)
            End If
        End If
        Return retVal
    End Function


    Private Function ValidateCard3() As Boolean
        Dim oDataTable As DataTable
        Dim r As DataRow
        Dim CardNo As String
        Dim Vendor As String
        Dim NumLength As Integer = 0
        Dim CardPattern As String = ""
        Dim retVal As Boolean = False
        Dim reg As Regex
        Dim ValidateNo As String = ""
        Dim ModNumber As Integer = 10
        Dim SumDigit As Integer = 0
        Dim tempNo As Integer
        Dim isEven As Boolean = False
        CardNo = Me.txtAirLccCardNum.Text
        Vendor = Me.ddlAirLccCC.SelectedValue
        oDataTable = Me.BLL.GetCardValidateFormat(Vendor)
        If oDataTable IsNot Nothing AndAlso oDataTable.Rows.Count > 0 Then
            '// Check format
            For i As Integer = 0 To oDataTable.Rows.Count - 1
                r = oDataTable.Rows(i)
                CardPattern = r("RegExpFormat").ToString
                NumLength = Util.DBNullToZero(r("NumberLength"))
                If CardNo.Length = NumLength Then
                    reg = New Regex(CardPattern)
                    If reg.IsMatch(CardNo) Then
                        retVal = True
                        Exit For
                    End If
                End If
            Next
            If retVal Then
                '// Do Mod
                ValidateNo = Format(CLng(CardNo), "00000000000000000000")
                For i As Integer = ValidateNo.Length - 1 To 0 Step -1
                    tempNo = Util.DBNullToZero(ValidateNo(i).ToString)
                    If isEven Then
                        tempNo = (tempNo * 2)
                        If tempNo >= 10 Then
                            tempNo = (tempNo \ ModNumber) + (tempNo Mod ModNumber)
                        End If
                    End If
                    Debug.Print(tempNo.ToString)
                    SumDigit += tempNo
                    Debug.Print("===" + SumDigit.ToString)
                    isEven = Not isEven
                Next
                retVal = ((SumDigit Mod ModNumber) = 0)
            End If
        End If
        Return retVal
    End Function


    Private Function ValidateCard4() As Boolean
        Dim oDataTable As DataTable
        Dim r As DataRow
        Dim CardNo As String
        Dim Vendor As String
        Dim NumLength As Integer = 0
        Dim CardPattern As String = ""
        Dim retVal As Boolean = False
        Dim reg As Regex
        Dim ValidateNo As String = ""
        Dim ModNumber As Integer = 10
        Dim SumDigit As Integer = 0
        Dim tempNo As Integer
        Dim isEven As Boolean = False
        CardNo = Me.txtHotelCardNum.Text
        Vendor = Me.ddlHotelCC.SelectedValue
        oDataTable = Me.BLL.GetCardValidateFormat(Vendor)
        If oDataTable IsNot Nothing AndAlso oDataTable.Rows.Count > 0 Then
            '// Check format
            For i As Integer = 0 To oDataTable.Rows.Count - 1
                r = oDataTable.Rows(i)
                CardPattern = r("RegExpFormat").ToString
                NumLength = Util.DBNullToZero(r("NumberLength"))
                If CardNo.Length = NumLength Then
                    reg = New Regex(CardPattern)
                    If reg.IsMatch(CardNo) Then
                        retVal = True
                        Exit For
                    End If
                End If
            Next
            If retVal Then
                '// Do Mod
                ValidateNo = Format(CLng(CardNo), "00000000000000000000")
                For i As Integer = ValidateNo.Length - 1 To 0 Step -1
                    tempNo = Util.DBNullToZero(ValidateNo(i).ToString)
                    If isEven Then
                        tempNo = (tempNo * 2)
                        If tempNo >= 10 Then
                            tempNo = (tempNo \ ModNumber) + (tempNo Mod ModNumber)
                        End If
                    End If
                    Debug.Print(tempNo.ToString)
                    SumDigit += tempNo
                    Debug.Print("===" + SumDigit.ToString)
                    isEven = Not isEven
                Next
                retVal = ((SumDigit Mod ModNumber) = 0)
            End If
        End If
        Return retVal
    End Function


    Private Function ValidateCard5() As Boolean
        Dim oDataTable As DataTable
        Dim r As DataRow
        Dim CardNo As String
        Dim Vendor As String
        Dim NumLength As Integer = 0
        Dim CardPattern As String = ""
        Dim retVal As Boolean = False
        Dim reg As Regex
        Dim ValidateNo As String = ""
        Dim ModNumber As Integer = 10
        Dim SumDigit As Integer = 0
        Dim tempNo As Integer
        Dim isEven As Boolean = False
        CardNo = Me.txtCarCardNum.Text
        Vendor = Me.ddlCarCC.SelectedValue
        oDataTable = Me.BLL.GetCardValidateFormat(Vendor)
        If oDataTable IsNot Nothing AndAlso oDataTable.Rows.Count > 0 Then
            '// Check format
            For i As Integer = 0 To oDataTable.Rows.Count - 1
                r = oDataTable.Rows(i)
                CardPattern = r("RegExpFormat").ToString
                NumLength = Util.DBNullToZero(r("NumberLength"))
                If CardNo.Length = NumLength Then
                    reg = New Regex(CardPattern)
                    If reg.IsMatch(CardNo) Then
                        retVal = True
                        Exit For
                    End If
                End If
            Next
            If retVal Then
                '// Do Mod
                ValidateNo = Format(CLng(CardNo), "00000000000000000000")
                For i As Integer = ValidateNo.Length - 1 To 0 Step -1
                    tempNo = Util.DBNullToZero(ValidateNo(i).ToString)
                    If isEven Then
                        tempNo = (tempNo * 2)
                        If tempNo >= 10 Then
                            tempNo = (tempNo \ ModNumber) + (tempNo Mod ModNumber)
                        End If
                    End If
                    Debug.Print(tempNo.ToString)
                    SumDigit += tempNo
                    Debug.Print("===" + SumDigit.ToString)
                    isEven = Not isEven
                Next
                retVal = ((SumDigit Mod ModNumber) = 0)
            End If
        End If
        Return retVal
    End Function


    Private Function ValidateCard6() As Boolean
        Dim oDataTable As DataTable
        Dim r As DataRow
        Dim CardNo As String
        Dim Vendor As String
        Dim NumLength As Integer = 0
        Dim CardPattern As String = ""
        Dim retVal As Boolean = False
        Dim reg As Regex
        Dim ValidateNo As String = ""
        Dim ModNumber As Integer = 10
        Dim SumDigit As Integer = 0
        Dim tempNo As Integer
        Dim isEven As Boolean = False
        CardNo = Me.txtAuxCardNum.Text
        Vendor = Me.ddlAuxCC.SelectedValue
        oDataTable = Me.BLL.GetCardValidateFormat(Vendor)
        If oDataTable IsNot Nothing AndAlso oDataTable.Rows.Count > 0 Then
            '// Check format
            For i As Integer = 0 To oDataTable.Rows.Count - 1
                r = oDataTable.Rows(i)
                CardPattern = r("RegExpFormat").ToString
                NumLength = Util.DBNullToZero(r("NumberLength"))
                If CardNo.Length = NumLength Then
                    reg = New Regex(CardPattern)
                    If reg.IsMatch(CardNo) Then
                        retVal = True
                        Exit For
                    End If
                End If
            Next
            If retVal Then
                '// Do Mod
                ValidateNo = Format(CLng(CardNo), "00000000000000000000")
                For i As Integer = ValidateNo.Length - 1 To 0 Step -1
                    tempNo = Util.DBNullToZero(ValidateNo(i).ToString)
                    If isEven Then
                        tempNo = (tempNo * 2)
                        If tempNo >= 10 Then
                            tempNo = (tempNo \ ModNumber) + (tempNo Mod ModNumber)
                        End If
                    End If
                    Debug.Print(tempNo.ToString)
                    SumDigit += tempNo
                    Debug.Print("===" + SumDigit.ToString)
                    isEven = Not isEven
                Next
                retVal = ((SumDigit Mod ModNumber) = 0)
            End If
        End If
        Return retVal
    End Function

    Private Sub AddAirDomData()
        Dim dr As DataRow
        Dim filter As String = ""
        Dim type As String
        Dim val As String
        Dim FoundRow As DataRow()

        If Not Me.ValidateCard2() Then
            Me.lblMsgBox.Text = "Card number is invalid under Air Domestic."
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.ajaxMsgBox.Show()
            Exit Sub
        End If

        type = Me.ddlAirDomCC.SelectedValue
        val = Me.txtAirDomCardNum.Text
        filter = "CCNum=" + Util.LimitTheString(val) + " and " + "CCVendor=" + Util.LimitTheString(type)
        FoundRow = Me.AirDomDataTable.Select(filter)
        If FoundRow IsNot Nothing AndAlso FoundRow.Length > 0 Then
            Me.lblMsgBox.Text = "Cannot add duplicated value under Air Domestic."
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.ajaxMsgBox.Show()
            Exit Sub
        End If

        dr = Me.AirDomDataTable.NewRow()
        If Me.AirDomDataTable.Rows.Count > 0 Then
            dr("ItemNo") = Util.DBNullToZero(Me.AirDomDataTable.Rows(Me.AirDomDataTable.Rows.Count - 1).Item("ItemNo") + 1)
        Else
            dr("ItemNo") = 1
        End If
        dr("Name") = Me.txtAirdomCardName.Text
        dr("CCVendor") = Me.ddlAirDomCC.SelectedValue
        dr("CCNum") = Me.txtAirDomCardNum.Text
        dr("ExpDate") = Me.txtAirDomExp.Text
        Me.AirDomDataTable.Rows.Add(dr)

    End Sub

    Private Sub AddAirIntData()
        Dim dr As DataRow
        Dim filter As String = ""
        Dim type As String
        Dim val As String
        Dim FoundRow As DataRow()

        If Not Me.ValidateCard1() Then
            Me.lblMsgBox.Text = "Card number is invalid under Air International."
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.ajaxMsgBox.Show()
            Exit Sub
        End If

        type = Me.ddlAirIntCC.SelectedValue
        val = Me.txtAirIntCardNum.Text
        filter = "CCNum=" + Util.LimitTheString(val) + " and " + "CCVendor=" + Util.LimitTheString(type)
        FoundRow = Me.AirIntDataTable.Select(filter)
        If FoundRow IsNot Nothing AndAlso FoundRow.Length > 0 Then
            Me.lblMsgBox.Text = "Cannot add duplicated value under Air International."
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.ajaxMsgBox.Show()
            Exit Sub
        End If

        dr = Me.AirIntDataTable.NewRow()
        If Me.AirIntDataTable.Rows.Count > 0 Then
            dr("ItemNo") = Util.DBNullToZero(Me.AirIntDataTable.Rows(Me.AirIntDataTable.Rows.Count - 1).Item("ItemNo") + 1)
        Else
            dr("ItemNo") = 1
        End If
        dr("Name") = Me.txtAirIntCardName.Text
        dr("CCVendor") = Me.ddlAirIntCC.SelectedValue
        dr("CCNum") = Me.txtAirIntCardNum.Text
        dr("ExpDate") = Me.txtAirIntExp.Text
        Me.AirIntDataTable.Rows.Add(dr)

    End Sub

    Private Sub AddAirLccData()
        Dim dr As DataRow
        Dim filter As String = ""
        Dim type As String
        Dim val As String
        Dim FoundRow As DataRow()

        If Not Me.ValidateCard3() Then
            Me.lblMsgBox.Text = "Card number is invalid under Air LCC."
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.ajaxMsgBox.Show()
            Exit Sub
        End If

        type = Me.ddlAirLccCC.SelectedValue
        val = Me.txtAirLccCardNum.Text
        filter = "CCNum=" + Util.LimitTheString(val) + " and " + "CCVendor=" + Util.LimitTheString(type)
        FoundRow = Me.AirLccDataTable.Select(filter)
        If FoundRow IsNot Nothing AndAlso FoundRow.Length > 0 Then
            Me.lblMsgBox.Text = "Cannot add duplicated value under Air LCC."
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.ajaxMsgBox.Show()
            Exit Sub
        End If

        dr = Me.AirLccDataTable.NewRow()
        If Me.AirLccDataTable.Rows.Count > 0 Then
            dr("ItemNo") = Util.DBNullToZero(Me.AirLccDataTable.Rows(Me.AirLccDataTable.Rows.Count - 1).Item("ItemNo") + 1)
        Else
            dr("ItemNo") = 1
        End If
        dr("Name") = Me.txtAirLccCardName.Text
        dr("CCVendor") = Me.ddlAirLccCC.SelectedValue
        dr("CCNum") = Me.txtAirLccCardNum.Text
        dr("ExpDate") = Me.txtAirLccExp.Text
        Me.AirLccDataTable.Rows.Add(dr)

    End Sub

    Private Sub AddHotelData()
        Dim dr As DataRow
        Dim filter As String = ""
        Dim type As String
        Dim val As String
        Dim FoundRow As DataRow()

        If Not Me.ValidateCard4() Then
            Me.lblMsgBox.Text = "Card number is invalid under Hotel."
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.ajaxMsgBox.Show()
            Exit Sub
        End If

        type = Me.ddlHotelCC.SelectedValue
        val = Me.txtHotelCardNum.Text
        filter = "CCNum=" + Util.LimitTheString(val) + " and " + "CCVendor=" + Util.LimitTheString(type)
        FoundRow = Me.HotelDataTable.Select(filter)
        If FoundRow IsNot Nothing AndAlso FoundRow.Length > 0 Then
            Me.lblMsgBox.Text = "Cannot add duplicated value under Hotel."
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.ajaxMsgBox.Show()
            Exit Sub
        End If

        dr = Me.HotelDataTable.NewRow()
        If Me.HotelDataTable.Rows.Count > 0 Then
            dr("ItemNo") = Util.DBNullToZero(Me.HotelDataTable.Rows(Me.HotelDataTable.Rows.Count - 1).Item("ItemNo") + 1)
        Else
            dr("ItemNo") = 1
        End If
        dr("Name") = Me.txtHotelCardName.Text
        dr("CCVendor") = Me.ddlHotelCC.SelectedValue
        dr("CCNum") = Me.txtHotelCardNum.Text
        dr("ExpDate") = Me.txtHotelExpDate.Text
        Me.HotelDataTable.Rows.Add(dr)

    End Sub


    Private Sub AddCarData()
        Dim dr As DataRow
        Dim filter As String = ""
        Dim type As String
        Dim val As String
        Dim FoundRow As DataRow()

        If Not Me.ValidateCard5() Then
            Me.lblMsgBox.Text = "Card number is invalid under Car."
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.ajaxMsgBox.Show()
            Exit Sub
        End If

        type = Me.ddlCarCC.SelectedValue
        val = Me.txtCarCardNum.Text
        filter = "CCNum=" + Util.LimitTheString(val) + " and " + "CCVendor=" + Util.LimitTheString(type)
        FoundRow = Me.CarDataTable.Select(filter)
        If FoundRow IsNot Nothing AndAlso FoundRow.Length > 0 Then
            Me.lblMsgBox.Text = "Cannot add duplicated value under Car."
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.ajaxMsgBox.Show()
            Exit Sub
        End If

        dr = Me.CarDataTable.NewRow()
        If Me.CarDataTable.Rows.Count > 0 Then
            dr("ItemNo") = Util.DBNullToZero(Me.CarDataTable.Rows(Me.CarDataTable.Rows.Count - 1).Item("ItemNo") + 1)
        Else
            dr("ItemNo") = 1
        End If
        dr("Name") = Me.txtCarCardName.Text
        dr("CCVendor") = Me.ddlCarCC.SelectedValue
        dr("CCNum") = Me.txtCarCardNum.Text
        dr("ExpDate") = Me.txtCarExp.Text
        Me.CarDataTable.Rows.Add(dr)

    End Sub


    Private Sub AddAuxData()
        Dim dr As DataRow
        Dim filter As String = ""
        Dim type As String
        Dim val As String
        Dim FoundRow As DataRow()

        If Not Me.ValidateCard6() Then
            Me.lblMsgBox.Text = "Card number is invalid under Auxilirary."
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.ajaxMsgBox.Show()
            Exit Sub
        End If

        type = Me.ddlAuxCC.SelectedValue
        val = Me.txtAuxCardNum.Text
        filter = "CCNum=" + Util.LimitTheString(val) + " and " + "CCVendor=" + Util.LimitTheString(type)
        FoundRow = Me.AuxDataTable.Select(filter)
        If FoundRow IsNot Nothing AndAlso FoundRow.Length > 0 Then
            Me.lblMsgBox.Text = "Cannot add duplicated value under Auxilirary."
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.ajaxMsgBox.Show()
            Exit Sub
        End If

        dr = Me.AuxDataTable.NewRow()
        If Me.AuxDataTable.Rows.Count > 0 Then
            dr("ItemNo") = Util.DBNullToZero(Me.AuxDataTable.Rows(Me.AuxDataTable.Rows.Count - 1).Item("ItemNo") + 1)
        Else
            dr("ItemNo") = 1
        End If
        dr("Name") = Me.txtAuxCardName.Text
        dr("CCVendor") = Me.ddlAuxCC.SelectedValue
        dr("CCNum") = Me.txtAuxCardNum.Text
        dr("ExpDate") = Me.txtAuxExp.Text
        Me.AuxDataTable.Rows.Add(dr)

    End Sub

    Private Sub LoadNewAirIntData()
        Me.txtAirIntHid.Value = ""
        Me.ddlAirIntCC.SelectedIndex = -1
        Me.txtAirIntCardName.Text = ""
        Me.txtAirIntCardNum.Text = ""
        Me.txtAirIntExp.Text = ""
       
        Me.btnAirIntAdd.Text = "Add"
    End Sub

    Private Sub LoadNewAirDomData()
        Me.txtAirDomHid.Value = ""
        Me.ddlAirDomCC.SelectedIndex = -1
        Me.txtAirDomCardName.Text = ""
        Me.txtAirDomCardNum.Text = ""
        Me.txtAirDomExp.Text = ""

        Me.btnAirDomAdd.Text = "Add"
    End Sub

    Private Sub LoadNewAirLccData()
        Me.txtAirLccHid.Value = ""
        Me.ddlAirLccCC.SelectedIndex = -1
        Me.txtAirLccCardName.Text = ""
        Me.txtAirLccCardNum.Text = ""
        Me.txtAirLccExp.Text = ""

        Me.btnAirLccAdd.Text = "Add"
    End Sub

    Private Sub LoadNewHotelData()
        Me.txtHotelHid.Value = ""
        Me.ddlHotelCC.SelectedIndex = -1
        Me.txtHotelCardName.Text = ""
        Me.txtHotelCardNum.Text = ""
        Me.txtHotelExpDate.Text = ""

        Me.btnHotelAdd.Text = "Add"
    End Sub


    Private Sub LoadNewCarData()
        Me.txtCarHid.Value = ""
        Me.ddlCarCC.SelectedIndex = -1
        Me.txtCarCardName.Text = ""
        Me.txtCarCardNum.Text = ""
        Me.txtCarExp.Text = ""

        Me.btnCarAdd.Text = "Add"
    End Sub


    Private Sub LoadNewAuxData()
        Me.txtAuxHid.Value = ""
        Me.ddlAuxCC.SelectedIndex = -1
        Me.txtAuxCardName.Text = ""
        Me.txtAuxCardNum.Text = ""
        Me.txtAuxExp.Text = ""

        Me.btnAuxAdd.Text = "Add"
    End Sub

   

    Private Sub LoadAirIntData(ByVal ItemNo As String)
        Dim dr As DataRow()
        Dim filter As String = ""
        filter = "ItemNo=" + Util.LimitTheString(ItemNo)
        dr = Me.AirIntDataTable.Select(filter)
        If dr IsNot Nothing AndAlso dr.Length > 0 Then
            Me.txtAirIntHid.Value = ItemNo
            Me.txtAirIntCardName.Text = dr(0).Item("Name").ToString
            Me.ddlAirIntCC.SelectedValue = dr(0).Item("CCVendor").ToString
            Me.txtAirIntCardNum.Text = dr(0).Item("CCNum").ToString
            Me.txtAirIntExp.Text = dr(0).Item("ExpDate").ToString
           
        End If
    End Sub

    Private Sub LoadAirDomData(ByVal ItemNo As String)
        Dim dr As DataRow()
        Dim filter As String = ""
        filter = "ItemNo=" + Util.LimitTheString(ItemNo)
        dr = Me.AirDomDataTable.Select(filter)
        If dr IsNot Nothing AndAlso dr.Length > 0 Then
            Me.txtAirDomHid.Value = ItemNo
            Me.txtAirDomCardName.Text = dr(0).Item("Name").ToString
            Me.ddlAirDomCC.SelectedValue = dr(0).Item("CCVendor").ToString
            Me.txtAirDomCardNum.Text = dr(0).Item("CCNum").ToString
            Me.txtAirDomExp.Text = dr(0).Item("ExpDate").ToString

        End If
    End Sub

    Private Sub LoadAirLccData(ByVal ItemNo As String)
        Dim dr As DataRow()
        Dim filter As String = ""
        filter = "ItemNo=" + Util.LimitTheString(ItemNo)
        dr = Me.AirLccDataTable.Select(filter)
        If dr IsNot Nothing AndAlso dr.Length > 0 Then
            Me.txtAirLccHid.Value = ItemNo
            Me.txtAirLccCardName.Text = dr(0).Item("Name").ToString
            Me.ddlAirLccCC.SelectedValue = dr(0).Item("CCVendor").ToString
            Me.txtAirLccCardNum.Text = dr(0).Item("CCNum").ToString
            Me.txtAirLccExp.Text = dr(0).Item("ExpDate").ToString

        End If
    End Sub

    Private Sub LoadHotelData(ByVal ItemNo As String)
        Dim dr As DataRow()
        Dim filter As String = ""
        filter = "ItemNo=" + Util.LimitTheString(ItemNo)
        dr = Me.HotelDataTable.Select(filter)
        If dr IsNot Nothing AndAlso dr.Length > 0 Then
            Me.txtHotelHid.Value = ItemNo
            Me.txtHotelCardName.Text = dr(0).Item("Name").ToString
            Me.ddlHotelCC.SelectedValue = dr(0).Item("CCVendor").ToString
            Me.txtHotelCardNum.Text = dr(0).Item("CCNum").ToString
            Me.txtHotelExpDate.Text = dr(0).Item("ExpDate").ToString

        End If
    End Sub

    Private Sub LoadCarData(ByVal ItemNo As String)
        Dim dr As DataRow()
        Dim filter As String = ""
        filter = "ItemNo=" + Util.LimitTheString(ItemNo)
        dr = Me.CarDataTable.Select(filter)
        If dr IsNot Nothing AndAlso dr.Length > 0 Then
            Me.txtCarHid.Value = ItemNo
            Me.txtCarCardName.Text = dr(0).Item("Name").ToString
            Me.ddlCarCC.SelectedValue = dr(0).Item("CCVendor").ToString
            Me.txtCarCardNum.Text = dr(0).Item("CCNum").ToString
            Me.txtCarExp.Text = dr(0).Item("ExpDate").ToString

        End If
    End Sub

    Private Sub LoadAuxData(ByVal ItemNo As String)
        Dim dr As DataRow()
        Dim filter As String = ""
        filter = "ItemNo=" + Util.LimitTheString(ItemNo)
        dr = Me.AuxDataTable.Select(filter)
        If dr IsNot Nothing AndAlso dr.Length > 0 Then
            Me.txtAuxHid.Value = ItemNo
            Me.txtAuxCardName.Text = dr(0).Item("Name").ToString
            Me.ddlAuxCC.SelectedValue = dr(0).Item("CCVendor").ToString
            Me.txtAuxCardNum.Text = dr(0).Item("CCNum").ToString
            Me.txtAuxExp.Text = dr(0).Item("ExpDate").ToString

        End If
    End Sub


    Private Sub LoadAirIntDataFromDB()
        Dim oDataTable As DataTable
        Dim oDataTable2 As DataTable
        Dim oRow2 As DataRow
        Dim oRow As DataRow
        Dim dr As DataRow

        Dim PayMode As String = ""

        oDataTable2 = Me.BLL.GetPaymentMode(Me.CurrentClientID, "AirInt")
        If oDataTable2.Rows.Count <> 0 Then
            For k As Integer = 0 To oDataTable2.Rows.Count - 1
                oRow2 = oDataTable2.Rows(0)
                PayMode = oRow2("PayMode").ToString
            Next
            Me.ddlAirIntMode.SelectedValue = PayMode

        Else
            Me.ddlAirIntMode.SelectedValue = "CORPCC"

        End If

        Select Case PayMode


            Case "CORPCC"
                oDataTable = Me.BLL.GetClientCard(Me.CurrentClientID, "AirInt", PayMode)
                If oDataTable IsNot Nothing Then
                    For i As Integer = 0 To oDataTable.Rows.Count - 1
                        oRow = oDataTable.Rows(i)
                        dr = Me.AirIntDataTable.NewRow()
                        If Me.AirIntDataTable.Rows.Count > 0 Then
                            dr("ItemNo") = Util.DBNullToZero(Me.AirIntDataTable.Rows(Me.AirIntDataTable.Rows.Count - 1).Item("ItemNo") + 1)
                        Else
                            dr("ItemNo") = 1
                        End If
                        dr("Name") = oRow("Name").ToString
                        dr("CCVendor") = oRow("CCVendor").ToString
                        dr("CCNum") = oRow("CCNumber").ToString
                        If IsDBNull(oRow("ExpDate")) Then
                            dr("ExpDate") = ""
                        Else
                            dr("ExpDate") = Format(oRow("ExpDate"), "MM/dd/yyyy")
                        End If
                        Me.AirIntDataTable.Rows.Add(dr)
                    Next
                    Call Me.RefreshAirIntGrid()
                End If
        End Select
    End Sub

    Private Sub LoadAirDomDataFromDB()
        Dim oDataTable As DataTable
        Dim oDataTable2 As DataTable
        Dim oRow2 As DataRow
        Dim oRow As DataRow
        Dim dr As DataRow

        Dim PayMode As String = ""

        oDataTable2 = Me.BLL.GetPaymentMode(Me.CurrentClientID, "AirDom")
        If oDataTable2.Rows.Count <> 0 Then
            For k As Integer = 0 To oDataTable2.Rows.Count - 1
                oRow2 = oDataTable2.Rows(0)
                PayMode = oRow2("PayMode").ToString
            Next
            Me.ddlAirDomMode.SelectedValue = PayMode

        Else
            Me.ddlAirDomMode.SelectedValue = "CORPCC"

        End If
        Select Case PayMode


            Case "CORPCC"
                oDataTable = Me.BLL.GetClientCard(Me.CurrentClientID, "AirDom", PayMode)
                If oDataTable IsNot Nothing Then
                    For i As Integer = 0 To oDataTable.Rows.Count - 1
                        oRow = oDataTable.Rows(i)
                        dr = Me.AirDomDataTable.NewRow()
                        If Me.AirDomDataTable.Rows.Count > 0 Then
                            dr("ItemNo") = Util.DBNullToZero(Me.AirDomDataTable.Rows(Me.AirDomDataTable.Rows.Count - 1).Item("ItemNo") + 1)
                        Else
                            dr("ItemNo") = 1
                        End If
                        dr("Name") = oRow("Name").ToString
                        dr("CCVendor") = oRow("CCVendor").ToString
                        dr("CCNum") = oRow("CCNumber").ToString
                        If IsDBNull(oRow("ExpDate")) Then
                            dr("ExpDate") = ""
                        Else
                            dr("ExpDate") = Format(oRow("ExpDate"), "MM/dd/yyyy")
                        End If
                        Me.AirDomDataTable.Rows.Add(dr)
                    Next
                    Call Me.RefreshAirDomGrid()
                End If
        End Select

       
    End Sub
   

    Private Sub LoadAirLccDataFromDB()
        Dim oDataTable As DataTable
        Dim oDataTable2 As DataTable
        Dim oRow2 As DataRow
        Dim oRow As DataRow
        Dim dr As DataRow

        Dim PayMode As String = ""

        oDataTable2 = Me.BLL.GetPaymentMode(Me.CurrentClientID, "AirLCC")
        If oDataTable2.Rows.Count <> 0 Then
            For k As Integer = 0 To oDataTable2.Rows.Count - 1
                oRow2 = oDataTable2.Rows(0)
                PayMode = oRow2("PayMode").ToString
            Next
            Me.ddlAirLccMode.SelectedValue = PayMode

        Else
            Me.ddlAirLccMode.SelectedValue = "CORPCC"

        End If
        Select Case PayMode


            Case "CORPCC"
                oDataTable = Me.BLL.GetClientCard(Me.CurrentClientID, "AirLCC", PayMode)
                If oDataTable IsNot Nothing Then
                    For i As Integer = 0 To oDataTable.Rows.Count - 1
                        oRow = oDataTable.Rows(i)
                        dr = Me.AirLccDataTable.NewRow()
                        If Me.AirLccDataTable.Rows.Count > 0 Then
                            dr("ItemNo") = Util.DBNullToZero(Me.AirLccDataTable.Rows(Me.AirLccDataTable.Rows.Count - 1).Item("ItemNo") + 1)
                        Else
                            dr("ItemNo") = 1
                        End If
                        dr("Name") = oRow("Name").ToString
                        dr("CCVendor") = oRow("CCVendor").ToString
                        dr("CCNum") = oRow("CCNumber").ToString
                        If IsDBNull(oRow("ExpDate")) Then
                            dr("ExpDate") = ""
                        Else
                            dr("ExpDate") = Format(oRow("ExpDate"), "MM/dd/yyyy")
                        End If
                        Me.AirLccDataTable.Rows.Add(dr)
                    Next
                    Call Me.RefreshAirLccGrid()
                End If
        End Select


    End Sub

    Private Sub LoadHotelDataFromDB()
        Dim oDataTable As DataTable
        Dim oDataTable2 As DataTable
        Dim oRow2 As DataRow
        Dim oRow As DataRow
        Dim dr As DataRow

        Dim PayMode As String = ""

        oDataTable2 = Me.BLL.GetPaymentMode(Me.CurrentClientID, "Hotel")
        If oDataTable2.Rows.Count <> 0 Then
            For k As Integer = 0 To oDataTable2.Rows.Count - 1
                oRow2 = oDataTable2.Rows(0)
                PayMode = oRow2("PayMode").ToString
            Next
            Me.ddlHotelMode.SelectedValue = PayMode

        Else
            Me.ddlHotelMode.SelectedValue = "CORPCC"

        End If
        Select Case PayMode


            Case "CORPCC"
                oDataTable = Me.BLL.GetClientCard(Me.CurrentClientID, "Hotel", PayMode)
                If oDataTable IsNot Nothing Then
                    For i As Integer = 0 To oDataTable.Rows.Count - 1
                        oRow = oDataTable.Rows(i)
                        dr = Me.HotelDataTable.NewRow()
                        If Me.HotelDataTable.Rows.Count > 0 Then
                            dr("ItemNo") = Util.DBNullToZero(Me.HotelDataTable.Rows(Me.HotelDataTable.Rows.Count - 1).Item("ItemNo") + 1)
                        Else
                            dr("ItemNo") = 1
                        End If
                        dr("Name") = oRow("Name").ToString
                        dr("CCVendor") = oRow("CCVendor").ToString
                        dr("CCNum") = oRow("CCNumber").ToString
                        If IsDBNull(oRow("ExpDate")) Then
                            dr("ExpDate") = ""
                        Else
                            dr("ExpDate") = Format(oRow("ExpDate"), "MM/dd/yyyy")
                        End If
                        Me.HotelDataTable.Rows.Add(dr)
                    Next
                    Call Me.RefreshHotelGrid()
                End If
        End Select


    End Sub

    Private Sub LoadCarDataFromDB()
        Dim oDataTable As DataTable
        Dim oDataTable2 As DataTable
        Dim oRow2 As DataRow
        Dim oRow As DataRow
        Dim dr As DataRow

        Dim PayMode As String = ""

        oDataTable2 = Me.BLL.GetPaymentMode(Me.CurrentClientID, "Car")
        If oDataTable2.Rows.Count <> 0 Then
            For k As Integer = 0 To oDataTable2.Rows.Count - 1
                oRow2 = oDataTable2.Rows(0)
                PayMode = oRow2("PayMode").ToString
            Next
            Me.ddlCarPayMode.SelectedValue = PayMode

        Else
            Me.ddlCarPayMode.SelectedValue = "CORPCC"

        End If
        Select Case PayMode


            Case "CORPCC"
                oDataTable = Me.BLL.GetClientCard(Me.CurrentClientID, "Aux", PayMode)
                If oDataTable IsNot Nothing Then
                    For i As Integer = 0 To oDataTable.Rows.Count - 1
                        oRow = oDataTable.Rows(i)
                        dr = Me.CarDataTable.NewRow()
                        If Me.CarDataTable.Rows.Count > 0 Then
                            dr("ItemNo") = Util.DBNullToZero(Me.CarDataTable.Rows(Me.CarDataTable.Rows.Count - 1).Item("ItemNo") + 1)
                        Else
                            dr("ItemNo") = 1
                        End If
                        dr("Name") = oRow("Name").ToString
                        dr("CCVendor") = oRow("CCVendor").ToString
                        dr("CCNum") = oRow("CCNumber").ToString
                        If IsDBNull(oRow("ExpDate")) Then
                            dr("ExpDate") = ""
                        Else
                            dr("ExpDate") = Format(oRow("ExpDate"), "MM/dd/yyyy")
                        End If
                        Me.CarDataTable.Rows.Add(dr)
                    Next
                    Call Me.RefreshCarGrid()
                End If
        End Select


    End Sub

    Private Sub LoadAuxDataFromDB()
        Dim oDataTable As DataTable
        Dim oDataTable2 As DataTable
        Dim oRow2 As DataRow
        Dim oRow As DataRow
        Dim dr As DataRow

        Dim PayMode As String = ""

        oDataTable2 = Me.BLL.GetPaymentMode(Me.CurrentClientID, "Aux")
        If oDataTable2.Rows.Count <> 0 Then
            For k As Integer = 0 To oDataTable2.Rows.Count - 1
                oRow2 = oDataTable2.Rows(0)
                PayMode = oRow2("PayMode").ToString
            Next
            Me.ddlAuxPayMode.SelectedValue = PayMode

        Else
            Me.ddlAuxPayMode.SelectedValue = "CORPCC"

        End If
        Select Case PayMode


            Case "CORPCC"
                oDataTable = Me.BLL.GetClientCard(Me.CurrentClientID, "Aux", PayMode)
                If oDataTable IsNot Nothing Then
                    For i As Integer = 0 To oDataTable.Rows.Count - 1
                        oRow = oDataTable.Rows(i)
                        dr = Me.AuxDataTable.NewRow()
                        If Me.AuxDataTable.Rows.Count > 0 Then
                            dr("ItemNo") = Util.DBNullToZero(Me.AuxDataTable.Rows(Me.AuxDataTable.Rows.Count - 1).Item("ItemNo") + 1)
                        Else
                            dr("ItemNo") = 1
                        End If
                        dr("Name") = oRow("Name").ToString
                        dr("CCVendor") = oRow("CCVendor").ToString
                        dr("CCNum") = oRow("CCNumber").ToString
                        If IsDBNull(oRow("ExpDate")) Then
                            dr("ExpDate") = ""
                        Else
                            dr("ExpDate") = Format(oRow("ExpDate"), "MM/dd/yyyy")
                        End If
                        Me.AuxDataTable.Rows.Add(dr)
                    Next
                    Call Me.RefreshAuxGrid()
                End If
        End Select


    End Sub

    Private Sub RemoveAirIntData(ByVal ItemNo As String)
        Dim dr As DataRow()
        Dim filter As String = ""
        filter = "ItemNo=" + Util.LimitTheString(ItemNo)
        dr = Me.AirIntDataTable.Select(filter)
        If dr IsNot Nothing AndAlso dr.Length > 0 Then
            Me.AirIntDataTable.Rows.Remove(dr(0))
        End If
    End Sub


    Private Sub RemoveAirDomData(ByVal ItemNo As String)
        Dim dr As DataRow()
        Dim filter As String = ""
        filter = "ItemNo=" + Util.LimitTheString(ItemNo)
        dr = Me.AirDomDataTable.Select(filter)
        If dr IsNot Nothing AndAlso dr.Length > 0 Then
            Me.AirDomDataTable.Rows.Remove(dr(0))
        End If
    End Sub

    Private Sub RemoveAirLccData(ByVal ItemNo As String)
        Dim dr As DataRow()
        Dim filter As String = ""
        filter = "ItemNo=" + Util.LimitTheString(ItemNo)
        dr = Me.AirLccDataTable.Select(filter)
        If dr IsNot Nothing AndAlso dr.Length > 0 Then
            Me.AirLccDataTable.Rows.Remove(dr(0))
        End If
    End Sub

    Private Sub RemoveHotelData(ByVal ItemNo As String)
        Dim dr As DataRow()
        Dim filter As String = ""
        filter = "ItemNo=" + Util.LimitTheString(ItemNo)
        dr = Me.HotelDataTable.Select(filter)
        If dr IsNot Nothing AndAlso dr.Length > 0 Then
            Me.HotelDataTable.Rows.Remove(dr(0))
        End If
    End Sub


    Private Sub RemoveCarData(ByVal ItemNo As String)
        Dim dr As DataRow()
        Dim filter As String = ""
        filter = "ItemNo=" + Util.LimitTheString(ItemNo)
        dr = Me.CarDataTable.Select(filter)
        If dr IsNot Nothing AndAlso dr.Length > 0 Then
            Me.CarDataTable.Rows.Remove(dr(0))
        End If
    End Sub

    Private Sub RemoveAuxData(ByVal ItemNo As String)
        Dim dr As DataRow()
        Dim filter As String = ""
        filter = "ItemNo=" + Util.LimitTheString(ItemNo)
        dr = Me.AuxDataTable.Select(filter)
        If dr IsNot Nothing AndAlso dr.Length > 0 Then
            Me.AuxDataTable.Rows.Remove(dr(0))
        End If
    End Sub


  

    Private Sub UpdateAirIntData(ByVal ItemNo As String)
        Dim dr As DataRow()
        Dim filter As String = ""
        Dim type As String
        Dim val As String
        Dim FoundRow As DataRow()
        If Not Me.ValidateCard1() Then
            Me.lblMsgBox.Text = "Card number is invalid under Air International."
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.ajaxMsgBox.Show()
            Exit Sub
        End If
        type = Me.ddlAirIntCC.SelectedValue
        val = Me.txtAirIntCardNum.Text
        filter = "CCNum=" + Util.LimitTheString(val) + " and " + "CCVendor=" + Util.LimitTheString(type) + " and ItemNo<>" + Util.LimitTheString(ItemNo)
        FoundRow = Me.AirIntDataTable.Select(filter)
        If FoundRow IsNot Nothing AndAlso FoundRow.Length > 0 Then
            Me.lblMsgBox.Text = "Cannot add duplicated value Air International."
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.ajaxMsgBox.Show()
            Exit Sub
        End If
        filter = "ItemNo=" + Util.LimitTheString(ItemNo)
        dr = Me.AirIntDataTable.Select(filter)
        If dr IsNot Nothing AndAlso dr.Length > 0 Then
            
            dr(0).Item("Name") = Me.txtAirIntCardName.Text
            dr(0).Item("CCVendor") = Me.ddlAirIntCC.SelectedValue
            dr(0).Item("CCNum") = Me.txtAirIntCardNum.Text
            dr(0).Item("ExpDate") = Me.txtAirIntExp.Text
        End If
    End Sub

    Private Sub UpdateAirDomData(ByVal ItemNo As String)
        Dim dr As DataRow()
        Dim filter As String = ""
        Dim type As String
        Dim val As String
        Dim FoundRow As DataRow()
        If Not Me.ValidateCard2() Then
            Me.lblMsgBox.Text = "Card number is invalid under Air Domestic."
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.ajaxMsgBox.Show()
            Exit Sub
        End If
        type = Me.ddlAirDomCC.SelectedValue
        val = Me.txtAirDomCardNum.Text
        filter = "CCNum=" + Util.LimitTheString(val) + " and " + "CCVendor=" + Util.LimitTheString(type) + " and ItemNo<>" + Util.LimitTheString(ItemNo)
        FoundRow = Me.AirDomDataTable.Select(filter)
        If FoundRow IsNot Nothing AndAlso FoundRow.Length > 0 Then
            Me.lblMsgBox.Text = "Cannot add duplicated value Air Domestic."
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.ajaxMsgBox.Show()
            Exit Sub
        End If
        filter = "ItemNo=" + Util.LimitTheString(ItemNo)
        dr = Me.AirDomDataTable.Select(filter)
        If dr IsNot Nothing AndAlso dr.Length > 0 Then

            dr(0).Item("Name") = Me.txtAirDomCardName.Text
            dr(0).Item("CCVendor") = Me.ddlAirDomCC.SelectedValue
            dr(0).Item("CCNum") = Me.txtAirDomCardNum.Text
            dr(0).Item("ExpDate") = Me.txtAirDomExp.Text
        End If
    End Sub

    Private Sub UpdateAirLccData(ByVal ItemNo As String)
        Dim dr As DataRow()
        Dim filter As String = ""
        Dim type As String
        Dim val As String
        Dim FoundRow As DataRow()
        If Not Me.ValidateCard3() Then
            Me.lblMsgBox.Text = "Card number is invalid under Air LCC."
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.ajaxMsgBox.Show()
            Exit Sub
        End If
        type = Me.ddlAirLccCC.SelectedValue
        val = Me.txtAirLccCardNum.Text
        filter = "CCNum=" + Util.LimitTheString(val) + " and " + "CCVendor=" + Util.LimitTheString(type) + " and ItemNo<>" + Util.LimitTheString(ItemNo)
        FoundRow = Me.AirLccDataTable.Select(filter)
        If FoundRow IsNot Nothing AndAlso FoundRow.Length > 0 Then
            Me.lblMsgBox.Text = "Cannot add duplicated value Air LCC."
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.ajaxMsgBox.Show()
            Exit Sub
        End If
        filter = "ItemNo=" + Util.LimitTheString(ItemNo)
        dr = Me.AirLccDataTable.Select(filter)
        If dr IsNot Nothing AndAlso dr.Length > 0 Then

            dr(0).Item("Name") = Me.txtAirLccCardName.Text
            dr(0).Item("CCVendor") = Me.ddlAirLccCC.SelectedValue
            dr(0).Item("CCNum") = Me.txtAirLccCardNum.Text
            dr(0).Item("ExpDate") = Me.txtAirLccExp.Text
        End If
    End Sub


    Private Sub UpdateHotelData(ByVal ItemNo As String)
        Dim dr As DataRow()
        Dim filter As String = ""
        Dim type As String
        Dim val As String
        Dim FoundRow As DataRow()
        If Not Me.ValidateCard4() Then
            Me.lblMsgBox.Text = "Card number is invalid under Hotel."
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.ajaxMsgBox.Show()
            Exit Sub
        End If
        type = Me.ddlHotelCC.SelectedValue
        val = Me.txtHotelCardNum.Text
        filter = "CCNum=" + Util.LimitTheString(val) + " and " + "CCVendor=" + Util.LimitTheString(type) + " and ItemNo<>" + Util.LimitTheString(ItemNo)
        FoundRow = Me.HotelDataTable.Select(filter)
        If FoundRow IsNot Nothing AndAlso FoundRow.Length > 0 Then
            Me.lblMsgBox.Text = "Cannot add duplicated value Air Domestic."
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.ajaxMsgBox.Show()
            Exit Sub
        End If
        filter = "ItemNo=" + Util.LimitTheString(ItemNo)
        dr = Me.HotelDataTable.Select(filter)
        If dr IsNot Nothing AndAlso dr.Length > 0 Then

            dr(0).Item("Name") = Me.txtHotelCardName.Text
            dr(0).Item("CCVendor") = Me.ddlHotelCC.SelectedValue
            dr(0).Item("CCNum") = Me.txtHotelCardNum.Text
            dr(0).Item("ExpDate") = Me.txtHotelExpDate.Text
        End If
    End Sub


    Private Sub UpdateCarData(ByVal ItemNo As String)
        Dim dr As DataRow()
        Dim filter As String = ""
        Dim type As String
        Dim val As String
        Dim FoundRow As DataRow()
        If Not Me.ValidateCard5() Then
            Me.lblMsgBox.Text = "Card number is invalid under Car."
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.ajaxMsgBox.Show()
            Exit Sub
        End If
        type = Me.ddlCarCC.SelectedValue
        val = Me.txtCarCardNum.Text
        filter = "CCNum=" + Util.LimitTheString(val) + " and " + "CCVendor=" + Util.LimitTheString(type) + " and ItemNo<>" + Util.LimitTheString(ItemNo)
        FoundRow = Me.CarDataTable.Select(filter)
        If FoundRow IsNot Nothing AndAlso FoundRow.Length > 0 Then
            Me.lblMsgBox.Text = "Cannot add duplicated value Car."
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.ajaxMsgBox.Show()
            Exit Sub
        End If
        filter = "ItemNo=" + Util.LimitTheString(ItemNo)
        dr = Me.CarDataTable.Select(filter)
        If dr IsNot Nothing AndAlso dr.Length > 0 Then

            dr(0).Item("Name") = Me.txtCarCardName.Text
            dr(0).Item("CCVendor") = Me.ddlCarCC.SelectedValue
            dr(0).Item("CCNum") = Me.txtCarCardNum.Text
            dr(0).Item("ExpDate") = Me.txtCarExp.Text
        End If
    End Sub


    Private Sub UpdateAuxData(ByVal ItemNo As String)
        Dim dr As DataRow()
        Dim filter As String = ""
        Dim type As String
        Dim val As String
        Dim FoundRow As DataRow()
        If Not Me.ValidateCard6() Then
            Me.lblMsgBox.Text = "Card number is invalid under Auxilirary."
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.ajaxMsgBox.Show()
            Exit Sub
        End If
        type = Me.ddlAuxCC.SelectedValue
        val = Me.txtAuxCardNum.Text
        filter = "CCNum=" + Util.LimitTheString(val) + " and " + "CCVendor=" + Util.LimitTheString(type) + " and ItemNo<>" + Util.LimitTheString(ItemNo)
        FoundRow = Me.AuxDataTable.Select(filter)
        If FoundRow IsNot Nothing AndAlso FoundRow.Length > 0 Then
            Me.lblMsgBox.Text = "Cannot add duplicated value Auxilirary."
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.ajaxMsgBox.Show()
            Exit Sub
        End If
        filter = "ItemNo=" + Util.LimitTheString(ItemNo)
        dr = Me.AuxDataTable.Select(filter)
        If dr IsNot Nothing AndAlso dr.Length > 0 Then

            dr(0).Item("Name") = Me.txtAuxCardName.Text
            dr(0).Item("CCVendor") = Me.ddlAuxCC.SelectedValue
            dr(0).Item("CCNum") = Me.txtAuxCardNum.Text
            dr(0).Item("ExpDate") = Me.txtAuxExp.Text
        End If
    End Sub

    Private Sub RefreshAirIntGrid()
        Dim dv As New DataView()
        With dv
            .Table = Me.AirIntDataTable
            .Sort = "ItemNo"
        End With
        With Me.gdAirIntData
            .DataSource = dv.ToTable()
            .DataBind()
        End With
        With Me.AirIntPgCtrl
            .GridID = Me.gdAirIntData.UniqueID
            .SetBindGrid()
        End With

        With dv
            .Table = Me.AirIntDataTable
            .Sort = "ItemNo"
        End With
        With Me.gdAirIntView
            .DataSource = dv.ToTable()
            .DataBind()
        End With
        With Me.AirIntPgCtrl2
            .GridID = Me.gdAirIntView.UniqueID
            .SetBindGrid()
        End With
    End Sub


    Private Sub RefreshAirDomGrid()
        Dim dv As New DataView()
        With dv
            .Table = Me.AirDomDataTable
            .Sort = "ItemNo"
        End With
        With Me.gdAirDomData
            .DataSource = dv.ToTable()
            .DataBind()
        End With
        With Me.pgAirDomCtrl
            .GridID = Me.gdAirDomData.UniqueID
            .SetBindGrid()
        End With

        With dv
            .Table = Me.AirDomDataTable
            .Sort = "ItemNo"
        End With
        With Me.gdDomView
            .DataSource = dv.ToTable()
            .DataBind()
        End With
        With Me.pgAirDomCtrl2
            .GridID = Me.gdDomView.UniqueID
            .SetBindGrid()
        End With
    End Sub

    Private Sub RefreshAirLccGrid()
        Dim dv As New DataView()
        With dv
            .Table = Me.AirLccDataTable
            .Sort = "ItemNo"
        End With
        With Me.gdAirLccData
            .DataSource = dv.ToTable()
            .DataBind()
        End With
        With Me.pgAirLccCtrl
            .GridID = Me.gdAirLccData.UniqueID
            .SetBindGrid()
        End With

        With dv
            .Table = Me.AirLccDataTable
            .Sort = "ItemNo"
        End With
        With Me.gdLccView
            .DataSource = dv.ToTable()
            .DataBind()
        End With
        With Me.pgAirLccCtrl2
            .GridID = Me.gdLccView.UniqueID
            .SetBindGrid()
        End With
    End Sub

    Private Sub RefreshHotelGrid()
        Dim dv As New DataView()
        With dv
            .Table = Me.HotelDataTable
            .Sort = "ItemNo"
        End With
        With Me.gdHotelData
            .DataSource = dv.ToTable()
            .DataBind()
        End With
        With Me.pgHotel
            .GridID = Me.gdHotelData.UniqueID
            .SetBindGrid()
        End With

        With dv
            .Table = Me.HotelDataTable
            .Sort = "ItemNo"
        End With
        With Me.gdHotelView
            .DataSource = dv.ToTable()
            .DataBind()
        End With
        With Me.pgHotel2
            .GridID = Me.gdHotelView.UniqueID
            .SetBindGrid()
        End With
    End Sub

    Private Sub RefreshCarGrid()
        Dim dv As New DataView()
        With dv
            .Table = Me.CarDataTable
            .Sort = "ItemNo"
        End With
        With Me.gdCarData
            .DataSource = dv.ToTable()
            .DataBind()
        End With
        With Me.pgCarCtrl
            .GridID = Me.gdCarData.UniqueID
            .SetBindGrid()
        End With

        With dv
            .Table = Me.CarDataTable
            .Sort = "ItemNo"
        End With
        With Me.gdCarView
            .DataSource = dv.ToTable()
            .DataBind()
        End With
        With Me.pgCarCtrl2
            .GridID = Me.gdCarView.UniqueID
            .SetBindGrid()
        End With
    End Sub

    Private Sub RefreshAuxGrid()
        Dim dv As New DataView()
        With dv
            .Table = Me.AuxDataTable
            .Sort = "ItemNo"
        End With
        With Me.gdAuxData
            .DataSource = dv.ToTable()
            .DataBind()
        End With
        With Me.pgAuxCtrl
            .GridID = Me.gdAuxData.UniqueID
            .SetBindGrid()
        End With

        With dv
            .Table = Me.AuxDataTable
            .Sort = "ItemNo"
        End With
        With Me.gdAuxView
            .DataSource = dv.ToTable()
            .DataBind()
        End With
        With Me.pgAuxCtrl2
            .GridID = Me.gdAuxView.UniqueID
            .SetBindGrid()
        End With
    End Sub

    Private Sub SetTableMode()

        Me.tblAirIntData.Visible = (Me.ddlAirIntMode.SelectedValue.Equals("CORPCC"))

        Me.tblAirDomData.Visible = (Me.ddlAirDomMode.SelectedValue.Equals("CORPCC"))
        Me.tblAirLccData.Visible = (Me.ddlAirLccMode.SelectedValue.Equals("CORPCC"))
        Me.tblHotelData.Visible = (Me.ddlHotelMode.SelectedValue.Equals("CORPCC"))
        Me.tblCarData.Visible = (Me.ddlCarPayMode.SelectedValue.Equals("CORPCC"))
        Me.tblAuxData.Visible = (Me.ddlAuxPayMode.SelectedValue.Equals("CORPCC"))

    End Sub

    Private Sub SaveData(ByVal IsNext As Boolean)
        Dim info As New DataInfo.CompanyPayCardInfo()
        'Dim card As New DataInfo.PaymentCardInfo()
        Dim airInt As New DataInfo.AirIntDataInfo()
        Dim airDom As New DataInfo.AirDomDataInfo()
        Dim airLcc As New DataInfo.AirLccDataInfo()
        Dim hotel As New DataInfo.HotelDataInfo()
        Dim car As New DataInfo.CarDataInfo()
        Dim aux As New DataInfo.AuxDataInfo()
        Dim chk1, chk2, chk3, chk4, chk5, chk6 As Boolean
        chk1 = True
        chk2 = True
        chk3 = True
        chk4 = True
        chk5 = True
        chk6 = True

        With info
            .ClientID = Me.CurrentClientID
            '.PayMode = Util.DBNullToZero(Me.ddlPayMode.SelectedValue)
            .AirIntPayMode = Me.ddlAirIntMode.SelectedValue
            .AirDomPayMode = Me.ddlAirDomMode.SelectedValue
            .AirLccPayMode = Me.ddlAirLccMode.SelectedValue
            .HotelPayMode = Me.ddlHotelMode.SelectedValue
            .CarPayMode = Me.ddlCarPayMode.SelectedValue
            .AuxPayMode = Me.ddlAuxPayMode.SelectedValue
            'If .PayMode = DataInfo.CompanyPayCardInfo.PaymentMode.CreditCard Then
            '    .ReferToProfile = Me.chkReferProfile.Checked
            '    '// Cards
            '    For i As Integer = 0 To Me.PaymentCardTable.Rows.Count - 1
            '        card = New DataInfo.PaymentCardInfo()
            '        card.Vendor = Me.PaymentCardTable.Rows(i).Item("CCVendor").ToString
            '        card.Number = Me.PaymentCardTable.Rows(i).Item("CCNumber").ToString
            '        card.ExpiryDate = Me.PaymentCardTable.Rows(i).Item("ExpDate").ToString
            '        card.PrefAir = CBool(Me.PaymentCardTable.Rows(i).Item("Air"))
            '        card.PrefHotel = CBool(Me.PaymentCardTable.Rows(i).Item("Hotel"))
            '        card.PrefCar = CBool(Me.PaymentCardTable.Rows(i).Item("Car"))
            '        .CardList.Add(card)
            '    Next
            'End If
            If .AirIntPayMode.Equals("CORPCC") Then
                For i As Integer = 0 To Me.AirIntDataTable.Rows.Count - 1
                    airInt = New DataInfo.AirIntDataInfo()
                    airInt.Name = Me.AirIntDataTable.Rows(i).Item("Name").ToString
                    airInt.CCVendor = Me.AirIntDataTable.Rows(i).Item("CCVendor").ToString
                    airInt.CCNum = Me.AirIntDataTable.Rows(i).Item("CCNum").ToString
                    airInt.ExpiryDate = Me.AirIntDataTable.Rows(i).Item("ExpDate").ToString
                    .AirIntList.Add(airInt)
                Next

            End If

            If .AirDomPayMode.Equals("CORPCC") Then
                For i As Integer = 0 To Me.AirDomDataTable.Rows.Count - 1
                    airDom = New DataInfo.AirDomDataInfo()
                    airDom.Name = Me.AirDomDataTable.Rows(i).Item("Name").ToString
                    airDom.CCVendor = Me.AirDomDataTable.Rows(i).Item("CCVendor").ToString
                    airDom.CCNum = Me.AirDomDataTable.Rows(i).Item("CCNum").ToString
                    airDom.ExpiryDate = Me.AirDomDataTable.Rows(i).Item("ExpDate").ToString
                    .AirDomList.Add(airDom)
                Next

            End If
            If .AirLccPayMode.Equals("CORPCC") Then
                For i As Integer = 0 To Me.AirLccDataTable.Rows.Count - 1
                    airLcc = New DataInfo.AirLccDataInfo()
                    airLcc.Name = Me.AirLccDataTable.Rows(i).Item("Name").ToString
                    airLcc.CCVendor = Me.AirLccDataTable.Rows(i).Item("CCVendor").ToString
                    airLcc.CCNum = Me.AirLccDataTable.Rows(i).Item("CCNum").ToString
                    airLcc.ExpiryDate = Me.AirLccDataTable.Rows(i).Item("ExpDate").ToString
                    .AirLccList.Add(airLcc)
                Next

            End If
            If .HotelPayMode.Equals("CORPCC") Then
                For i As Integer = 0 To Me.HotelDataTable.Rows.Count - 1
                    hotel = New DataInfo.HotelDataInfo()
                    hotel.Name = Me.HotelDataTable.Rows(i).Item("Name").ToString
                    hotel.CCVendor = Me.HotelDataTable.Rows(i).Item("CCVendor").ToString
                    hotel.CCNum = Me.HotelDataTable.Rows(i).Item("CCNum").ToString
                    hotel.ExpiryDate = Me.HotelDataTable.Rows(i).Item("ExpDate").ToString
                    .HotelList.Add(hotel)
                Next

            End If

            If .CarPayMode.Equals("CORPCC") Then
                For i As Integer = 0 To Me.CarDataTable.Rows.Count - 1
                    car = New DataInfo.CarDataInfo()
                    car.Name = Me.CarDataTable.Rows(i).Item("Name").ToString
                    car.CCVendor = Me.CarDataTable.Rows(i).Item("CCVendor").ToString
                    car.CCNum = Me.CarDataTable.Rows(i).Item("CCNum").ToString
                    car.ExpiryDate = Me.CarDataTable.Rows(i).Item("ExpDate").ToString
                    .CarList.Add(car)
                Next

            End If

            If .AuxPayMode.Equals("CORPCC") Then
                For i As Integer = 0 To Me.AuxDataTable.Rows.Count - 1
                    aux = New DataInfo.AuxDataInfo()
                    aux.Name = Me.AuxDataTable.Rows(i).Item("Name").ToString
                    aux.CCVendor = Me.AuxDataTable.Rows(i).Item("CCVendor").ToString
                    aux.CCNum = Me.AuxDataTable.Rows(i).Item("CCNum").ToString
                    aux.ExpiryDate = Me.AuxDataTable.Rows(i).Item("ExpDate").ToString
                    .AuxList.Add(aux)
                Next

            End If

        End With
        If Me.ddlAirIntMode.SelectedValue.Equals("CORPCC") Then
            If Me.AirIntDataTable.Rows.Count = 0 Then
                Me.lblMsg1.Text = "*Must add at least one credit card to Air International"
                
                chk1 = False
            Else
                Me.lblMsg1.Text = ""
                chk1 = True
            End If
        End If

        If Me.ddlAirDomMode.SelectedValue.Equals("CORPCC") Then
            If Me.AirDomDataTable.Rows.Count = 0 Then
                Me.lblMsg2.Text = "*Must add at least one credit card to Air Domestic"

                chk2 = False
            Else
                Me.lblMsg2.Text = ""
                chk2 = True
            End If
        End If

        If Me.ddlAirLccMode.SelectedValue.Equals("CORPCC") Then
            If Me.AirLccDataTable.Rows.Count = 0 Then
                Me.lblMsg3.Text = "*Must add at least one credit card to Air LCC"
                
                chk3 = False
            Else
                Me.lblMsg3.Text = ""
                chk3 = True
            End If
        End If

        If Me.ddlHotelMode.SelectedValue.Equals("CORPCC") Then
            If Me.HotelDataTable.Rows.Count = 0 Then
                Me.lblMsg4.Text = "*Must add at least one credit card to Hotel"
                
                chk4 = False
            Else
                Me.lblMsg4.Text = ""
                chk4 = True
            End If
        End If

        If Me.ddlCarPayMode.SelectedValue.Equals("CORPCC") Then
            If Me.CarDataTable.Rows.Count = 0 Then
                Me.lblMsg5.Text = "*Must add at least one credit card to Car"
               
                chk5 = False
            Else
                Me.lblMsg5.Text = ""
                chk5 = True
            End If
        End If

        If Me.ddlAuxPayMode.SelectedValue.Equals("CORPCC") Then
            If Me.AuxDataTable.Rows.Count = 0 Then
                Me.lblMsg6.Text = "*Must add at least one credit card to Auxilirary"
              
                chk6 = False
            Else
                Me.lblMsg6.Text = ""
                chk6 = True
            End If
        End If

        If chk1 = True And chk2 = True And chk3 = True And chk4 = True And chk5 = True And chk6 = True Then
            If Me.BLL.UpdatePaymentCard(info) > 0 Then
                Me.lblMsgBox.Text = Util.GetAppConfig(Util.MsgType.TRANS_SUCCESS.ToString)
                Me.lblMsgBox.ForeColor = Drawing.Color.Green
                Me.ajaxMsgBox.Show()
                If IsNext Then
                    Response.Redirect("CompanyPayment.aspx")
                End If
            Else
                Me.lblMsgBox.Text = Util.GetAppConfig(Util.MsgType.TRANS_ERROR.ToString)
                Me.lblMsgBox.ForeColor = Drawing.Color.Red
                Me.ajaxMsgBox.Show()
            End If
        End If

        
    End Sub

    Public Sub gdAirIntData_Command(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.CommandEventArgs)
        Select Case e.CommandName
            Case "delete"
                Call Me.RemoveAirIntData(Util.DBNullToZero(e.CommandArgument))
            Case "edit"
                Call Me.LoadAirIntData(Util.DBNullToZero(e.CommandArgument))
                Me.btnAirIntAdd.Text = "Update"
        End Select
        Call Me.RefreshAirIntGrid()
        Call Me.AccessControl("Payment")
    End Sub

    Public Sub gdAirDomData_Command(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.CommandEventArgs)
        Select Case e.CommandName
            Case "delete"
                Call Me.RemoveAirDomData(Util.DBNullToZero(e.CommandArgument))
            Case "edit"
                Call Me.LoadAirDomData(Util.DBNullToZero(e.CommandArgument))
                Me.btnAirDomAdd.Text = "Update"
        End Select
        Call Me.RefreshAirDomGrid()
        Call Me.AccessControl("Payment")
    End Sub

    Public Sub gdAirLccData_Command(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.CommandEventArgs)
        Select Case e.CommandName
            Case "delete"
                Call Me.RemoveAirLccData(Util.DBNullToZero(e.CommandArgument))
            Case "edit"
                Call Me.LoadAirLccData(Util.DBNullToZero(e.CommandArgument))
                Me.btnAirLccAdd.Text = "Update"
        End Select
        Call Me.RefreshAirLccGrid()
        Call Me.AccessControl("Payment")
    End Sub

    Public Sub gdHotelData_Command(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.CommandEventArgs)
        Select Case e.CommandName
            Case "delete"
                Call Me.RemoveHotelData(Util.DBNullToZero(e.CommandArgument))
            Case "edit"
                Call Me.LoadHotelData(Util.DBNullToZero(e.CommandArgument))
                Me.btnHotelAdd.Text = "Update"
        End Select
        Call Me.RefreshHotelGrid()
        Call Me.AccessControl("Payment")
    End Sub

    Public Sub gdCarData_Command(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.CommandEventArgs)
        Select Case e.CommandName
            Case "delete"
                Call Me.RemoveCarData(Util.DBNullToZero(e.CommandArgument))
            Case "edit"
                Call Me.LoadCarData(Util.DBNullToZero(e.CommandArgument))
                Me.btnCarAdd.Text = "Update"
        End Select
        Call Me.RefreshCarGrid()
        Call Me.AccessControl("Payment")
    End Sub

    Public Sub gdAuxData_Command(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.CommandEventArgs)
        Select Case e.CommandName
            Case "delete"
                Call Me.RemoveAuxData(Util.DBNullToZero(e.CommandArgument))
            Case "edit"
                Call Me.LoadAuxData(Util.DBNullToZero(e.CommandArgument))
                Me.btnAuxAdd.Text = "Update"
        End Select
        Call Me.RefreshAuxGrid()
        Call Me.AccessControl("Payment")
    End Sub

    Protected Sub btnAirIntAdd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnAirIntAdd.Click
        Dim ItemNo As String = ""
        ItemNo = Me.txtAirIntHid.Value
        If ItemNo = "" Then

            Call Me.AddAirIntData()
        Else
            Call Me.UpdateAirIntData(ItemNo)
        End If
        Call Me.RefreshAirIntGrid()
        Call Me.LoadNewAirIntData()
    End Sub


    Protected Sub btnAirDomAdd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnAirDomAdd.Click
        Dim ItemNo As String = ""
        ItemNo = Me.txtAirDomHid.Value
        If ItemNo = "" Then
            Call Me.AddAirDomData()
        Else
            Call Me.UpdateAirDomData(ItemNo)
        End If
        Call Me.RefreshAirDomGrid()
        Call Me.LoadNewAirDomData()
    End Sub

    Protected Sub btnAirLccAdd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnAirLccAdd.Click
        Dim ItemNo As String = ""
        ItemNo = Me.txtAirLccHid.Value
        If ItemNo = "" Then
            Call Me.AddAirLccData()
        Else
            Call Me.UpdateAirLccData(ItemNo)
        End If
        Call Me.RefreshAirLccGrid()
        Call Me.LoadNewAirLccData()
    End Sub

    Protected Sub btnHotelAdd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnHotelAdd.Click
        Dim ItemNo As String = ""
        ItemNo = Me.txtHotelHid.Value
        If ItemNo = "" Then
            Call Me.AddHotelData()
        Else
            Call Me.UpdateHotelData(ItemNo)
        End If
        Call Me.RefreshHotelGrid()
        Call Me.LoadNewHotelData()
    End Sub

    Protected Sub btnCarAdd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnCarAdd.Click
        Dim ItemNo As String = ""
        ItemNo = Me.txtCarHid.Value
        If ItemNo = "" Then
            Call Me.AddCarData()
        Else
            Call Me.UpdateCarData(ItemNo)
        End If
        Call Me.RefreshCarGrid()
        Call Me.LoadNewCarData()
    End Sub

    Protected Sub btnAuxAdd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnAuxAdd.Click
        Dim ItemNo As String = ""
        ItemNo = Me.txtAuxHid.Value
        If ItemNo = "" Then
            Call Me.AddAuxData()
        Else
            Call Me.UpdateAuxData(ItemNo)
        End If
        Call Me.RefreshAuxGrid()
        Call Me.LoadNewAuxData()
    End Sub

   

    Protected Sub gdAirIntData_RowDataBount(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gdAirIntData.RowDataBound
        Dim cwtLinkBtn As CWTCustomControls.CWTLinkButton
        cwtLinkBtn = TryCast(e.Row.FindControl("hrefAirIntDeleteItem"), CWTCustomControls.CWTLinkButton)
        If cwtLinkBtn IsNot Nothing Then
            cwtLinkBtn.PermissionInfo = Me.usrInfo
            cwtLinkBtn.Attributes.Add("onclick", "return confirm('This item will delete, continue?');")
        End If
    End Sub


    Protected Sub gdAirDomData_RowDataBount(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gdAirDomData.RowDataBound
        Dim cwtLinkBtn As CWTCustomControls.CWTLinkButton
        cwtLinkBtn = TryCast(e.Row.FindControl("hrefAirDomDeleteItem"), CWTCustomControls.CWTLinkButton)
        If cwtLinkBtn IsNot Nothing Then
            cwtLinkBtn.PermissionInfo = Me.usrInfo
            cwtLinkBtn.Attributes.Add("onclick", "return confirm('This item will delete, continue?');")
        End If
    End Sub

    Protected Sub gdAirLccData_RowDataBount(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gdAirLccData.RowDataBound
        Dim cwtLinkBtn As CWTCustomControls.CWTLinkButton
        cwtLinkBtn = TryCast(e.Row.FindControl("hrefAirLccDeleteItem"), CWTCustomControls.CWTLinkButton)
        If cwtLinkBtn IsNot Nothing Then
            cwtLinkBtn.PermissionInfo = Me.usrInfo
            cwtLinkBtn.Attributes.Add("onclick", "return confirm('This item will delete, continue?');")
        End If
    End Sub

    Protected Sub gdHotelData_RowDataBount(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gdHotelData.RowDataBound
        Dim cwtLinkBtn As CWTCustomControls.CWTLinkButton
        cwtLinkBtn = TryCast(e.Row.FindControl("hrefHotelDeleteItem"), CWTCustomControls.CWTLinkButton)
        If cwtLinkBtn IsNot Nothing Then
            cwtLinkBtn.PermissionInfo = Me.usrInfo
            cwtLinkBtn.Attributes.Add("onclick", "return confirm('This item will delete, continue?');")
        End If
    End Sub

    Protected Sub gdCarData_RowDataBount(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gdCarData.RowDataBound
        Dim cwtLinkBtn As CWTCustomControls.CWTLinkButton
        cwtLinkBtn = TryCast(e.Row.FindControl("hrefCarDeleteItem"), CWTCustomControls.CWTLinkButton)
        If cwtLinkBtn IsNot Nothing Then
            cwtLinkBtn.PermissionInfo = Me.usrInfo
            cwtLinkBtn.Attributes.Add("onclick", "return confirm('This item will delete, continue?');")
        End If
    End Sub

    Protected Sub gdAuxData_RowDataBount(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gdAuxData.RowDataBound
        Dim cwtLinkBtn As CWTCustomControls.CWTLinkButton
        cwtLinkBtn = TryCast(e.Row.FindControl("hrefAuxDeleteItem"), CWTCustomControls.CWTLinkButton)
        If cwtLinkBtn IsNot Nothing Then
            cwtLinkBtn.PermissionInfo = Me.usrInfo
            cwtLinkBtn.Attributes.Add("onclick", "return confirm('This item will delete, continue?');")
        End If
    End Sub

    Protected Sub ddlAirIntMode_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlAirIntMode.SelectedIndexChanged
        Call Me.SetTableMode()
        If Me.tblAirIntData.Visible Then
            Call Me.RefreshAirIntGrid()
            Me.ValidationSummaryAirInt.Visible = True
        End If
    End Sub

    Protected Sub ddlAirDomMode_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlAirdomMode.SelectedIndexChanged
        Call Me.SetTableMode()
        If Me.tblAirDomData.Visible Then
            Call Me.RefreshAirDomGrid()
        End If
    End Sub

    Protected Sub ddlAirLccMode_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlAirLccMode.SelectedIndexChanged
        Call Me.SetTableMode()
        If Me.tblAirLccData.Visible Then
            Call Me.RefreshAirLccGrid()
        End If
    End Sub

    Protected Sub ddlHotelMode_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlHotelMode.SelectedIndexChanged
        Call Me.SetTableMode()
        If Me.tblHotelData.Visible Then
            Call Me.RefreshHotelGrid()
        End If
    End Sub

    Protected Sub ddlCarPayMode_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlCarPayMode.SelectedIndexChanged
        Call Me.SetTableMode()
        If Me.tblCarData.Visible Then
            Call Me.RefreshCarGrid()
        End If
    End Sub

    Protected Sub ddlAuxPayMode_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlAuxPayMode.SelectedIndexChanged
        Call Me.SetTableMode()
        If Me.tblAuxData.Visible Then
            Call Me.RefreshAuxGrid()
        End If
    End Sub

    Protected Sub btnTrans_OnCancel(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans.OnCancel
        Response.Redirect("CompanySearch.aspx")
    End Sub

    Protected Sub btnTrans_OnSave(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans.OnSave
        Call Me.SaveData(False)
    End Sub

    Protected Sub btnTrans_OnSaveNext(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans.OnSaveNext
        Call Me.SaveData(True)
    End Sub

    

    Public Function GetAirIntVendorText(ByVal Val As String) As String
        Dim retVal As String = ""
        Dim li As ListItem
        li = Me.ddlAirIntCC.Items.FindByValue(Val)
        If li IsNot Nothing Then
            retVal = li.Text
        End If
        Return retVal
    End Function

    Public Function GetAirDomVendorText(ByVal Val As String) As String
        Dim retVal As String = ""
        Dim li As ListItem
        li = Me.ddlAirDomCC.Items.FindByValue(Val)
        If li IsNot Nothing Then
            retVal = li.Text
        End If
        Return retVal
    End Function

    Public Function GetAirLccVendorText(ByVal Val As String) As String
        Dim retVal As String = ""
        Dim li As ListItem
        li = Me.ddlAirDomCC.Items.FindByValue(Val)
        If li IsNot Nothing Then
            retVal = li.Text
        End If
        Return retVal
    End Function

    Public Function GetHotelVendorText(ByVal Val As String) As String
        Dim retVal As String = ""
        Dim li As ListItem
        li = Me.ddlHotelCC.Items.FindByValue(Val)
        If li IsNot Nothing Then
            retVal = li.Text
        End If
        Return retVal
    End Function

    Public Function GetCarVendorText(ByVal Val As String) As String
        Dim retVal As String = ""
        Dim li As ListItem
        li = Me.ddlCarCC.Items.FindByValue(Val)
        If li IsNot Nothing Then
            retVal = li.Text
        End If
        Return retVal
    End Function

    Public Function GetAuxVendorText(ByVal Val As String) As String
        Dim retVal As String = ""
        Dim li As ListItem
        li = Me.ddlAuxCC.Items.FindByValue(Val)
        If li IsNot Nothing Then
            retVal = li.Text
        End If
        Return retVal
    End Function


End Class









@


1.1.1.1
log
@no message
@
text
@@
