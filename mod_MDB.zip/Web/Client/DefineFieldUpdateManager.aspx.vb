head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.57;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.57;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@
Partial Class Web_Client_DefineFieldUpdateManager
    Inherits BasePage

    Private BLL2 As BusinessLogicLayer.StaffBLL
    Private BLL3 As BusinessLogicLayer.tblFunctionBLL

#Region "Page Properties & Variables"
    Private BLL As BusinessLogicLayer.CompanyReportBLL

    Public Property RecordID() As String
        Get
            Dim retVal As String = ""
            If Me.ViewState("_RecordID") IsNot Nothing Then
                retVal = Me.ViewState("_RecordID").ToString
            End If
            Return retVal
        End Get
        Set(ByVal value As String)
            Me.ViewState("_RecordID") = value
        End Set
    End Property

    Public ReadOnly Property RequestID() As String
        Get
            Dim retVal As String = ""
            If Me.Request("id") IsNot Nothing Then
                retVal = Me.Request("id")
            End If
            Return retVal
        End Get
    End Property

    Public ReadOnly Property RequestMode() As String
        Get
            Dim retVal As String = ""
            If Me.Request("mode") IsNot Nothing Then
                retVal = Me.Request("mode")
            End If
            Return retVal
        End Get
    End Property

    Private Property GDSTable() As DataTable
        Get
            Return Me.ViewState("_GDSTable")
        End Get
        Set(ByVal value As DataTable)
            Me.ViewState("_GDSTable") = value
        End Set
    End Property
#End Region

#Region "Page Event Handlers & Methods"
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.BLL = New BusinessLogicLayer.CompanyReportBLL()
        Me.BLL2 = New BusinessLogicLayer.StaffBLL()
        Me.BLL3 = New BusinessLogicLayer.tblFunctionBLL()

        If Not Me.BLL.GetClientDefineReport(Me.CurrentClientID) Then
            Response.Redirect("CompanySearch.aspx", True)
        End If
        If Not IsPostBack Then
            Call Me.CreateGDSTable()
            Call Me.LoadDropDownList()
            Select Case Me.RequestMode.ToLower()
                Case "add"
                    Me.CurrentPageMode = CWTMasterDB.TransactionMode.AddNewMode
                Case "edit"
                    Me.CurrentPageMode = CWTMasterDB.TransactionMode.UpdateMode
                    Me.RecordID = Me.RequestID
                    Call Me.LoadDataFromDB()
            End Select
            Call Me.LoadNewData()
            Call Me.ToggleValueBox()
            Call Me.SetupValidationControls()
        End If
        Call Me.AccessControl("Client Reporting")
    End Sub

    Private Sub AccessControl(ByVal title As String)

        Dim userName As String
        Dim oDatatable As DataTable
        Dim oDataTable2 As DataTable

        Static roleID As String

        userName = ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName
        oDatatable = Me.BLL2.GetUserByID(userName)

        If oDatatable.Rows.Count > 0 Then
            roleID = oDatatable.Rows(0).Item("RoleID").ToString
        End If

        oDataTable2 = Me.BLL3.GetUserRole(roleID)
        If oDataTable2.Rows.Count > 0 Then
            For k As Integer = 0 To oDataTable2.Rows.Count - 1
                If oDataTable2.Rows(k).Item("functionGroup") = "1" Then
                    If oDataTable2.Rows(k).Item("Permission") = "V" Then
                        If oDataTable2.Rows(k).Item("functionName").ToString = title Then

                            Call Me.toggleControl()

                        End If
                    End If
                End If

            Next

        End If


    End Sub

    Private Sub toggleControl()
        'Dim btnDelete As CWTCustomControls.CWTLinkButton

        Me.txtFieldName.Readonly = True
        Me.txtGDS.Readonly = True
        Me.txtMax.Readonly = True
        Me.txtMin.Readonly = True
        Me.txtSampleValue.Readonly = True
        Me.ddlFieldType.Enabled = False
        Me.ddlFormat.Enabled = False
        Me.ddlMandatory.Enabled = False
        Me.btnSave.Enabled = False
        Me.gdData.Visible = False
        Me.tblPg.Visible = False
        Me.gdDataView.Visible = True
        Me.tblPg2.Visible = True
        'For i As Integer = 0 To Me.gdData.Rows.Count - 1
        '    btnDelete = Me.gdData.Rows(i).FindControl("hrefDeleteItem")
        '    btnDelete.Enabled = False

        'Next


        Me.btnTrans.ShowSaveNextButton = False
        Me.btnTrans.SaveButton.Enabled = False
    End Sub

    Private Sub ToggleValueBox()
        Dim IsStatic As Boolean = False
        IsStatic = (Me.ddlFieldType.SelectedValue = "2")
        Me.reqSampleValue.Visible = IsStatic
        If IsStatic Then
            Me.lblSampleValue.Text = "Value"
        Else
            Me.lblSampleValue.Text = "Sample Value"
        End If
    End Sub
#End Region

#Region "GDS Sub Routines"
    Private Sub CreateGDSTable()
        Me.GDSTable = New DataTable("GDSTable")
        With Me.GDSTable
            .Columns.Add(New DataColumn("ItemNo", GetType(Integer)))
            .Columns.Add(New DataColumn("GDS"))
        End With
    End Sub

    Private Sub AddGDSData()
        Dim dr As DataRow
        Dim filter As String = ""
        Dim val As String = ""
        Dim FoundRow As DataRow()
        val = Me.txtGDS.Text
        filter = "GDS=" + Util.LimitTheString(val)
        FoundRow = Me.GDSTable.Select(filter)
        If FoundRow IsNot Nothing AndAlso FoundRow.Length > 0 Then
            Me.lblMsgBox.Text = "Cannot add duplicated GDS Mapping."
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.ajaxMsgBox.Show()
            Exit Sub
        End If
        dr = Me.GDSTable.NewRow()
        If Me.GDSTable.Rows.Count > 0 Then
            dr("ItemNo") = Util.DBNullToZero(Me.GDSTable.Rows(Me.GDSTable.Rows.Count - 1).Item("ItemNo") + 1)
        Else
            dr("ItemNo") = 1
        End If
        dr("GDS") = Me.txtGDS.Text
        Me.GDSTable.Rows.Add(dr)
    End Sub

    Private Sub LoadNewData()
        Me.txtItemNo.Value = ""
        Me.txtGDS.Text = ""
    End Sub

    Private Sub LoadData(ByVal ItemNo As String)
        Dim dr As DataRow()
        Dim filter As String = ""
        filter = "ItemNo=" + Util.LimitTheString(ItemNo)
        dr = Me.GDSTable.Select(filter)
        If dr IsNot Nothing AndAlso dr.Length > 0 Then
            Me.txtItemNo.Value = ItemNo
            Me.txtGDS.Text = dr(0).Item("GDS").ToString
        End If
    End Sub

    Private Sub RemoveGDSData(ByVal ItemNo As String)
        Dim dr As DataRow()
        Dim filter As String = ""
        filter = "ItemNo=" + Util.LimitTheString(ItemNo)
        dr = Me.GDSTable.Select(filter)
        If dr IsNot Nothing AndAlso dr.Length > 0 Then
            Me.GDSTable.Rows.Remove(dr(0))
        End If
    End Sub

    Private Sub UpdateData(ByVal ItemNo As String)
        Dim dr As DataRow()
        Dim filter As String = ""
        Dim val As String = ""
        Dim FoundRow As DataRow()
        val = Me.txtGDS.Text
        filter = "GDS=" + Util.LimitTheString(val) + " and ItemNo<>" + Util.LimitTheString(ItemNo)
        FoundRow = Me.GDSTable.Select(filter)
        If FoundRow IsNot Nothing AndAlso FoundRow.Length > 0 Then
            Me.lblMsgBox.Text = "Cannot add duplicated value."
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.ajaxMsgBox.Show()
            Exit Sub
        End If
        filter = "ItemNo=" + Util.LimitTheString(ItemNo)
        dr = Me.GDSTable.Select(filter)
        If dr IsNot Nothing AndAlso dr.Length > 0 Then
            dr(0).Item("GDS") = Me.txtGDS.Text
        End If
    End Sub

    Private Sub RefreshGrid()
        Dim dv As New DataView()
        With dv
            .Table = Me.GDSTable
            .Sort = "ItemNo"
        End With
        With Me.gdData
            .DataSource = dv.ToTable()
            .DataBind()
        End With
        With Me.pgControl
            .GridID = Me.gdData.UniqueID
            .SetBindGrid()
        End With


        With dv
            .Table = Me.GDSTable
            .Sort = "ItemNo"
        End With
        With Me.gdDataView
            .DataSource = dv.ToTable()
            .DataBind()
        End With
        With Me.pgControl2
            .GridID = Me.gdDataView.UniqueID
            .SetBindGrid()
        End With

    End Sub
#End Region

#Region "Data Binding"
    Private Sub LoadDropDownList()
        Dim oDataTable As DataTable
        oDataTable = Me.BLL.GetReportingFieldType()
        With Me.ddlFieldType
            .DataTextField = "ReportingFieldType"
            .DataValueField = "ReportingFieldTypeID"
            .DataSource = oDataTable
            .DataBind()
        End With
    End Sub

    Private Sub LoadDataFromDB()
        Dim oDataTable As DataTable
        Dim oRow As DataRow
        Dim dr As DataRow
        On Error Resume Next
        oDataTable = Me.BLL.GetUDFReportList(Me.CurrentClientID, Me.RecordID)
        If oDataTable IsNot Nothing AndAlso oDataTable.Rows.Count > 0 Then
            oRow = oDataTable.Rows(0)
            Me.txtFieldName.Text = oRow("Description").ToString
            Me.ddlFieldType.SelectedValue = oRow("FieldType").ToString
            Me.ddlMandatory.SelectedValue = oRow("Mandatory").ToString
            Me.ddlFormat.SelectedValue = oRow("DataType").ToString
            Me.txtMin.Text = oRow("Min").ToString
            Me.txtMax.Text = oRow("Max").ToString
            If Me.ddlFieldType.SelectedValue = "2" Then
                Me.txtSampleValue.Text = oRow("ActualValue").ToString
            Else
                Me.txtSampleValue.Text = oRow("SampleValue").ToString
            End If
        End If
        '// GDS
        oDataTable = Me.BLL.GetUDFReportGDS(Me.RecordID)
        If oDataTable IsNot Nothing Then
            For i As Integer = 0 To oDataTable.Rows.Count - 1
                oRow = oDataTable.Rows(i)
                dr = Me.GDSTable.NewRow()
                If Me.GDSTable.Rows.Count > 0 Then
                    dr("ItemNo") = Util.DBNullToZero(Me.GDSTable.Rows(Me.GDSTable.Rows.Count - 1).Item("ItemNo") + 1)
                Else
                    dr("ItemNo") = 1
                End If
                dr("GDS") = oRow("GDSFormat").ToString
                Me.GDSTable.Rows.Add(dr)
            Next
            Call Me.RefreshGrid()
        End If
        Dim min As Integer
        Dim max As Integer
        Dim swap As Integer
        min = Util.DBNullToZero(Me.BLL.GetMinDropValue(Me.RecordID))
        max = Util.DBNullToZero(Me.BLL.GetMaxDropValue(Me.RecordID))
        If min > max Then
            swap = max
            max = min
            min = swap
        End If
        If min <> 0 Then
            Me.RangeValidatorMin.MaximumValue = min
            Me.RangeValidatorMin.ErrorMessage = "Minimum value is invalid (0-" + min.ToString + ")."
        End If
        If max <> 0 Then
            Me.RangeValidatorMax.MinimumValue = max
            Me.RangeValidatorMax.ErrorMessage = "Maximum value is invalid (" + max.ToString + "-100)."
        End If
    End Sub
#End Region

#Region "Page Validations"
    Private Sub SetupValidationControls()
        Select Case Me.ddlFormat.SelectedValue
            Case "alpha"
                Me.regSampleValueAlpha.Visible = True
                Me.regSampleValueNum.Visible = False
            Case "numeric"
                Me.regSampleValueAlpha.Visible = False
                Me.regSampleValueNum.Visible = True
            Case Else
                Me.regSampleValueAlpha.Visible = False
                Me.regSampleValueNum.Visible = False
        End Select
    End Sub
#End Region

#Region "Data Transaction"
    Private Sub SaveData()
        Dim info As New DataInfo.UDFReportInfo
        Dim value As String
        value = Me.txtSampleValue.Text
        With info
            .PageMode = Me.CurrentPageMode
            .ClientID = Me.CurrentClientID
            .ID = Me.RecordID
            .Description = Me.txtFieldName.Text
            .FieldType = Me.ddlFieldType.SelectedValue
            .DataType = Me.ddlFormat.SelectedValue
            .Mandatory = Me.ddlMandatory.SelectedValue
            .Min = Me.txtMin.Text
            .Max = Me.txtMax.Text
            .SampleValue = Me.txtSampleValue.Text()
            If .Min <> "" AndAlso .Min <> "0" AndAlso .SampleValue.Length < Util.DBNullToZero(.Min) Then
                Me.lblMsgBox.Text = "Value cannot less than Minimum setting."
                Me.lblMsgBox.ForeColor = Drawing.Color.Red
                Me.ajaxMsgBox.Show()
                Exit Sub
            End If
            If .Max <> "" AndAlso .Max <> "0" AndAlso .SampleValue.Length > Util.DBNullToZero(.Max) Then
                Me.lblMsgBox.Text = "Value cannot greater than Maximum setting."
                Me.lblMsgBox.ForeColor = Drawing.Color.Red
                Me.ajaxMsgBox.Show()
                Exit Sub
            End If
            If Me.ddlFormat.SelectedValue = "character" Then

                If value.Length > 0 Then
                    For i As Integer = 0 To value.Length - 1
                        Me.lblError.Text = value.Substring(i).ToString
                        If value.Substring(i, 1) = "/" Then
                            Me.lblMsgBox.Text = "Sample Value is invalid format."
                            Me.lblMsgBox.ForeColor = Drawing.Color.Red
                            Me.ajaxMsgBox.Show()
                            Exit Sub
                        Else
                            Continue For
                        End If
                    Next
                End If
            End If

            '// GDS Mapping
            For i As Integer = 0 To Me.GDSTable.Rows.Count - 1
                .GDSFormat.Add(Me.GDSTable.Rows(i).Item("GDS").ToString)
            Next
        End With
        If Me.BLL.IsExistName(Me.txtFieldName.Text, Me.RecordID, Me.CurrentClientID) Then
            Me.lblMsgBox.Text = "Field name is exist."
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.ajaxMsgBox.Show()
            Exit Sub
        Else
            If Me.GDSTable.Rows.Count <= 0 Then
                Me.lblMsgBox.Text = "At least one GDS mapping data is needed"
                Me.lblMsgBox.ForeColor = Drawing.Color.Red
                Me.ajaxMsgBox.Show()
                Exit Sub
            End If
        End If
        If Me.BLL.UpdateUDFReport(info) > 0 Then
            Me.lblMsgBox.Text = Util.GetAppConfig(Util.MsgType.TRANS_SUCCESS.ToString)
            Me.lblMsgBox.ForeColor = Drawing.Color.Green
            Me.ajaxMsgBox.Show()
            Response.Redirect("DefineFieldManager.aspx")
        Else
            Me.lblMsgBox.Text = Util.GetAppConfig(Util.MsgType.TRANS_ERROR.ToString)
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.ajaxMsgBox.Show()
        End If
    End Sub
#End Region

#Region "Page Control Event Handlers"
    Public Sub gdData_Command(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.CommandEventArgs)
        Select Case e.CommandName
            Case "delete"
                Call Me.RemoveGDSData(Util.DBNullToZero(e.CommandArgument))
            Case "edit"
                Call Me.LoadData(Util.DBNullToZero(e.CommandArgument))
        End Select
        Call Me.RefreshGrid()
        Call Me.AccessControl("Client Reporting")
    End Sub

    Protected Sub btnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSave.Click
        Dim ItemNo As String = ""
        ItemNo = Me.txtItemNo.Value
        If ItemNo = "" Then
            Call Me.AddGDSData()
        Else
            Call Me.UpdateData(ItemNo)
        End If
        Call Me.RefreshGrid()
        Call Me.LoadNewData()
    End Sub

    Protected Sub gdData_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gdData.RowDataBound
        Dim cwtLinkBtn As CWTCustomControls.CWTLinkButton
        cwtLinkBtn = TryCast(e.Row.FindControl("hrefDeleteItem"), CWTCustomControls.CWTLinkButton)
        If cwtLinkBtn IsNot Nothing Then
            cwtLinkBtn.PermissionInfo = Me.usrInfo
            cwtLinkBtn.Attributes.Add("onclick", "return confirm('This item will delete, continue?');")
        End If
    End Sub

    Protected Sub btnTrans_OnCancel(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans.OnCancel
        Response.Redirect("DefineFieldManager.aspx")
    End Sub

    Protected Sub btnTrans_OnSave(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans.OnSave
        Call Me.SaveData()
    End Sub

    Private Sub ddlFieldType_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlFieldType.SelectedIndexChanged
        Call Me.ToggleValueBox()
    End Sub

    Private Sub ddlFormat_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlFormat.SelectedIndexChanged
        Call Me.SetupValidationControls()
    End Sub
#End Region

#Region "Misc"

#End Region

End Class
@


1.1.1.1
log
@no message
@
text
@@
