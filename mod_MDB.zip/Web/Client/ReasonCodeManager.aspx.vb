head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.58;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.58;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@
Partial Class Web_Client_ReasonCodeManager
    Inherits BasePage

    Private BLL As BusinessLogicLayer.ReasonCodeBLL

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim comBLL As BusinessLogicLayer.CompanyReportBLL
        Me.BLL = New BusinessLogicLayer.ReasonCodeBLL()
        comBLL = New BusinessLogicLayer.CompanyReportBLL()
        If Not comBLL.GetStandardReport(Me.CurrentClientID) Then
            Response.Redirect("CompanySearch.aspx", True)
        End If
        If Not IsPostBack Then
            Call Me.LoadDataGrid()
            '// this will load from db later
            'Me.chkApplyStd.Checked = True
            'Call Me.SetTableMode()
            'Me.chkApplyStd.Attributes.Add("onclick", "return confirm('this might be lost all settings, continue?');")
        End If
    End Sub

    Private Sub LoadDataGrid()
        Dim oDataTable As DataTable
        oDataTable = Me.BLL.GetReasonCodeList(Me.CurrentClientID)
        With Me.gdData
            .DataSource = oDataTable
            .DataBind()
        End With
        With Me.pgControl
            .GridID = Me.gdData.UniqueID
            .SetBindGrid()
        End With
    End Sub

    Public Sub gdData_Command(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.CommandEventArgs)
        Select Case e.CommandName
            Case "SelectItem"
                Call Me.SelectItem(Util.DBNullToZero(e.CommandArgument))
        End Select
    End Sub

    Private Sub SetTableMode()
        Dim IsStd As Boolean = False
        'IsStd = Me.chkApplyStd.Checked
        Me.trBodyArea.Visible = Not IsStd
        If Not IsStd Then
            Call Me.LoadDataGrid()
        End If
    End Sub

    Private Sub SelectItem(ByVal index As Integer)
        Dim ProductID As String
        Dim TypeID As String
        ProductID = Me.gdData.DataKeys(index).Item(0).ToString
        TypeID = Me.gdData.DataKeys(index).Item(1).ToString
        Response.Redirect("ReasonCodeUpdateManager.aspx?mode=edit&prodid=" + ProductID + "&typeid=" + TypeID)
    End Sub

    'Protected Sub chkApplyStd_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkApplyStd.CheckedChanged
    '    Call Me.SetTableMode()
    'End Sub

    Protected Sub btnNextStep_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnNextStep.Click
        Dim comBLL As New BusinessLogicLayer.CompanyReportBLL()
        If Not comBLL.GetClientDefineReport(Me.CurrentClientID) Then
            Response.Redirect("AirPolicyManager.aspx", True)
        Else
            Response.Redirect("DefineFieldManager.aspx", True)
        End If
    End Sub

End Class
@


1.1.1.1
log
@no message
@
text
@@
