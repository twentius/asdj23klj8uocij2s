head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.58;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.58;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@
Partial Class Web_Client_ucContactNoLookup
    Inherits BaseUserControl

    Private BLL2 As BusinessLogicLayer.StaffBLL
    Private BLL3 As BusinessLogicLayer.tblFunctionBLL

    Public ReadOnly Property Title() As CWTCustomControls.CWTDropDownList
        Get
            Return Me.ddlTitle
        End Get
    End Property
    Public ReadOnly Property FirstName() As CWTCustomControls.CWTTextBox
        Get
            Return Me.txtFirstName
        End Get
    End Property
    Public ReadOnly Property LastName() As CWTCustomControls.CWTTextBox
        Get
            Return Me.txtLastName
        End Get
    End Property
    Public ReadOnly Property Email() As CWTCustomControls.CWTTextBox
        Get
            Return Me.txtEmail
        End Get
    End Property
    Public ReadOnly Property JobTitle() As CWTCustomControls.CWTTextBox
        Get
            Return Me.txtJobTitle
        End Get
    End Property
    Public ReadOnly Property PhoneCode() As CWTCustomControls.CWTTextBox
        Get
            Return Me.txtPhoneCode
        End Get
    End Property
    Public ReadOnly Property Phone() As CWTCustomControls.CWTTextBox
        Get
            Return Me.txtPhoneNo
        End Get
    End Property
    Public ReadOnly Property HPCode() As CWTCustomControls.CWTTextBox
        Get
            Return Me.txtHPCode
        End Get
    End Property
    Public ReadOnly Property HP() As CWTCustomControls.CWTTextBox
        Get
            Return Me.txtHPNo
        End Get
    End Property
    Public ReadOnly Property FaxCode() As CWTCustomControls.CWTTextBox
        Get
            Return Me.txtFaxCode
        End Get
    End Property
    Public ReadOnly Property Fax() As CWTCustomControls.CWTTextBox
        Get
            Return Me.txtFaxNo
        End Get
    End Property

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.BLL2 = New BusinessLogicLayer.StaffBLL()
        Me.BLL3 = New BusinessLogicLayer.tblFunctionBLL()

        If Not IsPostBack Then
            'Call Me.LoadTitle()
        End If
        Call Me.AccessControl("Client Contact")
    End Sub

    Private Sub AccessControl(ByVal title As String)

        Dim userName As String
        Dim oDatatable As DataTable
        Dim oDataTable2 As DataTable

        Static roleID As String

        userName = ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName
        oDatatable = Me.BLL2.GetUserByID(userName)

        If oDatatable.Rows.Count > 0 Then
            roleID = oDatatable.Rows(0).Item("RoleID").ToString
        End If

        oDataTable2 = Me.BLL3.GetUserRole(roleID)
        If oDataTable2.Rows.Count > 0 Then
            For k As Integer = 0 To oDataTable2.Rows.Count - 1
                If oDataTable2.Rows(k).Item("functionGroup") = "1" Then
                    If oDataTable2.Rows(k).Item("Permission") = "V" Then
                        If oDataTable2.Rows(k).Item("functionName").ToString = title Then

                            Call Me.toggleControl()

                        End If
                    End If
                End If

            Next

        End If


    End Sub

    Private Sub toggleControl()

        Me.txtFirstName.Readonly = True
        Me.txtLastName.Readonly = True
        Me.txtJobTitle.Readonly = True
        Me.txtPhoneCode.Readonly = True
        Me.txtPhoneNo.Readonly = True
        Me.txtHPCode.Readonly = True
        Me.txtHPNo.Readonly = True
        Me.txtFaxCode.Readonly = True
        Me.txtFaxNo.Readonly = True
        Me.txtEmail.Readonly = True
        Me.ddlTitle.Enabled = False


    End Sub


    Public Function GetUserInfo() As DataInfo.UserInfo
        Dim retVal As New DataInfo.UserInfo()
        With retVal
            .Title = Me.ddlTitle.SelectedValue
            .FirstName = Me.txtFirstName.Text
            .LastName = Me.txtLastName.Text
            .Email = Me.txtEmail.Text
            .JobTitle = Me.txtJobTitle.Text
            .PhoneCode = Me.txtPhoneCode.Text
            .MobileCode = Me.txtHPCode.Text
            .Phone = Me.txtPhoneNo.Text
            .Mobile = Me.txtHPNo.Text
            .FaxCode = Me.txtFaxCode.Text
            .Fax = Me.txtFaxNo.Text
        End With
        Return retVal
    End Function

    Public Function ValidateForm() As Boolean
        Return (Me.txtFirstName.Text.Trim <> "")
    End Function

    Public Sub ClearData()
        Me.txtFirstName.Text = ""
        Me.txtLastName.Text = ""
        Me.txtJobTitle.Text = ""
        Me.txtPhoneCode.Text = ""
        Me.txtPhoneNo.Text = ""
        Me.txtHPCode.Text = ""
        Me.txtHPNo.Text = ""
        Me.txtFaxCode.Text = ""
        Me.txtFaxNo.Text = ""
        Me.txtEmail.Text = ""
        Me.ddlTitle.SelectedIndex = -1
    End Sub

    Private Sub LoadTitle()
        'With Me.ddlTitle
        '    .Items.Add(New ListItem("Mr.", "Mr."))
        '    .Items.Add(New ListItem("Miss", "Miss"))
        '    .Items.Add(New ListItem("Mrs", "Mrs"))
        'End With
    End Sub

    Public Sub SetValidateMessage(ByVal index As String)
        Me.vadFirstName.ErrorMessage = "Client Contact " + index + ":First Name is required."
        Me.vadEmail.ErrorMessage = "Client Contact " + index + ":Email is required."
        Me.vadPhone.ErrorMessage = "Client Contact " + index + ":Business Phone is required."
        Me.fvadEmail.ErrorMessage = "Client Contact " + index + ":Email is in invalid format."
        Me.vadPhoneCode.ErrorMessage = "Client Contact " + index + ":Phone code is invalid."
        Me.vadPhoneNumber.ErrorMessage = "Client Contact " + index + ":Phone number is invalid."
        Me.vadFaxCode.ErrorMessage = "Client Contact " + index + ":Fax code is invalid."
        Me.vadFaxNumber.ErrorMessage = "Client Contact " + index + ":Fax number is invalid."
        Me.vadMobileCode.ErrorMessage = "Client Contact " + index + ":Mobile code is invalid."
        Me.vadMobileNumber.ErrorMessage = "Client Contact " + index + ":Mobile number is invalid."
    End Sub

End Class
@


1.1.1.1
log
@no message
@
text
@@
