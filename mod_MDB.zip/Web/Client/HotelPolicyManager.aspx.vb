head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.57;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.57;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@
Partial Class Web_Client_HotelPolicyManager
    Inherits BasePage

#Region "Page Properties & Variables"
    Private BLL As BusinessLogicLayer.CompanyPolicyBLL
    Private BLL2 As BusinessLogicLayer.StaffBLL
    Private BLL3 As BusinessLogicLayer.tblFunctionBLL

    Private Property PolicyTable() As DataTable
        Get
            Return Me.ViewState("_PolicyTable")
        End Get
        Set(ByVal value As DataTable)
            Me.ViewState("_PolicyTable") = value
        End Set
    End Property

    Private Property ClassTable() As DataTable
        Get
            Return Me.ViewState("_ClassTable")
        End Get
        Set(ByVal value As DataTable)
            Me.ViewState("_ClassTable") = value
        End Set
    End Property

    Public Property CurentWebMode() As DataInfo.CompanyPolicyInfo.WebMode
        Get
            Dim retVal As DataInfo.CompanyInfo.WebMode = DataInfo.CompanyInfo.WebMode.GeneralInfo
            If Me.ViewState("_CurentWebMode") IsNot Nothing Then
                retVal = Me.ViewState("_CurentWebMode")
            End If
            Return retVal
        End Get
        Set(ByVal value As DataInfo.CompanyPolicyInfo.WebMode)
            Me.ViewState("_CurentWebMode") = value
        End Set
    End Property

    Public ReadOnly Property RequestWebMode() As String
        Get
            Dim retVal As String = ""
            If Me.Request("wmode") IsNot Nothing Then
                retVal = Me.Request("wmode")
            End If
            Return retVal
        End Get
    End Property
#End Region

#Region "Page Event Handlers & Methods"
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.BLL = New BusinessLogicLayer.CompanyPolicyBLL()
        Me.BLL2 = New BusinessLogicLayer.StaffBLL()
        Me.BLL3 = New BusinessLogicLayer.tblFunctionBLL()
        Select Case Me.RequestWebMode.ToLower()
            Case "class"
                Me.CurentWebMode = DataInfo.CompanyPolicyInfo.WebMode.ClassPolicy
                'Call Me.CreateTable()
                Call Me.AccessControl("Room")
            Case Else
                Me.CurentWebMode = DataInfo.CompanyPolicyInfo.WebMode.PolicyLine
                'Call Me.CreateTable()
                Call Me.AccessControl("General")
        End Select
        If Not IsPostBack Then
            Call Me.CreateTable()
        End If
    End Sub

    Private Sub AccessControl(ByVal title As String)

        Dim userName As String
        Dim oDatatable As DataTable
        Dim oDataTable2 As DataTable

        Static roleID As String

        userName = ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName
        oDatatable = Me.BLL2.GetUserByID(userName)

        If oDatatable.Rows.Count > 0 Then
            roleID = oDatatable.Rows(0).Item("RoleID").ToString
        End If

        oDataTable2 = Me.BLL3.GetUserRole(roleID)
        If oDataTable2.Rows.Count > 0 Then
            For k As Integer = 0 To oDataTable2.Rows.Count - 1
                If oDataTable2.Rows(k).Item("functionGroup") = "1" Then
                    If oDataTable2.Rows(k).Item("Permission") = "V" Then
                        If oDataTable2.Rows(k).Item("ParentID").ToString = "PH" Then
                            If oDataTable2.Rows(k).Item("functionName").ToString = title Then
                                If title = "Room" Then
                                    Call Me.toggleControl2()
                                Else
                                    Call Me.toggleControl()
                                End If



                            End If
                        End If

                    End If
                End If

            Next

        End If


    End Sub

    Private Sub toggleControl()

        Me.txtPolicyLine.Readonly = True
        Me.btnSave.Enabled = False
        Me.gdData.Visible = False
        Me.tblPg.Visible = False

        Me.gdDataViewGN.Visible = True
        Me.tblPgGN.Visible = True

       


        Me.btnTrans.ShowSaveNextButton = False
        Me.btnTrans.SaveButton.Enabled = False
    End Sub

    Private Sub toggleControl2()

        Me.txtRemark.Readonly = True
        Me.btnAdd2.Enabled = False
        Me.ddlClass.Enabled = False

        Me.txtTravelerType.Readonly = True
        Me.gdDataClass.Visible = False
        Me.tblPg2.Visible = False
        Me.gdDataViewCL.Visible = True
        Me.tblPgCL.Visible = True

       


        Me.btnTrans.ShowSaveNextButton = False
        Me.btnTrans.SaveButton.Enabled = False
    End Sub


    Private Sub CreateTable()
        If Me.CurentWebMode = DataInfo.CompanyPolicyInfo.WebMode.PolicyLine Then
            Me.tblPolicy.Visible = True
            Me.tblClassPolicy.Visible = False
            Call Me.CreatePolicyTable()
            Call Me.LoadPolicyDataFromDB()
        Else
            Me.tblPolicy.Visible = False
            Me.tblClassPolicy.Visible = True
            Call Me.CreateClassTable()
            Call Me.LoadDropDownList()
            Call Me.LoadClassDataFromDB()
        End If
        Call Me.LoadNewData()
    End Sub
#End Region

#Region "Policy Sub Routines"
    Private Sub CreatePolicyTable()
        Me.PolicyTable = New DataTable("PolicyTable")
        With Me.PolicyTable
            .Columns.Add(New DataColumn("ItemNo", GetType(Integer)))
            .Columns.Add(New DataColumn("PolicyLine"))
        End With
    End Sub

    Private Sub AddPolicyData()
        Dim dr As DataRow
        dr = Me.PolicyTable.NewRow()
        If Me.PolicyTable.Rows.Count > 0 Then
            dr("ItemNo") = Util.DBNullToZero(Me.PolicyTable.Rows(Me.PolicyTable.Rows.Count - 1).Item("ItemNo") + 1)
        Else
            dr("ItemNo") = 1
        End If
        dr("PolicyLine") = Me.txtPolicyLine.Text
        Me.PolicyTable.Rows.Add(dr)
    End Sub

    Private Sub LoadPolicyData(ByVal ItemNo As String)
        Dim dr As DataRow()
        Dim filter As String = ""
        filter = "ItemNo=" + Util.LimitTheString(ItemNo)
        dr = Me.PolicyTable.Select(filter)
        If dr IsNot Nothing AndAlso dr.Length > 0 Then
            Me.txtItemNo.Value = ItemNo
            Me.txtPolicyLine.Text = dr(0).Item("PolicyLine").ToString
        End If
    End Sub

    Private Sub LoadPolicyDataFromDB()
        Dim oDataTable As DataTable
        Dim oRow As DataRow
        Dim dr As DataRow
        oDataTable = Me.BLL.GetHotelPolicyData(Me.CurrentClientID)
        If oDataTable IsNot Nothing Then
            For i As Integer = 0 To oDataTable.Rows.Count - 1
                oRow = oDataTable.Rows(i)
                dr = Me.PolicyTable.NewRow()
                If Me.PolicyTable.Rows.Count > 0 Then
                    dr("ItemNo") = Util.DBNullToZero(Me.PolicyTable.Rows(Me.PolicyTable.Rows.Count - 1).Item("ItemNo") + 1)
                Else
                    dr("ItemNo") = 1
                End If
                dr("PolicyLine") = oRow("PolicyLine").ToString
                Me.PolicyTable.Rows.Add(dr)
            Next
            Call Me.RefreshPolicyGrid()
        End If
    End Sub

    Private Sub RemovePolicyData(ByVal ItemNo As String)
        Dim dr As DataRow()
        Dim filter As String = ""
        filter = "ItemNo=" + Util.LimitTheString(ItemNo)
        dr = Me.PolicyTable.Select(filter)
        If dr IsNot Nothing AndAlso dr.Length > 0 Then
            Me.PolicyTable.Rows.Remove(dr(0))
        End If
    End Sub

    Private Sub UpdatePolicyData(ByVal ItemNo As String)
        Dim dr As DataRow()
        Dim filter As String = ""
        filter = "ItemNo=" + Util.LimitTheString(ItemNo)
        dr = Me.PolicyTable.Select(filter)
        If dr IsNot Nothing AndAlso dr.Length > 0 Then
            dr(0).Item("PolicyLine") = Me.txtPolicyLine.Text
        End If
    End Sub

    Private Sub RefreshPolicyGrid()
        Dim dv As New DataView()
        With dv
            .Table = Me.PolicyTable
            .Sort = "ItemNo"
        End With
        With Me.gdData
            .DataSource = dv.ToTable()
            .DataBind()
        End With
        With Me.pgControl
            .GridID = Me.gdData.UniqueID
            .SetBindGrid()
        End With

        With dv
            .Table = Me.PolicyTable
            .Sort = "ItemNo"
        End With
        With Me.gdDataViewGN
            .DataSource = dv.ToTable()
            .DataBind()
        End With
        With Me.pgControlGN
            .GridID = Me.gdDataViewGN.UniqueID
            .SetBindGrid()
        End With
    End Sub

    Public Sub gdData_Command(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.CommandEventArgs)
        Select Case e.CommandName
            Case "delete"
                Call Me.RemovePolicyData(Util.DBNullToZero(e.CommandArgument))
            Case "edit"
                Call Me.LoadPolicyData(Util.DBNullToZero(e.CommandArgument))
                Me.btnSave.Text = "Update"
        End Select
        Call Me.RefreshPolicyGrid()
        Call Me.AccessControl("General")
    End Sub

    Protected Sub btnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSave.Click
        Dim ItemNo As String = ""
        ItemNo = Me.txtItemNo.Value
        If ItemNo = "" Then
            Call Me.AddPolicyData()
        Else
            Call Me.UpdatePolicyData(ItemNo)
        End If
        Call Me.RefreshPolicyGrid()
        Call Me.LoadNewData()
    End Sub

    Protected Sub btnCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        Call Me.LoadNewData()
    End Sub
#End Region

#Region "Class sub routine"
    Private Sub CreateClassTable()
        Me.ClassTable = New DataTable("ClassTable")
        With Me.ClassTable
            .Columns.Add(New DataColumn("ItemNo", GetType(Integer)))
            .Columns.Add(New DataColumn("TravelerType"))
            .Columns.Add(New DataColumn("RoomTypecode"))
            .Columns.Add(New DataColumn("Remark"))
        End With
    End Sub

    Private Sub AddClassData()
        Dim dr As DataRow
        dr = Me.ClassTable.NewRow()
        If Me.ClassTable.Rows.Count > 0 Then
            dr("ItemNo") = Util.DBNullToZero(Me.ClassTable.Rows(Me.ClassTable.Rows.Count - 1).Item("ItemNo") + 1)
        Else
            dr("ItemNo") = 1
        End If
        dr("TravelerType") = Me.txtTravelerType.Text
        dr("RoomTypecode") = Me.ddlClass.SelectedValue
        dr("Remark") = Me.txtRemark.Text
        Me.ClassTable.Rows.Add(dr)
    End Sub

    Private Sub LoadClassData(ByVal ItemNo As String)
        On Error Resume Next
        Dim dr As DataRow()
        Dim filter As String = ""
        filter = "ItemNo=" + Util.LimitTheString(ItemNo)
        dr = Me.ClassTable.Select(filter)
        If dr IsNot Nothing AndAlso dr.Length > 0 Then
            Me.txtItemNo2.Value = ItemNo
            Me.txtTravelerType.Text = dr(0).Item("TravelerType").ToString
            Me.ddlClass.SelectedValue = dr(0).Item("RoomTypecode").ToString
            Me.txtRemark.Text = dr(0).Item("Remark").ToString
        End If
    End Sub

    Private Sub LoadClassDataFromDB()
        Dim oDataTable As DataTable
        Dim oRow As DataRow
        Dim dr As DataRow
        Try
            oDataTable = Me.BLL.GetHotelClassData(Me.CurrentClientID)
            If oDataTable IsNot Nothing Then
                For i As Integer = 0 To oDataTable.Rows.Count - 1
                    oRow = oDataTable.Rows(i)
                    dr = Me.ClassTable.NewRow()
                    If Me.ClassTable.Rows.Count > 0 Then
                        dr("ItemNo") = Util.DBNullToZero(Me.ClassTable.Rows(Me.ClassTable.Rows.Count - 1).Item("ItemNo") + 1)
                    Else
                        dr("ItemNo") = 1
                    End If
                    dr("TravelerType") = oRow("TravelerType").ToString
                    dr("RoomTypecode") = oRow("RoomTypeCode").ToString
                    dr("Remark") = oRow("Remarks").ToString
                    Me.ClassTable.Rows.Add(dr)
                Next
                Call Me.RefreshClassGrid()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub RemoveClassData(ByVal ItemNo As String)
        Dim dr As DataRow()
        Dim filter As String = ""
        filter = "ItemNo=" + Util.LimitTheString(ItemNo)
        dr = Me.ClassTable.Select(filter)
        If dr IsNot Nothing AndAlso dr.Length > 0 Then
            Me.ClassTable.Rows.Remove(dr(0))
        End If
    End Sub

    Private Sub UpdateClassData(ByVal ItemNo As String)
        Dim dr As DataRow()
        Dim filter As String = ""
        filter = "ItemNo=" + Util.LimitTheString(ItemNo)
        dr = Me.ClassTable.Select(filter)
        If dr IsNot Nothing AndAlso dr.Length > 0 Then
            dr(0).Item("TravelerType") = Me.txtTravelerType.Text
            dr(0).Item("RoomTypecode") = Me.ddlClass.SelectedValue
            dr(0).Item("Remark") = Me.txtRemark.Text
        End If
    End Sub

    Private Sub RefreshClassGrid()
        Dim dv As New DataView()
        With dv
            .Table = Me.ClassTable
            .Sort = "ItemNo"
        End With
        With Me.gdDataClass
            .DataSource = dv.ToTable()
            .DataBind()
        End With
        With Me.pgControl2
            .GridID = Me.gdDataClass.UniqueID
            .SetBindGrid()
        End With

        With dv
            .Table = Me.ClassTable
            .Sort = "ItemNo"
        End With
        With Me.gdDataViewCL
            .DataSource = dv.ToTable()
            .DataBind()
        End With
        With Me.pgControlCL
            .GridID = Me.gdDataViewCL.UniqueID
            .SetBindGrid()
        End With
    End Sub

    Public Sub gdDataClass_Command(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.CommandEventArgs)
        Select Case e.CommandName
            Case "delete"
                Call Me.RemoveClassData(Util.DBNullToZero(e.CommandArgument))
            Case "edit"
                Call Me.LoadClassData(Util.DBNullToZero(e.CommandArgument))
                Me.btnAdd2.Text = "Update"
        End Select
        Call Me.RefreshClassGrid()
        Call Me.AccessControl("Room")
    End Sub

    Protected Sub btnAdd2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnAdd2.Click
        Dim ItemNo As String = ""
        ItemNo = Me.txtItemNo2.Value
        If ItemNo = "" Then
            Call Me.AddClassData()
        Else
            Call Me.UpdateClassData(ItemNo)
        End If
        Call Me.RefreshClassGrid()
        Call Me.LoadNewData()
    End Sub

    Protected Sub btnCancel2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnCancel2.Click
        Call Me.LoadNewData()
    End Sub

    Public Function GetClassText(ByVal val As String) As String
        Dim retVal As String = ""
        Dim li As ListItem
        li = Me.ddlClass.Items.FindByValue(val)
        If li IsNot Nothing Then
            retVal = li.Text
        End If
        Return retVal
    End Function
#End Region

#Region "Data Binding"
    Private Sub LoadClass()
        Dim BLL As New BusinessLogicLayer.CompanyPolicyBLL()
        Dim oDataTable As DataTable
        oDataTable = BLL.GetHotelClassList()
        With Me.ddlClass
            .DataTextField = "RoomTypeDescription"
            .DataValueField = "RoomTypeCode"
            .DataSource = oDataTable
            .DataBind()
        End With
    End Sub

    Private Sub LoadDropDownList()
        Call Me.LoadClass()
    End Sub

    Private Sub LoadNewData()
        Me.txtPolicyLine.Text = ""
        '//
        Me.txtItemNo.Value = ""
        Me.txtItemNo2.Value = ""
        Me.txtTravelerType.Text = ""
        Me.ddlClass.SelectedIndex = -1
        Me.txtRemark.Text = ""
        Me.btnSave.Text = "Add"
        Me.btnAdd2.Text = "Add"
    End Sub

    Private Sub LoadDataFromDB()
        Call Me.LoadPolicyDataFromDB()
        Call Me.LoadClassDataFromDB()
    End Sub
#End Region

#Region "Data Transaction"
    Private Sub SaveData(ByVal IsNext As Boolean)
        Dim info As New DataInfo.CompanyPolicyInfo()
        Dim Hotel As DataInfo.BaseItemClassInfo
        Dim r As DataRow
        With info
            .PageMode = Me.CurrentPageMode
            .ClientID = Me.CurrentClientID
            .CurrentWebMode = Me.CurentWebMode
            If Me.CurentWebMode = DataInfo.CompanyPolicyInfo.WebMode.PolicyLine Then
                '// Policy
                For i As Integer = 0 To Me.PolicyTable.Rows.Count - 1
                    .PolicyLines.Add(Me.PolicyTable.Rows(i).Item("PolicyLine").ToString)
                Next
            Else
                For i As Integer = 0 To Me.ClassTable.Rows.Count - 1
                    r = Me.ClassTable.Rows(i)
                    Hotel = New DataInfo.BaseItemClassInfo()
                    With Hotel
                        .TravellerType = r("TravelerType")
                        .PreferredClass = r("RoomTypecode")
                        .Remark = r("Remark")
                    End With
                    .HotelClassList.Add(Hotel)
                Next
            End If
        End With
        If Me.BLL.UpdateHotelPolicy(info) > 0 Then
            Me.lblMsgBox.Text = Util.GetAppConfig(Util.MsgType.TRANS_SUCCESS.ToString)
            Me.lblMsgBox.ForeColor = Drawing.Color.Green
            Me.ajaxMsgBox.Show()
            If Me.CurentWebMode = DataInfo.CompanyPolicyInfo.WebMode.PolicyLine Then
                Response.Redirect("HotelPolicyManager.aspx?wmode=class")
            Else
                Response.Redirect("CarPolicyManager.aspx")
            End If
        Else
            Me.lblMsgBox.Text = Util.GetAppConfig(Util.MsgType.TRANS_ERROR.ToString)
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.ajaxMsgBox.Show()
        End If
    End Sub
#End Region

#Region "Page Control Event Handlers"
    Protected Sub btnTrans_OnCancel(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans.OnCancel
        Response.Redirect("CompanySearch.aspx")
    End Sub

    Protected Sub btnTrans_OnSave(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans.OnSave
        Call Me.SaveData(False)
    End Sub

    Protected Sub btnTrans_OnSaveNext(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans.OnSaveNext
        Call Me.SaveData(True)
    End Sub
#End Region

#Region "Misc"

#End Region

End Class
@


1.1.1.1
log
@no message
@
text
@@
