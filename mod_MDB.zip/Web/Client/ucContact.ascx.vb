head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.58;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.58;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports System.DirectoryServices
Imports System.DirectoryServices.DirectoryEntry
Imports System.DirectoryServices.DirectorySearcher
Imports System.DirectoryServices.SearchResultCollection
Imports System.DirectoryServices.SearchResult
Imports System.DirectoryServices.ResultPropertyCollection
Imports System.DirectoryServices.PropertyValueCollection

Partial Class Web_Client_ucContact
    Inherits BaseUserControl


    Private BLL2 As BusinessLogicLayer.StaffBLL
    Private BLL3 As BusinessLogicLayer.tblFunctionBLL


    Private Property IsError() As Boolean
        Get
            Dim retVal As Boolean
            If Me.ViewState("_IsError") IsNot Nothing Then
                retVal = CBool(Me.ViewState("_IsError"))
            End If
            Return retVal
        End Get
        Set(ByVal value As Boolean)
            Me.ViewState("_IsError") = value
        End Set
    End Property
    Public Property RecordID() As String
        Get
            Dim retVal As String = ""
            If Me.ViewState("_RecordID") IsNot Nothing Then
                retVal = Me.ViewState("_RecordID").ToString
            End If
            Return retVal
        End Get
        Set(ByVal value As String)
            Me.ViewState("_RecordID") = value
        End Set
    End Property

    Public Property RecordID2() As String
        Get
            Dim retVal As String = ""
            If Me.ViewState("_RecordID2") IsNot Nothing Then
                retVal = Me.ViewState("_RecordID2").ToString
            End If
            Return retVal
        End Get
        Set(ByVal value As String)
            Me.ViewState("_RecordID2") = value
        End Set
    End Property
  


    Public Function GetCWTContact() As DataInfo.UserInfo
        Dim retVal As New DataInfo.UserInfo()
        With retVal
            .Title = Me.ddlTitle.SelectedValue
            .FirstName = Me.txtFirstName.Text
            .LastName = Me.txtLastName.Text
            .Email = Me.txtEmail.Text
            .JobTitle = Me.txtJobTitle.Text
            .PhoneCode = Me.txtPhoneCode.Text
            .MobileCode = Me.txtHPCode.Text
            .Phone = Me.txtPhoneNo.Text
            .Mobile = Me.txtHPNo.Text
            .UserName = Me.txtUID.Text
        End With
        Return retVal
    End Function

    Public ReadOnly Property UserID() As String
        Get
            Return Me.txtUID.Text
        End Get
    End Property

    Public Event PreUserDataBind(ByVal sender As Object, ByVal e As System.EventArgs)

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.BLL2 = New BusinessLogicLayer.StaffBLL()
        Me.BLL3 = New BusinessLogicLayer.tblFunctionBLL()
        Me.RecordID = Me.CurrentClientID
        Me.RecordID2 = Me.txtUID.Text
        If Not IsPostBack Then
            'Call Me.RegistScript()
        End If
        Call Me.AccessControl("CWT contact")
    End Sub

    'Private Sub RegistScript()
    '    Dim sc As String
    '    sc = "openRegCtrl('" + Util.JSEncode(Me.txtUID.ClientID) + "','" + Util.JSEncode(Me.btnFakeGetInfo.ClientID) + "');"
    '    Me.btnGetInfo.OnClientClick = sc
    'End Sub

    Private Sub AccessControl(ByVal title As String)

        Dim userName As String
        Dim oDatatable As DataTable
        Dim oDataTable2 As DataTable

        Static roleID As String

        userName = ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName
        oDatatable = Me.BLL2.GetUserByID(userName)

        If oDatatable.Rows.Count > 0 Then
            roleID = oDatatable.Rows(0).Item("RoleID").ToString
        End If

        oDataTable2 = Me.BLL3.GetUserRole(roleID)
        If oDataTable2.Rows.Count > 0 Then
            For k As Integer = 0 To oDataTable2.Rows.Count - 1
                If oDataTable2.Rows(k).Item("functionGroup") = "1" Then
                    If oDataTable2.Rows(k).Item("Permission") = "V" Then
                        If oDataTable2.Rows(k).Item("functionName").ToString = title Then
                            Call Me.toggleControl()
                        End If
                    End If
                End If

            Next

        End If

    End Sub

    Private Sub toggleControl()
        
        '// 
        Me.txtUID.Readonly = True
        Me.btnGetInfo.Enabled = False
    End Sub

    Private Sub LoadData()
        Dim BLL As New BusinessLogicLayer.StaffBLL()
        Dim oDataTable As DataTable
        oDataTable = BLL.GetUserList("", "", False)
        With Me.gdData
            .DataSource = oDataTable
            .DataBind()
        End With
        With Me.pgControl
            .GridID = Me.gdData.UniqueID
            .PageDataTable = oDataTable.Copy()
            .SetBindGrid()
        End With
    End Sub

    Public Sub SetUserInfo(ByVal UID As String, ByVal clientID As String)
        Me.txtUID.Text = UID

        Me.RecordID = Me.CurrentClientID

        Call Me.GetUserInfo(Me.txtUID.Text, Me.RecordID)
    End Sub

    Public Sub ClearData()
        Me.txtFirstName.Text = ""
        Me.txtLastName.Text = ""
        Me.txtJobTitle.Text = ""
        Me.txtPhoneCode.Text = ""
        Me.txtPhoneNo.Text = ""
        Me.txtHPCode.Text = ""
        Me.txtHPNo.Text = ""
        Me.txtEmail.Text = ""
        'Me.ddlTitle.Text = ""
        '// 
        Me.txtUID.Text = ""
    End Sub

    Private Sub GetUserInfo(ByVal Username As String, ByVal clientID As String)
        Dim BLL As New BusinessLogicLayer.StaffBLL()
        Dim oDataTable As DataTable
        Dim oRow As DataRow = Nothing
        Dim chkTitle As String
        Dim UID As String = ""
        UID = Me.txtUID.Text
        oDataTable = BLL.GetCWTContact(UID, clientID)
        If oDataTable IsNot Nothing AndAlso oDataTable.Rows.Count > 0 Then
            oRow = oDataTable.Rows(0)
            'Me.txtFirstName.Text = oRow("FirstName").ToString()
            'Me.txtLastName.Text = oRow("LastName").ToString()
            'Me.txtJobTitle.Text = oRow("JobTitle").ToString()
            Me.txtPhoneCode.Text = oRow("LocalCode").ToString()
            Me.txtPhoneNo.Text = oRow("Phone").ToString()
            Me.txtHPCode.Text = oRow("LocalCodeMobile").ToString()
            Me.txtHPNo.Text = oRow("Mobile").ToString()
            'Me.txtEmail.Text = oRow("Email").ToString()
            chkTitle = oRow("Title").ToString()
            If chkTitle <> "" Then
                Me.ddlTitle.SelectedValue = oRow("Title").ToString()
            Else
                Me.ddlTitle.SelectedValue = "Mr."
            End If

        End If

        Dim de As DirectoryEntry = CType(Me.Session("_dirEntry"), DirectoryEntry)
        Dim deSearch As New DirectorySearcher()

        With deSearch
            .SearchRoot = de
            deSearch.Filter = "(&(objectClass=user) (SAMAccountName=" + Username + "))"
            .PropertiesToLoad.Add("givenName") '; // user's first name
            .PropertiesToLoad.Add("sn") '; // user's surname
            .PropertiesToLoad.Add("mail") '; // user's surname
            .PropertiesToLoad.Add("title")

            '.PropertiesToLoad.Add("")

        End With
        Dim results As SearchResult = deSearch.FindOne()
        If results IsNot Nothing Then
            If results.Properties("givenname").Count > 0 Then

                Me.txtFirstName.Text = Util.DBNullToText(results.Properties("givenname").Item(0).ToString)
            Else
                If oDataTable IsNot Nothing AndAlso oDataTable.Rows.Count > 0 Then
                    Me.txtFirstName.Text = oRow("FirstName").ToString()
                Else
                    Me.txtFirstName.Text = ""
                End If

            End If
            If results.Properties("sn").Count > 0 Then

                Me.txtLastName.Text = Util.DBNullToText(results.Properties("sn").Item(0).ToString)
            Else
                If oDataTable IsNot Nothing AndAlso oDataTable.Rows.Count > 0 Then
                    Me.txtLastName.Text = oRow("LastName").ToString()
                Else
                    Me.txtLastName.Text = ""
                End If

            End If

            If results.Properties("mail").Count > 0 Then

                Me.txtEmail.Text = Util.DBNullToText(results.Properties("mail").Item(0).ToString)
            Else
                If oDataTable IsNot Nothing AndAlso oDataTable.Rows.Count > 0 Then
                    Me.txtEmail.Text = oRow("Email").ToString()
                Else
                    Me.txtEmail.Text = ""
                End If

            End If

            If results.Properties("title").Count > 0 Then

                Me.txtJobTitle.Text = Util.DBNullToText(results.Properties("title").Item(0).ToString)
            Else
                If oDataTable IsNot Nothing AndAlso oDataTable.Rows.Count > 0 Then
                    Me.txtJobTitle.Text = oRow("JobTitle").ToString()
                Else
                    Me.txtJobTitle.Text = ""
                End If

            End If

        Else

            Call Me.ClearData()
            Me.lblMsgBox.Text = "Cannot get any information from system or user does not exist."
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.IsError = True
            Me.ajaxMsgBox.Show()
        End If


        RaiseEvent PreUserDataBind(Me, Nothing)



    End Sub

    Protected Sub txtUID_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtUID.TextChanged
        Call Me.GetUserInfo(Me.txtUID.Text, Me.RecordID)
    End Sub

    Protected Sub btnGetInfo_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnGetInfo.Click
        'Call Me.LoadData()
        'Me.ajaxPopup.Show()
        Call Me.GetUserInfo(Me.RecordID2, Me.RecordID)
    End Sub

    Protected Sub gdData_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles gdData.SelectedIndexChanged
        Me.txtUID.Text = Me.gdData.SelectedRow.Cells(2).Text
        Call Me.GetUserInfo(Me.txtUID.Text, Me.RecordID)
    End Sub

    Protected Sub btnFakeGetInfo_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnFakeGetInfo.Click
        Call Me.GetUserInfo(Me.txtUID.Text, Me.RecordID)
    End Sub

    Public Sub SetValidateMessage2(ByVal index As String)
        Me.vadFirstName.ErrorMessage = "CWT Contact " + index + ":First Name is required."
        Me.vadEmail.ErrorMessage = "CWT Contact " + index + ":Email is required."
        Me.vadPhone.ErrorMessage = "CWT Contact " + index + ":Business Phone is required."
        Me.fvadEmail.ErrorMessage = "CWT Contact " + index + ":Email is in invalid format."
        Me.vadPhoneCode.ErrorMessage = "CWT Contact " + index + ":Phone code is invalid."
        Me.vadPhoneNumber.ErrorMessage = "CWT Contact " + index + ":Phone number is invalid."
        Me.vadMobileCode.ErrorMessage = "CWT Contact " + index + ":Mobile code is invalid."
        Me.vadMobileNumber.ErrorMessage = "CWT Contact " + index + ":Mobile number is invalid."
    End Sub

End Class
@


1.1.1.1
log
@no message
@
text
@@
