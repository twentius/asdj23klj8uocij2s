head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.56;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.56;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@
Partial Class Web_Client_CompanyCannedRemarkManager
    Inherits BasePage

#Region "Page Properties & Variables"
    Private BLL As BusinessLogicLayer.CompanyCannedRemarkBLL
    Private BLL2 As BusinessLogicLayer.StaffBLL
    Private BLL3 As BusinessLogicLayer.tblFunctionBLL

    Private Property RemarkTable() As DataTable
        Get
            Return Me.ViewState("_RemarkTable")
        End Get
        Set(ByVal value As DataTable)
            Me.ViewState("_RemarkTable") = value
        End Set
    End Property

    Private Property ClassTable() As DataTable
        Get
            Return Me.ViewState("_ClassTable")
        End Get
        Set(ByVal value As DataTable)
            Me.ViewState("_ClassTable") = value
        End Set
    End Property

    Private Property StdCannedRemark() As Boolean
        Get
            Return Util.DBNullToFalse(Me.ViewState("_StdCannedRemark"))
        End Get
        Set(ByVal value As Boolean)
            Me.ViewState("_StdCannedRemark") = value
        End Set
    End Property
#End Region

#Region "Page Event Handlers & Methods"
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.BLL = New BusinessLogicLayer.CompanyCannedRemarkBLL()
        Me.BLL2 = New BusinessLogicLayer.StaffBLL()
        Me.BLL3 = New BusinessLogicLayer.tblFunctionBLL()

        If Not IsPostBack Then
            Call Me.CreateTable()
            Call Me.LoadDataFromDB()
            Call Me.LoadNewData()

            Me.StdCannedRemark = False
            Call Me.ToggleStdRemarkMode()
            Me.gdDataView.Visible = False
            Me.tblPage2.Visible = False
            Call Me.AccessControl("Canned Remarks")

        End If
        

    End Sub

    Private Sub AccessControl(ByVal title As String)

        Dim userName As String
        Dim oDatatable As DataTable
        Dim oDataTable2 As DataTable

        Static roleID As String

        userName = ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName
        oDatatable = Me.BLL2.GetUserByID(userName)

        If oDatatable.Rows.Count > 0 Then
            roleID = oDatatable.Rows(0).Item("RoleID").ToString
        End If

        oDataTable2 = Me.BLL3.GetUserRole(roleID)
        If oDataTable2.Rows.Count > 0 Then
            For k As Integer = 0 To oDataTable2.Rows.Count - 1
                If oDataTable2.Rows(k).Item("functionGroup") = "1" Then
                    If oDataTable2.Rows(k).Item("Permission") = "V" Then
                        If oDataTable2.Rows(k).Item("ParentID").ToString = "GN" Then
                            If oDataTable2.Rows(k).Item("functionName").ToString = title Then

                                Call Me.toggleControl()
                            End If
                        End If

                    End If
                End If

            Next

        End If


    End Sub

    Private Sub toggleControl()
        'Dim a As Integer

        'Dim btnDelete As CWTCustomControls.CWTLinkButton

       
        Me.chkApplyStd.Enabled = False
        Me.chkLoadToPNR.Enabled = False
        Me.txtRemark.Readonly = True
        Me.btnSave.Enabled = False

        
        'For i As Integer = 0 To Me.gdData.Rows.Count - 1

        '    btnDelete = Me.gdData.Rows(i).FindControl("hrefDeleteItem")
        '    btnDelete.Enabled = False

        'Next
        Me.gdData.Visible = False
        Me.tblPage.Visible = False
        Me.gdDataView.Visible = True
        Me.tblPage2.Visible = True
        Me.btnTrans.ShowSaveNextButton = False
        Me.btnTrans.SaveButton.Enabled = False
    End Sub

    Private Sub CreateTable()
        Call Me.CreateRemarkTable()
    End Sub
#End Region

#Region "Remark Sub Routines"
    Private Sub CreateRemarkTable()
        Me.RemarkTable = New DataTable("RemarkTable")
        With Me.RemarkTable
            .Columns.Add(New DataColumn("ItemNo", GetType(Integer)))
            .Columns.Add(New DataColumn("Remark"))
            .Columns.Add(New DataColumn("LoadToPNR"))
            .Columns.Add(New DataColumn("IsStandard"))
        End With
    End Sub

    Private Sub AddRemarkData()
        Dim dr As DataRow
        dr = Me.RemarkTable.NewRow()
        If Me.RemarkTable.Rows.Count > 0 Then
            dr("ItemNo") = Util.DBNullToZero(Me.RemarkTable.Rows(Me.RemarkTable.Rows.Count - 1).Item("ItemNo") + 1)
        Else
            dr("ItemNo") = 1
        End If
        dr("Remark") = Me.txtRemark.Text
        dr("LoadToPNR") = Me.chkLoadToPNR.Checked
        dr("IsStandard") = 0
        Me.RemarkTable.Rows.Add(dr)
    End Sub

    Private Sub LoadRemarkData(ByVal ItemNo As String)
        Dim dr As DataRow()
        Dim filter As String = ""
        filter = "ItemNo=" + Util.LimitTheString(ItemNo)
        dr = Me.RemarkTable.Select(filter)
        If dr IsNot Nothing AndAlso dr.Length > 0 Then
            Me.txtItemNo.Value = ItemNo
            Me.txtRemark.Text = dr(0).Item("Remark").ToString
            Me.chkLoadToPNR.Checked = Util.DBNullToFalse(dr(0).Item("LoadToPNR"))
        End If
    End Sub

    Private Sub LoadRemarkDataFromDB()
        Dim oDataTable As DataTable
        Dim oRow As DataRow
        Dim dr As DataRow
        oDataTable = Me.BLL.GetCannedRemark(Me.CurrentClientID)
        If oDataTable IsNot Nothing Then
            For i As Integer = 0 To oDataTable.Rows.Count - 1
                oRow = oDataTable.Rows(i)
                dr = Me.RemarkTable.NewRow()
                If Me.RemarkTable.Rows.Count > 0 Then
                    dr("ItemNo") = Util.DBNullToZero(Me.RemarkTable.Rows(Me.RemarkTable.Rows.Count - 1).Item("ItemNo") + 1)
                Else
                    dr("ItemNo") = 1
                End If
                dr("Remark") = oRow("CannedRemark").ToString
                dr("LoadToPNR") = Util.DBNullToFalse(oRow("LoadToPNR"))
                Me.RemarkTable.Rows.Add(dr)
            Next
            Call Me.RefreshRemarkGrid()
            Me.chkApplyStd.Checked = Me.BLL.GetStandardRemark(Me.CurrentClientID)
        Else
            Me.chkApplyStd.Checked = True
        End If
    End Sub

    Private Sub RemoveRemarkData(ByVal ItemNo As String)
        Dim dr As DataRow()
        Dim filter As String = ""
        filter = "ItemNo=" + Util.LimitTheString(ItemNo)
        dr = Me.RemarkTable.Select(filter)
        If dr IsNot Nothing AndAlso dr.Length > 0 Then
            Me.RemarkTable.Rows.Remove(dr(0))
        End If
    End Sub

    Private Sub UpdateRemarkData(ByVal ItemNo As String)
        Dim dr As DataRow()
        Dim filter As String = ""
        filter = "ItemNo=" + Util.LimitTheString(ItemNo)
        dr = Me.RemarkTable.Select(filter)
        If dr IsNot Nothing AndAlso dr.Length > 0 Then
            dr(0).Item("Remark") = Me.txtRemark.Text
            dr(0).Item("LoadToPNR") = Me.chkLoadToPNR.Checked
        End If
    End Sub

    Private Sub RefreshRemarkGrid()
        Dim dv As New DataView()
        With dv
            .Table = Me.RemarkTable
            .Sort = "ItemNo"
        End With
        With Me.gdData
            .DataSource = dv.ToTable()
            .DataBind()
        End With
        With Me.pgControl
            .GridID = Me.gdData.UniqueID
            .SetBindGrid()
        End With

        With dv
            .Table = Me.RemarkTable
            .Sort = "ItemNo"
        End With
        With Me.gdDataView
            .DataSource = dv.ToTable()
            .DataBind()
        End With
        With Me.pgControlView
            .GridID = Me.gdDataView.UniqueID
            .SetBindGrid()
        End With

    End Sub

    Public Sub gdData_Command(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.CommandEventArgs)
        Select Case e.CommandName
            Case "delete"
                Call Me.RemoveRemarkData(Util.DBNullToZero(e.CommandArgument))
            Case "edit"
                Call Me.LoadRemarkData(Util.DBNullToZero(e.CommandArgument))
                Me.btnSave.Text = "Update"
        End Select
        Call Me.RefreshRemarkGrid()
        Call Me.AccessControl("Canned Remarks")
    End Sub

    Protected Sub btnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSave.Click
        Dim ItemNo As String = ""
        ItemNo = Me.txtItemNo.Value
        If ItemNo = "" Then
            Call Me.AddRemarkData()
        Else
            Call Me.UpdateRemarkData(ItemNo)
        End If
        Call Me.RefreshRemarkGrid()
        Call Me.LoadNewData()
    End Sub

    Protected Sub btnCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        Call Me.LoadNewData()
    End Sub
#End Region

#Region "Data Binding"
    Private Sub LoadNewData()
        Me.btnSave.Text = "Add"
        '//
        Me.txtRemark.Text = ""
        Me.txtItemNo.Value = ""
    End Sub

    Private Sub LoadDataFromDB()
        Call Me.LoadRemarkDataFromDB()
    End Sub
#End Region

#Region "Data Transaction"
    Private Sub SaveData(ByVal IsNext As Boolean)
        Dim info As New DataInfo.CompanyCannedRemarkInfo()
        Dim canned As DataInfo.PNRCannedRemarkInfo
        With info
            .ClientID = Me.CurrentClientID
            .ApplyStd = Me.chkApplyStd.Checked
            '// Remark
            For i As Integer = 0 To Me.RemarkTable.Rows.Count - 1
                canned = New DataInfo.PNRCannedRemarkInfo()
                canned.Remark = Me.RemarkTable.Rows(i).Item("Remark").ToString
                canned.LoadToPNR = Util.DBNullToFalse(Me.RemarkTable.Rows(i).Item("LoadToPNR"))
                .Remarks.Add(canned)
            Next
        End With
        If Me.BLL.UpdateCannedRemark(info) > 0 Then
            Me.lblMsgBox.Text = Util.GetAppConfig(Util.MsgType.TRANS_SUCCESS.ToString)
            Me.lblMsgBox.ForeColor = Drawing.Color.Green
            Me.ajaxMsgBox.Show()
            If IsNext Then
                Response.Redirect("ClientPCCConfig.aspx")
            End If
        Else
            Me.lblMsgBox.Text = Util.GetAppConfig(Util.MsgType.TRANS_ERROR.ToString)
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.ajaxMsgBox.Show()
        End If
    End Sub
#End Region

#Region "Page Control Event Handlers"
    Private Sub ToggleStdRemarkGrid()
        Me.StdCannedRemark = Not Me.StdCannedRemark
        Me.UcStdCannedRemark1.Visible = Me.StdCannedRemark
        If Me.StdCannedRemark Then
            Me.btnToggleStd.Text = "Hide Standard"
        Else
            Me.btnToggleStd.Text = "View Standard"
        End If
    End Sub

    Private Sub ToggleStdRemarkMode()
        If Me.chkApplyStd.Checked Then
            Me.btnToggleStd.Visible = True
        Else
            Me.btnToggleStd.Visible = False
            Me.StdCannedRemark = False
        End If
        Call Me.ToggleStdRemarkGrid()
    End Sub

    Protected Sub btnTrans_OnCancel(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans.OnCancel
        Response.Redirect(Util.GetAppConfig("RootPath") + "/Default.aspx")
    End Sub

    Protected Sub btnTrans_OnSave(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans.OnSave
        Call Me.SaveData(False)
    End Sub

    Private Sub btnTrans_OnSaveNext(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans.OnSaveNext
        Call Me.SaveData(True)
    End Sub

    Protected Sub btnToggleStd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnToggleStd.Click
        Call Me.ToggleStdRemarkGrid()
        Call Me.AccessControl("Canned Remarks")
    End Sub

    Protected Sub chkApplyStd_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkApplyStd.CheckedChanged
        Call Me.ToggleStdRemarkMode()
    End Sub
#End Region

End Class
@


1.1.1.1
log
@no message
@
text
@@
