head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.07.01;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.07.01;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@
Partial Class Web_CWT_CannedRemarkManager
    Inherits BasePage

#Region "Page Properties & Variables"
    Private BLL As BusinessLogicLayer.CannedRemarkBLL
    Private BLL2 As BusinessLogicLayer.StaffBLL
    Private BLL3 As BusinessLogicLayer.tblFunctionBLL

    Private Property RemarkTable() As DataTable
        Get
            Return Me.ViewState("_RemarkTable")
        End Get
        Set(ByVal value As DataTable)
            Me.ViewState("_RemarkTable") = value
        End Set
    End Property

    Private Property ClassTable() As DataTable
        Get
            Return Me.ViewState("_ClassTable")
        End Get
        Set(ByVal value As DataTable)
            Me.ViewState("_ClassTable") = value
        End Set
    End Property
#End Region

#Region "Page Event Handlers & Methods"
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.BLL = New BusinessLogicLayer.CannedRemarkBLL()
        Me.BLL2 = New BusinessLogicLayer.StaffBLL()
        Me.BLL3 = New BusinessLogicLayer.tblFunctionBLL()
        If Not IsPostBack Then
            Call Me.CreateTable()
            Call Me.LoadDataFromDB()
            Call Me.LoadNewData()
        End If

        Call Me.AccessControl("Canned Remark")
    End Sub

    Private Sub AccessControl(ByVal title As String)

        Dim userName As String
        Dim oDatatable As DataTable
        Dim oDataTable2 As DataTable

        Static roleID As String

        userName = ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName
        oDatatable = Me.BLL2.GetUserByID(userName)

        If oDatatable.Rows.Count > 0 Then
            roleID = oDatatable.Rows(0).Item("RoleID").ToString
        End If

        oDataTable2 = Me.BLL3.GetUserRole(roleID)
        If oDataTable2.Rows.Count > 0 Then
            For k As Integer = 0 To oDataTable2.Rows.Count - 1
                If oDataTable2.Rows(k).Item("functionGroup") = "0" Then
                    If oDataTable2.Rows(k).Item("Permission") = "V" Then
                        If oDataTable2.Rows(k).Item("functionName").ToString = title Then
                            Call Me.toggleControl()

                        End If
                    End If
                End If

            Next

        End If


    End Sub

    Private Sub toggleControl()
        'Dim btnDelete As CWTCustomControls.CWTLinkButton

        Me.btnSave.Enabled = False
        Me.btnTrans.SaveButton.Enabled = False
        Me.txtRemark.Readonly = True
        Me.gdData.Visible = False
        Me.tblPg.Visible = False
        Me.gdDataView.Visible = True
        Me.tblPg2.Visible = True

        'For i As Integer = 0 To Me.gdData.Rows.Count - 1
        '    btnDelete = Me.gdData.Rows(i).FindControl("hrefDeleteItem")
        '    btnDelete.Enabled = False

        'Next
    End Sub

    Private Sub CreateTable()
        Call Me.CreateRemarkTable()
    End Sub
#End Region

#Region "Remark Sub Routines"
    Private Sub CreateRemarkTable()
        Me.RemarkTable = New DataTable("RemarkTable")
        With Me.RemarkTable
            .Columns.Add(New DataColumn("ItemNo", GetType(Integer)))
            .Columns.Add(New DataColumn("Remark"))
        End With
    End Sub

    Private Sub AddRemarkData()
        Dim dr As DataRow
        'Dim str As String()
        'Dim str2 As String()
        dr = Me.RemarkTable.NewRow()
        If Me.RemarkTable.Rows.Count > 0 Then
            dr("ItemNo") = Util.DBNullToZero(Me.RemarkTable.Rows(Me.RemarkTable.Rows.Count - 1).Item("ItemNo") + 1)
        Else
            dr("ItemNo") = 1
        End If
        'str = Util.DBNullToText(Me.txtRemark.Text).Split("<"c)
        'If str.Length > 1 Then
        '    Me.lblMsgBox.Text = "Not allow to input symbol '<' '>' !"
        '    Me.lblMsgBox.ForeColor = Drawing.Color.Red
        '    Me.ajaxMsgBox.Show()
        '    Exit Sub
        'End If
        'str2 = Util.DBNullToText(Me.txtRemark.Text).Split(">"c)
        'If str2.Length > 1 Then
        '    Me.lblMsgBox.Text = "Not allow to input symbol '<' '>' !"
        '    Me.lblMsgBox.ForeColor = Drawing.Color.Red
        '    Me.ajaxMsgBox.Show()
        '    Exit Sub
        'End If


        dr("Remark") = Me.txtRemark.Text
        Me.RemarkTable.Rows.Add(dr)
    End Sub

    Private Sub LoadRemarkData(ByVal ItemNo As String)
        Dim dr As DataRow()
        Dim filter As String = ""
        filter = "ItemNo=" + Util.LimitTheString(ItemNo)
        dr = Me.RemarkTable.Select(filter)
        If dr IsNot Nothing AndAlso dr.Length > 0 Then
            Me.txtItemNo.Value = ItemNo
            Me.txtRemark.Text = dr(0).Item("Remark").ToString
        End If
    End Sub

    Private Sub LoadRemarkDataFromDB()
        Dim oDataTable As DataTable
        Dim oRow As DataRow
        Dim dr As DataRow
        oDataTable = Me.BLL.GetCannedRemark()
        If oDataTable IsNot Nothing Then
            For i As Integer = 0 To oDataTable.Rows.Count - 1
                oRow = oDataTable.Rows(i)
                dr = Me.RemarkTable.NewRow()
                If Me.RemarkTable.Rows.Count > 0 Then
                    dr("ItemNo") = Util.DBNullToZero(Me.RemarkTable.Rows(Me.RemarkTable.Rows.Count - 1).Item("ItemNo") + 1)
                Else
                    dr("ItemNo") = 1
                End If
                dr("Remark") = oRow("CannedRmk").ToString
                Me.RemarkTable.Rows.Add(dr)
            Next
            Call Me.RefreshRemarkGrid()
        End If
    End Sub

    Private Sub RemoveRemarkData(ByVal ItemNo As String)
        Dim dr As DataRow()
        Dim filter As String = ""
        filter = "ItemNo=" + Util.LimitTheString(ItemNo)
        dr = Me.RemarkTable.Select(filter)
        If dr IsNot Nothing AndAlso dr.Length > 0 Then
            Me.RemarkTable.Rows.Remove(dr(0))
        End If
    End Sub

    Private Sub UpdateRemarkData(ByVal ItemNo As String)
        Dim dr As DataRow()
        Dim filter As String = ""
        filter = "ItemNo=" + Util.LimitTheString(ItemNo)
        dr = Me.RemarkTable.Select(filter)
        If dr IsNot Nothing AndAlso dr.Length > 0 Then
            dr(0).Item("Remark") = Me.txtRemark.Text
        End If
    End Sub

    Private Sub RefreshRemarkGrid()
        Dim dv As New DataView()
        With dv
            .Table = Me.RemarkTable
            .Sort = "ItemNo"
        End With
        With Me.gdData
            .DataSource = dv.ToTable()
            .DataBind()
        End With
        With Me.pgControl
            .GridID = Me.gdData.UniqueID
            .SetBindGrid()
        End With

        With dv
            .Table = Me.RemarkTable
            .Sort = "ItemNo"
        End With
        With Me.gdDataView
            .DataSource = dv.ToTable()
            .DataBind()
        End With
        With Me.pgControl2
            .GridID = Me.gdDataView.UniqueID
            .SetBindGrid()
        End With
    End Sub

    Public Sub gdData_Command(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.CommandEventArgs)
        Select Case e.CommandName
            Case "delete"
                Call Me.RemoveRemarkData(Util.DBNullToZero(e.CommandArgument))
            Case "edit"
                Call Me.LoadRemarkData(Util.DBNullToZero(e.CommandArgument))
                Me.btnSave.Text = "Update"
        End Select
        Call Me.RefreshRemarkGrid()
        Call Me.AccessControl("Canned Remark")
    End Sub

    Protected Sub btnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSave.Click
        Dim ItemNo As String = ""
        ItemNo = Me.txtItemNo.Value
        If ItemNo = "" Then
            Call Me.AddRemarkData()
        Else
            Call Me.UpdateRemarkData(ItemNo)
        End If
        Call Me.RefreshRemarkGrid()
        Call Me.LoadNewData()
    End Sub

    Protected Sub btnCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        Call Me.LoadNewData()
    End Sub
#End Region

#Region "Data Binding"
    Private Sub LoadNewData()
        Me.btnSave.Text = "Add"
        '//
        Me.txtRemark.Text = ""
        Me.txtItemNo.Value = ""
    End Sub

    Private Sub LoadDataFromDB()
        Call Me.LoadRemarkDataFromDB()
    End Sub
#End Region

#Region "Data Transaction"
    Private Sub SaveData()
        Dim info As New DataInfo.CannedRemarkInfo()
        With info
            '// Remark
            For i As Integer = 0 To Me.RemarkTable.Rows.Count - 1
                .Remarks.Add(Me.RemarkTable.Rows(i).Item("Remark").ToString)
            Next
        End With
        If Me.BLL.UpdateCannedRemark(info) > 0 Then
            Me.lblMsgBox.Text = Util.GetAppConfig(Util.MsgType.TRANS_SUCCESS.ToString)
            Me.lblMsgBox.ForeColor = Drawing.Color.Green
            Me.ajaxMsgBox.Show()
        Else
            Me.lblMsgBox.Text = Util.GetAppConfig(Util.MsgType.TRANS_ERROR.ToString)
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.ajaxMsgBox.Show()
        End If
    End Sub
#End Region

#Region "Page Control Event Handlers"
    Protected Sub btnTrans_OnCancel(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans.OnCancel
        Response.Redirect(Util.GetAppConfig("RootPath") + "/Default.aspx")
    End Sub

    Protected Sub btnTrans_OnSave(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans.OnSave
        Call Me.SaveData()
    End Sub
#End Region

End Class
@


1.1.1.1
log
@no message
@
text
@@
