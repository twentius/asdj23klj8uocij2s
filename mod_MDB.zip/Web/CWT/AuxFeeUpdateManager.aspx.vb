head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.07.00;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.07.00;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@
Partial Class Web_CWT_AuxFeeUpdateManager
    Inherits BasePage

    Private BLL As BusinessLogicLayer.AuxPricingBLL

    Public Property RecordID() As String
        Get
            Dim retVal As String = ""
            If Me.ViewState("_RecordID") IsNot Nothing Then
                retVal = Me.ViewState("_RecordID").ToString()
            End If
            Return retVal
        End Get
        Set(ByVal value As String)
            Me.ViewState("_RecordID") = value
        End Set
    End Property

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.BLL = New BusinessLogicLayer.AuxPricingBLL()
        If Not IsPostBack Then
            If Me.Request("mode") Is Nothing Then
                Response.Redirect(Util.GetAppConfig("RootPath") + "/AuxFeeManager.aspx", True)
            End If
            Select Case Me.Request("mode").ToString()
                Case "add"
                    Me.CurrentPageMode = CWTMasterDB.TransactionMode.AddNewMode
                    Me.lblProduct.Visible = False
                    Me.ddlProduct.Visible = True
                Case "edit"
                    Me.CurrentPageMode = CWTMasterDB.TransactionMode.UpdateMode
                    Me.lblProduct.Visible = True
                    Me.ddlProduct.Visible = False
                    Me.RecordID = Me.Request("id").ToString()
                    Call Me.LoadData()
            End Select
            Call Me.LoadDropDownList()
        End If
    End Sub

    Private Sub LoadDropDownList()
        Dim oDataTable As DataTable
        oDataTable = Me.BLL.GetProductList()
        If Me.CurrentPageMode = CWTMasterDB.TransactionMode.AddNewMode Then
            With Me.ddlProduct
                .DataTextField = "Name"
                .DataValueField = "Number"
                .DataSource = oDataTable
                .DataBind()
            End With
            Me.CompareValidator1.Visible = True
            Me.CompareValidator2.Visible = False
        Else
            Me.CompareValidator1.Visible = False
            Me.CompareValidator2.Visible = True
        End If
        With Me.ddlFeeProduct
            .DataTextField = "Name"
            .DataValueField = "Number"
            .DataSource = oDataTable
            .DataBind()
        End With
    End Sub

    Private Sub LoadData()
        Dim oDataTable As DataTable
        Dim r As DataRow
        oDataTable = Me.BLL.GetAuxPricingByID(Me.RecordID)
        If oDataTable IsNot Nothing AndAlso oDataTable.Rows.Count > 0 Then
            r = oDataTable.Rows(0)
            Me.hidProductID.Text = r("ApplytoProduct").ToString
            Me.lblProduct.Text = r("ApplytoProductName").ToString
            Me.txtFeeName.Text = r("FeeName").ToString
            Me.txtFeeAmount.Text = r("FeeAmount").ToString
            If Not IsDBNull(r("FeeProduct")) Then
                Me.ddlFeeProduct.SelectedValue = r("FeeProduct").ToString
            End If
        End If
    End Sub

    Public Function ValidateForm() As Boolean
        Dim retVal As Boolean = True
        Dim ProductID As String
        If Me.CurrentPageMode = CWTMasterDB.TransactionMode.AddNewMode Then
            ProductID = Me.ddlProduct.SelectedValue
        Else
            ProductID = Me.hidProductID.Text
        End If
        If Me.BLL.IsExistName(Me.txtFeeName.Text, ProductID) Then
            retVal = False
        End If
        Return retVal
    End Function

    Private Sub SaveData()
        Dim Info As New DataInfo.AuxFeeInfo()
        If Not Me.ValidateForm Then
            Me.lblMsgBox.Text = "Name already exists in database."
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.ajaxMsgBox.Show()
            Exit Sub
        End If
        With Info
            .ID = Me.RecordID
            .PageMode = Me.CurrentPageMode
            If .PageMode = CWTMasterDB.TransactionMode.AddNewMode Then
                .ApplyProduct = Me.ddlProduct.SelectedValue
            End If
            .Name = Me.txtFeeName.Text
            .FeeAmount = Me.txtFeeAmount.Text
            .FeeProduct = Me.ddlFeeProduct.SelectedValue
        End With
        If Me.BLL.UpdateAuxPrice(Info) > 0 Then
            Me.lblMsgBox.Text = Util.GetAppConfig(Util.MsgType.TRANS_SUCCESS.ToString)
            Me.lblMsgBox.ForeColor = Drawing.Color.Green
            Me.ajaxMsgBox.Show()
        Else
            Me.lblMsgBox.Text = Util.GetAppConfig(Util.MsgType.TRANS_ERROR.ToString)
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.ajaxMsgBox.Show()
        End If
    End Sub

    Protected Sub btnTrans_OnCancel(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans.OnCancel
        Response.Redirect("AuxFeeManager.aspx")
    End Sub

    Protected Sub btnTrans_OnSave(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans.OnSave
        Call Me.SaveData()
    End Sub

End Class
@


1.1.1.1
log
@no message
@
text
@@
