head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.59;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.59;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports System.Collections.Generic

Partial Class Web_CWT_AirFeeByPNR
    Inherits BasePage

#Region "Page Properties & Variables"
    Private BLL As BusinessLogicLayer.AirFeeBLL
    Private BLL2 As BusinessLogicLayer.StaffBLL
    Private BLL3 As BusinessLogicLayer.tblFunctionBLL

    Public ReadOnly Property RegionString() As String
        Get
            Dim retVal As String = ""
            retVal = Me.CurrentPNRInfo.RegionString
            Return retVal
        End Get
    End Property
    Public ReadOnly Property CountryString() As String
        Get
            Dim retVal As String = ""
            retVal = Me.CurrentPNRInfo.CountryString
            Return retVal
        End Get
    End Property
    Public ReadOnly Property CityString() As String
        Get
            Dim retVal As String = ""
            retVal = Me.CurrentPNRInfo.CityString
            Return retVal
        End Get
    End Property
    Public Property PagePNR() As DataInfo.TransPNRInfo
        Get
            Return Me.ViewState("PagePNR")
        End Get
        Set(ByVal value As DataInfo.TransPNRInfo)
            Me.ViewState("PagePNR") = value
        End Set
    End Property
    Public Property CurrentPNRInfo() As DataInfo.PNRItemInfo
        Get
            Return Me.ViewState("CurrentPNRInfo")
        End Get
        Set(ByVal value As DataInfo.PNRItemInfo)
            Me.ViewState("CurrentPNRInfo") = value
        End Set
    End Property

    Private Property ClassTable() As DataTable
        Get
            Return Me.ViewState("_ClassTable")
        End Get
        Set(ByVal value As DataTable)
            Me.ViewState("_ClassTable") = value
        End Set
    End Property

    Public Property RecordID() As String
        Get
            Dim retVal As String = ""
            If Me.ViewState("_RecordID") IsNot Nothing Then
                retVal = Me.ViewState("_RecordID").ToString
            End If
            Return retVal
        End Get
        Set(ByVal value As String)
            Me.ViewState("_RecordID") = value
        End Set
    End Property

    Public ReadOnly Property RequestID() As String
        Get
            Dim retVal As String = ""
            If Me.Request("id") IsNot Nothing Then
                retVal = Me.Request("id")
            End If
            Return retVal
        End Get
    End Property

    Public ReadOnly Property RequestMode() As String
        Get
            Dim retVal As String = ""
            If Me.Request("mode") IsNot Nothing Then
                retVal = Me.Request("mode")
            End If
            Return retVal
        End Get
    End Property
#End Region

#Region "Page Event Handlers & Methods"
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.BLL = New BusinessLogicLayer.AirFeeBLL()
        Me.BLL2 = New BusinessLogicLayer.StaffBLL()
        Me.BLL3 = New BusinessLogicLayer.tblFunctionBLL()
        If Not IsPostBack Then
            Me.PagePNR() = New DataInfo.TransPNRInfo()
            Call Me.CreateTable()
            Select Case Me.RequestMode.ToLower()
                Case "add"
                    Me.CurrentPageMode = CWTMasterDB.TransactionMode.AddNewMode
                    Call Me.LoadNewData()
                Case "edit"
                    Me.CurrentPageMode = CWTMasterDB.TransactionMode.UpdateMode
                    Me.RecordID = Me.RequestID
                    Call Me.LoadDataFromDB()
                    Call Me.LoadNewData()
            End Select
            Call Me.SetMode()
            Call Me.RefreshList()
            Call Me.AccessControl("Fee")
        End If
    End Sub

    Private Sub AccessControl(ByVal title As String)

        Dim userName As String
        Dim oDatatable As DataTable
        Dim oDataTable2 As DataTable

        Static roleID As String

        userName = ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName
        oDatatable = Me.BLL2.GetUserByID(userName)

        If oDatatable.Rows.Count > 0 Then
            roleID = oDatatable.Rows(0).Item("RoleID").ToString
        End If

        oDataTable2 = Me.BLL3.GetUserRole(roleID)
        If oDataTable2.Rows.Count > 0 Then
            For k As Integer = 0 To oDataTable2.Rows.Count - 1
                If oDataTable2.Rows(k).Item("functionGroup") = "0" Then
                    If oDataTable2.Rows(k).Item("Permission") = "V" Then
                        If oDataTable2.Rows(k).Item("functionName").ToString = title Then
                            Call Me.toggleControl()

                        End If
                    End If
                End If

            Next

        End If


    End Sub

    Private Sub toggleControl()
        'Dim btnDelete As CWTCustomControls.CWTLinkButton
        Me.btnAdd.Enabled = False
        Me.btnTrans.SaveButton.Enabled = False
        Me.ddlApplyBy.Enabled = False
        Me.ddlCountry.Enabled = False
        Me.ddlRegion.Enabled = False
        Me.ddlSelectedCountry.Enabled = False
        Me.ddlItem.Enabled = False
        Me.ddlSelectedItem.Enabled = False
        Me.ddlSelectedRegion.Enabled = False
        Me.txtEndAmount.Readonly = True
        Me.txtFeeAmt.Readonly = True
        Me.txtName.Readonly = True
        Me.txtStartAmount.Readonly = True
        Me.btnRemoveAll.Enabled = False
        Me.btnSelAll.Enabled = False
        Me.btnRemove.Enabled = False
        Me.btnSave.Enabled = False

        Me.gdDataClass.Visible = False
        Me.tblPg.Visible = False
        Me.gdDataView.Visible = True
        Me.tblPg2.Visible = True
        'For i As Integer = 0 To Me.gdDataClass.Rows.Count - 1
        '    btnDelete = Me.gdDataClass.Rows(i).FindControl("hrefDeleteItem")
        '    btnDelete.Enabled = False

        'Next


    End Sub


    Private Sub CreateTable()
        Call Me.CreateClassTable()
    End Sub
#End Region

#Region "Class sub routine"
    Private Sub CreateClassTable()
        Me.ClassTable = New DataTable("ClassTable")
        With Me.ClassTable
            .Columns.Add(New DataColumn("ItemNo", GetType(Integer)))
            .Columns.Add(New DataColumn("StartAmount"))
            .Columns.Add(New DataColumn("EndAmount"))
            .Columns.Add(New DataColumn("ApplyAll"))
            .Columns.Add(New DataColumn("TerritoryCode"))
            .Columns.Add(New DataColumn("TerritoryType"))
            .Columns.Add(New DataColumn("FeeAmt"))
        End With
    End Sub

    Private Sub AddClassData()
        Dim dr As DataRow
        dr = Me.ClassTable.NewRow()
        If Me.ClassTable.Rows.Count > 0 Then
            dr("ItemNo") = Util.DBNullToZero(Me.ClassTable.Rows(Me.ClassTable.Rows.Count - 1).Item("ItemNo") + 1)
        Else
            dr("ItemNo") = 1
        End If
        dr("StartAmount") = Me.txtStartAmount.Text
        dr("EndAmount") = Me.txtEndAmount.Text
        dr("FeeAmt") = Me.txtFeeAmt.Text
        'dr("ApplyAll") = Me.chkApplyAll.Checked
        dr("TerritoryType") = Me.CurrentPNRInfo.ApplyMode
        Select Case Me.CurrentPNRInfo.ApplyMode
            Case DataInfo.PNRItemInfo.ApplyByItem.Region
                dr("TerritoryCode") = Me.CurrentPNRInfo.RegionString
            Case DataInfo.PNRItemInfo.ApplyByItem.Country
                dr("TerritoryCode") = Me.CurrentPNRInfo.CountryString
            Case DataInfo.PNRItemInfo.ApplyByItem.City
                dr("TerritoryCode") = Me.CurrentPNRInfo.CityString
        End Select
        '//
        With Me.CurrentPNRInfo
            .FareFrom = Me.txtStartAmount.Text
            .FareTo = Me.txtEndAmount.Text
            .FareAmt = Me.txtFeeAmt.Text
            '.IsApplyAll = Me.chkApplyAll.Checked
        End With
        Me.ClassTable.Rows.Add(dr)

        Me.PagePNR.PNRList.Add(Me.CurrentPNRInfo.DeepClone())
    End Sub

    Private Sub LoadClassData(ByVal ItemNo As String)
        On Error Resume Next
        Dim dr As DataRow()
        Dim filter As String = ""
        Dim Index As Integer = 0
        filter = "ItemNo=" + Util.LimitTheString(ItemNo)
        dr = Me.ClassTable.Select(filter)
        If dr IsNot Nothing AndAlso dr.Length > 0 Then
            Index = Util.DBNullToZero(ItemNo) - 1
            Me.txtItemNo.Value = ItemNo
            Me.txtStartAmount.Text = dr(0).Item("StartAmount").ToString
            Me.txtEndAmount.Text = dr(0).Item("EndAmount").ToString
            Me.txtFeeAmt.Text = dr(0).Item("FeeAmt").ToString
            Me.CurrentPNRInfo = Me.PagePNR.PNRList(Index).DeepClone()
            Me.ddlApplyBy.SelectedValue = Me.CurrentPNRInfo.ApplyMode
            ' Me.chkApplyAll.Checked = Me.CurrentPNRInfo.IsApplyAll
            Call Me.SetMode()
            Call Me.RefreshList()
        End If
    End Sub

    Private Sub LoadClassDataFromDB()
        Dim oDataTable As DataTable
        Dim oRow As DataRow
        Dim dr As DataRow
        Dim str As String()
        Dim pnr As DataInfo.PNRItemInfo
        Dim region As DataInfo.RegionDataInfo
        Dim country As DataInfo.CountryDataInfo
        Dim city As DataInfo.CityDataInfo
        Dim ConBLL As New BusinessLogicLayer.ConfigurationBLL()
        Dim dt As DataTable
        Dim dt2 As DataTable
        Dim countryCode As String
        Dim cityCode As String
        Try
            oDataTable = Me.BLL.GetFeeByPNRData(Me.RecordID)

            If oDataTable IsNot Nothing Then
                For i As Integer = 0 To oDataTable.Rows.Count - 1
                    oRow = oDataTable.Rows(i)
                    pnr = New DataInfo.PNRItemInfo()
                    dr = Me.ClassTable.NewRow()
                    If Me.ClassTable.Rows.Count > 0 Then
                        dr("ItemNo") = Util.DBNullToZero(Me.ClassTable.Rows(Me.ClassTable.Rows.Count - 1).Item("ItemNo") + 1)
                    Else
                        dr("ItemNo") = 1
                    End If
                    dr("StartAmount") = Util.DBNullToZero(oRow("StartAmount"))
                    dr("EndAmount") = Util.DBNullToZero(oRow("EndAmount"))
                    dr("FeeAmt") = Util.DBNullToZero(oRow("TFAmount"))
                    dr("ApplyAll") = Util.DBNullToFalse(oRow("ApplyAll"))
                    dr("TerritoryType") = Util.DBNullToZero(oRow("TerritoryType"))
                    dr("TerritoryCode") = oRow("TerritoryCode").ToString
                    '//
                    pnr.FareFrom = Util.DBNullToZero(oRow("StartAmount"))
                    pnr.FareTo = Util.DBNullToZero(oRow("EndAmount"))
                    pnr.FareAmt = Util.DBNullToZero(oRow("TFAmount"))
                    pnr.ApplyMode = Util.DBNullToZero(oRow("TerritoryType"))
                    'pnr.IsApplyAll = Util.DBNullToFalse(oRow("ApplyAll"))
                    str = Util.DBNullToText(oRow("TerritoryCode")).Split(";"c)
                    For j As Integer = 0 To str.Length - 1
                        If str(j) = "" Then
                            Continue For
                        End If
                        Select Case pnr.ApplyMode
                            Case DataInfo.PNRItemInfo.ApplyByItem.Region
                                If str(j) = "X" Then
                                    dt = ConBLL.GetRegionByID2()

                                    For s As Integer = 0 To dt.Rows.Count - 1
                                        region = New DataInfo.RegionDataInfo()
                                        region.RegionCode = dt.Rows(s).Item("RegionCode").ToString
                                        region.RegionName = dt.Rows(s).Item("Description").ToString
                                        pnr.RegionSelectedItems.Add(region)
                                    Next
                                    pnr.RegionSelect = "All"
                                Else
                                    dt = ConBLL.GetRegionByID(str(j))
                                    region = New DataInfo.RegionDataInfo()
                                    region.RegionCode = str(j)
                                    region.RegionName = dt.Rows(0).Item("RegionName").ToString
                                    pnr.RegionSelectedItems.Add(region)
                                    pnr.RegionSelect = "Single"
                                End If

                               
                            Case DataInfo.PNRItemInfo.ApplyByItem.Country
                                If str.Length = 1 Then
                                    dt = ConBLL.GetCountryByRegion(str(j), "")
                                    For f As Integer = 0 To dt.Rows.Count - 1
                                        countryCode = dt.Rows(f).Item("CountryCode")
                                        dt2 = ConBLL.GetCountryByID(countryCode)
                                        country = New DataInfo.CountryDataInfo()
                                        country.LinkRegion.RegionCode = dt2.Rows(0).Item("RegionCode").ToString
                                        country.LinkRegion.RegionName = dt2.Rows(0).Item("RegionName").ToString
                                        country.CountryCode = countryCode
                                        country.CountryName = dt2.Rows(0).Item("CountryName").ToString
                                        pnr.CountrySelectedItems.Add(country)
                                    Next
                                    pnr.CountrySelect = "All"

                                Else
                                    dt = ConBLL.GetCountryByID(str(j))
                                    country = New DataInfo.CountryDataInfo()
                                    country.LinkRegion.RegionCode = dt.Rows(0).Item("RegionCode").ToString
                                    country.LinkRegion.RegionName = dt.Rows(0).Item("RegionName").ToString
                                    country.CountryCode = str(j)
                                    country.CountryName = dt.Rows(0).Item("CountryName").ToString
                                    pnr.CountrySelectedItems.Add(country)
                                    pnr.CountrySelect = "Single"
                                End If
                                'dt = ConBLL.GetCountryByID(str(j))
                                'country = New DataInfo.CountryDataInfo()
                                'country.LinkRegion.RegionCode = dt.Rows(0).Item("RegionCode").ToString
                                'country.LinkRegion.RegionName = dt.Rows(0).Item("RegionName").ToString
                                'country.CountryCode = str(j)
                                'country.CountryName = dt.Rows(0).Item("CountryName").ToString
                                'pnr.CountrySelectedItems.Add(country)
                            Case DataInfo.PNRItemInfo.ApplyByItem.City

                                If str.Length = 1 Then
                                    dt = ConBLL.GetCity(str(j), "")
                                    For h As Integer = 0 To dt.Rows.Count - 1
                                        cityCode = dt.Rows(h).Item("CityCode")
                                        dt2 = ConBLL.GetCityByID(cityCode)
                                        city = New DataInfo.CityDataInfo()
                                        city.LinkCountry.LinkRegion.RegionCode = dt2.Rows(0).Item("RegionCode").ToString
                                        city.LinkCountry.LinkRegion.RegionName = dt2.Rows(0).Item("RegionName").ToString
                                        city.LinkCountry.CountryCode = dt2.Rows(0).Item("CountryCode").ToString
                                        city.LinkCountry.CountryName = dt2.Rows(0).Item("CountryName").ToString
                                        city.CityCode = cityCode
                                        city.CityName = dt2.Rows(0).Item("City").ToString
                                        pnr.CitySelectedItems.Add(city)
                                    Next
                                    pnr.CitySelect = "All"
                                Else
                                    dt = ConBLL.GetCityByID(str(j))
                                    city = New DataInfo.CityDataInfo()
                                    city.LinkCountry.LinkRegion.RegionCode = dt.Rows(0).Item("RegionCode").ToString
                                    city.LinkCountry.LinkRegion.RegionName = dt.Rows(0).Item("RegionName").ToString
                                    city.LinkCountry.CountryCode = dt.Rows(0).Item("CountryCode").ToString
                                    city.LinkCountry.CountryName = dt.Rows(0).Item("CountryName").ToString
                                    city.CityCode = str(j)
                                    city.CityName = dt.Rows(0).Item("City").ToString
                                    pnr.CitySelectedItems.Add(city)
                                    pnr.CitySelect = "Single"
                                End If
                                'dt = ConBLL.GetCityByID(str(j))
                                'city = New DataInfo.CityDataInfo()
                                'city.LinkCountry.LinkRegion.RegionCode = dt.Rows(0).Item("RegionCode").ToString
                                'city.LinkCountry.LinkRegion.RegionName = dt.Rows(0).Item("RegionName").ToString
                                'city.LinkCountry.CountryCode = dt.Rows(0).Item("CountryCode").ToString
                                'city.LinkCountry.CountryName = dt.Rows(0).Item("CountryName").ToString
                                'city.CityCode = str(j)
                                'city.CityName = dt.Rows(0).Item("City").ToString
                                'pnr.CitySelectedItems.Add(city)
                        End Select
                    Next
                    Me.PagePNR.PNRList.Add(pnr)
                    Me.ClassTable.Rows.Add(dr)
                Next
                Call Me.RefreshClassGrid()
            End If
        Catch ex As Exception
            System.Diagnostics.Debug.Print(ex.ToString)
        End Try
    End Sub

    Private Sub RemoveClassData(ByVal ItemNo As String)
        Dim dr As DataRow()
        Dim filter As String = ""
        filter = "ItemNo=" + Util.LimitTheString(ItemNo)
        dr = Me.ClassTable.Select(filter)
        If dr IsNot Nothing AndAlso dr.Length > 0 Then
            Me.ClassTable.Rows.Remove(dr(0))
            'Me.PagePNR.PNRList(Util.DBNullToZero(ItemNo) - 1) = Nothing
            Me.PagePNR.PNRList.RemoveAt(Util.DBNullToZero(ItemNo) - 1)

        End If
    End Sub

    Private Sub UpdateClassData(ByVal ItemNo As String)
        Dim dr As DataRow()
        Dim filter As String = ""
        Dim Index As Integer = 0
        filter = "ItemNo=" + Util.LimitTheString(ItemNo)
        dr = Me.ClassTable.Select(filter)
        If dr IsNot Nothing AndAlso dr.Length > 0 Then
            Index = Util.DBNullToZero(ItemNo) - 1
            dr(0).Item("StartAmount") = Me.txtStartAmount.Text
            dr(0).Item("EndAmount") = Me.txtEndAmount.Text
            dr(0).Item("FeeAmt") = Me.txtFeeAmt.Text
            'dr(0).Item("ApplyAll") = Me.chkApplyAll.Checked
            dr(0).Item("TerritoryType") = Me.CurrentPNRInfo.ApplyMode
            Select Case Me.CurrentPNRInfo.ApplyMode
                Case DataInfo.PNRItemInfo.ApplyByItem.Region
                    dr(0).Item("TerritoryCode") = Me.CurrentPNRInfo.RegionString
                Case DataInfo.PNRItemInfo.ApplyByItem.Country
                    dr(0).Item("TerritoryCode") = Me.CurrentPNRInfo.CountryString
                Case DataInfo.PNRItemInfo.ApplyByItem.City
                    dr(0).Item("TerritoryCode") = Me.CurrentPNRInfo.CityString
            End Select
            '//
            With Me.CurrentPNRInfo
                .FareFrom = Me.txtStartAmount.Text
                .FareTo = Me.txtEndAmount.Text
                .FareAmt = Me.txtFeeAmt.Text
                '.IsApplyAll = Me.chkApplyAll.Checked
            End With
            Me.PagePNR.PNRList(Index) = Me.CurrentPNRInfo.DeepClone()
        End If
    End Sub

    Private Sub RefreshClassGrid()
        Dim dv As New DataView()
        With dv
            .Table = Me.ClassTable
            .Sort = "ItemNo"
        End With
        With Me.gdDataClass
            .DataSource = dv.ToTable()
            .DataBind()
        End With
        With Me.pgControl
            .GridID = Me.gdDataClass.UniqueID
            .SetBindGrid()
        End With

        With dv
            .Table = Me.ClassTable
            .Sort = "ItemNo"
        End With
        With Me.gdDataView
            .DataSource = dv.ToTable()
            .DataBind()
        End With
        With Me.pgControl2
            .GridID = Me.gdDataView.UniqueID
            .SetBindGrid()
        End With
    End Sub

    Public Sub gdDataClass_Command(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.CommandEventArgs)
        Select Case e.CommandName
            Case "delete"
                Call Me.RemoveClassData(Util.DBNullToZero(e.CommandArgument))
            Case "edit"
                Call Me.LoadClassData(Util.DBNullToZero(e.CommandArgument))
                Me.btnSave.Text = "Update"
                'Me.CurrentPNRInfo = Me.PagePNR.PNRList(Me.txtItemNo.Value)
        End Select
        Call Me.RefreshClassGrid()
        Call Me.AccessControl("Fee")
    End Sub

    Protected Sub btnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSave.Click
        Dim ItemNo As String = ""
        ItemNo = Me.txtItemNo.Value
        If ItemNo = "" Then
            Call Me.AddClassData()
        Else
            Call Me.UpdateClassData(ItemNo)
        End If
        Call Me.RefreshClassGrid()
        Call Me.LoadNewData()
        Call Me.RefreshList(True)
    End Sub

    Protected Sub btnCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        Call Me.LoadNewData()
    End Sub
#End Region

#Region "Region Settings"
    Private Sub SetSelectedRegion()
        Dim RegionList As New List(Of String)
        Dim SelectedIndex() As Integer
        Dim itm As DataInfo.RegionDataInfo
        SelectedIndex = Me.ddlItem.GetSelectedIndices
        If SelectedIndex.Length <= 0 Then
            Me.divEmpty.Visible = True
            Exit Sub
        End If
        Me.CurrentPNRInfo.RegionSelect = "Single"
        For i As Integer = 0 To SelectedIndex.Length - 1
            itm = New DataInfo.RegionDataInfo()
            With itm
                .RegionCode = Me.ddlItem.Items(SelectedIndex(i)).Value
                .RegionName = Me.ddlItem.Items(SelectedIndex(i)).Text
            End With
            Me.CurrentPNRInfo.RegionSelectedItems.Add(itm)
        Next
        Me.divEmpty.Visible = False
    End Sub

    Private Sub SetAllRegion()
        Dim RegionList As New List(Of String)
        Dim itm As DataInfo.RegionDataInfo
        If Me.ddlItem.Items.Count <= 0 Then
            Me.divEmpty.Visible = True
            Exit Sub
        End If
        Me.CurrentPNRInfo.RegionSelect = "All"
        For i As Integer = 0 To Me.ddlItem.Items.Count - 1
            itm = New DataInfo.RegionDataInfo()
            With itm
                .RegionCode = Me.ddlItem.Items(i).Value
                .RegionName = Me.ddlItem.Items(i).Text
            End With
            Me.CurrentPNRInfo.RegionSelectedItems.Add(itm)
        Next
        Me.divEmpty.Visible = False
    End Sub

    Private Sub RemoveRegion()
        Dim ItemCode As String
        Dim index As Integer
        Dim filter As String = ""
        Dim SelectedIndex() As Integer
        SelectedIndex = Me.ddlSelectedItem.GetSelectedIndices
        If SelectedIndex.Length <= 0 Then
            Exit Sub
        End If
        For i As Integer = 0 To SelectedIndex.Length - 1
            ItemCode = Me.ddlSelectedItem.Items(SelectedIndex(i)).Value
            index = Me.CurrentPNRInfo.RegionIndexOf(ItemCode)
            If index >= 0 Then
                Me.CurrentPNRInfo.RegionSelectedItems.RemoveAt(index)
            End If
        Next
        If Me.CurrentPNRInfo.RegionSelectedItems.Count <= 0 Then
            Me.divEmpty.Visible = True
        End If
    End Sub

    Private Sub RemoveAllRegion()
        Dim ItemCode As String
        Dim index As Integer
        Dim filter As String = ""
        If Me.ddlSelectedItem.Items.Count <= 0 Then
            Exit Sub
        End If
        For i As Integer = 0 To Me.ddlSelectedItem.Items.Count - 1
            ItemCode = Me.ddlSelectedItem.Items(i).Value
            index = Me.CurrentPNRInfo.RegionIndexOf(ItemCode)
            If index >= 0 Then
                Me.CurrentPNRInfo.RegionSelectedItems.RemoveAt(index)
            End If
        Next
        If Me.CurrentPNRInfo.RegionSelectedItems.Count <= 0 Then
            Me.divEmpty.Visible = True
        End If
    End Sub

    Private Sub RefreshRegion()
        Dim dt As DataTable
        dt = Me.CurrentPNRInfo.ToRegionTable()
        With Me.ddlSelectedItem
            .DataTextField = "Region"
            .DataValueField = "RegionCode"
            .DataSource = dt
            .DataBind()
        End With
        If Me.ddlSelectedItem.Items.Count <= 0 Then
            Me.divSelectedItem.Visible = False
            Me.divEmpty.Visible = True
        Else
            Me.divSelectedItem.Visible = True
            Me.divEmpty.Visible = False
        End If
    End Sub
#End Region

#Region "Country Settings"
    Private Sub SetSelectedCountry()
        Dim RegionList As New List(Of String)
        Dim SelectedIndex() As Integer
        Dim itm As DataInfo.CountryDataInfo
        SelectedIndex = Me.ddlItem.GetSelectedIndices
        If SelectedIndex.Length <= 0 Then
            Me.divEmpty.Visible = True
            Exit Sub
        End If
        Me.CurrentPNRInfo.CountrySelect = "Single"
        For i As Integer = 0 To SelectedIndex.Length - 1
            itm = New DataInfo.CountryDataInfo()
            With itm
                .LinkRegion.RegionCode = Me.ddlRegion.SelectedValue
                .LinkRegion.RegionName = Me.ddlRegion.SelectedItem.Text
                .CountryCode = Me.ddlItem.Items(SelectedIndex(i)).Value
                .CountryName = Me.ddlItem.Items(SelectedIndex(i)).Text
            End With
            Me.CurrentPNRInfo.CountrySelectedItems.Add(itm)
        Next
        Me.divEmpty.Visible = False
    End Sub

    Private Sub SetAllCountry()
        Dim CountryList As New List(Of String)
        Dim itm As DataInfo.CountryDataInfo
        If Me.ddlItem.Items.Count <= 0 Then
            Me.divEmpty.Visible = True
            Exit Sub
        End If
        Me.CurrentPNRInfo.CountrySelect = "All"
        For i As Integer = 0 To Me.ddlItem.Items.Count - 1
            itm = New DataInfo.CountryDataInfo()
            '\\sdsadasd
            With itm
                .LinkRegion.RegionCode = Me.ddlRegion.SelectedValue
                .LinkRegion.RegionName = Me.ddlRegion.SelectedItem.Text
                .CountryCode = Me.ddlItem.Items(i).Value
                .CountryName = Me.ddlItem.Items(i).Text
            End With
            Me.CurrentPNRInfo.CountrySelectedItems.Add(itm)
        Next
        Me.divEmpty.Visible = False
    End Sub

    Private Sub RemoveCountry()
        Dim ItemCode As String
        Dim index As Integer
        Dim filter As String = ""
        Dim SelectedIndex() As Integer
        SelectedIndex = Me.ddlSelectedItem.GetSelectedIndices
        If SelectedIndex.Length <= 0 Then
            Exit Sub
        End If
        For i As Integer = 0 To SelectedIndex.Length - 1
            ItemCode = Me.ddlSelectedItem.Items(SelectedIndex(i)).Value
            index = Me.CurrentPNRInfo.CountryIndexOf(ItemCode)
            If index >= 0 Then
                Me.CurrentPNRInfo.CountrySelectedItems.RemoveAt(index)
            End If
        Next
        If Me.CurrentPNRInfo.CountrySelectedItems.Count <= 0 Then
            Me.divEmpty.Visible = True
        End If
    End Sub

    Private Sub RemoveAllCountry()
        Dim ItemCode As String
        Dim index As Integer
        Dim filter As String = ""
        If Me.ddlSelectedItem.Items.Count <= 0 Then
            Exit Sub
        End If
        For i As Integer = 0 To Me.ddlSelectedItem.Items.Count - 1
            ItemCode = Me.ddlSelectedItem.Items(i).Value
            index = Me.CurrentPNRInfo.CountryIndexOf(ItemCode)
            If index >= 0 Then
                Me.CurrentPNRInfo.CountrySelectedItems.RemoveAt(index)
            End If
        Next
        If Me.CurrentPNRInfo.CountrySelectedItems.Count <= 0 Then
            Me.divEmpty.Visible = True
        End If
    End Sub

    Private Sub RefreshCountry()
        Dim dt As DataTable
        Dim hash As New SortedList()
        Dim key As String = ""
        Dim val As String = ""
        For i As Integer = 0 To Me.CurrentPNRInfo.CountrySelectedItems.Count - 1
            key = Me.CurrentPNRInfo.CountrySelectedItems(i).LinkRegion.RegionName
            val = Me.CurrentPNRInfo.CountrySelectedItems(i).LinkRegion.RegionCode
            If hash.ContainsKey(key) Then
                Continue For
            End If
            hash.Add(key, val)
        Next
        Me.ddlSelectedRegion.Items.Clear()
        Me.ddlSelectedItem.Items.Clear()

        With Me.ddlSelectedRegion
            .DataTextField = "Key"
            .DataValueField = "Value"
            .DataSource = hash
            .DataBind()
            If .Items.Count <= 0 Then
                Me.selRegion2.Visible = False
            Else
                Me.selRegion2.Visible = True
            End If
        End With
        dt = Me.CurrentPNRInfo.ToCountryTable(Me.ddlSelectedRegion.SelectedValue)
        With Me.ddlSelectedItem
            .DataTextField = "Country"
            .DataValueField = "CountryCode"
            .DataSource = dt
            .DataBind()
        End With
        If Me.ddlSelectedItem.Items.Count <= 0 Then
            Me.divSelectedItem.Visible = False
            Me.divEmpty.Visible = True
        Else
            Me.divSelectedItem.Visible = True
            Me.divEmpty.Visible = False
        End If
    End Sub
#End Region

#Region "City Settings"
    Private Sub SetSelectedCity()
        Dim RegionList As New List(Of String)
        Dim SelectedIndex() As Integer
        Dim itm As DataInfo.CityDataInfo
        SelectedIndex = Me.ddlItem.GetSelectedIndices
        If SelectedIndex.Length <= 0 Then
            Me.divEmpty.Visible = True
            Exit Sub
        End If
        Me.CurrentPNRInfo.CitySelect = "Single"
        For i As Integer = 0 To SelectedIndex.Length - 1
            itm = New DataInfo.CityDataInfo()
            With itm
                .LinkCountry.LinkRegion.RegionCode = Me.ddlRegion.SelectedValue
                .LinkCountry.LinkRegion.RegionName = Me.ddlRegion.SelectedItem.Text
                .LinkCountry.CountryCode = Me.ddlCountry.SelectedValue
                .LinkCountry.CountryName = Me.ddlCountry.SelectedItem.Text
                .CityCode = Me.ddlItem.Items(SelectedIndex(i)).Value
                .CityName = Me.ddlItem.Items(SelectedIndex(i)).Text
            End With
            Me.CurrentPNRInfo.CitySelectedItems.Add(itm)
        Next
        Me.divEmpty.Visible = False
    End Sub

    Private Sub SetAllCity()
        Dim CityList As New List(Of String)
        Dim itm As DataInfo.CityDataInfo
        If Me.ddlItem.Items.Count <= 0 Then
            Me.divEmpty.Visible = True
            Exit Sub
        End If
        Me.CurrentPNRInfo.CitySelect = "All"
        For i As Integer = 0 To Me.ddlItem.Items.Count - 1
            itm = New DataInfo.CityDataInfo()
            With itm
                .LinkCountry.LinkRegion.RegionCode = Me.ddlRegion.SelectedValue
                .LinkCountry.LinkRegion.RegionName = Me.ddlRegion.SelectedItem.Text
                .LinkCountry.CountryCode = Me.ddlCountry.SelectedValue
                .LinkCountry.CountryName = Me.ddlCountry.SelectedItem.Text
                .CityCode = Me.ddlItem.Items(i).Value
                .CityName = Me.ddlItem.Items(i).Text
            End With
            Me.CurrentPNRInfo.CitySelectedItems.Add(itm)
        Next
        Me.divEmpty.Visible = False
    End Sub

    Private Sub RemoveCity()
        Dim ItemCode As String
        Dim index As Integer
        Dim filter As String = ""
        Dim SelectedIndex() As Integer
        SelectedIndex = Me.ddlSelectedItem.GetSelectedIndices
        If SelectedIndex.Length <= 0 Then
            Exit Sub
        End If
        For i As Integer = 0 To SelectedIndex.Length - 1
            ItemCode = Me.ddlSelectedItem.Items(SelectedIndex(i)).Value
            index = Me.CurrentPNRInfo.CityIndexOf(ItemCode)
            If index >= 0 Then
                Me.CurrentPNRInfo.CitySelectedItems.RemoveAt(index)
            End If
        Next
        If Me.CurrentPNRInfo.CitySelectedItems.Count <= 0 Then
            Me.divEmpty.Visible = True
        End If
    End Sub

    Private Sub RemoveAllCity()
        Dim ItemCode As String
        Dim index As Integer
        Dim filter As String = ""
        If Me.ddlSelectedItem.Items.Count <= 0 Then
            Exit Sub
        End If
        For i As Integer = 0 To Me.ddlSelectedItem.Items.Count - 1
            ItemCode = Me.ddlSelectedItem.Items(i).Value
            index = Me.CurrentPNRInfo.CityIndexOf(ItemCode)
            If index >= 0 Then
                Me.CurrentPNRInfo.CitySelectedItems.RemoveAt(index)
            End If
        Next
        If Me.CurrentPNRInfo.CitySelectedItems.Count <= 0 Then
            Me.divEmpty.Visible = True
        End If
    End Sub

    Private Sub RefreshCity()
        Dim dt As DataTable
        Dim hash As New SortedList()
        Dim key As String = ""
        Dim val As String = ""
        Me.ddlSelectedRegion.Items.Clear()
        For i As Integer = 0 To Me.CurrentPNRInfo.CitySelectedItems.Count - 1
            key = Me.CurrentPNRInfo.CitySelectedItems(i).LinkCountry.LinkRegion.RegionName
            val = Me.CurrentPNRInfo.CitySelectedItems(i).LinkCountry.LinkRegion.RegionCode
            If hash.ContainsKey(key) Then
                Continue For
            End If
            hash.Add(key, val)
        Next
        With Me.ddlSelectedRegion
            .DataTextField = "Key"
            .DataValueField = "Value"
            .DataSource = hash
            .DataBind()
            If .Items.Count <= 0 Then
                Me.selRegion2.Visible = False
            Else
                Me.selRegion2.Visible = True
            End If
        End With
        hash = New SortedList()
        Me.ddlSelectedCountry.Items.Clear()
        For i As Integer = 0 To Me.CurrentPNRInfo.CitySelectedItems.Count - 1
            key = Me.CurrentPNRInfo.CitySelectedItems(i).LinkCountry.CountryName
            val = Me.CurrentPNRInfo.CitySelectedItems(i).LinkCountry.CountryCode
            If hash.ContainsKey(key) Then
                Continue For
            End If
            hash.Add(key, val)
        Next
        With Me.ddlSelectedCountry
            .DataTextField = "Key"
            .DataValueField = "Value"
            .DataSource = hash
            .DataBind()
            If .Items.Count <= 0 Then
                Me.selCountry2.Visible = False
            Else
                Me.selCountry2.Visible = True
            End If
        End With
        Me.ddlSelectedItem.Items.Clear()

        dt = Me.CurrentPNRInfo.ToCityTable(Me.ddlSelectedCountry.SelectedValue)
        With Me.ddlSelectedItem
            .DataTextField = "City"
            .DataValueField = "CityCode"
            .DataSource = dt
            .DataBind()
        End With
        If Me.ddlSelectedItem.Items.Count <= 0 Then
            Me.divSelectedItem.Visible = False
            Me.divEmpty.Visible = True
        Else
            Me.divSelectedItem.Visible = True
            Me.divEmpty.Visible = False
        End If
    End Sub
#End Region

#Region "General"
    Private Sub LoadRegion()
        Dim BLL As New BusinessLogicLayer.ConfigurationBLL()
        Dim oDataTable As DataTable
        Dim selVal As String = ""
        Dim hasSel As Boolean = False
        oDataTable = BLL.GetRegion(True, "")
        With Me.ddlRegion
            'If .Items.Count > 0 Then
            '    selVal = .SelectedValue
            '    hasSel = True
            'End If
            .DataTextField = "Description"
            .DataValueField = "RegionCode"
            .DataSource = oDataTable
            .DataBind()
            If .Items.Count <= 0 Then
                Me.selRegion.Visible = False
            Else
                'If hasSel AndAlso selVal <> "" Then
                '    .SelectedValue = selVal
                'End If
                Me.selRegion.Visible = True
            End If
        End With
    End Sub

    Private Sub LoadCountry()
        Dim BLL As New BusinessLogicLayer.ConfigurationBLL()
        Dim oDataTable As DataTable
        Dim selVal As String = ""
        Dim hasSel As Boolean = False
        Dim RegionCode As String
        RegionCode = Me.ddlRegion.SelectedValue
        oDataTable = BLL.GetCountryByRegion(RegionCode, "")
        With Me.ddlCountry
            'If .Items.Count > 0 Then
            '    selVal = .SelectedValue
            '    hasSel = True
            'End If
            .DataTextField = "CountryName"
            .DataValueField = "CountryCode"
            .DataSource = oDataTable
            .DataBind()
            If .Items.Count <= 0 Then
                Me.selCountry.Visible = False
            Else
                'If hasSel AndAlso selVal <> "" Then
                '    .SelectedValue = selVal
                'End If
                Me.selCountry.Visible = True
            End If
        End With
    End Sub
    Private Sub LoadItem()
        Dim ConfigBLL As New BusinessLogicLayer.ConfigurationBLL()
        Dim oDataTable As DataTable
        Dim textMember As String = ""
        Dim valMember As String = ""
        Dim filter As String
        Select Case Me.CurrentPNRInfo.ApplyMode
            Case DataInfo.PNRItemInfo.ApplyByItem.Region
                filter = Me.CurrentPNRInfo.RegionString
                textMember = "Description"
                valMember = "RegionCode"
                oDataTable = ConfigBLL.GetRegion(True, filter)
            Case DataInfo.PNRItemInfo.ApplyByItem.Country
                filter = Me.CurrentPNRInfo.CountryString
                textMember = "CountryName"
                valMember = "CountryCode"
                oDataTable = ConfigBLL.GetCountryByRegion(Me.ddlRegion.SelectedValue, filter)
            Case DataInfo.PNRItemInfo.ApplyByItem.City
                filter = Me.CurrentPNRInfo.CityString
                textMember = "City"
                valMember = "CityCode"
                oDataTable = ConfigBLL.GetCity(Me.ddlCountry.SelectedValue, filter)
            Case Else
                Exit Sub
        End Select

        With Me.ddlItem
            .DataTextField = textMember
            .DataValueField = valMember
            .DataSource = oDataTable
            .DataBind()
        End With
    End Sub

    Private Sub LoadDropdownList()
        'If Me.CurrentPNRInfo.IsApplyAll Then
        '    Exit Sub
        'End If
        Select Case Me.CurrentPNRInfo.ApplyMode
            Case DataInfo.PNRItemInfo.ApplyByItem.Region

            Case DataInfo.PNRItemInfo.ApplyByItem.Country
                Call Me.LoadRegion()
            Case DataInfo.PNRItemInfo.ApplyByItem.City
                Call Me.LoadRegion()
                Call Me.LoadCountry()
        End Select
        Call Me.LoadItem()
    End Sub

    Protected Sub btnAdd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnAdd.Click
        Select Case Me.CurrentPNRInfo.ApplyMode
            Case DataInfo.PNRItemInfo.ApplyByItem.Region
                Call Me.SetSelectedRegion()
            Case DataInfo.PNRItemInfo.ApplyByItem.Country
                Call Me.SetSelectedCountry()
            Case DataInfo.PNRItemInfo.ApplyByItem.City
                Call Me.SetSelectedCity()
        End Select
        Call Me.RefreshList()
    End Sub

    Protected Sub btnRemove_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnRemove.Click
        Select Case Me.CurrentPNRInfo.ApplyMode
            Case DataInfo.PNRItemInfo.ApplyByItem.Region
                Call Me.RemoveRegion()
            Case DataInfo.PNRItemInfo.ApplyByItem.Country
                Call Me.RemoveCountry()
            Case DataInfo.PNRItemInfo.ApplyByItem.City
                Call Me.RemoveCity()
        End Select
        Call Me.RefreshList()
    End Sub

    Protected Sub btnSelAll_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSelAll.Click
        Select Case Me.CurrentPNRInfo.ApplyMode
            Case DataInfo.PNRItemInfo.ApplyByItem.Region
                Call Me.SetAllRegion()
            Case DataInfo.PNRItemInfo.ApplyByItem.Country
                Call Me.SetAllCountry()
            Case DataInfo.PNRItemInfo.ApplyByItem.City
                Call Me.SetAllCity()
        End Select
        Call Me.RefreshList()
    End Sub

    Protected Sub btnRemoveAll_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnRemoveAll.Click
        Select Case Me.CurrentPNRInfo.ApplyMode
            Case DataInfo.PNRItemInfo.ApplyByItem.Region
                Call Me.RemoveAllRegion()
            Case DataInfo.PNRItemInfo.ApplyByItem.Country
                Call Me.RemoveAllCountry()
            Case DataInfo.PNRItemInfo.ApplyByItem.City
                Call Me.RemoveAllCity()
        End Select
        Call Me.RefreshList()
    End Sub
#End Region

#Region "Data Binding"
    Private Sub LoadNewData()
        Me.txtItemNo.Value = ""
        Me.txtStartAmount.Text = "0"
        Me.txtEndAmount.Text = "0"
        Me.txtFeeAmt.Text = "0"
        Me.btnSave.Text = "Add"
        Me.ddlApplyBy.SelectedIndex = -1
        'Me.chkApplyAll.Checked = False
        Me.CurrentPNRInfo = New DataInfo.PNRItemInfo()
    End Sub

    Private Sub LoadDataFromDB()
        Dim FeeName As String
        FeeName = Me.BLL.GetFeeNameByID(Me.RecordID, DataInfo.AirFeeInfo.AirFeeManagerType.FeeByPNR)
        Me.txtName.Text = FeeName
        Call Me.LoadClassDataFromDB()
    End Sub
#End Region

#Region "Data Transaction"
    Private Sub SaveData()


        If Me.ClassTable.Rows.Count <= 0 Then
            Me.lblMsgBox.Text = "Must add at least one criteria for the fee by PNR!"
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.ajaxMsgBox.Show()

            Exit Sub

        End If

        With Me.PagePNR
            .PageMode = Me.CurrentPageMode
            .FeeName = Me.txtName.Text
            .FeeID = Me.RecordID
        End With
        If Me.BLL.UpdateFeeByPNRData(Me.PagePNR) > 0 Then
            Me.lblMsgBox.Text = Util.GetAppConfig(Util.MsgType.TRANS_SUCCESS.ToString)
            Me.lblMsgBox.ForeColor = Drawing.Color.Green
            Me.ajaxMsgBox.Show()
        Else
            Me.lblMsgBox.Text = Util.GetAppConfig(Util.MsgType.TRANS_ERROR.ToString)
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.ajaxMsgBox.Show()
        End If
    End Sub
#End Region

#Region "Page Control Event Handlers"
    Protected Sub btnTrans_OnCancel(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans.OnCancel
        Response.Redirect("AirFeeManager.aspx")
    End Sub

    Protected Sub btnTrans_OnSave(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans.OnSave
        Call Me.SaveData()
    End Sub
#End Region

    Private Sub RefreshList(Optional ByVal RefreshCombo As Boolean = True)
        Select Case Me.CurrentPNRInfo.ApplyMode
            Case DataInfo.PNRItemInfo.ApplyByItem.Region
                Call Me.RefreshRegion()
            Case DataInfo.PNRItemInfo.ApplyByItem.Country
                Call Me.RefreshCountry()
            Case DataInfo.PNRItemInfo.ApplyByItem.City
                Call Me.RefreshCity()
        End Select
        If RefreshCombo Then Call Me.LoadDropdownList()
    End Sub

    Private Sub SetMode()
        'If Me.CurrentPNRInfo.IsApplyAll Then
        '    Me.divItem.Visible = False
        'Else
        Me.divItem.Visible = True
        Select Case Me.CurrentPNRInfo.ApplyMode
            Case DataInfo.PNRItemInfo.ApplyByItem.Region
                Me.ddlRegion.Visible = False
                Me.ddlCountry.Visible = False
                Me.ddlSelectedRegion.Visible = False
                Me.ddlSelectedCountry.Visible = False
                Me.selRegion.Visible = False
                Me.selRegion2.Visible = False
                Me.selCountry.Visible = False
                Me.selCountry2.Visible = False
            Case DataInfo.PNRItemInfo.ApplyByItem.Country
                Me.ddlRegion.Visible = True
                Me.ddlCountry.Visible = False
                Me.ddlSelectedRegion.Visible = True
                Me.ddlSelectedCountry.Visible = False
                Me.selRegion.Visible = True
                Me.selRegion2.Visible = True
                Me.selCountry.Visible = False
                Me.selCountry2.Visible = False
            Case DataInfo.PNRItemInfo.ApplyByItem.City
                Me.ddlRegion.Visible = True
                Me.ddlCountry.Visible = True
                Me.ddlSelectedRegion.Visible = True
                Me.ddlSelectedCountry.Visible = True
                Me.selRegion.Visible = True
                Me.selRegion2.Visible = True
                Me.selCountry.Visible = True
                Me.selCountry2.Visible = True
        End Select
        'End If
    End Sub

    Protected Sub ddlApplyBy_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlApplyBy.SelectedIndexChanged
        Me.CurrentPNRInfo = New DataInfo.PNRItemInfo()
        Me.CurrentPNRInfo.ApplyMode = Util.DBNullToZero(Me.ddlApplyBy.SelectedValue)
        Call Me.SetMode()
        Call Me.RefreshList()
    End Sub

    'Protected Sub chkApplyAll_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkApplyAll.CheckedChanged
    '    Me.CurrentPNRInfo.IsApplyAll = Me.chkApplyAll.Checked
    '    Call Me.SetMode()
    'End Sub

    Protected Sub ddlSelectedRegion_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlSelectedRegion.SelectedIndexChanged
        Call Me.RefreshList(False)
    End Sub

    Protected Sub ddlSelectedCountry_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlSelectedCountry.SelectedIndexChanged
        Call Me.RefreshList(False)
    End Sub

    Protected Sub ddlRegion_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlRegion.SelectedIndexChanged
        Call Me.LoadCountry()
        Call Me.LoadItem()
    End Sub

    Protected Sub ddlCountry_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlCountry.SelectedIndexChanged
        Call Me.LoadItem()
    End Sub

    Public Function GetApplyText(ByVal ItemNo As String) As String
        Dim Index As Integer = 0
        Dim retVal As String = ""
        Index = Util.DBNullToZero(ItemNo) - 1
        If Me.PagePNR.PNRList.Count > 0 Then
            Select Case Me.PagePNR.PNRList(Index).ApplyMode
                Case DataInfo.PNRItemInfo.ApplyByItem.Region
                    retVal = "Region (" + Me.PagePNR.PNRList(Index).RegionSelectedItems.Count.ToString + " items)"
                Case DataInfo.PNRItemInfo.ApplyByItem.Country
                    retVal = "Country (" + Me.PagePNR.PNRList(Index).CountrySelectedItems.Count.ToString + " items)"
                Case DataInfo.PNRItemInfo.ApplyByItem.City
                    retVal = "City (" + Me.PagePNR.PNRList(Index).CitySelectedItems.Count.ToString + " items)"
            End Select
        End If
        Return retVal
    End Function

End Class
@


1.1.1.1
log
@no message
@
text
@@
