head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.07.01;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.07.01;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@
Partial Class Web_CWT_CountryConfig
    Inherits BasePage

    Private BLL As BusinessLogicLayer.DatabaseBLL
    Private BLL2 As BusinessLogicLayer.StaffBLL
    Private BLL3 As BusinessLogicLayer.tblFunctionBLL

    Private ReadOnly Property KeyID() As String
        Get
            If Session("CONN_KeyID") Is Nothing Then
                Response.Redirect(Util.GetAppConfig("RootPath") + "/Login.aspx", True)
            End If
            Return Session("CONN_KeyID")
        End Get
    End Property

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.BLL = New BusinessLogicLayer.DatabaseBLL()
        Me.BLL2 = New BusinessLogicLayer.StaffBLL()
        Me.BLL3 = New BusinessLogicLayer.tblFunctionBLL()
        If Not IsPostBack Then
            Call Me.LoadConfigurationData()
            Call Me.LoadCurrency()
            Call Me.LoadDataFromDB()
            Call Me.AccessControl("Country Config")
        End If
    End Sub


    Private Sub AccessControl(ByVal title As String)

        Dim userName As String
        Dim oDatatable As DataTable
        Dim oDataTable2 As DataTable

        Static roleID As String

        userName = ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName
        oDatatable = Me.BLL2.GetUserByID(userName)

        If oDatatable.Rows.Count > 0 Then
            roleID = oDatatable.Rows(0).Item("RoleID").ToString
        End If

        oDataTable2 = Me.BLL3.GetUserRole(roleID)
        If oDataTable2.Rows.Count > 0 Then
            For k As Integer = 0 To oDataTable2.Rows.Count - 1
                If oDataTable2.Rows(k).Item("functionGroup") = "0" Then
                    If oDataTable2.Rows(k).Item("Permission") = "V" Then
                        If oDataTable2.Rows(k).Item("functionName").ToString = title Then
                            Call Me.toggleControl()

                        End If
                    End If
                End If

            Next

        End If


    End Sub

    Private Sub toggleControl()
        Me.btnTrans.SaveButton.Enabled = False
        Me.txtDecimal.Readonly = True
        Me.txtRoundUnit.Readonly = True
        Me.ddlConfigurationID.Enabled = False
        Me.ddlCurrency.Enabled = False
        Me.chkDefaultTktAll.Enabled = False
        Me.chkDefaultTktInv.Enabled = False
        Me.chkDefaultTktItin.Enabled = False
        Me.chkDefaultTktTicket.Enabled = False
        Me.chkDefaultTktMir.Enabled = False
    End Sub

    Private Sub LoadConfigurationData()
        Dim CBLL As New BusinessLogicLayer.ConfigurationBLL()
        Dim oDataTable As DataTable
        oDataTable = CBLL.GetConfigurationData()
        With Me.ddlConfigurationID
            .DataTextField = "ConfigurationDesc"
            .DataValueField = "ConfigurationID"
            .DataSource = oDataTable
            .DataBind()
        End With
    End Sub

    Private Sub LoadCurrency()
        Dim CBLL As New BusinessLogicLayer.ConfigurationBLL()
        Dim oDataTable As DataTable
        oDataTable = CBLL.GetCurrency()
        With Me.ddlCurrency
            .DataTextField = "CurrencyName"
            .DataValueField = "CurrencyCode"
            .DataSource = oDataTable
            .DataBind()
        End With
    End Sub

    Private Sub LoadDataFromDB()
        Dim oDataTable As DataTable
        Dim r As DataRow
        Try
            oDataTable = Me.BLL.GetCountryConfig(Me.KeyID)
            r = oDataTable.Rows(0)
            If oDataTable IsNot Nothing AndAlso oDataTable.Rows.Count > 0 Then
                If Not IsDBNull(r("ConfigurationID")) AndAlso r("ConfigurationID").ToString <> "" Then
                    Me.ddlConfigurationID.SelectedValue = r("ConfigurationID").ToString
                End If
                If Not IsDBNull(r("CurrencyCode")) AndAlso r("CurrencyCode").ToString <> "" Then
                    Me.ddlCurrency.SelectedValue = r("CurrencyCode").ToString
                End If
                'Me.txtGST.Text = Util.DBNullToZero(r("GST"))
                Me.txtDecimal.Text = Util.DBNullToZero(r("DecimalPoint"))
                Me.txtRoundUnit.Text = Util.DBNullToZero(r("RoundUnit"))
                Me.chkDefaultTktAll.Checked = Util.DBNullToFalse(r("DefaultTktAll"))
                If Not Me.chkDefaultTktAll.Checked Then
                    Me.chkDefaultTktTicket.Checked = Util.DBNullToFalse(r("DefaultTktTicket"))
                    Me.chkDefaultTktItin.Checked = Util.DBNullToFalse(r("DefaultTktItin"))
                    Me.chkDefaultTktInv.Checked = Util.DBNullToFalse(r("DefaultTktInv"))
                    Me.chkDefaultTktMir.Checked = Util.DBNullToFalse(r("DefaultTktMir"))
                End If
            End If
            Me.divDefaultTkOp.Visible = (Not Me.chkDefaultTktAll.Checked)
        Catch ex As Exception

        End Try
    End Sub

    Private Sub SaveData()
        Dim Info As New DataInfo.CountryInfo()
        With Info
            .KeyID = Me.KeyID
            .ConfigurationID = Me.ddlConfigurationID.SelectedValue
            .Currency = Me.ddlCurrency.SelectedValue
            '.GST = Util.DBNullToZero(Me.txtGST.Text)
            .DecimalPt = Util.DBNullToZero(Me.txtDecimal.Text)
            .RoundUnit = Util.DBNullToZero(Me.txtRoundUnit.Text)
            .DefaultTkAll = Me.chkDefaultTktAll.Checked
            If Not Me.chkDefaultTktAll.Checked Then
                .DefaultTktTicket = Me.chkDefaultTktTicket.Checked
                .DefaultTktItin = Me.chkDefaultTktItin.Checked
                .DefaultTktInv = Me.chkDefaultTktInv.Checked
                .DefaultTktMir = Me.chkDefaultTktMir.Checked
            End If
        End With
        If Me.BLL.UpdateCountryConfig(Info) > 0 Then
            Me.lblMsgBox.Text = Util.GetAppConfig(Util.MsgType.TRANS_SUCCESS.ToString)
            Me.lblMsgBox.ForeColor = Drawing.Color.Green
            Me.ajaxMsgBox.Show()
        Else
            Me.lblMsgBox.Text = Util.GetAppConfig(Util.MsgType.TRANS_ERROR.ToString)
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.ajaxMsgBox.Show()
        End If
    End Sub

    Protected Sub btnTrans_OnCancel(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans.OnCancel
        Response.Redirect(Util.GetAppConfig("RootPath") + "/Default.aspx")
    End Sub

    Protected Sub btnTrans_OnSave(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans.OnSave
        Call Me.SaveData()
    End Sub

    Private Sub chkDefaultTktAll_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkDefaultTktAll.CheckedChanged
        Me.divDefaultTkOp.Visible = (Not Me.chkDefaultTktAll.Checked)
    End Sub

End Class
@


1.1.1.1
log
@no message
@
text
@@
