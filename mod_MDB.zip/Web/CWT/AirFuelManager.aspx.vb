head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.07.00;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.07.00;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports System.Web.Services
Imports System.Web.Script.Services

Partial Class Web_CWT_AirFuelManager
    Inherits BasePage

    Private BLL As BusinessLogicLayer.AirlineBLL

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.BLL = New BusinessLogicLayer.AirlineBLL()
        If Not IsPostBack Then
            With Me.gdData
                .DataSource = New DataTable()
                .DataBind()
            End With
        Else
            Call Me.LoadDataGrid()
        End If
    End Sub

    Private Sub LoadDataGrid()
        Dim oDataTable As DataTable
        oDataTable = Me.BLL.GetAirlineList(Me.txtAirlineDescription.Text)
        With Me.gdData
            .DataSource = oDataTable
            .DataBind()
        End With
        With Me.pgControl
            .GridID = Me.gdData.UniqueID
            .SetBindGrid()
        End With
    End Sub

    Private Sub DeleteFuelCharge(ByVal AirlineCode As String)
        'Me.BLL.DeleteHolidayByHolidayID(HolidayID)
    End Sub

    Protected Sub btnSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSearch.Click
        Call Me.LoadDataGrid()
    End Sub

#Region "Control Event"
    Public Sub gdData_Command(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.CommandEventArgs)
        Select Case e.CommandName
            Case "DeleteItem"
                Call Me.DeleteFuelCharge(Util.DBNullToZero(e.CommandArgument))
        End Select
        Call Me.LoadDataGrid()
    End Sub

    Protected Sub gdData_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gdData.RowDataBound
        Dim cwtLinkBtn As CWTCustomControls.CWTLinkButton

        cwtLinkBtn = TryCast(e.Row.FindControl("hrefDelete"), CWTCustomControls.CWTLinkButton)

        If cwtLinkBtn IsNot Nothing Then
            cwtLinkBtn.PermissionInfo = Me.usrInfo
            cwtLinkBtn.Attributes.Add("onclick", "return confirm('Fuel charge will delete, continue?');")
        End If
    End Sub
#End Region

#Region "Webservices Methods"
    <WebMethod(), ScriptMethod()> _
    Public Shared Function GetAirlineName(ByVal prefixText As String, ByVal count As Integer) As String()
        Dim CompBLL As New BusinessLogicLayer.AirlineBLL()
        Return CompBLL.GetAirlineName(prefixText)
    End Function
#End Region

End Class
@


1.1.1.1
log
@no message
@
text
@@
