head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.07.00;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.07.00;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@
Partial Class Web_CWT_AirFuelUpdateManager
    Inherits BasePage

#Region "Page Properties & Variables"
    Private BLL As BusinessLogicLayer.AirlineBLL

    Private Property IsErrorBefore() As Boolean
        Get
            Dim retVal As Boolean
            If Me.ViewState("_IsErrorBefore") IsNot Nothing Then
                retVal = CBool(Me.ViewState("_IsErrorBefore"))
            End If
            Return retVal
        End Get
        Set(ByVal value As Boolean)
            Me.ViewState("_IsErrorBefore") = value
        End Set
    End Property

    Private Property IsError() As Boolean
        Get
            Dim retVal As Boolean
            If Me.ViewState("_IsError") IsNot Nothing Then
                retVal = CBool(Me.ViewState("_IsError"))
            End If
            Return retVal
        End Get
        Set(ByVal value As Boolean)
            Me.ViewState("_IsError") = value
        End Set
    End Property

    Public Property RecordID() As String
        Get
            Dim retVal As String = ""
            If Me.ViewState("_RecordID") IsNot Nothing Then
                retVal = Me.ViewState("_RecordID").ToString()
            End If
            Return retVal
        End Get
        Set(ByVal value As String)
            Me.ViewState("_RecordID") = value
        End Set
    End Property
#End Region

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.BLL = New BusinessLogicLayer.AirlineBLL()
        If Not IsPostBack Then
            If Me.Request("mode") Is Nothing Then
                Response.Redirect(Util.GetAppConfig("RootPath") + "/AirFuelManager.aspx", True)
            End If
            Select Case Me.Request("mode").ToString()
                Case "add"
                    Me.CurrentPageMode = CWTMasterDB.TransactionMode.AddNewMode
                    Me.btnGetInfo.Visible = True
                Case "edit"
                    Me.CurrentPageMode = CWTMasterDB.TransactionMode.UpdateMode
                    Me.RecordID = Me.Request("id").ToString()
                    Call Me.LoadData()
                    Me.btnGetInfo.Visible = False
            End Select
            Call Me.InitializeControls()
        End If
    End Sub

    Private Sub InitializeControls()
        Dim sc As New StringBuilder()
        sc.AppendLine("txtID='" + Me.hidAirlineCode.ClientID + "';")
        sc.AppendLine("txtName='" + Me.txtAirlineDescription.ClientID + "';")
        sc.AppendLine("txtFuelCharge='" + Me.txtFuelCharge.ClientID + "';")
        Util.RegClientScript(sc.ToString, "RegistScript", Util.ClientScriptRegistType.RegStartUpBlock)
    End Sub

    Private Sub LoadData()
        Dim oDataTable As DataTable
        oDataTable = Me.BLL.GetAirlineFuelData(Me.RecordID)
        If oDataTable IsNot Nothing AndAlso oDataTable.Rows.Count > 0 Then
            Me.hidAirlineCode.Value = Me.RecordID
            Me.txtAirlineDescription.Text = oDataTable.Rows(0).Item("AirlineDescription").ToString
            Me.txtFuelCharge.Text = Util.DBNullToZero(oDataTable.Rows(0).Item("FuelCharge"))
        End If
    End Sub

    Private Sub LoadDataGrid()
        Dim oDataTable As DataTable
        oDataTable = Me.BLL.GetAirlineList()
        With Me.gdData
            .DataSource = oDataTable
            .DataBind()
        End With
        With Me.pgControl
            .GridID = Me.gdData.UniqueID
            .PageDataTable = oDataTable.Copy()
            .SetBindGrid()
        End With
    End Sub

    Private Sub SaveData()
        Dim info As New DataInfo.AirlineInfo()
        With info
            .PageMode = Me.CurrentPageMode
            .AirlineCode = Me.hidAirlineCode.Value
            .FuelCharge = Util.DBNullToZero(Me.txtFuelCharge.Text)
        End With
        If Me.BLL.UpdateAirlineFuel(info) > 0 Then
            Me.lblMsgBox.Text = Util.GetAppConfig(Util.MsgType.TRANS_SUCCESS.ToString)
            Me.lblMsgBox.ForeColor = Drawing.Color.Green
            Me.ajaxMsgBox.Show()
            Response.Redirect("AirFuelManager.aspx")
        Else
            Me.lblMsgBox.Text = Util.GetAppConfig(Util.MsgType.TRANS_ERROR.ToString)
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.ajaxMsgBox.Show()
        End If
    End Sub

    Protected Sub btnGetInfo_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnGetInfo.Click
        'Call Me.LoadDataGrid()
        'Me.ajaxPopup.Show()
    End Sub

    Protected Sub gdData_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles gdData.SelectedIndexChanged
        Me.hidAirlineCode.Value = Me.gdData.SelectedRow.Cells(0).Text
        Me.txtAirlineDescription.Text = Me.gdData.SelectedRow.Cells(1).Text
        Me.txtFuelCharge.Text = "0"
    End Sub

    Protected Sub btnTrans_OnCancel(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans.OnCancel
        Response.Redirect("AirFuelManager.aspx")
    End Sub

    Protected Sub btnTrans_OnSave(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans.OnSave
        Call Me.SaveData()
    End Sub

End Class
@


1.1.1.1
log
@no message
@
text
@@
