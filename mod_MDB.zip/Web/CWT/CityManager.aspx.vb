head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.07.01;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.07.01;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Partial Public Class CityManager
    Inherits BasePage

    Private BLL As BusinessLogicLayer.CityBLL
    Private BLL2 As BusinessLogicLayer.StaffBLL
    Private BLL3 As BusinessLogicLayer.tblFunctionBLL
    Private blnchek As Boolean = True

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.BLL = New BusinessLogicLayer.CityBLL()
        Me.BLL2 = New BusinessLogicLayer.StaffBLL()
        Me.BLL3 = New BusinessLogicLayer.tblFunctionBLL()

        If Not IsPostBack Then
            Call Me.LoadDropDownList()
            'Call Me.LoadDataGrid()
            'Call Me.LoadDataGrid2()
        End If
        Call Me.AccessControl("Airport")
    End Sub

    Private Sub AccessControl(ByVal title As String)

        Dim userName As String
        Dim oDatatable As DataTable
        Dim oDataTable2 As DataTable

        Static roleID As String

        userName = ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName
        oDatatable = Me.BLL2.GetUserByID(userName)

        If oDatatable.Rows.Count > 0 Then
            roleID = oDatatable.Rows(0).Item("RoleID").ToString
        End If

        oDataTable2 = Me.BLL3.GetUserRole(roleID)
        If oDataTable2.Rows.Count > 0 Then
            For k As Integer = 0 To oDataTable2.Rows.Count - 1
                If oDataTable2.Rows(k).Item("functionGroup") = "0" Then
                    If oDataTable2.Rows(k).Item("Permission") = "V" Then
                        If oDataTable2.Rows(k).Item("functionName").ToString = title Then
                            Call Me.toggleControl()
                            blnchek = False
                            Exit Sub
                        End If
                    End If
                End If

            Next

        End If
        Call Me.LoadDataGrid()

    End Sub

    Private Sub toggleControl()
        'Dim btnDelete As CWTCustomControls.CWTLinkButton

        Call Me.LoadDataGrid2()
        Me.hrefAdd.Enabled = False
        Me.gdData.Visible = False
        Me.tblPg.Visible = False

        Me.gdDataView.Visible = True
        Me.tblPg2.Visible = True

        'For i As Integer = 0 To Me.gdData.Rows.Count - 1
        '    btnDelete = Me.gdData.Rows(i).FindControl("hrefDelete")
        '    btnDelete.Visible = False

        'Next
    End Sub


    Private Sub LoadCityType()
        Dim oDataTable As DataTable
        oDataTable = Me.BLL.GetCityTypeList()
        With Me.ddlType
            .DataTextField = "CityTypeDesc"
            .DataValueField = "CityTypeCode"
            .DataSource = oDataTable
            .DataBind()
            .Items.Insert(0, New ListItem("All", ""))
        End With
    End Sub

    Private Sub LoadDropDownList()
        Call Me.LoadCityType()
    End Sub

    Private Sub LoadDataGrid()
        Dim oDataTable As DataTable
        oDataTable = Me.BLL.GetCityList(Me.txtAirportCode.Text, Me.ddlType.SelectedValue)
        With Me.gdData
            .DataSource = oDataTable
            .DataBind()
        End With
        With Me.pgControl
            .GridID = Me.gdData.UniqueID
            .SetBindGrid()
        End With
    End Sub
    Private Sub LoadDataGrid2()
        Dim oDataTable As DataTable
        oDataTable = Me.BLL.GetCityList(Me.txtAirportCode.Text, Me.ddlType.SelectedValue)
        With Me.gdDataView
            .DataSource = oDataTable
            .DataBind()
        End With
        With Me.pgControl2
            .GridID = Me.gdDataView.UniqueID
            .SetBindGrid()
        End With
    End Sub

    Private Sub DeleteCity(ByVal AirportCode As String)
        Me.BLL.DeleteCityByCode(AirportCode)
        Call Me.LoadDataGrid()
    End Sub

    Protected Sub btnSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSearch.Click

        Call Me.AccessControl("Airport")
        If blnchek = True Then
            Call Me.LoadDataGrid()
        Else
            Call Me.LoadDataGrid2()
        End If



    End Sub

#Region "Control Event"
    Public Sub gdData_Command(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.CommandEventArgs)
        Select Case e.CommandName
            Case "DeleteItem"
                Call Me.DeleteCity(e.CommandArgument)
        End Select
        Call Me.LoadDataGrid()
    End Sub

    Protected Sub gdData_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gdData.RowDataBound
        Dim cwtLinkBtn As CWTCustomControls.CWTLinkButton
        cwtLinkBtn = TryCast(e.Row.FindControl("hrefDelete"), CWTCustomControls.CWTLinkButton)
        If cwtLinkBtn IsNot Nothing Then
            cwtLinkBtn.Attributes.Add("onclick", "return confirm('Item will delete, continue?');")
        End If
    End Sub
#End Region


End Class










@


1.1.1.1
log
@no message
@
text
@@
