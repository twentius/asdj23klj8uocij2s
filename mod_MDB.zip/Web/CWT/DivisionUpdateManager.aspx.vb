head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.07.01;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.07.01;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Class Admin_UserSystem_DivisionUpdateManager
    Inherits BasePage

    Private BLL As BusinessLogicLayer.DivisionBLL


#Region "Properties"
    Public ReadOnly Property RequestMode() As String
        Get
            Dim retVal As String = ""
            If Me.Request("mode") IsNot Nothing Then
                retVal = Me.Request("mode")
            End If
            Return retVal
        End Get
    End Property
    Public Property RecordID() As String
        Get
            Dim retVal As String = ""
            If Me.ViewState("_RecordID") IsNot Nothing Then
                retVal = Me.ViewState("_RecordID").ToString
            End If
            Return retVal
        End Get
        Set(ByVal value As String)
            Me.ViewState("_RecordID") = value
        End Set
    End Property

    Public Property RecordUid() As String
        Get
            Dim retVal As String = ""
            If Me.ViewState("_RecordUid") IsNot Nothing Then
                retVal = Me.ViewState("_RecordUid").ToString
            End If
            Return retVal
        End Get
        Set(ByVal value As String)
            Me.ViewState("_RecordUid") = value
        End Set
    End Property


    Public Property RecordName() As String
        Get
            Dim retVal As String = ""
            If Me.ViewState("_RecordName") IsNot Nothing Then
                retVal = Me.ViewState("_RecordName").ToString
            End If
            Return retVal
        End Get
        Set(ByVal value As String)
            Me.ViewState("_RecordName") = value
        End Set
    End Property

    Public ReadOnly Property RequestID() As String
        Get
            Dim retVal As String = ""
            If Me.Request("id") IsNot Nothing Then
                retVal = Me.Request("id")
            End If
            Return retVal
        End Get
    End Property

    Public ReadOnly Property RequestName() As String
        Get
            Dim retVal As String = ""
            If Me.Request("name") IsNot Nothing Then
                retVal = Me.Request("name")
            End If
            Return retVal
        End Get
    End Property

    Public ReadOnly Property RequestUid() As String
        Get
            Dim retVal As String = ""
            If Me.Request("uid") IsNot Nothing Then
                retVal = Me.Request("uid")
            End If
            Return retVal
        End Get
    End Property

    Private Property IsError() As Boolean
        Get
            Dim retVal As Boolean
            If Me.ViewState("_IsError") IsNot Nothing Then
                retVal = CBool(Me.ViewState("_IsError"))
            End If
            Return retVal
        End Get
        Set(ByVal value As Boolean)
            Me.ViewState("_IsError") = value
        End Set
    End Property
#End Region

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.BLL = New BusinessLogicLayer.DivisionBLL

        If Not IsPostBack Then
            Select Case Me.RequestMode.ToLower()
                Case "add"
                    Me.CurrentPageMode = CWTMasterDB.TransactionMode.AddNewMode
                    Me.lblTitle.Text = "Add New Division"
                    Me.UcDivision1.Visible = True
                    Me.UcDivision1.NewDivision()
                    Me.UcAgent1.Visible = False

                    'InitialData()
                Case "edit1"
                    Me.CurrentPageMode = CWTMasterDB.TransactionMode.UpdateMode
                    Me.RecordID = Me.RequestID
                    Me.RecordName = Me.RequestName
                    Me.RecordUid = Me.RequestUid
                    Me.lblTitle.Text = "Update Agent For Division"
                    'InitialData()  
                    Me.UcDivision1.Visible = False
                    Me.UcAgent1.Visible = True
                    Me.UcAgent1.LoadDivisionList(Me.RecordID, Me.RecordUid, Me.RecordName)
                Case "edit2"
                    Me.RecordID = Me.RequestID
                    Me.lblTitle.Text = "Update Division"
                    Me.UcDivision1.Visible = True
                    Me.UcAgent1.Visible = False
                    Me.UcDivision1.LoadDivision(Me.RecordID)

            End Select
        End If
    End Sub

End Class@


1.1.1.1
log
@no message
@
text
@@
