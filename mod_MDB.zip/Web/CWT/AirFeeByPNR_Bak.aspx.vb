head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.59;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.59;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports System.Collections.Generic

Partial Class Web_CWT_AirFeeByPNR_Bak
    Inherits BasePage

#Region "Page Properties & Variables"
    Private BLL As BusinessLogicLayer.AirFeeBLL

    Public ReadOnly Property RegionString() As String
        Get
            Dim retVal As String = ""
            retVal = Me.CurrentPNRInfo.RegionString
            Return retVal
        End Get
    End Property
    Public ReadOnly Property CountryString() As String
        Get
            Dim retVal As String = ""
            retVal = Me.CurrentPNRInfo.CountryString
            Return retVal
        End Get
    End Property
    Public ReadOnly Property CityString() As String
        Get
            Dim retVal As String = ""
            retVal = Me.CurrentPNRInfo.CityString
            Return retVal
        End Get
    End Property
    Public Property PagePNR() As DataInfo.TransPNRInfo
        Get
            Return Me.ViewState("PagePNR")
        End Get
        Set(ByVal value As DataInfo.TransPNRInfo)
            Me.ViewState("PagePNR") = value
        End Set
    End Property
    Public Property CurrentPNRInfo() As DataInfo.PNRItemInfo
        Get
            Return Me.ViewState("CurrentPNRInfo")
        End Get
        Set(ByVal value As DataInfo.PNRItemInfo)
            Me.ViewState("CurrentPNRInfo") = value
        End Set
    End Property

    Private Property ClassTable() As DataTable
        Get
            Return Me.ViewState("_ClassTable")
        End Get
        Set(ByVal value As DataTable)
            Me.ViewState("_ClassTable") = value
        End Set
    End Property

    Public Property RecordID() As String
        Get
            Dim retVal As String = ""
            If Me.ViewState("_RecordID") IsNot Nothing Then
                retVal = Me.ViewState("_RecordID").ToString
            End If
            Return retVal
        End Get
        Set(ByVal value As String)
            Me.ViewState("_RecordID") = value
        End Set
    End Property

    Public ReadOnly Property RequestID() As String
        Get
            Dim retVal As String = ""
            If Me.Request("id") IsNot Nothing Then
                retVal = Me.Request("id")
            End If
            Return retVal
        End Get
    End Property

    Public ReadOnly Property RequestMode() As String
        Get
            Dim retVal As String = ""
            If Me.Request("mode") IsNot Nothing Then
                retVal = Me.Request("mode")
            End If
            Return retVal
        End Get
    End Property
#End Region

#Region "Page Event Handlers & Methods"
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.BLL = New BusinessLogicLayer.AirFeeBLL()
        If Not IsPostBack Then
            Call Me.CreateTable()
            Select Case Me.RequestMode.ToLower()
                Case "add"
                    Me.CurrentPageMode = CWTMasterDB.TransactionMode.AddNewMode
                Case "edit"
                    Me.CurrentPageMode = CWTMasterDB.TransactionMode.UpdateMode
                    Me.RecordID = Me.RequestID
                    Call Me.LoadDataFromDB()
            End Select
            Call Me.LoadNewData()
            Call Me.LoadDropdownList()
        End If
    End Sub

    Private Sub CreateTable()
        Call Me.CreateClassTable()
    End Sub
#End Region

#Region "Class sub routine"
    Private Sub CreateClassTable()
        Me.ClassTable = New DataTable("ClassTable")
        With Me.ClassTable
            .Columns.Add(New DataColumn("ItemNo", GetType(Integer)))
            .Columns.Add(New DataColumn("StartAmount"))
            .Columns.Add(New DataColumn("EndAmount"))
            .Columns.Add(New DataColumn("Region"))
            .Columns.Add(New DataColumn("Country"))
            .Columns.Add(New DataColumn("City"))
            .Columns.Add(New DataColumn("FeeAmt"))
        End With
    End Sub

    Private Sub AddClassData()
        Dim dr As DataRow
        dr = Me.ClassTable.NewRow()
        If Me.ClassTable.Rows.Count > 0 Then
            dr("ItemNo") = Util.DBNullToZero(Me.ClassTable.Rows(Me.ClassTable.Rows.Count - 1).Item("ItemNo") + 1)
        Else
            dr("ItemNo") = 1
        End If
        dr("StartAmount") = Me.txtStartAmount.Text
        dr("EndAmount") = Me.txtEndAmount.Text
        dr("FeeAmt") = Me.txtFeeAmt.Text
        dr("Region") = Me.RegionString()
        dr("Country") = Me.CountryString()
        dr("City") = Me.CityString()
        Me.ClassTable.Rows.Add(dr)
    End Sub

    Private Sub LoadClassData(ByVal ItemNo As String)
        On Error Resume Next
        Dim dr As DataRow()
        Dim filter As String = ""
        filter = "ItemNo=" + Util.LimitTheString(ItemNo)
        dr = Me.ClassTable.Select(filter)
        If dr IsNot Nothing AndAlso dr.Length > 0 Then
            Me.txtItemNo.Value = ItemNo
            Me.txtStartAmount.Text = dr(0).Item("StartAmount").ToString
            Me.txtEndAmount.Text = dr(0).Item("EndAmount").ToString
            Me.txtFeeAmt.Text = dr(0).Item("FeeAmt").ToString
        End If
    End Sub

    Private Sub LoadClassDataFromDB()
        Dim oDataTable As DataTable
        Dim oRow As DataRow
        Dim dr As DataRow
        Try
            oDataTable = Me.BLL.GetFeeByCouponData(Me.RecordID)
            If oDataTable IsNot Nothing Then
                For i As Integer = 0 To oDataTable.Rows.Count - 1
                    oRow = oDataTable.Rows(i)
                    dr = Me.ClassTable.NewRow()
                    If Me.ClassTable.Rows.Count > 0 Then
                        dr("ItemNo") = Util.DBNullToZero(Me.ClassTable.Rows(Me.ClassTable.Rows.Count - 1).Item("ItemNo") + 1)
                    Else
                        dr("ItemNo") = 1
                    End If
                    dr("StartAmount") = oRow("StartAmount").ToString
                    dr("EndAmount") = oRow("EndAmount").ToString
                    dr("FeeAmt") = oRow("TFAmount").ToString
                    Me.ClassTable.Rows.Add(dr)
                Next
                Call Me.RefreshClassGrid()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub RemoveClassData(ByVal ItemNo As String)
        Dim dr As DataRow()
        Dim filter As String = ""
        filter = "ItemNo=" + Util.LimitTheString(ItemNo)
        dr = Me.ClassTable.Select(filter)
        If dr IsNot Nothing AndAlso dr.Length > 0 Then
            Me.ClassTable.Rows.Remove(dr(0))
        End If
    End Sub

    Private Sub UpdateClassData(ByVal ItemNo As String)
        Dim dr As DataRow()
        Dim filter As String = ""
        filter = "ItemNo=" + Util.LimitTheString(ItemNo)
        dr = Me.ClassTable.Select(filter)
        If dr IsNot Nothing AndAlso dr.Length > 0 Then
            dr(0).Item("StartAmount") = Me.txtStartAmount.Text
            dr(0).Item("EndAmount") = Me.txtEndAmount.Text
            dr(0).Item("FeeAmt") = Me.txtFeeAmt.Text
            dr(0).Item("Region") = Me.RegionString()
            dr(0).Item("Country") = Me.CountryString()
            dr(0).Item("City") = Me.CityString()
        End If
    End Sub

    Private Sub RefreshClassGrid()
        Dim dv As New DataView()
        With dv
            .Table = Me.ClassTable
            .Sort = "ItemNo"
        End With
        With Me.gdDataClass
            .DataSource = dv.ToTable()
            .DataBind()
        End With
    End Sub

    Public Sub gdDataClass_Command(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.CommandEventArgs)
        Select Case e.CommandName
            Case "delete"
                Call Me.RemoveClassData(Util.DBNullToZero(e.CommandArgument))
            Case "edit"
                Call Me.LoadClassData(Util.DBNullToZero(e.CommandArgument))
                Me.btnSave.Text = "Update"
                Me.CurrentPNRInfo = Me.PagePNR.PNRList(Me.txtItemNo.Value)
        End Select
        Call Me.RefreshClassGrid()
    End Sub

    Protected Sub btnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSave.Click
        Dim ItemNo As String = ""
        ItemNo = Me.txtItemNo.Value
        If ItemNo = "" Then
            Call Me.AddClassData()
        Else
            Call Me.UpdateClassData(ItemNo)
        End If
        Call Me.RefreshClassGrid()
        Call Me.LoadNewData()
    End Sub

    Protected Sub btnCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        Call Me.LoadNewData()
    End Sub
#End Region

#Region "Region Settings"
    Private Sub SetSelectedRegion()
        Dim RegionList As New List(Of String)
        Dim SelectedIndex() As Integer
        Dim itm As DataInfo.RegionDataInfo
        SelectedIndex = Me.ddlRegion.GetSelectedIndices
        If SelectedIndex.Length <= 0 Then
            Me.divEmpty.Visible = True
            Exit Sub
        End If
        For i As Integer = 0 To SelectedIndex.Length - 1
            itm = New DataInfo.RegionDataInfo()
            With itm
                .RegionCode = Me.ddlRegion.Items(SelectedIndex(i)).Value
                .RegionName = Me.ddlRegion.Items(SelectedIndex(i)).Text
            End With
            Me.CurrentPNRInfo.RegionSelectedItems.Add(itm)
        Next
        Me.divEmpty.Visible = False
        Me.lblSelectedRegionAmt.Text = Me.gdRegion.Rows.Count.ToString
    End Sub

    Private Sub SetAllRegion()
        Dim RegionList As New List(Of String)
        Dim itm As DataInfo.RegionDataInfo
        If Me.ddlRegion.Items.Count <= 0 Then
            Me.divEmpty.Visible = True
            Exit Sub
        End If
        For i As Integer = 0 To Me.ddlRegion.Items.Count - 1
            itm = New DataInfo.RegionDataInfo()
            With itm
                .RegionCode = Me.ddlRegion.Items(i).Value
                .RegionName = Me.ddlRegion.Items(i).Text
            End With
            Me.CurrentPNRInfo.RegionSelectedItems.Add(itm)
        Next
        Me.divEmpty.Visible = False
        Me.lblSelectedRegionAmt.Text = Me.gdRegion.Rows.Count.ToString
    End Sub

    Private Sub RemoveRegion()
        Dim chk As CWTCustomControls.CWTCheckBox
        Dim hid As HiddenField
        Dim ItemCode As String
        Dim index As Integer
        Dim filter As String = ""
        If Me.gdRegion.Rows.Count <= 0 Then
            Exit Sub
        End If
        For i As Integer = 0 To Me.gdRegion.Rows.Count - 1
            chk = Me.gdRegion.Rows(i).FindControl("chkCheckRegion")
            If chk IsNot Nothing AndAlso chk.Checked Then
                hid = Me.gdRegion.Rows(i).FindControl("hidRegionCode")
                ItemCode = hid.Value
                index = Me.CurrentPNRInfo.RegionIndexOf(ItemCode)
                If index >= 0 Then
                    Me.CurrentPNRInfo.RegionSelectedItems.RemoveAt(index)
                End If
            End If
        Next
        If Me.CurrentPNRInfo.RegionSelectedItems.Count <= 0 Then
            Me.divEmpty.Visible = True
        End If
    End Sub

    Private Sub RefreshRegion()
        With Me.gdRegion
            .DataSource = Me.CurrentPNRInfo.ToRegionTable()
            .DataBind()
        End With
        '//
        Dim BLL As New BusinessLogicLayer.ConfigurationBLL()
        Dim oDataTable As DataTable
        oDataTable = BLL.GetRegion(True)
        With Me.ddlRegion
            .DataTextField = "Description"
            .DataValueField = "RegionCode"
            If Me.RegionString <> "" Then
                Dim vFilter As DataView
                vFilter = New DataView(oDataTable, "RegionCode not in (" + Me.RegionString + ")", "", DataViewRowState.CurrentRows)
                .DataSource = vFilter.ToTable()
            Else
                .DataSource = oDataTable
            End If
            .DataBind()
        End With
    End Sub

    Protected Sub btnAdd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnAdd.Click
        Call Me.SetSelectedRegion()
        Call Me.RefreshRegion()
    End Sub

    Protected Sub btnRemove_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnRemove.Click
        Call Me.RemoveRegion()
        Call Me.RefreshRegion()
    End Sub

    Protected Sub btnSelAll_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSelAll.Click
        Call Me.SetAllRegion()
        Call Me.RefreshRegion()
    End Sub
#End Region

#Region "Country Settings"
    Private Sub SetSelectedCountry()
        Dim RegionList As New List(Of String)
        Dim SelectedIndex() As Integer
        Dim itm As DataInfo.CountryDataInfo
        SelectedIndex = Me.ddlCountry.GetSelectedIndices
        If SelectedIndex.Length <= 0 Then
            Me.divEmpty2.Visible = True
            Exit Sub
        End If
        For i As Integer = 0 To SelectedIndex.Length - 1
            itm = New DataInfo.CountryDataInfo()
            With itm
                .LinkRegion.RegionCode = Me.ddlRegion2.SelectedValue
                .LinkRegion.RegionName = Me.ddlRegion2.SelectedItem.Text
                .CountryCode = Me.ddlCountry.Items(SelectedIndex(i)).Value
                .CountryName = Me.ddlCountry.Items(SelectedIndex(i)).Text
            End With
            Me.CurrentPNRInfo.CountrySelectedItems.Add(itm)
        Next
        Me.divEmpty2.Visible = False
        Me.lblSelectedCountryAmt.Text = Me.gdCountry.Rows.Count.ToString
    End Sub

    Private Sub SetAllCountry()
        Dim CountryList As New List(Of String)
        Dim itm As DataInfo.CountryDataInfo
        If Me.ddlCountry.Items.Count <= 0 Then
            Me.divEmpty2.Visible = True
            Exit Sub
        End If
        For i As Integer = 0 To Me.ddlCountry.Items.Count - 1
            itm = New DataInfo.CountryDataInfo()
            With itm
                .CountryCode = Me.ddlCountry.Items(i).Value
                .CountryName = Me.ddlCountry.Items(i).Text
            End With
            Me.CurrentPNRInfo.CountrySelectedItems.Add(itm)
        Next
        Me.divEmpty2.Visible = False
        Me.lblSelectedCountryAmt.Text = Me.gdCountry.Rows.Count.ToString
    End Sub

    Private Sub RemoveCountry()
        Dim chk As CWTCustomControls.CWTCheckBox
        Dim hid As HiddenField
        Dim ItemCode As String
        Dim index As Integer
        Dim filter As String = ""
        If Me.gdCountry.Rows.Count <= 0 Then
            Exit Sub
        End If
        For i As Integer = 0 To Me.gdCountry.Rows.Count - 1
            chk = Me.gdCountry.Rows(i).FindControl("chkCheckCountry")
            If chk IsNot Nothing AndAlso chk.Checked Then
                hid = Me.gdCountry.Rows(i).FindControl("hidCountryCode")
                ItemCode = hid.Value
                index = Me.CurrentPNRInfo.CountryIndexOf(ItemCode)
                If index >= 0 Then
                    Me.CurrentPNRInfo.CountrySelectedItems.RemoveAt(index)
                End If
            End If
        Next
        If Me.CurrentPNRInfo.CountrySelectedItems.Count <= 0 Then
            Me.divEmpty2.Visible = True
        End If
    End Sub

    Private Sub RefreshCountry()
        With Me.gdCountry
            .DataSource = Me.CurrentPNRInfo.ToCountryTable()
            .DataBind()
        End With
        '//
        Dim BLL As New BusinessLogicLayer.ConfigurationBLL()
        Dim oDataTable As DataTable
        Dim RegionCode As String
        RegionCode = Me.ddlRegion2.SelectedValue
        oDataTable = BLL.GetCountryByRegion(RegionCode)
        With Me.ddlCountry
            .DataTextField = "CountryName"
            .DataValueField = "CountryCode"
            If Me.CountryString <> "" Then
                Dim vFilter As DataView
                vFilter = New DataView(oDataTable, "CountryCode not in (" + Me.CountryString + ")", "", DataViewRowState.CurrentRows)
                .DataSource = vFilter.ToTable()
            Else
                .DataSource = oDataTable
            End If
            .DataSource = oDataTable
            .DataBind()
        End With
    End Sub

    Protected Sub btnAdd2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnAdd2.Click
        Call Me.SetSelectedCountry()
        Call Me.RefreshCountry()
    End Sub

    Protected Sub btnRemove2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnRemove2.Click
        Call Me.RemoveRegion()
        Call Me.RefreshRegion()
    End Sub

    Protected Sub btnSelAll2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSelAll2.Click
        Call Me.SetAllCountry()
        Call Me.RefreshRegion()
    End Sub
#End Region

#Region "City Settings"
    Private Sub SetSelectedCity()
        Dim RegionList As New List(Of String)
        Dim SelectedIndex() As Integer
        Dim itm As DataInfo.CityDataInfo
        SelectedIndex = Me.ddlCity.GetSelectedIndices
        If SelectedIndex.Length <= 0 Then
            Me.divEmpty3.Visible = True
            Exit Sub
        End If
        For i As Integer = 0 To SelectedIndex.Length - 1
            itm = New DataInfo.CityDataInfo()
            With itm
                .LinkCountry.LinkRegion.RegionCode = Me.ddlRegion3.SelectedValue
                .LinkCountry.LinkRegion.RegionName = Me.ddlRegion3.SelectedItem.Text
                .LinkCountry.CountryCode = Me.ddlCountry2.SelectedValue
                .LinkCountry.CountryName = Me.ddlCountry2.SelectedItem.Text
                .CityCode = Me.ddlCity.Items(SelectedIndex(i)).Value
                .CityName = Me.ddlCity.Items(SelectedIndex(i)).Text
            End With
            Me.CurrentPNRInfo.CitySelectedItems.Add(itm)
        Next
        Me.divEmpty3.Visible = False
        Me.lblSelectedCityAmt.Text = Me.gdCity.Rows.Count.ToString
    End Sub

    Private Sub SetAllCity()
        Dim CityList As New List(Of String)
        Dim itm As DataInfo.CityDataInfo
        If Me.ddlCity.Items.Count <= 0 Then
            Me.divEmpty3.Visible = True
            Exit Sub
        End If
        For i As Integer = 0 To Me.ddlCity.Items.Count - 1
            itm = New DataInfo.CityDataInfo()
            With itm
                .CityCode = Me.ddlCity.Items(i).Value
                .CityName = Me.ddlCity.Items(i).Text
            End With
            Me.CurrentPNRInfo.CitySelectedItems.Add(itm)
        Next
        Me.divEmpty3.Visible = False
        Me.lblSelectedCityAmt.Text = Me.gdCity.Rows.Count.ToString
    End Sub

    Private Sub RemoveCity()
        Dim chk As CWTCustomControls.CWTCheckBox
        Dim hid As HiddenField
        Dim ItemCode As String
        Dim index As Integer
        Dim filter As String = ""
        If Me.gdCity.Rows.Count <= 0 Then
            Exit Sub
        End If
        For i As Integer = 0 To Me.gdCity.Rows.Count - 1
            chk = Me.gdCity.Rows(i).FindControl("chkCheckCity")
            If chk IsNot Nothing AndAlso chk.Checked Then
                hid = Me.gdCity.Rows(i).FindControl("hidCityCode")
                ItemCode = hid.Value
                index = Me.CurrentPNRInfo.CityIndexOf(ItemCode)
                If index >= 0 Then
                    Me.CurrentPNRInfo.CitySelectedItems.RemoveAt(index)
                End If
            End If
        Next
        If Me.CurrentPNRInfo.CitySelectedItems.Count <= 0 Then
            Me.divEmpty3.Visible = True
        End If
    End Sub

    Private Sub RefreshCity()
        With Me.gdCity
            .DataSource = Me.CurrentPNRInfo.ToCityTable()
            .DataBind()
        End With
        '//
        Call Me.LoadCity()
    End Sub

    Protected Sub btnAdd3_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnAdd3.Click
        Call Me.SetSelectedCity()
        Call Me.RefreshCity()
    End Sub

    Protected Sub btnRemove3_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnRemove3.Click
        Call Me.RemoveCity()
        Call Me.RefreshCity()
    End Sub

    Protected Sub btnSelAll3_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSelAll3.Click
        Call Me.SetAllCity()
        Call Me.RefreshCity()
    End Sub
#End Region

#Region "General"
    Private Sub LoadRegion()
        Dim BLL As New BusinessLogicLayer.ConfigurationBLL()
        Dim oDataTable As DataTable
        oDataTable = BLL.GetRegion(True)
        With Me.ddlRegion
            .DataTextField = "Description"
            .DataValueField = "RegionCode"
            If Me.RegionString <> "" Then
                Dim vFilter As DataView
                vFilter = New DataView(oDataTable, "RegionCode not in (" + Me.RegionString + ")", "", DataViewRowState.CurrentRows)
                .DataSource = vFilter.ToTable()
            Else
                .DataSource = oDataTable
            End If
            .DataBind()
        End With
        With Me.ddlRegion2
            .DataTextField = "Description"
            .DataValueField = "RegionCode"
            .DataSource = oDataTable
            .DataBind()
        End With
        With Me.ddlRegion3
            .DataTextField = "Description"
            .DataValueField = "RegionCode"
            .DataSource = oDataTable
            .DataBind()
        End With
        If oDataTable.Rows.Count > 0 Then
            Call Me.LoadCountry()
        End If
    End Sub

    Private Sub LoadCountry()
        Dim BLL As New BusinessLogicLayer.ConfigurationBLL()
        Dim oDataTable As DataTable
        Dim RegionCode As String
        RegionCode = Me.ddlRegion2.SelectedValue
        oDataTable = BLL.GetCountryByRegion(RegionCode)
        With Me.ddlCountry
            .DataTextField = "CountryName"
            .DataValueField = "CountryCode"
            If Me.CountryString <> "" Then
                Dim vFilter As DataView
                vFilter = New DataView(oDataTable, "CountryCode not in (" + Me.CountryString + ")", "", DataViewRowState.CurrentRows)
                .DataSource = vFilter.ToTable()
            Else
                .DataSource = oDataTable
            End If
            .DataSource = oDataTable
            .DataBind()
        End With
        With Me.ddlCountry2
            .DataTextField = "CountryName"
            .DataValueField = "CountryCode"
            .DataBind()
        End With
        If oDataTable.Rows.Count > 0 Then
            Call Me.LoadCity()
        End If
    End Sub

    Private Sub LoadCity()
        Dim BLL As New BusinessLogicLayer.ConfigurationBLL()
        Dim oDataTable As DataTable
        Dim CountryCode As String

        CountryCode = Me.ddlCountry2.SelectedValue
        oDataTable = New DataTable()
        oDataTable = BLL.GetCity(CountryCode, "")
        With Me.ddlCity
            .DataTextField = "City"
            .DataValueField = "CityCode"
            If Me.CityString <> "" Then
                Dim vFilter As DataView
                vFilter = New DataView(oDataTable, "CityCode not in (" + Me.CityString + ")", "", DataViewRowState.CurrentRows)
                .DataSource = vFilter.ToTable()
            Else
                .DataSource = oDataTable
            End If
            .DataBind()
        End With
    End Sub

    Private Sub LoadDropdownList()
        Call Me.LoadRegion()
        Call Me.LoadCountry()
        Call Me.LoadCity()
    End Sub

    Private Sub LoadCountryByRegion2()
        Dim BLL As New BusinessLogicLayer.ConfigurationBLL()
        Dim oDataTable As DataTable
        Dim RegionCode As String
        RegionCode = Me.ddlRegion2.SelectedValue
        oDataTable = BLL.GetCountryByRegion(RegionCode)
        With Me.ddlCountry
            .DataTextField = "CountryName"
            .DataValueField = "CountryCode"
            .DataSource = oDataTable
            .DataBind()
        End With
    End Sub

    Private Sub LoadCountryByRegion3()
        Dim BLL As New BusinessLogicLayer.ConfigurationBLL()
        Dim oDataTable As DataTable
        Dim RegionCode As String
        RegionCode = Me.ddlRegion3.SelectedValue
        oDataTable = BLL.GetCountryByRegion(RegionCode)
        With Me.ddlCountry2
            .DataTextField = "CountryName"
            .DataValueField = "CountryCode"
            .DataSource = oDataTable
            .DataBind()
        End With
        Call Me.LoadCity()
    End Sub

    Protected Sub ddlRegion2_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlRegion2.SelectedIndexChanged
        Call Me.LoadCountryByRegion2()
    End Sub

    Protected Sub ddlRegion3_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlRegion3.SelectedIndexChanged
        Call Me.LoadCountryByRegion3()
    End Sub

    Protected Sub ddlCountry2_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlCountry2.SelectedIndexChanged
        Call Me.LoadCity()
    End Sub
#End Region

#Region "Data Binding"
    Private Sub LoadNewData()
        Me.txtItemNo.Value = ""
        Me.txtStartAmount.Text = "0"
        Me.txtEndAmount.Text = "0"
        Me.txtFeeAmt.Text = "0"
        Me.btnSave.Text = "Add"
        Me.CurrentPNRInfo = New DataInfo.PNRItemInfo()
    End Sub

    Private Sub LoadDataFromDB()
        Dim FeeName As String
        FeeName = Me.BLL.GetFeeNameByID(Me.RecordID, DataInfo.AirFeeInfo.AirFeeManagerType.FeeByPNR)
        Me.txtName.Text = FeeName
        Call Me.LoadClassDataFromDB()
    End Sub
#End Region

#Region "Data Transaction"
    Private Sub SaveData(ByVal IsNext As Boolean)
        Dim info As New DataInfo.TransCouponInfo()
        Dim Amount As DataInfo.CouponInfo
        Dim r As DataRow
        With info
            .PageMode = Me.CurrentPageMode
            .FeeID = Me.RecordID
            .FeeName = Me.txtName.Text
            For i As Integer = 0 To Me.ClassTable.Rows.Count - 1
                r = Me.ClassTable.Rows(i)
                Amount = New DataInfo.CouponInfo()
                With Amount
                    .StartCoupon = r("StartAmount")
                    .EndCoupon = r("EndAmount")
                    .Type = r("ItemType")
                    .Threshold = r("Threshold")
                    .FeeAmt = r("FeeAmt")
                End With
                .CouponList.Add(Amount)
            Next
        End With
        If Me.BLL.UpdateFeeByCouponData(info) > 0 Then
            Me.lblMsgBox.Text = Util.GetAppConfig(Util.MsgType.TRANS_SUCCESS.ToString)
            Me.lblMsgBox.ForeColor = Drawing.Color.Green
            Me.ajaxMsgBox.Show()
        Else
            Me.lblMsgBox.Text = Util.GetAppConfig(Util.MsgType.TRANS_ERROR.ToString)
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.ajaxMsgBox.Show()
        End If
    End Sub
#End Region

#Region "Page Control Event Handlers"
    Protected Sub btnTrans_OnCancel(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans.OnCancel
        Response.Redirect("AirFeeManager.aspx")
    End Sub

    Protected Sub btnTrans_OnSave(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans.OnSave
        Call Me.SaveData(False)
    End Sub
#End Region

End Class
@


1.1.1.1
log
@no message
@
text
@@
