head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.07.01;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.07.01;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@
Partial Class Web_DivisionManager
    Inherits BasePage

    Private BLL As BusinessLogicLayer.DivisionBLL
    Private BLL2 As BusinessLogicLayer.StaffBLL
    Private BLL3 As BusinessLogicLayer.tblFunctionBLL

    Private Enum NodeDataType
        Division
        Agent
    End Enum

    Protected Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.BLL = New BusinessLogicLayer.DivisionBLL
        Me.BLL2 = New BusinessLogicLayer.StaffBLL()
        Me.BLL3 = New BusinessLogicLayer.tblFunctionBLL()
        'Call Me.LoadTree()

        If Not IsPostBack Then
            'Call Me.LoadData(NodeDataType.Division, True)
            Call Me.LoadDivision()
        End If
        Call Me.AccessControl("Agent & Division")
    End Sub


    Private Sub AccessControl(ByVal title As String)

        Dim userName As String
        Dim oDatatable As DataTable
        Dim oDataTable2 As DataTable

        Static roleID As String

        userName = ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName
        oDatatable = Me.BLL2.GetUserByID(userName)

        If oDatatable.Rows.Count > 0 Then
            roleID = oDatatable.Rows(0).Item("RoleID").ToString
        End If

        oDataTable2 = Me.BLL3.GetUserRole(roleID)
        If oDataTable2.Rows.Count > 0 Then
            For k As Integer = 0 To oDataTable2.Rows.Count - 1
                If oDataTable2.Rows(k).Item("functionGroup") = "0" Then
                    If oDataTable2.Rows(k).Item("Permission") = "V" Then
                        If oDataTable2.Rows(k).Item("functionName").ToString = title Then
                            Call Me.toggleControl()

                        End If
                    End If
                End If

            Next

        End If


    End Sub

    Private Sub toggleControl()

        Me.hrefAdd.Enabled = False

    End Sub

    Private Sub LoadDivision()
        Dim oDataTable As DataTable



        oDataTable = Me.BLL.GetDivisionList()
        With Me.gdView
            .DataSource = oDataTable
            .DataBind()
        End With
        With Me.pgControl2
            .GridID = Me.gdView.UniqueID
            .SetBindGrid()
        End With

        Me.gdView.Visible = True
        Me.pgControl2.Visible = True
        Me.gdData.Visible = False
        Me.pgControl.Visible = False
        Me.gdData.Columns.Clear()
    End Sub

    Private Sub LoadDivision2()

        Me.gdData.Visible = True
        Me.pgControl.Visible = True
        Me.gdView.Columns.Clear()
        Me.gdView.Visible = False
        Me.pgControl2.Visible = False


        Dim oDataTable As DataTable


        oDataTable = Me.BLL.GetDivisionList2(Me.txtFieldID.Text, Me.txtFieldName.Text, Me.txtUID.Text, Me.txtAgentName.Text, Me.txtSignOn.Text)
        With Me.gdData
            .DataSource = oDataTable
            .DataBind()
        End With
        With Me.pgControl
            .GridID = Me.gdData.UniqueID
            .SetBindGrid()
        End With
    End Sub


    'Private Sub LoadTree()
    '    Dim oDataTable As DataTable
    '    Dim oRow As DataRow
    '    Dim CurrentDiv As String = ""
    '    Dim root As New TreeNode()
    '    Dim node As TreeNode
    '    oDataTable = Me.BLL.GetDivisionAgentTree()
    '    Me.treeDivList.Nodes.Clear()
    '    If oDataTable IsNot Nothing AndAlso oDataTable.Rows.Count > 0 Then
    '        For i As Integer = 0 To oDataTable.Rows.Count - 1
    '            oRow = oDataTable.Rows(i)
    '            If oRow("DivID").ToString() <> CurrentDiv Then
    '                If CurrentDiv <> "" Then
    '                    Me.treeDivList.Nodes.Add(root)
    '                End If
    '                CurrentDiv = oRow("DivID").ToString()
    '                root = New TreeNode()
    '                With root
    '                    .Text = oRow("DivisionDesc").ToString()
    '                    .Value = oRow("DivID").ToString()
    '                End With
    '            End If
    '            node = New TreeNode()
    '            With node
    '                .Text = oRow("AgentID").ToString()
    '                .Value = oRow("AgentID").ToString()
    '            End With
    '            root.ChildNodes.Add(node)
    '        Next
    '        Me.treeDivList.Nodes.Add(root)
    '    End If
    '    Me.treeDivList.ExpandAll()
    'End Sub

    'Private Sub LoadData(ByVal Type As NodeDataType, ByVal IsNew As Boolean)
    '    '//
    '    Select Case Type
    '        Case NodeDataType.Division
    '            Me.UcDivision1.Visible = True
    '            Me.UcAgent1.Visible = False
    '            If IsNew Then
    '                Me.UcDivision1.NewDivision()
    '            Else
    '                Me.UcDivision1.LoadDivision(Me.treeDivList.SelectedNode.Value)
    '            End If
    '        Case NodeDataType.Agent
    '            Me.UcDivision1.Visible = False
    '            Me.UcAgent1.Visible = True
    '            If IsNew Then
    '                Me.UcAgent1.NewAgent()
    '            Else
    '                Me.UcAgent1.LoadAgent(Me.treeDivList.SelectedNode.Value)
    '            End If
    '    End Select
    'End Sub

    'Protected Sub treeDivList_SelectedNodeChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles treeDivList.SelectedNodeChanged
    '    If Me.treeDivList.SelectedNode.Parent Is Nothing Then
    '        Call Me.LoadData(NodeDataType.Division, False)
    '    Else
    '        Call Me.LoadData(NodeDataType.Agent, False)
    '    End If
    'End Sub

    'Protected Sub btnAddDiv_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnAddDiv.Click
    '    Call Me.LoadData(NodeDataType.Division, True)
    'End Sub

    'Protected Sub btnAddAgent_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnAddAgent.Click
    '    Call Me.LoadData(NodeDataType.Agent, True)
    'End Sub

    'Protected Sub UcDivision1_CompleteTransaction(ByVal sender As Object, ByVal e As System.EventArgs) Handles UcDivision1.CompleteTransaction
    '    Call Me.LoadTree()
    '    Call LoadData(NodeDataType.Division, True)
    'End Sub
    'Protected Sub UcAgent1_CompleteTransaction(ByVal sender As Object, ByVal e As System.EventArgs) Handles UcAgent1.CompleteTransaction
    '    Call Me.LoadTree()
    '    Call LoadData(NodeDataType.Agent, True)
    'End Sub

    'Protected Sub UcDivision1_CancelTransaction(ByVal sender As Object, ByVal e As System.EventArgs) Handles UcDivision1.CancelTransaction
    '    Call Me.LoadTree()
    '    Call Me.LoadData(NodeDataType.Division, True)
    'End Sub
    'Protected Sub UcAgent1_CancelTransaction(ByVal sender As Object, ByVal e As System.EventArgs) Handles UcAgent1.CancelTransaction
    '    Call Me.LoadTree()
    '    Call Me.LoadData(NodeDataType.Division, True)
    'End Sub
    Private Sub DeleteProduct(ByVal Number As Integer)

    End Sub

    Public Sub gdData_Command(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.CommandEventArgs)
        Select Case e.CommandName
            Case "delete"
                Call Me.DeleteProduct(Util.DBNullToZero(Convert.ToInt16(e.CommandArgument)))
        End Select
        Call Me.LoadDivision()
    End Sub

    Protected Sub gdData_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gdData.RowDataBound
        Dim cwtLinkBtn As CWTCustomControls.CWTLinkButton

        cwtLinkBtn = TryCast(e.Row.FindControl("hrefDeleteItem"), CWTCustomControls.CWTLinkButton)

        If cwtLinkBtn IsNot Nothing Then
            cwtLinkBtn.PermissionInfo = Me.usrInfo
            cwtLinkBtn.Attributes.Add("onclick", "return confirm('Product will delete, continue?');")
        End If
    End Sub

    Public Sub gdView_Command(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.CommandEventArgs)
        Select Case e.CommandName
            Case "delete"
                Call Me.DeleteProduct(Util.DBNullToZero(Convert.ToInt16(e.CommandArgument)))
        End Select
        Call Me.LoadDivision()
    End Sub

    Protected Sub gdView_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gdView.RowDataBound
        Dim cwtLinkBtn As CWTCustomControls.CWTLinkButton

        cwtLinkBtn = TryCast(e.Row.FindControl("hrefDeleteItem"), CWTCustomControls.CWTLinkButton)

        If cwtLinkBtn IsNot Nothing Then
            cwtLinkBtn.PermissionInfo = Me.usrInfo
            cwtLinkBtn.Attributes.Add("onclick", "return confirm('Product will delete, continue?');")
        End If
    End Sub



    Protected Sub btnSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSearch.Click
        Dim oDataTable As DataTable

        If Me.txtFieldID.Text = "" And Me.txtFieldName.Text = "" And Me.txtUID.Text = "" And Me.txtAgentName.Text = "" And Me.txtSignOn.Text = "" Then
            Call Me.LoadDivision()
        Else
            If Me.txtAgentName.Text <> "" And Me.txtUID.Text <> "" And Me.txtSignOn.Text <> "" Then
                oDataTable = Me.BLL.GetDivisionList2(Me.txtFieldID.Text, Me.txtFieldName.Text, Me.txtUID.Text, Me.txtAgentName.Text, Me.txtSignOn.Text)

                If oDataTable.Rows.Count = 1 Then
                    Response.Redirect("DivisionUpdateManager.aspx?mode=edit1&id=" + oDataTable.Rows(0).Item("DivisionID") + " &name=" + oDataTable.Rows(0).Item("FirstName") + " &uid=" + oDataTable.Rows(0).Item("AgentID") + " ")
                    Exit Sub
                Else
                    LoadDivision2()
                End If
            ElseIf Me.txtAgentName.Text <> "" And Me.txtUID.Text = "" And Me.txtSignOn.Text = "" Then
                oDataTable = Me.BLL.GetDivisionList2(Me.txtFieldID.Text, Me.txtFieldName.Text, Me.txtUID.Text, Me.txtAgentName.Text, Me.txtSignOn.Text)

                If oDataTable.Rows.Count = 1 Then
                    Response.Redirect("DivisionUpdateManager.aspx?mode=edit1&id=" + oDataTable.Rows(0).Item("DivisionID") + " &name=" + oDataTable.Rows(0).Item("FirstName") + " &uid=" + oDataTable.Rows(0).Item("AgentID") + " ")
                    Exit Sub
                Else
                    LoadDivision2()
                End If
            ElseIf Me.txtAgentName.Text = "" And Me.txtUID.Text <> "" And Me.txtSignOn.Text = "" Then
                oDataTable = Me.BLL.GetDivisionList2(Me.txtFieldID.Text, Me.txtFieldName.Text, Me.txtUID.Text, Me.txtAgentName.Text, Me.txtSignOn.Text)

                If oDataTable.Rows.Count = 1 Then
                    Response.Redirect("DivisionUpdateManager.aspx?mode=edit1&id=" + oDataTable.Rows(0).Item("DivisionID") + " &name=" + oDataTable.Rows(0).Item("FirstName") + " &uid=" + oDataTable.Rows(0).Item("AgentID") + " ")
                    Exit Sub
                Else
                    LoadDivision2()
                End If
            ElseIf Me.txtAgentName.Text = "" And Me.txtUID.Text = "" And Me.txtSignOn.Text <> "" Then
                oDataTable = Me.BLL.GetDivisionList2(Me.txtFieldID.Text, Me.txtFieldName.Text, Me.txtUID.Text, Me.txtAgentName.Text, Me.txtSignOn.Text)

                If oDataTable.Rows.Count = 1 Then
                    Response.Redirect("DivisionUpdateManager.aspx?mode=edit1&id=" + oDataTable.Rows(0).Item("DivisionID") + " &name=" + oDataTable.Rows(0).Item("FirstName") + " &uid=" + oDataTable.Rows(0).Item("AgentID") + " ")
                    Exit Sub
                Else
                    LoadDivision2()
                End If
            Else
                LoadDivision2()
            End If

        End If
        Call Me.AccessControl("Agent & Division")
    End Sub
End Class
@


1.1.1.1
log
@no message
@
text
@@
