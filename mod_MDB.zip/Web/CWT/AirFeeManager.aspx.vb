head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.07.00;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.07.00;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports System.Web.Services
Imports System.Web.Script.Services

Partial Class Web_CWT_AirFeeManager
    Inherits BasePage

    Private BLL As BusinessLogicLayer.AirFeeBLL
    Private BLL2 As BusinessLogicLayer.StaffBLL
    Private BLL3 As BusinessLogicLayer.tblFunctionBLL

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.BLL = New BusinessLogicLayer.AirFeeBLL()
        Me.BLL2 = New BusinessLogicLayer.StaffBLL()
        Me.BLL3 = New BusinessLogicLayer.tblFunctionBLL()

        If Not IsPostBack Then
            With Me.gdData
                .DataSource = New DataTable()
                .DataBind()
            End With
            Me.hrefAdd.PostBackUrl = "AirFeeByPNR.aspx?mode=add"
        End If
        Call Me.AccessControl("Fee")
    End Sub

    Private Sub AccessControl(ByVal title As String)

        Dim userName As String
        Dim oDatatable As DataTable
        Dim oDataTable2 As DataTable

        Static roleID As String

        userName = ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName
        oDatatable = Me.BLL2.GetUserByID(userName)

        If oDatatable.Rows.Count > 0 Then
            roleID = oDatatable.Rows(0).Item("RoleID").ToString
        End If

        oDataTable2 = Me.BLL3.GetUserRole(roleID)
        If oDataTable2.Rows.Count > 0 Then
            For k As Integer = 0 To oDataTable2.Rows.Count - 1
                If oDataTable2.Rows(k).Item("functionGroup") = "0" Then
                    If oDataTable2.Rows(k).Item("Permission") = "V" Then
                        If oDataTable2.Rows(k).Item("functionName").ToString = title Then
                            Call Me.toggleControl()

                        End If
                    End If
                End If

            Next

        End If


    End Sub

    Private Sub toggleControl()


        Me.hrefAdd.Enabled = False

       

    End Sub


    Private Sub LoadDataGrid()
        Dim oDataTable As DataTable
        oDataTable = Me.BLL.GetFeeList(Me.txtName.Text, Util.DBNullToZero(Me.ddlField.SelectedValue))
        With Me.gdData
            .DataSource = oDataTable
            .DataBind()
        End With
        With Me.pgControl
            .GridID = Me.gdData.UniqueID
            .SetBindGrid()
        End With
    End Sub

    Protected Sub btnSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSearch.Click
        Call Me.LoadDataGrid()
        Call Me.AccessControl("Fee")
    End Sub

    Protected Sub ddlField_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlField.SelectedIndexChanged
        Dim FieldType As DataInfo.AirFeeInfo.AirFeeManagerType
        FieldType = Util.DBNullToZero(Me.ddlField.SelectedValue)
        '//
        Me.AutoCompleteExtender1.ContextKey = FieldType.ToString
        '//
        Select Case FieldType
            Case DataInfo.AirFeeInfo.AirFeeManagerType.FeeByPNR
                Me.hrefAdd.PostBackUrl = "AirFeeByPNR.aspx?mode=add"
            Case DataInfo.AirFeeInfo.AirFeeManagerType.FeeByTicket
                Me.hrefAdd.PostBackUrl = "AirFeeByTicket.aspx?mode=add"
            Case DataInfo.AirFeeInfo.AirFeeManagerType.FeeByCoupon
                Me.hrefAdd.PostBackUrl = "AirFeeByCoupon.aspx?mode=add"
            Case DataInfo.AirFeeInfo.AirFeeManagerType.ConditionalMarkUp
                Me.hrefAdd.PostBackUrl = "AirFeeByConditional.aspx?mode=add"
        End Select
        Me.txtName.Text = ""
    End Sub

    Public Function GetURL(ByVal FeeID As String) As String
        Dim url As String
        Dim FieldType As DataInfo.AirFeeInfo.AirFeeManagerType
        FieldType = Util.DBNullToZero(Me.ddlField.SelectedValue)
        Select Case FieldType
            Case DataInfo.AirFeeInfo.AirFeeManagerType.FeeByPNR
                url = "AirFeeByPNR.aspx?mode=edit&id=" + FeeID
            Case DataInfo.AirFeeInfo.AirFeeManagerType.FeeByTicket
                url = "AirFeeByTicket.aspx?mode=edit&id=" + FeeID
            Case DataInfo.AirFeeInfo.AirFeeManagerType.FeeByCoupon
                url = "AirFeeByCoupon.aspx?mode=edit&id=" + FeeID
            Case DataInfo.AirFeeInfo.AirFeeManagerType.ConditionalMarkUp
                url = "AirFeeByConditional.aspx?mode=edit&id=" + FeeID
            Case Else
                url = ""
        End Select
        Return url
    End Function

#Region "Webservices Methods"
    <WebMethod(), ScriptMethod()> _
    Public Shared Function GetFeeName(ByVal prefixText As String, ByVal count As Integer, ByVal contextKey As String) As String()
        Dim CompBLL As New BusinessLogicLayer.AirFeeBLL()
        Return CompBLL.GetFeeName(prefixText, contextKey)
    End Function
#End Region

End Class
@


1.1.1.1
log
@no message
@
text
@@
