head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.07.00;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.07.00;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@
Partial Class Web_CWT_AuxFeeManager
    Inherits BasePage

    Private BLL As BusinessLogicLayer.AuxPricingBLL

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.BLL = New BusinessLogicLayer.AuxPricingBLL()
        If Not IsPostBack Then
            Call Me.LoadDropDownList()
            Call Me.LoadDataGrid()
        End If
    End Sub

    Private Sub LoadDropDownList()
        Dim oDataTable As DataTable
        oDataTable = Me.BLL.GetProductList()
        With Me.ddlProduct
            .DataTextField = "Name"
            .DataValueField = "Number"
            .DataSource = oDataTable
            .DataBind()
        End With
    End Sub

    Private Sub LoadDataGrid()
        Dim oDataTable As DataTable
        oDataTable = Me.BLL.GetAuxPricingList(Me.txtFeeName.Text, Me.ddlProduct.SelectedValue)
        With Me.gdData
            .DataSource = oDataTable
            .DataBind()
        End With
        With Me.pgControl
            .GridID = Me.gdData.UniqueID
            .SetBindGrid()
        End With
    End Sub

    Private Sub DeleteFuelCharge(ByVal AirlineCode As String)

    End Sub

    Protected Sub btnSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSearch.Click
        Me.lblProduct.Text = Me.ddlProduct.SelectedItem.Text
        Call Me.LoadDataGrid()
    End Sub

#Region "Control Event"
    Public Sub gdData_Command(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.CommandEventArgs)
        Select Case e.CommandName
            Case "DeleteItem"
                'Call Me.DeleteFuelCharge(Util.DBNullToZero(e.CommandArgument))
        End Select
        Call Me.LoadDataGrid()
    End Sub

    Protected Sub gdData_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gdData.RowDataBound

    End Sub
#End Region

End Class
@


1.1.1.1
log
@no message
@
text
@@
