head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.59;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.59;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@
Partial Class Web_CWT_AirFeeByConditional
    Inherits BasePage

#Region "Page Properties & Variables"
    Private BLL As BusinessLogicLayer.AirFeeBLL
    Private BLL2 As BusinessLogicLayer.StaffBLL
    Private BLL3 As BusinessLogicLayer.tblFunctionBLL

    Private Property ClassTable() As DataTable
        Get
            Return Me.ViewState("_ClassTable")
        End Get
        Set(ByVal value As DataTable)
            Me.ViewState("_ClassTable") = value
        End Set
    End Property

    Public Property RecordID() As String
        Get
            Dim retVal As String = ""
            If Me.ViewState("_RecordID") IsNot Nothing Then
                retVal = Me.ViewState("_RecordID").ToString
            End If
            Return retVal
        End Get
        Set(ByVal value As String)
            Me.ViewState("_RecordID") = value
        End Set
    End Property

    Public ReadOnly Property RequestID() As String
        Get
            Dim retVal As String = ""
            If Me.Request("id") IsNot Nothing Then
                retVal = Me.Request("id")
            End If
            Return retVal
        End Get
    End Property

    Public ReadOnly Property RequestMode() As String
        Get
            Dim retVal As String = ""
            If Me.Request("mode") IsNot Nothing Then
                retVal = Me.Request("mode")
            End If
            Return retVal
        End Get
    End Property
#End Region

#Region "Page Event Handlers & Methods"
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.BLL = New BusinessLogicLayer.AirFeeBLL()
        Me.BLL2 = New BusinessLogicLayer.StaffBLL()
        Me.BLL3 = New BusinessLogicLayer.tblFunctionBLL()

        If Not IsPostBack Then
            Call Me.CreateTable()
            Call Me.LoadDropDownList()
            Select Case Me.RequestMode.ToLower()
                Case "add"
                    Me.CurrentPageMode = CWTMasterDB.TransactionMode.AddNewMode
                Case "edit"
                    Me.CurrentPageMode = CWTMasterDB.TransactionMode.UpdateMode
                    Me.RecordID = Me.RequestID
                    Call Me.LoadDataFromDB()
            End Select
            Call Me.LoadNewData()
        End If
        Call Me.AccessControl("Fee")
    End Sub

    Private Sub AccessControl(ByVal title As String)

        Dim userName As String
        Dim oDatatable As DataTable
        Dim oDataTable2 As DataTable

        Static roleID As String

        userName = ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName
        oDatatable = Me.BLL2.GetUserByID(userName)

        If oDatatable.Rows.Count > 0 Then
            roleID = oDatatable.Rows(0).Item("RoleID").ToString
        End If

        oDataTable2 = Me.BLL3.GetUserRole(roleID)
        If oDataTable2.Rows.Count > 0 Then
            For k As Integer = 0 To oDataTable2.Rows.Count - 1
                If oDataTable2.Rows(k).Item("functionGroup") = "0" Then
                    If oDataTable2.Rows(k).Item("Permission") = "V" Then
                        If oDataTable2.Rows(k).Item("functionName").ToString = title Then
                            Call Me.toggleControl()

                        End If
                    End If
                End If

            Next

        End If


    End Sub

    Private Sub toggleControl()
        Dim btnDelete As CWTCustomControls.CWTLinkButton

        Me.btnTrans.SaveButton.Enabled = False
      
        Me.txtEndAmount.Readonly = True
        Me.txtFeeAmt.Readonly = True
        Me.txtName.Readonly = True
        Me.txtStartAmount.Readonly = True
      
        Me.btnSave.Enabled = False
        Me.gdDataClass.Visible = False
        Me.tblPg.Visible = False
        Me.gdDataView.Visible = True
        Me.tblPg2.Visible = True


        'For i As Integer = 0 To Me.gdDataClass.Rows.Count - 1
        '    btnDelete = Me.gdDataClass.Rows(i).FindControl("hrefDeleteItem")
        '    btnDelete.Enabled = False

        'Next


    End Sub


    Private Sub CreateTable()
        Call Me.CreateClassTable()
    End Sub
#End Region

#Region "Class sub routine"
    Private Sub CreateClassTable()
        Me.ClassTable = New DataTable("ClassTable")
        With Me.ClassTable
            .Columns.Add(New DataColumn("ItemNo", GetType(Integer)))
            .Columns.Add(New DataColumn("StartAmount"))
            .Columns.Add(New DataColumn("EndAmount"))
            .Columns.Add(New DataColumn("FeeAmt"))
        End With
    End Sub

    Private Sub AddClassData()
        Dim dr As DataRow
        dr = Me.ClassTable.NewRow()
        If Me.ClassTable.Rows.Count > 0 Then
            dr("ItemNo") = Util.DBNullToZero(Me.ClassTable.Rows(Me.ClassTable.Rows.Count - 1).Item("ItemNo") + 1)
        Else
            dr("ItemNo") = 1
        End If
        dr("StartAmount") = Me.txtStartAmount.Text
        dr("EndAmount") = Me.txtEndAmount.Text
        dr("FeeAmt") = Me.txtFeeAmt.Text
        Me.ClassTable.Rows.Add(dr)
    End Sub

    Private Sub LoadClassData(ByVal ItemNo As String)
        On Error Resume Next
        Dim dr As DataRow()
        Dim filter As String = ""
        filter = "ItemNo=" + Util.LimitTheString(ItemNo)
        dr = Me.ClassTable.Select(filter)
        If dr IsNot Nothing AndAlso dr.Length > 0 Then
            Me.txtItemNo.Value = ItemNo
            Me.txtStartAmount.Text = dr(0).Item("StartAmount").ToString
            Me.txtEndAmount.Text = dr(0).Item("EndAmount").ToString
            Me.txtFeeAmt.Text = dr(0).Item("FeeAmt").ToString
        End If
    End Sub

    Private Sub LoadClassDataFromDB()
        Dim oDataTable As DataTable
        Dim oRow As DataRow
        Dim dr As DataRow
        Try
            oDataTable = Me.BLL.GetFeeByConditionalData(Me.RecordID)
            If oDataTable IsNot Nothing Then
                For i As Integer = 0 To oDataTable.Rows.Count - 1
                    oRow = oDataTable.Rows(i)
                    dr = Me.ClassTable.NewRow()
                    If Me.ClassTable.Rows.Count > 0 Then
                        dr("ItemNo") = Util.DBNullToZero(Me.ClassTable.Rows(Me.ClassTable.Rows.Count - 1).Item("ItemNo") + 1)
                    Else
                        dr("ItemNo") = 1
                    End If
                    dr("StartAmount") = oRow("StartAmount").ToString
                    dr("EndAmount") = oRow("EndAmount").ToString
                    dr("FeeAmt") = oRow("MarkUpAmount").ToString
                    Me.ClassTable.Rows.Add(dr)
                Next
                Call Me.RefreshClassGrid()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub RemoveClassData(ByVal ItemNo As String)
        Dim dr As DataRow()
        Dim filter As String = ""
        filter = "ItemNo=" + Util.LimitTheString(ItemNo)
        dr = Me.ClassTable.Select(filter)
        If dr IsNot Nothing AndAlso dr.Length > 0 Then
            Me.ClassTable.Rows.Remove(dr(0))
        End If
    End Sub

    Private Sub UpdateClassData(ByVal ItemNo As String)
        Dim dr As DataRow()
        Dim filter As String = ""
        filter = "ItemNo=" + Util.LimitTheString(ItemNo)
        dr = Me.ClassTable.Select(filter)
        If dr IsNot Nothing AndAlso dr.Length > 0 Then
            dr(0).Item("StartAmount") = Me.txtStartAmount.Text
            dr(0).Item("EndAmount") = Me.txtEndAmount.Text
            dr(0).Item("FeeAmt") = Me.txtFeeAmt.Text
        End If
    End Sub

    Private Sub RefreshClassGrid()
        Dim dv As New DataView()
        With dv
            .Table = Me.ClassTable
            .Sort = "ItemNo"
        End With
        With Me.gdDataClass
            .DataSource = dv.ToTable()
            .DataBind()
        End With
        With Me.pgControl
            .GridID = Me.gdDataClass.UniqueID
            .SetBindGrid()
        End With

        With dv
            .Table = Me.ClassTable
            .Sort = "ItemNo"
        End With
        With Me.gdDataView
            .DataSource = dv.ToTable()
            .DataBind()
        End With
        With Me.pgControl2
            .GridID = Me.gdDataView.UniqueID
            .SetBindGrid()
        End With
    End Sub

    Public Sub gdDataClass_Command(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.CommandEventArgs)
        Select Case e.CommandName
            Case "delete"
                Call Me.RemoveClassData(Util.DBNullToZero(e.CommandArgument))
            Case "edit"
                Call Me.LoadClassData(Util.DBNullToZero(e.CommandArgument))
                Me.btnSave.Text = "Update"
        End Select
        Call Me.RefreshClassGrid()
        Call Me.AccessControl("Fee")
    End Sub

    Protected Sub btnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSave.Click
        Dim ItemNo As String = ""
        ItemNo = Me.txtItemNo.Value
        If ItemNo = "" Then
            Call Me.AddClassData()
        Else
            Call Me.UpdateClassData(ItemNo)
        End If
        Call Me.RefreshClassGrid()
        Call Me.LoadNewData()
    End Sub

    Protected Sub btnCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        Call Me.LoadNewData()
    End Sub
#End Region

#Region "Data Binding"
    Private Sub LoadDropDownList()

    End Sub

    Private Sub LoadNewData()
        Me.txtItemNo.Value = ""
        Me.txtStartAmount.Text = "0"
        Me.txtEndAmount.Text = "0"
        Me.txtFeeAmt.Text = "0"
        Me.btnSave.Text = "Add"
    End Sub

    Private Sub LoadDataFromDB()
        Dim FeeName As String
        FeeName = Me.BLL.GetFeeNameByID(Me.RecordID, DataInfo.AirFeeInfo.AirFeeManagerType.ConditionalMarkUp)
        Me.txtName.Text = FeeName
        Call Me.LoadClassDataFromDB()
    End Sub
#End Region

#Region "Data Transaction"
    Private Sub SaveData(ByVal IsNext As Boolean)
        Dim info As New DataInfo.TransConditionalInfo()
        Dim Amount As DataInfo.ConditionalInfo
        Dim r As DataRow

        If Me.ClassTable.Rows.Count <= 0 Then
            Me.lblMsgBox.Text = "Must add at least one criteria for the fee by Conditional!"
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.ajaxMsgBox.Show()

            Exit Sub

        End If

        With info
            .PageMode = Me.CurrentPageMode
            .FeeID = Me.RecordID
            .FeeName = Me.txtName.Text
            For i As Integer = 0 To Me.ClassTable.Rows.Count - 1
                r = Me.ClassTable.Rows(i)
                Amount = New DataInfo.ConditionalInfo()
                With Amount
                    .StartAmount = r("StartAmount")
                    .EndAmount = r("EndAmount")
                    .FeeAmt = r("FeeAmt")
                End With
                .ConditionalList.Add(Amount)
            Next
            If Me.BLL.IsExistName(.FeeName, .FeeID, DataInfo.AirFeeInfo.AirFeeManagerType.ConditionalMarkUp) Then
                Me.lblMsgBox.Text = "Fee name is exist."
                Me.lblMsgBox.ForeColor = Drawing.Color.Red
                Exit Sub
            End If
        End With
        If Me.BLL.UpdateFeeByConditionalData(info) > 0 Then
            Me.lblMsgBox.Text = Util.GetAppConfig(Util.MsgType.TRANS_SUCCESS.ToString)
            Me.lblMsgBox.ForeColor = Drawing.Color.Green
            Me.ajaxMsgBox.Show()
        Else
            Me.lblMsgBox.Text = Util.GetAppConfig(Util.MsgType.TRANS_ERROR.ToString)
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.ajaxMsgBox.Show()
        End If
    End Sub
#End Region

#Region "Page Control Event Handlers"
    Protected Sub btnTrans_OnCancel(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans.OnCancel
        Response.Redirect("AirFeeManager.aspx")
    End Sub

    Protected Sub btnTrans_OnSave(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans.OnSave
        Call Me.SaveData(False)
    End Sub
#End Region

End Class
@


1.1.1.1
log
@no message
@
text
@@
