head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.07.01;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.07.01;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Public Partial Class CityUpdateManager
    Inherits BasePage

#Region "Page Properties & Variables"
    Private BLL As BusinessLogicLayer.CityBLL
    Private BLL2 As BusinessLogicLayer.StaffBLL
    Private BLL3 As BusinessLogicLayer.tblFunctionBLL

    Public Property RecordID() As String
        Get
            Dim retVal As String = ""
            If Me.ViewState("_RecordID") IsNot Nothing Then
                retVal = Me.ViewState("_RecordID").ToString()
            End If
            Return retVal
        End Get
        Set(ByVal value As String)
            Me.ViewState("_RecordID") = value
        End Set
    End Property
#End Region

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.BLL = New BusinessLogicLayer.CityBLL()
        Me.BLL2 = New BusinessLogicLayer.StaffBLL()
        Me.BLL3 = New BusinessLogicLayer.tblFunctionBLL()
        If Not IsPostBack Then
            If Me.Request("mode") Is Nothing Then
                Response.Redirect(Util.GetAppConfig("RootPath") + "/CityManager.aspx", True)
            End If
            Call Me.LoadDropDownList()
            Select Case Me.Request("mode").ToString()
                Case "add"
                    Me.CurrentPageMode = CWTMasterDB.TransactionMode.AddNewMode
                    Me.txtAirportCode.Readonly = False
                Case "edit"
                    Me.CurrentPageMode = CWTMasterDB.TransactionMode.UpdateMode
                    Me.RecordID = Me.Request("id").ToString()
                    Me.txtAirportCode.Readonly = True
                    Call Me.LoadData()
            End Select
        End If
        Call Me.AccessControl("Airport")
    End Sub

    Private Sub AccessControl(ByVal title As String)

        Dim userName As String
        Dim oDatatable As DataTable
        Dim oDataTable2 As DataTable

        Static roleID As String

        userName = ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName
        oDatatable = Me.BLL2.GetUserByID(userName)

        If oDatatable.Rows.Count > 0 Then
            roleID = oDatatable.Rows(0).Item("RoleID").ToString
        End If

        oDataTable2 = Me.BLL3.GetUserRole(roleID)
        If oDataTable2.Rows.Count > 0 Then
            For k As Integer = 0 To oDataTable2.Rows.Count - 1
                If oDataTable2.Rows(k).Item("functionGroup") = "0" Then
                    If oDataTable2.Rows(k).Item("Permission") = "V" Then
                        If oDataTable2.Rows(k).Item("functionName").ToString = title Then
                            Call Me.toggleControl()

                        End If
                    End If
                End If

            Next

        End If


    End Sub

    Private Sub toggleControl()
        Me.txtAirportCode.Readonly = True
        Me.txtAirportName.Readonly = True
        Me.txtCityName.Readonly = True
        Me.txtCityCode.Readonly = True
        Me.txtCoTerminal.Readonly = True
        Me.ddlDiffGMT.Enabled = False
        Me.txtSubDivCode.Readonly = True
        Me.txtITAArea.Readonly = True
        Me.txtLatitude.Readonly = True
        Me.txtLongitude.Readonly = True

        Me.ddlCountryCode.Enabled = False
        Me.ddlRegion.Enabled = False
        Me.ddlType.Enabled = False
        Me.btnTrans.SaveButton.Enabled = False
    End Sub

    Private Sub LoadRegion()
        Dim oDataTable As DataTable
        oDataTable = Me.BLL.GetRegionList()
        With Me.ddlRegion
            .DataTextField = "Description"
            .DataValueField = "RegionCode"
            .DataSource = oDataTable
            .DataBind()
        End With
    End Sub

    Private Sub LoadCountry()
        Dim oDataTable As DataTable
        oDataTable = Me.BLL.GetCountryList()
        With Me.ddlCountryCode
            .DataTextField = "CountryName"
            .DataValueField = "CountryCode"
            .DataSource = oDataTable
            .DataBind()
        End With
    End Sub

    Private Sub LoadCityType()
        Dim oDataTable As DataTable
        oDataTable = Me.BLL.GetCityTypeList()
        With Me.ddlType
            .DataTextField = "CityTypeDesc"
            .DataValueField = "CityTypeCode"
            .DataSource = oDataTable
            .DataBind()
        End With
    End Sub

    Private Sub LoadDropDownList()
        Call Me.LoadRegion()
        Call Me.LoadCountry()
        Call Me.LoadCityType()
    End Sub

    Private Sub LoadData()
        Dim oDataTable As DataTable
        oDataTable = Me.BLL.GetCityByAirportCode(Me.RecordID)
        If oDataTable IsNot Nothing AndAlso oDataTable.Rows.Count > 0 Then
            Me.txtAirportCode.Text = Me.RecordID
            Me.txtAirportName.Text = oDataTable.Rows(0).Item("Airport").ToString
            Me.txtCityName.Text = oDataTable.Rows(0).Item("City").ToString
            Me.txtCityCode.Text = oDataTable.Rows(0).Item("CityCode").ToString
            Me.txtCoTerminal.Text = oDataTable.Rows(0).Item("CoTerminal").ToString
            Me.ddlDiffGMT.SelectedValue = FormatNumber(Util.DBNullToZero(oDataTable.Rows(0).Item("DiffGMT")), 2, TriState.False, TriState.False, TriState.False)
            Me.txtSubDivCode.Text = oDataTable.Rows(0).Item("CountrySubDivCode").ToString
            Me.txtITAArea.Text = oDataTable.Rows(0).Item("IATAArea").ToString
            Me.txtLatitude.Text = Util.DBNullToZero(oDataTable.Rows(0).Item("Latitude")).ToString
            Me.txtLongitude.Text = Util.DBNullToZero(oDataTable.Rows(0).Item("Longtitude")).ToString
            On Error Resume Next
            Me.ddlCountryCode.SelectedValue = oDataTable.Rows(0).Item("CountryCode").ToString
            Me.ddlRegion.SelectedValue = oDataTable.Rows(0).Item("RegionCode").ToString
            Me.ddlType.SelectedValue = oDataTable.Rows(0).Item("Type").ToString
        End If
    End Sub

    Private Sub SaveData()
        Dim info As New DataInfo.CityInfo()
        With info
            .PageMode = Me.CurrentPageMode
            .AirportCode = Me.txtAirportCode.Text
            If .PageMode = CWTMasterDB.TransactionMode.AddNewMode AndAlso Me.BLL.IsExistName(info.AirportCode) Then
                Me.lblMsgBox.Text = "Airport Code already exists in database."
                Me.lblMsgBox.ForeColor = Drawing.Color.Red
                Me.ajaxMsgBox.Show()
                Exit Sub
            End If
            .Airport = Me.txtAirportName.Text
            .CityCode = Me.txtCityCode.Text
            .City = Me.txtCityName.Text
            .CoTerminal = Me.txtCoTerminal.Text
            .DiffGMT = Util.DBNullToZero(Me.ddlDiffGMT.SelectedValue)
            .CountrySubDivCode = Me.txtSubDivCode.Text
            .IATAArea = Me.txtITAArea.Text
            .Latitude = Util.DBNullToZero(Me.txtLatitude.Text)
            .Longtitude = Util.DBNullToZero(Me.txtLongitude.Text)
            .RegionCode = Me.ddlRegion.SelectedValue
            .CountryCode = Me.ddlCountryCode.SelectedValue
            .Type = Me.ddlType.SelectedValue
        End With
        If Me.BLL.UpdateCity(info) > 0 Then
            Me.lblMsgBox.Text = Util.GetAppConfig(Util.MsgType.TRANS_SUCCESS.ToString)
            Me.lblMsgBox.ForeColor = Drawing.Color.Green
            Me.ajaxMsgBox.Show()
            Response.Redirect("CityManager.aspx")
        Else
            Me.lblMsgBox.Text = Util.GetAppConfig(Util.MsgType.TRANS_ERROR.ToString)
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.ajaxMsgBox.Show()
        End If
    End Sub

    Protected Sub btnTrans_OnCancel(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans.OnCancel
        Response.Redirect("CityManager.aspx")
    End Sub

    Protected Sub btnTrans_OnSave(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans.OnSave
        Call Me.SaveData()
    End Sub

End Class@


1.1.1.1
log
@no message
@
text
@@
