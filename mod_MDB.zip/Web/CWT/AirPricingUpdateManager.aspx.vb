head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.07.00;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.07.00;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@
Partial Class Web_CWT_AirPricingUpdateManager
    Inherits BasePage

    Private BLL As BusinessLogicLayer.AirPricingBLL
    Private BLL2 As BusinessLogicLayer.StaffBLL
    Private BLL3 As BusinessLogicLayer.tblFunctionBLL

    Public ReadOnly Property RequestMode() As String
        Get
            Dim retVal As String = ""
            If Me.Request("mode") IsNot Nothing Then
                retVal = Me.Request("mode")
            End If
            Return retVal
        End Get
    End Property
    Public Property RecordID() As String
        Get
            Dim retVal As String = ""
            If Me.ViewState("_RecordID") IsNot Nothing Then
                retVal = Me.ViewState("_RecordID").ToString
            End If
            Return retVal
        End Get
        Set(ByVal value As String)
            Me.ViewState("_RecordID") = value
        End Set
    End Property

    Public ReadOnly Property RequestID() As String
        Get
            Dim retVal As String = ""
            If Me.Request("id") IsNot Nothing Then
                retVal = Me.Request("id")
            End If
            Return retVal
        End Get
    End Property

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        BLL = New BusinessLogicLayer.AirPricingBLL()
        Me.BLL2 = New BusinessLogicLayer.StaffBLL()
        Me.BLL3 = New BusinessLogicLayer.tblFunctionBLL()
        If Not IsPostBack Then
            Call Me.RegistClientScript()
            Select Case Me.RequestMode.ToLower()
                Case "add"
                    Me.CurrentPageMode = CWTMasterDB.TransactionMode.AddNewMode
                    'Me.UcAirPricing1.LoadCheckBoxList()
                    'Me.UcAirPricing2.LoadCheckBoxList()
                Case "edit"
                    Me.CurrentPageMode = CWTMasterDB.TransactionMode.UpdateMode
                    Me.RecordID = Me.RequestID
                    Call Me.LoadData()
            End Select
        End If
        Call Me.AccessControl("Pricing")
    End Sub

    Private Sub AccessControl(ByVal title As String)

        Dim userName As String
        Dim oDatatable As DataTable
        Dim oDataTable2 As DataTable

        Static roleID As String

        userName = ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName
        oDatatable = Me.BLL2.GetUserByID(userName)

        If oDatatable.Rows.Count > 0 Then
            roleID = oDatatable.Rows(0).Item("RoleID").ToString
        End If

        oDataTable2 = Me.BLL3.GetUserRole(roleID)
        If oDataTable2.Rows.Count > 0 Then
            For k As Integer = 0 To oDataTable2.Rows.Count - 1
                If oDataTable2.Rows(k).Item("functionGroup") = "0" Then
                    If oDataTable2.Rows(k).Item("Permission") = "V" Then
                        If oDataTable2.Rows(k).Item("functionName").ToString = title Then
                            Call Me.toggleControl()

                        End If
                    End If
                End If

            Next

        End If


    End Sub

    Private Sub toggleControl()
        'Dim btnDelete As CWTCustomControls.CWTLinkButton


        Me.txtName.Readonly = True
        Me.btnTrans.SaveButton.Enabled = False
        Me.chkLccSameAsInt.Enabled = False

        'For i As Integer = 0 To Me.gdData.Rows.Count - 1
        '    btnDelete = Me.gdData.Rows(i).FindControl("hrefDelete")
        '    btnDelete.Enabled = False

        'Next
    End Sub

    Private Sub RegistClientScript()
        Dim oDataTable As DataTable
        Dim sc As New StringBuilder()
        Dim r As DataRow
        oDataTable = Me.BLL.GetAirVariableGroups()
        If oDataTable IsNot Nothing AndAlso oDataTable.Rows.Count > 0 Then
            For i As Integer = 0 To oDataTable.Rows.Count - 1
                r = oDataTable.Rows(i)
                sc.AppendLine("varList['" + Util.JSEncode(r("FieldName").ToString) + "']='" + Util.JSEncode(r("OtherFieldName").ToString) + "';")
            Next
            Call Util.RegClientScript(sc.ToString, "CreateVarList", Util.ClientScriptRegistType.RegStartUpBlock)
        End If
    End Sub

    Private Sub LoadData()
        Dim oDataTable As DataTable
        Dim r As DataRow
        oDataTable = Me.BLL.GetAirPriceData(Me.RecordID)
        If oDataTable IsNot Nothing AndAlso oDataTable.Rows.Count > 0 Then
            r = oDataTable.Rows(0)
            Me.txtName.Text = r("AirPricingName").ToString
            Me.chkSameAsInt.Checked = Util.DBNullToFalse(r("DomSameAsInt"))
            Me.chkLccSameAsInt.Checked = Util.DBNullToFalse(r("LCCSameAsInt"))
            Me.UcPrice1.LoadData(oDataTable, "I")
            'Me.UcAirPricing1.LoadCheckBoxList(Me.RecordID, True)
            If Not Me.chkSameAsInt.Checked Then
                Me.UcPrice2.LoadData(oDataTable, "D")
            End If
            If Not Me.chkLccSameAsInt.Checked Then
                Me.UcPrice3.LoadData(oDataTable, "L")
            End If
            'Me.UcAirPricing2.LoadCheckBoxList(Me.RecordID, False)
        End If
        Call Me.SetMode()
    End Sub

    Private Sub SaveData()
        Dim info As New DataInfo.AirPriceInfo()
        With info
            .ID = Me.RecordID
            .PageMode = Me.CurrentPageMode
            .Name = Me.txtName.Text
            '//
            If Me.BLL.IsExistName(info.Name, info.ID) Then
                Me.lblMsgBox.Text = "Name already exists in database."
                Me.lblMsgBox.ForeColor = Drawing.Color.Red
                Me.ajaxMsgBox.Show()
                Exit Sub
            End If
            '//
            .DomSameAsInt = Me.chkSameAsInt.Checked
            .IntFomula = Me.UcPrice1.GetInfo()
            If Not .DomSameAsInt Then
                .DomFomula = UcPrice2.GetInfo()
            End If
            .LCCSameAsInt = Me.chkLccSameAsInt.Checked
            If Not .LCCSameAsInt Then
                .LCCFomula = UcPrice3.GetInfo()
            End If
        End With
        If Me.BLL.UpdateAirPrice(info) > 0 Then
            Me.lblMsgBox.Text = Util.GetAppConfig(Util.MsgType.TRANS_SUCCESS.ToString)
            Me.lblMsgBox.ForeColor = Drawing.Color.Green
            Me.ajaxMsgBox.Show()
            Response.Redirect("AirPricingManager.aspx")
        Else
            Me.lblMsgBox.Text = Util.GetAppConfig(Util.MsgType.TRANS_ERROR.ToString)
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.ajaxMsgBox.Show()
        End If
    End Sub

    Private Sub SetMode()
        Me.UcPrice2.Visible = Not (Me.chkSameAsInt.Checked)
        Me.UcPrice3.Visible = Not (Me.chkLccSameAsInt.Checked)
    End Sub

    Protected Sub chkSameAsInt_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkSameAsInt.CheckedChanged
        Call Me.SetMode()
        'If Not Me.chkSameAsInt.Checked Then
        '    Select Case Me.CurrentPageMode
        '        Case CWTMasterDB.TransactionMode.AddNewMode
        '            Me.UcAirPricing2.LoadCheckBoxList()
        '        Case Else
        '            Me.UcAirPricing2.LoadCheckBoxList(Me.RecordID, False)
        '    End Select
        'End If
    End Sub

    Private Sub chkLccSameAsInt_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkLccSameAsInt.CheckedChanged
        Call Me.SetMode()
    End Sub

    Protected Sub btnTrans_OnCancel(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans.OnCancel
        Response.Redirect("AirPricingManager.aspx")
    End Sub

    Protected Sub btnTrans_OnSave(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans.OnSave
        Call Me.SaveData()
    End Sub

End Class













@


1.1.1.1
log
@no message
@
text
@@
