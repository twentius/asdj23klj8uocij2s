head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.07.01;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.07.01;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@
Partial Class Admin_ConfigurationUpdateManager
    Inherits BasePage

#Region "Global Variables"
    Private BLL As BusinessLogicLayer.ConfigurationBLL
    Private BLL2 As BusinessLogicLayer.StaffBLL
    Private BLL3 As BusinessLogicLayer.tblFunctionBLL

    Private Property IsError() As Boolean
        Get
            Dim retVal As Boolean
            If Me.ViewState("_IsError") IsNot Nothing Then
                retVal = CBool(Me.ViewState("_IsError"))
            End If
            Return retVal
        End Get
        Set(ByVal value As Boolean)
            Me.ViewState("_IsError") = value
        End Set
    End Property
#End Region

#Region "Properties"
    Public ReadOnly Property RequestMode() As String
        Get
            Dim retVal As String = ""
            If Me.Request("mode") IsNot Nothing Then
                retVal = Me.Request("mode")
            End If
            Return retVal
        End Get
    End Property
    Public Property RecordID() As String
        Get
            Dim retVal As String = ""
            If Me.ViewState("_RecordID") IsNot Nothing Then
                retVal = Me.ViewState("_RecordID").ToString
            End If
            Return retVal
        End Get
        Set(ByVal value As String)
            Me.ViewState("_RecordID") = value
        End Set
    End Property

    Public ReadOnly Property RequestID() As String
        Get
            Dim retVal As String = ""
            If Me.Request("id") IsNot Nothing Then
                retVal = Me.Request("id")
            End If
            Return retVal
        End Get
    End Property
#End Region

#Region "Page Load Event"
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.BLL = New BusinessLogicLayer.ConfigurationBLL()
        Me.BLL2 = New BusinessLogicLayer.StaffBLL()
        Me.BLL3 = New BusinessLogicLayer.tblFunctionBLL()
        If Not IsPostBack Then
            Select Case Me.RequestMode.ToLower()
                Case "add"
                    Me.CurrentPageMode = CWTMasterDB.TransactionMode.AddNewMode
                    Me.lblTitle.Text = "Add new Configuration"
                    InitialData()
                    btnTrans.ShowDeleteButton = False
                Case "edit"
                    Me.CurrentPageMode = CWTMasterDB.TransactionMode.UpdateMode
                    Me.RecordID = Me.RequestID
                    InitialData()
                    Call Me.LoadData()
                    Me.lblTitle.Text = "Update Configuration"
                    btnTrans.DeleteButton.Attributes.Add("onclick", "return confirm('Configuration will delete, continue?');")
            End Select
        End If
        Me.lblError.Visible = False
        Call Me.AccessControl("PCC Config")
    End Sub
#End Region

    Private Sub AccessControl(ByVal title As String)

        Dim userName As String
        Dim oDatatable As DataTable
        Dim oDataTable2 As DataTable

        Static roleID As String

        userName = ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName
        oDatatable = Me.BLL2.GetUserByID(userName)

        If oDatatable.Rows.Count > 0 Then
            roleID = oDatatable.Rows(0).Item("RoleID").ToString
        End If

        oDataTable2 = Me.BLL3.GetUserRole(roleID)
        If oDataTable2.Rows.Count > 0 Then
            For k As Integer = 0 To oDataTable2.Rows.Count - 1
                If oDataTable2.Rows(k).Item("functionGroup") = "0" Then
                    If oDataTable2.Rows(k).Item("Permission") = "V" Then
                        If oDataTable2.Rows(k).Item("functionName").ToString = title Then
                            Call Me.toggleControl()

                        End If
                    End If
                End If

            Next

        End If


    End Sub

    Private Sub toggleControl()
        Me.txtConfigurationDesc.Readonly = True
        Me.ddlGDS.Enabled = False
        Me.txtBookingPCC.Readonly = True
        'Me.txtProfilePCC.Text = oDataTable.Rows(0).Item("ProfilePCC").ToString()
        Me.txtFarePCC.Readonly = True
        Me.ddlCountry.Enabled = False
        Me.txtTicketPCC.Readonly = True
        Me.txtTicketAddress.Readonly = True

        Me.txtItinPCC.Readonly = True
        Me.txtItinAddress.Readonly = True
        Me.txtItinDYO.Readonly = True
        Me.txtInvPCC.Readonly = True
        Me.txtInvAddress.Readonly = True
        Me.txtInvDYO.Readonly = True
        Me.txtItinPCC2.Readonly = True
        Me.txtMirAddress.Readonly = True
        Me.txtMirPCC.Readonly = True
        Me.ddlCityCode.Enabled = False
        Me.btnTrans.SaveButton.Enabled = False
        Me.btnTrans.DeleteButton.Enabled = False

    End Sub

#Region "Controls Event"
    Protected Sub btnTrans_OnCancel(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans.OnCancel
        Response.Redirect("ConfigurationManager.aspx")
    End Sub

    Protected Sub btnTrans_OnDelete(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans.OnDelete
        Call Me.DeleteData()
    End Sub

    Protected Sub btnTrans_OnSave(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans.OnSave
        Call Me.SaveData()
    End Sub

    Protected Sub btnClose_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Me.ajaxMsgBox.Hide()
        If Not Me.IsError Then
            Response.Redirect("ConfigurationManager.aspx")
        End If
    End Sub
#End Region

#Region "Method"
    Private Function ValidateForm() As Boolean
        Dim retVal As Boolean = True
        If Me.BLL.IsExistName(Me.txtConfigurationDesc.Text, Me.RecordID) Then
            retVal = False
            Me.lblError.Text = "Name already exists in database."
        End If
        Return retVal
    End Function

    Private Sub LoadCountry()
        Dim oDataTable As DataTable
        oDataTable = Me.BLL.GetCountry()
        With Me.ddlCountry
            .DataTextField = "CountryName"
            .DataValueField = "CountryCode"
            .DataSource = oDataTable
            .DataBind()
        End With
        If Me.ddlCountry.Items.Count > 0 Then
            Call Me.LoadCity()
        End If
    End Sub

    Private Sub LoadCity()
        Dim oDataTable As DataTable
        oDataTable = Me.BLL.GetCity(Me.ddlCountry.SelectedValue, "")
        With Me.ddlCityCode
            .DataTextField = "City"
            .DataValueField = "CityCode"
            .DataSource = oDataTable
            .DataBind()
        End With
    End Sub

    Private Sub LoadCurrency()
        'Dim oDataTable As DataTable
        'oDataTable = Me.BLL.GetCurrency()
        'With Me.ddlCurrency
        '    .DataTextField = "CurrencyName"
        '    .DataValueField = "CurrencyCode"
        '    .DataSource = oDataTable
        '    .DataBind()
        'End With
    End Sub

    Private Sub LoadGDS()
        Dim oDataTable As DataTable
        oDataTable = Me.BLL.GetGDS()
        With Me.ddlGDS
            .DataTextField = "GDSName"
            .DataValueField = "GDSNumber"
            .DataSource = oDataTable
            .DataBind()
        End With
    End Sub

    Private Sub LoadDropDownList()
        Call Me.LoadCountry()
        Call Me.LoadCurrency()
        Call Me.LoadGDS()
    End Sub

    Private Sub DeleteData()
        If Me.BLL.DeleteConfigurationByConfiguration(Me.RecordID) > 0 Then
            'Util.AlertBox("Delete Completed", True, "ConfigurationManager.aspx")
            Response.Redirect("ConfigurationManager.aspx")
        Else
            Me.lblMsgBox.Text = "Cannot delete this item."
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.IsError = True
            Me.ajaxMsgBox.Show()
        End If
    End Sub
    Private Sub SaveData()
        If Me.ValidateForm Then
            Select Case Me.CurrentPageMode
                Case CWTMasterDB.TransactionMode.AddNewMode
                    If Me.BLL.InsertConfiguration(txtConfigurationDesc.Text, _
    Me.ddlGDS.SelectedValue, txtBookingPCC.Text, txtFarePCC.Text, "", ddlCityCode.SelectedValue, _
    txtTicketPCC.Text, txtTicketAddress.Text, txtItinPCC.Text, txtItinAddress.Text, txtItinDYO.Text, txtInvPCC.Text, _
    txtInvAddress.Text, txtInvDYO.Text, txtMirPCC.Text, txtItinPCC2.Text, txtMirAddress.Text, "") > 0 Then
                        'Util.AlertBox("Save Completed", True, "ConfigurationManager.aspx")
                        Me.lblMsgBox.Text = Util.GetAppConfig(Util.MsgType.TRANS_SUCCESS.ToString)
                        Me.lblMsgBox.ForeColor = Drawing.Color.Green
                        Me.IsError = False
                        Me.ajaxMsgBox.Show()
                        Response.Redirect("ConfigurationManager.aspx")
                    Else
                        Me.lblMsgBox.Text = Util.GetAppConfig(Util.MsgType.TRANS_ERROR.ToString)
                        Me.lblMsgBox.ForeColor = Drawing.Color.Red
                        Me.IsError = True
                        Me.ajaxMsgBox.Show()
                    End If
                Case CWTMasterDB.TransactionMode.UpdateMode
                    If Me.BLL.UpdateConfigurationByConfiguration(Me.RecordID, txtConfigurationDesc.Text, _
    Me.ddlGDS.SelectedValue, txtBookingPCC.Text, txtFarePCC.Text, "", ddlCityCode.SelectedValue, _
    txtTicketPCC.Text, txtTicketAddress.Text, txtItinPCC.Text, txtItinAddress.Text, txtItinDYO.Text, txtInvPCC.Text, _
    txtInvAddress.Text, txtInvDYO.Text, txtMirPCC.Text, txtItinPCC2.Text, txtMirAddress.Text, "") > 0 Then
                        'Util.AlertBox("Save Completed", True, "ConfigurationManager.aspx")
                        Me.lblMsgBox.Text = Util.GetAppConfig(Util.MsgType.TRANS_SUCCESS.ToString)
                        Me.lblMsgBox.ForeColor = Drawing.Color.Green
                        Me.IsError = False
                        Me.ajaxMsgBox.Show()
                        Response.Redirect("ConfigurationManager.aspx")
                    Else
                        Me.lblMsgBox.Text = Util.GetAppConfig(Util.MsgType.TRANS_ERROR.ToString)
                        Me.lblMsgBox.ForeColor = Drawing.Color.Red
                        Me.IsError = True
                        Me.ajaxMsgBox.Show()
                    End If
                Case Else
                    Exit Sub
            End Select
        Else
            Me.lblError.Visible = True
        End If
    End Sub
    Private Sub CloseWindows()
        Call Util.RegClientScript("CloseWindow();", "ConfigurationUpdateManager_CloseWin", Util.ClientScriptRegistType.RegStartUpBlock)
    End Sub
    Private Sub LoadData()
        Dim oDataTable As DataTable
        Dim CityCode As String
        oDataTable = Me.BLL.getConfigurationByConfiguration(Me.RecordID)
        If oDataTable IsNot Nothing AndAlso oDataTable.Rows.Count > 0 Then
            Me.txtConfigurationDesc.Text = oDataTable.Rows(0).Item("ConfigurationDesc").ToString()
            Me.ddlGDS.SelectedValue = oDataTable.Rows(0).Item("GDS").ToString()
            Me.txtBookingPCC.Text = oDataTable.Rows(0).Item("BookingPCC").ToString()
            'Me.txtProfilePCC.Text = oDataTable.Rows(0).Item("ProfilePCC").ToString()
            Me.txtFarePCC.Text = oDataTable.Rows(0).Item("FarePCC").ToString()
            'Me.ddlCurrency.SelectedValue = oDataTable.Rows(0).Item("Currency").ToString()
            Me.txtTicketPCC.Text = oDataTable.Rows(0).Item("TicketPCC").ToString()
            Me.txtTicketAddress.Text = oDataTable.Rows(0).Item("TicketAddress").ToString()

            Me.txtItinPCC.Text = oDataTable.Rows(0).Item("ItinPCC").ToString()
            Me.txtItinAddress.Text = oDataTable.Rows(0).Item("ItinAddress").ToString()
            Me.txtItinDYO.Text = oDataTable.Rows(0).Item("ItinDYO").ToString()
            Me.txtInvPCC.Text = oDataTable.Rows(0).Item("InvPCC").ToString()
            Me.txtInvAddress.Text = oDataTable.Rows(0).Item("InvAddress").ToString()
            Me.txtInvDYO.Text = oDataTable.Rows(0).Item("InvDYO").ToString()
            Me.txtItinPCC2.Text = oDataTable.Rows(0).Item("TicketIATA").ToString()
            Me.txtMirAddress.Text = oDataTable.Rows(0).Item("MIRAddress").ToString()
            Me.txtMirPCC.Text = oDataTable.Rows(0).Item("MirPCC").ToString()
            CityCode = oDataTable.Rows(0).Item("CityCode").ToString
            Me.ddlCountry.SelectedValue = Me.BLL.GetCountryByCity(CityCode)
            Call Me.LoadCity()
            Me.ddlCityCode.SelectedValue = CityCode
            'Me.txtDecimalPlc.Text = Util.DBNullToZero(oDataTable.Rows(0).Item("DecimalPlc"))
        End If
    End Sub
    Private Sub InitialData()
        Call Me.LoadDropDownList()
    End Sub

    Protected Sub ddlCountry_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlCountry.SelectedIndexChanged
        Call Me.LoadCity()
    End Sub
#End Region

End Class




@


1.1.1.1
log
@no message
@
text
@@
