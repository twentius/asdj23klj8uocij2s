head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.07.03;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.07.03;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Public Partial Class FeeByPNR
    Inherits System.Web.UI.UserControl

    Private BLL As BusinessLogicLayer.AirFeeBLL
    Private BLL2 As BusinessLogicLayer.StaffBLL
    Private BLL3 As BusinessLogicLayer.tblFunctionBLL

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.BLL = New BusinessLogicLayer.AirFeeBLL()
        Me.BLL2 = New BusinessLogicLayer.StaffBLL()
        Me.BLL3 = New BusinessLogicLayer.tblFunctionBLL()

        If Not IsPostBack Then
            GetPNRData()
            GetTransactionData()
            SetDDL()
        End If
        
    End Sub

    Public Sub GetPNRData()
        Dim dt As DataTable
        dt = Me.BLL.GetTempFeeData("PNR")
        With gdData
            .DataSource = dt
            .DataBind()
        End With
        With Me.pgControl
            .GridID = Me.gdData.UniqueID
            .SetBindGrid()
        End With
    End Sub

    Public Sub GetTransactionData()
        Dim dt As DataTable
        dt = Me.BLL.GetTempTransactionFeeData("PNR")
        With gdData2
            .DataSource = dt
            .DataBind()
        End With
        With Me.pgControl1
            .GridID = Me.gdData2.UniqueID
            .SetBindGrid()
        End With
    End Sub

    Public Sub SetDDL()
        Me.ddlParameter.Items.Add("PNR Name")
    End Sub

    Public Sub GetTempPNRByName()
        Dim dt As DataTable
        Dim dt2 As DataTable
        Dim FeeID As String = ""

        dt = Me.BLL.GetTempFeeDataByName(Me.txtParameter.Text, "PNR", Me.txtDateFrom.Text, Me.txtDateTo.Text)
        With gdData
            .DataSource = dt
            .DataBind()
        End With
        With Me.pgControl
            .GridID = Me.gdData.UniqueID
            .SetBindGrid()
        End With

        If Me.txtParameter.Text <> "" And dt.Rows.Count > 0 Then
            FeeID = dt.Rows(0).Item("FeeID").ToString()
        Else
            FeeID = ""
        End If

        dt2 = Me.BLL.GetTempTransactionFeeDataByName(FeeID, "PNR", Me.txtDateFrom.Text, Me.txtDateTo.Text)
        With gdData2
            .DataSource = dt2
            .DataBind()
        End With
        With Me.pgControl1
            .GridID = Me.gdData2.UniqueID
            .SetBindGrid()
        End With
    End Sub

    Protected Sub btnSearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSearch.Click
        GetTempPNRByName()
    End Sub
End Class@


1.1.1.1
log
@no message
@
text
@@
