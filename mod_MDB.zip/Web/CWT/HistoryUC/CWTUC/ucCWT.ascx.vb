head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.07.03;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.07.03;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Public Partial Class ucCWT
    Inherits System.Web.UI.UserControl

    Public Shared SelectedValue As String
    Public Shared SelectedValue2 As String
    Private BLL As BusinessLogicLayer.StaffBLL
    Private BLL2 As BusinessLogicLayer.StaffRoleBLL
    Private BLL3 As BusinessLogicLayer.tblFunctionBLL
    Private BLL4 As BusinessLogicLayer.DatabaseBLL
    Private BLL5 As BusinessLogicLayer.RemarkBLL
    Private BLL6 As BusinessLogicLayer.ConfigurationBLL
    Private BLL7 As BusinessLogicLayer.HolidayBLL
    Private ProductBLL As BusinessLogicLayer.ProductBLL
    Private AuxChargeBLL As BusinessLogicLayer.AuxChargeBLL
    Private AuxPricingBLL As BusinessLogicLayer.AuxPricingBLL
    Private HotelFeeBLL As BusinessLogicLayer.HotelFeeBLL
    Private CityBLL As BusinessLogicLayer.CityBLL
    Private CannedRmkBLL As BusinessLogicLayer.CannedRemarkBLL
    Private LineDefBLL As BusinessLogicLayer.LineDefBLL
    Private AuxCustomBLL As BusinessLogicLayer.AuxCustomFieldBLL
    Private AirFeeBLL As BusinessLogicLayer.AirFeeBLL
    Private DivisionBLL As BusinessLogicLayer.DivisionBLL

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'Me.trBodyArea.Visible = False
        'Me.trBodyArea2.Visible = False
        'Me.trBodyArea3.Visible = False
        'Me.trBodyArea4.Visible = False
        'Me.txtParameter.Text = ""
        'Me.txtDateFrom.Text = ""
        'Me.txtDateTo.Text = ""
    End Sub

    Private Sub SetVisibleToFalse()
        Me.trBodyArea.Visible = False
        Me.trBodyArea2.Visible = False
        Me.trBodyArea3.Visible = False
        Me.trBodyArea4.Visible = False
    End Sub

    Public Sub LoadUserData()
        Me.BLL = New BusinessLogicLayer.StaffBLL()
        ddlParameter.Visible = True
        Me.txtParameter.Visible = True
        ddlParameter.Items.Clear()
        ddlParameter.Items.Add("Admin UserID")
        Dim ds As New DataSet
        SetVisibleToFalse()
        ds = Me.BLL.GetTempUser(txtParameter.Text, txtDateFrom.Text, txtDateTo.Text)
        If ds.Tables("User").Rows.Count > 0 Then
            Me.trBodyArea.Visible = True
            Me.lblDetail.Text = "User Details"
            With gdData
                .AutoGenerateColumns = True
                .DataSource = ds.Tables("User")
                .DataBind()
            End With
            With Me.pgControl
                .GridID = Me.gdData.UniqueID
                .SetBindGrid()
            End With
        End If
    End Sub

    Public Sub LoadRoleData()
        Me.BLL2 = New BusinessLogicLayer.StaffRoleBLL()
        Me.BLL3 = New BusinessLogicLayer.tblFunctionBLL()
        ddlParameter.Visible = False
        Me.txtParameter.Visible = False
        'ddlParameter.Items.Clear()
        'ddlParameter.Items.Add("Role Name")
        Dim ds As New DataSet
        Dim ds2 As New DataSet
        SetVisibleToFalse()
        ds = Me.BLL2.GetTempRoleDataByRoleName(txtParameter.Text, txtDateFrom.Text, txtDateTo.Text)
        ds2 = Me.BLL3.GetTempPermissionByRoleName(txtParameter.Text, txtDateFrom.Text, txtDateTo.Text)
        If ds.Tables("Role").Rows.Count > 0 Then
            Me.trBodyArea.Visible = True
            Me.lblDetail.Text = "Staff Role Details"
            With gdData
                .AutoGenerateColumns = True
                .DataSource = ds.Tables("Role")
                .DataBind()
            End With
            With Me.pgControl
                .GridID = Me.gdData.UniqueID
                .SetBindGrid()
            End With
        End If

        If ds2.Tables("Permission").Rows.Count > 0 Then
            Me.trBodyArea2.Visible = True
            Me.lblDetail2.Text = "Staff Permission Details"
            With gdData2
                .AutoGenerateColumns = True
                .DataSource = ds2.Tables("Permission")
                .DataBind()
            End With
            With Me.pgControl2
                .GridID = Me.gdData2.UniqueID
                .SetBindGrid()
            End With
        End If
    End Sub

    Public Sub LoadCountryConfig()
        Dim ds As New DataSet
        Me.BLL3 = New BusinessLogicLayer.tblFunctionBLL()
        ddlParameter.Items.Clear()
        ddlParameter.Visible = False
        Me.txtParameter.Visible = False
        SetVisibleToFalse()
        ds = Me.BLL3.GetTempCountryConfig(txtDateFrom.Text, txtDateTo.Text)
        If ds.Tables("Country").Rows.Count > 0 Then
            Me.trBodyArea.Visible = True
            Me.lblDetail.Text = "Country Configuration Details"
            With gdData
                .AutoGenerateColumns = True
                .DataSource = ds.Tables("Country")
                .DataBind()
            End With
            With Me.pgControl
                .GridID = Me.gdData.UniqueID
                .SetBindGrid()
            End With
        End If
    End Sub

    Public Sub LoadPCCConfiguration()
        Dim ds As New DataSet
        Me.BLL6 = New BusinessLogicLayer.ConfigurationBLL()
        ddlParameter.Visible = True
        Me.txtParameter.Visible = True
        ddlParameter.Items.Clear()
        ddlParameter.Items.Add("PCC Configuration Description")
        SetVisibleToFalse()
        ds = Me.BLL6.GetTempConfiguration(Me.txtParameter.Text, Me.txtDateFrom.Text, Me.txtDateTo.Text)
        If ds.Tables("Config").Rows.Count > 0 Then
            Me.trBodyArea.Visible = True
            Me.lblDetail.Text = "PCC Configuration Details"
            With gdData
                .AutoGenerateColumns = True
                .DataSource = ds.Tables("Config")
                .DataBind()
            End With
            With Me.pgControl
                .GridID = Me.gdData.UniqueID
                .SetBindGrid()
            End With
        End If
    End Sub

    Public Sub LoadAgentDivision()
        Dim AgentDT As DataTable
        Dim DivisionDT As DataTable
        Dim DivisionID As String = ""

        Me.DivisionBLL = New BusinessLogicLayer.DivisionBLL
        ddlParameter.Visible = True
        Me.txtParameter.Visible = True
        ddlParameter.Items.Clear()
        ddlParameter.Items.Add("Agent ID")
        SetVisibleToFalse()
        'Agent
        AgentDT = Me.DivisionBLL.GetTempAgentByID(Me.txtParameter.Text, Me.txtDateFrom.Text, Me.txtDateTo.Text)
        If AgentDT.Rows.Count > 0 Then
            Me.trBodyArea.Visible = True
            Me.lblDetail.Text = "Agent Details"
            With gdData
                .AutoGenerateColumns = True
                .DataSource = AgentDT
                .DataBind()
            End With
            With Me.pgControl
                .GridID = Me.gdData.UniqueID
                .SetBindGrid()
            End With
        End If

        If Me.txtParameter.Text <> "" And AgentDT.Rows.Count > 0 Then
            DivisionID = AgentDT.Rows(0).Item("DivisionID").ToString()
        Else
            DivisionID = ""
        End If

        'Division
        DivisionDT = Me.DivisionBLL.GetTempDivisionByID(DivisionID, Me.txtDateFrom.Text, Me.txtDateTo.Text)
        If DivisionDT.Rows.Count > 0 Then
            Me.lblDetail2.Text = "Division Details"
            Me.trBodyArea2.Visible = True
            With gdData2
                .AutoGenerateColumns = True
                .DataSource = DivisionDT
                .DataBind()
            End With
            With Me.pgControl2
                .GridID = Me.gdData2.UniqueID
                .SetBindGrid()
            End With
        End If
    End Sub

    Public Sub LoadRemark()
        Dim ds As New DataSet
        Dim Code As String = ""
        Me.BLL5 = New BusinessLogicLayer.RemarkBLL()
        ddlParameter.Visible = True
        Me.txtParameter.Visible = True
        ddlParameter.Items.Clear()
        ddlParameter.Items.Add("Remark Type")
        If Me.txtParameter.Text <> "" Then
            If Me.txtParameter.Text = "Timatic" Then
                Code = "Timatic"
            ElseIf Me.txtParameter.Text = "Fare Quote" Then
                Code = "FareQuote"
            ElseIf Me.txtParameter.Text = "Other Services" Then
                Code = "OtherSrv"
            Else
                Code = Me.txtParameter.Text
            End If
        End If
        SetVisibleToFalse()
        ds = BLL5.GetTempRemark(Code, txtDateFrom.Text, txtDateTo.Text)
        If ds.Tables("Remark").Rows.Count > 0 Then
            Me.trBodyArea.Visible = True
            Me.lblDetail.Text = "Remark Details"
            With gdData
                .AutoGenerateColumns = True
                .DataSource = ds.Tables("Remark")
                .DataBind()
            End With
            With Me.pgControl
                .GridID = Me.gdData.UniqueID
                .SetBindGrid()
            End With
        End If
    End Sub

    Public Sub LoadHoliday()
        Dim ds As New DataSet
        Me.BLL7 = New BusinessLogicLayer.HolidayBLL()
        ddlParameter.Visible = False
        Me.txtParameter.Visible = False
        'ddlParameter.Items.Clear()
        'ddlParameter.Items.Add("Holiday Name")
        SetVisibleToFalse()
        ds = Me.BLL7.GetTempHoliday(Me.txtDateFrom.Text, Me.txtDateTo.Text)
        If ds.Tables("Holiday").Rows.Count > 0 Then
            Me.trBodyArea.Visible = True
            Me.lblDetail.Text = "Holiday Details"
            With gdData
                .AutoGenerateColumns = True
                .DataSource = ds.Tables("Holiday")
                .DataBind()
            End With
            With Me.pgControl
                .GridID = Me.gdData.UniqueID
                .SetBindGrid()
            End With
        End If

    End Sub

    Public Sub LoadProduct()
        Dim ds As DataSet
        Me.ProductBLL = New BusinessLogicLayer.ProductBLL()
        ddlParameter.Visible = True
        Me.txtParameter.Visible = True
        ddlParameter.Items.Clear()
        ddlParameter.Items.Add("Product Name")
        SetVisibleToFalse()
        ds = Me.ProductBLL.GetTempProduct(txtParameter.Text, Me.txtDateFrom.Text, Me.txtDateTo.Text)

        If ds.Tables("Product").Rows.Count > 0 Then
            Me.trBodyArea.Visible = True
            Me.lblDetail.Text = "Products Details"
            With gdData
                .AutoGenerateColumns = True
                .DataSource = ds.Tables("Product")
                .DataBind()
            End With
            With Me.pgControl
                .GridID = Me.gdData.UniqueID
                .SetBindGrid()
            End With
        End If
      

        'If ds.Tables.Count > 1 AndAlso ds.Tables("MFByProduct").Rows.Count > 0 Then
        '    Me.trBodyArea2.Visible = True
        '    Me.lblDetail2.Text = "MFBy Product Details"
        '    With gdData2
        '        .AutoGenerateColumns = True
        '        .DataSource = ds.Tables("MFByProduct")
        '        .DataBind()
        '    End With
        '    With Me.pgControl2
        '        .GridID = Me.gdData2.UniqueID
        '        .SetBindGrid()
        '    End With
        'End If
    End Sub

    Public Sub LoadPricingAuxiliary()
        Dim ds As New DataSet
        Me.AuxChargeBLL = New BusinessLogicLayer.AuxChargeBLL
        ddlParameter.Visible = True
        Me.txtParameter.Visible = True
        ddlParameter.Items.Clear()
        ddlParameter.Items.Add("Product Item Name")
        SetVisibleToFalse()
        ds = Me.AuxChargeBLL.GetTempAuxCharge(txtParameter.Text, Me.txtDateFrom.Text, Me.txtDateTo.Text)

        If ds.Tables("AuxCharge").Rows.Count > 0 Then
            Me.trBodyArea.Visible = True
            Me.lblDetail.Text = "Pricing Auxiliary Details"
            With gdData
                .AutoGenerateColumns = True
                .DataSource = ds.Tables("AuxCharge")
                .DataBind()
            End With
            With Me.pgControl
                .GridID = Me.gdData.UniqueID
                .SetBindGrid()
            End With

        End If
        
    End Sub

    Public Sub LoadFeeAir(ByVal Type As String)
        Dim dt As DataTable
        Dim dt2 As DataTable
        Dim FeeID As String = ""
        Me.AirFeeBLL = New BusinessLogicLayer.AirFeeBLL
        ddlParameter.Visible = True
        Me.txtParameter.Visible = True
        SetVisibleToFalse()

        If Type = "PNR" Then
            Me.lblDetail.Text = "PNR Details "
            ddlParameter.Items.Clear()
            ddlParameter.Items.Add("PNR Name")
            Me.trBodyArea.Visible = True
            Me.trBodyArea2.Visible = True
            Me.lblDetail2.Text = "PNR Transaction Details (TerritoryType: 0 = Region, 1 = Country, 2 = City)  (TerritoryCode: Code for either Region,Country Or City)"
        ElseIf Type = "Ticket" Then
            Me.lblDetail.Text = "Ticket Details "
            ddlParameter.Items.Clear()
            ddlParameter.Items.Add("Ticket Name")
            Me.trBodyArea.Visible = True
            Me.trBodyArea2.Visible = True
            Me.lblDetail2.Text = "Ticket Transaction Details (TerritoryType: 0 = Region, 1 = Country, 2 = City)  (TerritoryCode: Code for either Region,Country Or City)"
        ElseIf Type = "Coupon" Then
            Me.lblDetail.Text = "Coupon Details "
            ddlParameter.Items.Clear()
            ddlParameter.Items.Add("Coupon Name")
            Me.lblDetail2.Text = "Coupon Transaction Details "
            Me.trBodyArea.Visible = True
            Me.trBodyArea2.Visible = True
        ElseIf Type = "Conditional" Then
            Me.lblDetail.Text = "Conditional MarkUp Details "
            ddlParameter.Items.Clear()
            ddlParameter.Items.Add("Conditional Name")
            Me.trBodyArea.Visible = True
            Me.trBodyArea2.Visible = True
        End If
        dt = Me.AirFeeBLL.GetTempFeeDataByName(Me.txtParameter.Text, Type, Me.txtDateFrom.Text, Me.txtDateTo.Text)
        With gdData
            .AutoGenerateColumns = True
            .DataSource = dt
            .DataBind()
        End With
        With Me.pgControl
            .GridID = Me.gdData.UniqueID
            .SetBindGrid()
        End With

        'If Me.txtParameter.Text <> "" And dt.Rows.Count > 0 Then
        '    FeeID = dt.Rows(0).Item("FeeID").ToString()
        'Else
        '    FeeID = ""
        'End If


        dt2 = Me.AirFeeBLL.GetTempTransactionFeeDataByName(Me.txtParameter.Text, Type, Me.txtDateFrom.Text, Me.txtDateTo.Text)
        With gdData2
            .AutoGenerateColumns = True
            .DataSource = dt2
            .DataBind()
        End With
        With Me.pgControl2
            .GridID = Me.gdData2.UniqueID
            .SetBindGrid()
        End With
    End Sub

    Public Sub LoadFeeAuxiliary()
        Dim ds As New DataSet
        Me.AuxPricingBLL = New BusinessLogicLayer.AuxPricingBLL
        ddlParameter.Visible = True
        Me.txtParameter.Visible = True
        ddlParameter.Items.Clear()
        ddlParameter.Items.Add("Fee Name")
        SetVisibleToFalse()
        ds = Me.AuxPricingBLL.GetTempFeeAux(txtParameter.Text, Me.txtDateFrom.Text, Me.txtDateTo.Text)
        If ds.Tables("AuxFee").Rows.Count > 0 Then
            Me.trBodyArea.Visible = True
            Me.lblDetail.Text = "Fee Auxiliary Details"
            With gdData
                .AutoGenerateColumns = True
                .DataSource = ds.Tables("AuxFee")
                .DataBind()
            End With
            With Me.pgControl
                .GridID = Me.gdData.UniqueID
                .SetBindGrid()
            End With
        End If
    End Sub

    Public Sub LoadHotelFee()
        Dim ds As New DataSet
        Me.HotelFeeBLL = New BusinessLogicLayer.HotelFeeBLL
        ddlParameter.Visible = True
        Me.txtParameter.Visible = True
        ddlParameter.Items.Clear()
        ddlParameter.Items.Add("Hotel Fee Name")
        SetVisibleToFalse()
        ds = Me.HotelFeeBLL.GetTempHotelFee(txtParameter.Text, Me.txtDateFrom.Text, Me.txtDateTo.Text)
        If ds.Tables("HotelFee").Rows.Count > 0 Then
            Me.trBodyArea.Visible = True
            Me.lblDetail.Text = "Hotel Fee Details"
            With gdData
                .AutoGenerateColumns = True
                .DataSource = ds.Tables("HotelFee")
                .DataBind()
            End With
            With Me.pgControl
                .GridID = Me.gdData.UniqueID
                .SetBindGrid()
            End With
        End If
    End Sub

    Public Sub LoadAirpotCity()
        Dim ds As New DataSet
        Me.CityBLL = New BusinessLogicLayer.CityBLL
        ddlParameter.Visible = True
        Me.txtParameter.Visible = True
        ddlParameter.Items.Clear()
        ddlParameter.Items.Add("Airport Name")
        SetVisibleToFalse()
        ds = Me.CityBLL.GetTempAirportCity(txtParameter.Text, Me.txtDateFrom.Text, Me.txtDateTo.Text)
        If ds.Tables("City").Rows.Count > 0 Then
            Me.trBodyArea.Visible = True
            Me.lblDetail.Text = "Airport Details"
            With gdData
                .AutoGenerateColumns = True
                .DataSource = ds.Tables("City")
                .DataBind()
            End With
            With Me.pgControl
                .GridID = Me.gdData.UniqueID
                .SetBindGrid()
            End With
        End If
    End Sub

    Public Sub LoadTempCannedRemark()
        Dim ds As New DataSet
        Me.CannedRmkBLL = New BusinessLogicLayer.CannedRemarkBLL
        ddlParameter.Visible = False
        Me.txtParameter.Visible = False
        ddlParameter.Items.Clear()
        SetVisibleToFalse()
        ds = Me.CannedRmkBLL.GetTempCannedRemark(Me.txtDateFrom.Text, Me.txtDateTo.Text)
        If ds.Tables("Canned").Rows.Count > 0 Then
            Me.trBodyArea.Visible = True
            Me.lblDetail.Text = "Canned Remark Details"
            With gdData
                .AutoGenerateColumns = True
                .DataSource = ds.Tables("Canned")
                .DataBind()
            End With
            With Me.pgControl
                .GridID = Me.gdData.UniqueID
                .SetBindGrid()
            End With
        End If
      
    End Sub

    Public Sub LoadGDSLineDef()
        Dim ds As New DataSet
        Me.LineDefBLL = New BusinessLogicLayer.LineDefBLL
        ddlParameter.Visible = True
        Me.txtParameter.Visible = True
        ddlParameter.Items.Clear()
        ddlParameter.Items.Add("Line Def Name")
        SetVisibleToFalse()
        ds = Me.LineDefBLL.GetTempLineDef(txtParameter.Text, Me.txtDateFrom.Text, Me.txtDateTo.Text)
        If ds.Tables("LineDefMaster").Rows.Count > 0 Then
            Me.trBodyArea.Visible = True
            Me.lblDetail.Text = "GDS Line Master Def Details"
            With gdData
                .AutoGenerateColumns = True
                .DataSource = ds.Tables("LineDefMaster")
                .DataBind()
            End With
            With Me.pgControl
                .GridID = Me.gdData.UniqueID
                .SetBindGrid()
            End With
        End If
      
        If ds.Tables.Count > 1 AndAlso ds.Tables("LineDefVersion").Rows.Count > 0 Then
            Me.trBodyArea2.Visible = True
            Me.lblDetail2.Text = "GDS Line Def Version Details"
            With gdData2
                .AutoGenerateColumns = True
                .DataSource = ds.Tables("LineDefVersion")
                .DataBind()
            End With
            With Me.pgControl
                .GridID = Me.gdData2.UniqueID
                .SetBindGrid()
            End With
        End If

        If ds.Tables.Count > 2 AndAlso ds.Tables("LineDef").Rows.Count > 0 Then
            Me.trBodyArea3.Visible = True
            Me.lblDetail3.Text = "GDS Line Def Details"
            With gdData3
                .AutoGenerateColumns = True
                .DataSource = ds.Tables("LineDef")
                .DataBind()
            End With
            With Me.pgControl3
                .GridID = Me.gdData3.UniqueID
                .SetBindGrid()
            End With
        End If

    End Sub

    Public Sub LoadAuxCustomField()
        Dim ds As New DataSet
        Me.AuxCustomBLL = New BusinessLogicLayer.AuxCustomFieldBLL
        ddlParameter.Visible = True
        Me.txtParameter.Visible = True
        ddlParameter.Items.Clear()
        ddlParameter.Items.Add("Custom Field Name")
        SetVisibleToFalse()
        ds = Me.AuxCustomBLL.GetTempAuxCustomField(txtParameter.Text, Me.txtDateFrom.Text, Me.txtDateTo.Text)
        If ds.Tables("AuxCusCtrl").Rows.Count > 0 Then
            Me.trBodyArea.Visible = True
            Me.lblDetail.Text = "Aux Custome Field Details"
            With gdData
                .AutoGenerateColumns = True
                .DataSource = ds.Tables("AuxCusCtrl")
                .DataBind()
            End With
            With Me.pgControl
                .GridID = Me.gdData.UniqueID
                .SetBindGrid()
            End With
        End If
        

        If ds.Tables.Count > 1 AndAlso ds.Tables("AuxCusCtrlCmd").Rows.Count > 0 Then
            Me.trBodyArea2.Visible = True
            Me.lblDetail2.Text = "Aux Custom Command"
            With gdData2
                .AutoGenerateColumns = True
                .DataSource = ds.Tables("AuxCusCtrlCmd")
                .DataBind()
            End With
            With Me.pgControl2
                .GridID = Me.gdData2.UniqueID
                .SetBindGrid()
            End With
        End If

        If ds.Tables.Count > 2 AndAlso ds.Tables("AuxCusCtrlValue").Rows.Count > 0 Then
            Me.trBodyArea3.Visible = True
            Me.lblDetail3.Text = "Aux Custom Value"
            With gdData3
                .AutoGenerateColumns = True
                .DataSource = ds.Tables("AuxCusCtrlValue")
                .DataBind()
            End With
            With Me.pgControl3
                .GridID = Me.gdData3.UniqueID
                .SetBindGrid()
            End With
        End If

        If ds.Tables.Count > 3 AndAlso ds.Tables("AuxCusCtrlEO").Rows.Count > 0 Then
            Me.trBodyArea4.Visible = True
            Me.lblDetail4.Text = "Aux Custom EO"
            With gdData4
                .AutoGenerateColumns = True
                .DataSource = ds.Tables("AuxCusCtrlEO")
                .DataBind()
            End With
            With Me.pgControl4
                .GridID = Me.gdData4.UniqueID
                .SetBindGrid()
            End With
        End If
    End Sub

    Private Sub LoadData(ByVal Type As String, ByVal Type2 As String)
        Select Case Type
            Case "User"
                LoadUserData()
            Case "Role"
                LoadRoleData()
            Case "Config Instances"
                LoadCountryConfig()
            Case "PCC Config"
                LoadPCCConfiguration()
            Case "Agent & Division"
                LoadAgentDivision()
            Case "Remark"
                LoadRemark()
            Case "Holiday"
                LoadHoliday()
            Case "Product"
                LoadProduct()
            Case "Pricing-Auxiliary"
                LoadPricingAuxiliary()
            Case "Fee-Air"
                LoadFeeAir(Type2)
            Case "Fee-Aux"
                LoadFeeAuxiliary()
            Case "Fee-Hotel"
                LoadHotelFee()
            Case "Airport"
                LoadAirpotCity()
            Case "Canned Remark"
                LoadTempCannedRemark()
            Case "GDSLineDef"
                LoadGDSLineDef()
            Case "Aux Custom Field"
                LoadAuxCustomField()

        End Select
    End Sub

    Public Sub SetSelectedValue(ByVal Type As String, ByVal Type2 As String)
        SelectedValue = Type
        SelectedValue2 = Type2
    End Sub

    Public Sub SetTextToEmpty()
        Me.txtParameter.Text = ""
        Me.txtDateFrom.Text = ""
        Me.txtDateTo.Text = ""
    End Sub

    Protected Sub btnSearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSearch.Click

        LoadData(SelectedValue, SelectedValue2)
    End Sub
End Class@


1.1.1.1
log
@no message
@
text
@@
