head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.07.03;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.07.03;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Public Partial Class SuppAirlineCommission
    Inherits System.Web.UI.UserControl

    Private BLL As BusinessLogicLayer.SupplierAirRuleBLL
    Private BLL2 As BusinessLogicLayer.StaffBLL
    Private BLL3 As BusinessLogicLayer.tblFunctionBLL

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.BLL = New BusinessLogicLayer.SupplierAirRuleBLL()
    End Sub

    Public Sub LoadData()
        Dim dt As DataTable
        Dim dt2 As DataTable
        trBodyArea1.Visible = False
        trBodyArea2.Visible = False
        dt = Me.BLL.GetTempAirlineComm()
        dt2 = Me.BLL.GetTempAirlineRule()

        If dt.Rows.Count > 0 Then
            trBodyArea1.Visible = True
            Me.lblComm.Text = "Airline Commission Details"
            With gdData
                .DataSource = dt
                .DataBind()
            End With
            With Me.pgControl
                .GridID = Me.gdData.UniqueID
                .SetBindGrid()
            End With
        End If

        If dt2.Rows.Count > 0 Then
            trBodyArea2.Visible = True
            Me.lblDetail.Text = "Airline Rule Details"
            With gdAirlineRule
                .DataSource = dt2
                .DataBind()
            End With
            With Me.pgControl
                .GridID = Me.gdAirlineRule.UniqueID
                .SetBindGrid()
            End With

        End If
        
    End Sub

    Public Sub SetDDL()
        Me.ddlParameter.Items.Clear()
        Me.ddlParameter.Items.Add("Airline Code")
    End Sub

    Public Sub GetTempAirlineByAirlineCode()
        Dim dt As DataTable
        Dim dt2 As DataTable
        Dim dt3 As DataTable
        trBodyArea1.Visible = False
        trBodyArea2.Visible = False
        trBodyArea3.Visible = False
        dt = Me.BLL.GetTempAirlineCommByAirlineCode(Me.txtParameter.Text, Me.txtDateFrom.Text, Me.txtDateTo.Text)
        dt2 = Me.BLL.GetTempAirlineCCByAirlineCode(Me.txtParameter.Text, Me.txtDateFrom.Text, Me.txtDateTo.Text)
        dt3 = Me.BLL.GetTempAirlineRuleByAirlineCode(Me.txtParameter.Text, Me.txtDateFrom.Text, Me.txtDateTo.Text)
        If dt.Rows.Count > 0 Then
            trBodyArea1.Visible = True
            Me.lblComm.Text = "Airline Commission Details"
            With gdData
                .DataSource = dt
                .DataBind()
            End With
            With Me.pgControl
                .GridID = Me.gdData.UniqueID
                .SetBindGrid()
            End With
        End If

        If dt2.Rows.Count > 0 Then
            trBodyArea2.Visible = True
            Me.lblAirCC.Text = "Airline CC Details"
            With gdAirlineCC
                .AutoGenerateColumns = True
                .DataSource = dt2
                .DataBind()
            End With
            With Me.pgControl2
                .GridID = Me.gdAirlineCC.UniqueID
                .SetBindGrid()
            End With
        End If

        If dt3.Rows.Count > 0 Then
            trBodyArea3.Visible = True
            Me.lblDetail.Text = "Airline Rule Details"
            With gdAirlineRule
                .AutoGenerateColumns = True
                .DataSource = dt3
                .DataBind()
            End With
            With Me.pgControl3
                .GridID = Me.gdAirlineRule.UniqueID
                .SetBindGrid()
            End With
        End If
        
    End Sub

    Protected Sub btnSearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSearch.Click
        GetTempAirlineByAirlineCode()
    End Sub
End Class@


1.1.1.1
log
@no message
@
text
@@
