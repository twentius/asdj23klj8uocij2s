head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.07.03;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.07.03;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Public Partial Class ucSupplier
    Inherits System.Web.UI.UserControl

    Public Shared SelectedValue As String
    Private StdAirlineBLL As BusinessLogicLayer.StdAirlineBLL
    Private AirlineContactBLL As BusinessLogicLayer.SupplierAirlinrContBLL
    Private ClientRateBLL As BusinessLogicLayer.ClientRateBLL
    Private SupplierVendorBLL As BusinessLogicLayer.SupplierVendorBLL
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'Me.trBodyArea.Visible = False
        'Me.trBodyArea2.Visible = False
        'Me.trBodyArea3.Visible = False
        'Me.trBodyArea4.Visible = False
    End Sub

    Private Sub SetVisibleToFalse()
        Me.trBodyArea.Visible = False
        Me.trBodyArea2.Visible = False
        Me.trBodyArea3.Visible = False
        Me.trBodyArea4.Visible = False
    End Sub

    Public Sub LoadAirlineInfo()
        Dim ds As New DataSet
        SetVisibleToFalse()
        ddlParameter.Visible = True
        Me.txtParameter.Visible = True
        ddlParameter.Items.Clear()
        ddlParameter.Items.Add("Airline Code")
        Me.StdAirlineBLL = New BusinessLogicLayer.StdAirlineBLL
        ds = Me.StdAirlineBLL.GetTempAirlineInfo(txtParameter.Text, txtDateFrom.Text, txtDateTo.Text)
        If ds.Tables("Airline").Rows.Count > 0 Then
            Me.lblDetail.Text = "Airlines Details"
            Me.trBodyArea.Visible = True
            With gdData
                .AutoGenerateColumns = True
                .DataSource = ds.Tables("Airline")
                .DataBind()
            End With
            With Me.pgControl
                .GridID = Me.gdData.UniqueID
                .SetBindGrid()
            End With
        End If
    End Sub

    Public Sub LoadAirlineContact()
        Dim ds As New DataSet
        SetVisibleToFalse()
        ddlParameter.Visible = True
        Me.txtParameter.Visible = True
        ddlParameter.Items.Clear()
        ddlParameter.Items.Add("Client  Name")
        Me.AirlineContactBLL = New BusinessLogicLayer.SupplierAirlinrContBLL
        ds = Me.AirlineContactBLL.GetTempAirlineContactInfo(txtParameter.Text, txtDateFrom.Text, txtDateTo.Text)
        If ds.Tables("Contact").Rows.Count > 0 Then
            Me.lblDetail.Text = "Airline Contact Details"
            Me.trBodyArea.Visible = True
            With gdData
                .AutoGenerateColumns = True
                .DataSource = ds.Tables("Contact")
                .DataBind()
            End With
            With Me.pgControl
                .GridID = Me.gdData.UniqueID
                .SetBindGrid()
            End With
        End If
    End Sub

    Public Sub LoadRateCode()
        Dim ds As New DataSet
        SetVisibleToFalse()
        ddlParameter.Visible = True
        Me.txtParameter.Visible = True

        Me.ClientRateBLL = New BusinessLogicLayer.ClientRateBLL
        If ddlParameter.SelectedValue.ToString() = "CWT" Then
            txtParameter.Text = "Yes"
            txtParameter.Readonly = True
        Else
            ddlParameter.Items.Clear()
            ddlParameter.Items.Add("Client Name")
            ddlParameter.Items.Add("CWT")
            txtParameter.Readonly = False
        End If
        ds = Me.ClientRateBLL.GetTempClientRateCodeInfo(txtParameter.Text, txtDateFrom.Text, txtDateTo.Text)
        If ds.Tables("Rate").Rows.Count > 0 Then
            Me.lblDetail.Text = "Hotel Rate Code Details"
            Me.trBodyArea.Visible = True
            With gdData
                .AutoGenerateColumns = True
                .DataSource = ds.Tables("Rate")
                .DataBind()
            End With
            With Me.pgControl
                .GridID = Me.gdData.UniqueID
                .SetBindGrid()
            End With
        End If
    End Sub

    Public Sub LoadVendorInfo()
        Dim ds As New DataSet
        SetVisibleToFalse()
        ddlParameter.Visible = True
        Me.txtParameter.Visible = True
        ddlParameter.Items.Clear()
        ddlParameter.Items.Add("Vendor Name")
        Me.SupplierVendorBLL = New BusinessLogicLayer.SupplierVendorBLL
        ds = Me.SupplierVendorBLL.GetTempVendorInfo(txtParameter.Text, txtDateFrom.Text, txtDateTo.Text)
        If ds.Tables("Vendor").Rows.Count > 0 Then
            Me.lblDetail.Text = "Vendors Details"
            Me.trBodyArea.Visible = True
            With gdData
                .AutoGenerateColumns = True
                .DataSource = ds.Tables("Vendor")
                .DataBind()
            End With
            With Me.pgControl
                .GridID = Me.gdData.UniqueID
                .SetBindGrid()
            End With
        End If
        If ds.Tables("Product").Rows.Count > 0 Then
            Me.lblDetail2.Text = "Vendors Product Details"
            Me.trBodyArea2.Visible = True
            With gdData2
                .AutoGenerateColumns = True
                .DataSource = ds.Tables("Product")
                .DataBind()
            End With
            With Me.pgControl
                .GridID = Me.gdData2.UniqueID
                .SetBindGrid()
            End With
        End If
        If ds.Tables("Contact").Rows.Count > 0 Then
            Me.lblDetail3.Text = "Vendors Contact Details"
            Me.trBodyArea3.Visible = True
            With gdData3
                .AutoGenerateColumns = True
                .DataSource = ds.Tables("Contact")
                .DataBind()
            End With
            With Me.pgControl
                .GridID = Me.gdData3.UniqueID
                .SetBindGrid()
            End With
        End If
    End Sub


    Public Sub LoadData(ByVal Type As String)
        Select Case Type
            Case "Airlines"
                Me.LoadAirlineInfo()
            Case "Airline Contact"
                Me.LoadAirlineContact()
            Case "Hotel Contact"
                Me.LoadRateCode()
            Case "Vendor"
                Me.LoadVendorInfo()
        End Select
    End Sub

    Public Sub SetSelectedValue(ByVal Type As String)
        SelectedValue = Type
    End Sub

    Public Sub SetTextToEmpty()
        Me.txtParameter.Text = ""
        Me.txtDateFrom.Text = ""
        Me.txtDateTo.Text = ""
    End Sub


    Protected Sub btnSearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSearch.Click
        LoadData(SelectedValue)
    End Sub
End Class@


1.1.1.1
log
@no message
@
text
@@
