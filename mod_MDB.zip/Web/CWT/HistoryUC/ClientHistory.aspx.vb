head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.07.03;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.07.03;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Public Partial Class ClientHistory
    Inherits System.Web.UI.Page

    Private BLL2 As BusinessLogicLayer.StaffBLL
    Private BLL3 As BusinessLogicLayer.tblFunctionBLL

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.BLL2 = New BusinessLogicLayer.StaffBLL()
        Me.BLL3 = New BusinessLogicLayer.tblFunctionBLL()

        AccessControl("History")
    End Sub

    Public Sub LoadData(ByVal Type As String)
        Select Case Type
            Case "ClientInfo"
                Me.ucClient1.LoadClientInfo()
            Case "Billing"
                Me.ucClient1.LoadBillingInfo()
            Case "Payment"
                Me.ucClient1.LoadPaymentInfo()
            Case "Application"
                Me.ucClient1.LoadMFInfo()
            Case "Product"
                Me.ucClient1.LoadMFProductInfo()
            Case "AccountingData"
                Me.ucClient1.LoadAccountData()
            Case "Config"
                Me.ucClient1.LoadReportingConfig()
            Case "ReasonCode"
                Me.ucClient1.LoadReasonCode()
            Case "ClientReporting"
                Me.ucClient1.LoadClientReporting()
            Case "AirGeneral&Class"
                Me.ucClient1.LoadPolicyAirInfo()
            Case "HighRisk"
                Me.ucClient1.LoadHighRisk()
            Case "Hotel"
                Me.ucClient1.LoadHotelPolicyInfo()
            Case "Car"
                Me.ucClient1.LoadCarInfo()
            Case "Auxiliary"
                Me.ucClient1.LoadAuxInfo()
            Case "Pricing-Air"
                Me.ucAirPrice1.GetClientPricingByID()
            Case "Pricing-Aux"
                Me.ucClient1.LoadPricingAuxInfo()
            Case "Pricing-HotelFee"
                Me.ucClient1.LoadPricingClientHotelInfo()
            Case "SLA"
                Me.ucClient1.LoadSLAInfo()
            Case "Services"
                Me.ucClient1.LoadServiceConfigInfo()
            Case "Approval"
                Me.ucClient1.LoadTAInfo()
            Case "Incident"
                Me.ucClient1.LoadIncidentInfo()
            Case "CannedRemark"
                Me.ucClient1.LoadCannedRemarkInfo()
            Case "PCCConfiguration"
                Me.ucClient1.LoadPCCInfo()
            Case "GDSMapping"
                Me.ucClient1.LoadGDSInfo()
        End Select
        Me.ucClient1.SetSelectedValue(Type)
    End Sub

    Protected Sub ddlField_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.ucClient1.SetTextToEmpty()
        If Me.ddlField.SelectedValue.ToString() <> "0" And ddlField.SelectedValue.ToString <> "Pricing-Air" Then
            Me.ucClient1.Visible = True
            Me.ucAirPrice1.Visible = False
            LoadData(ddlField.SelectedValue.ToString())
        ElseIf ddlField.SelectedValue.ToString = "Pricing-Air" Then
            Me.ucClient1.Visible = False
            Me.ucAirPrice1.Visible = True
            LoadData(ddlField.SelectedValue.ToString())
        Else
            Me.ucClient1.Visible = False
            Me.ucAirPrice1.Visible = False
        End If
    End Sub

    Private Sub AccessControl(ByVal title As String)

        Dim userName As String
        Dim oDatatable As DataTable
        Dim oDataTable2 As DataTable

        Static roleID As String

        userName = ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName
        oDatatable = Me.BLL2.GetUserByID(userName)

        If oDatatable.Rows.Count > 0 Then
            roleID = oDatatable.Rows(0).Item("RoleID").ToString
        End If

        oDataTable2 = Me.BLL3.GetUserRole2(roleID)
        If oDataTable2.Rows.Count > 0 Then
            For k As Integer = 0 To oDataTable2.Rows.Count - 1
                If oDataTable2.Rows(k).Item("functionGroup") = "0" Then
                    If Not oDataTable2.Rows(k).Item("Role") = "Super Admin" Then
                        If oDataTable2.Rows(k).Item("functionName").ToString = title Then
                            Call Me.toggleControl()

                        End If
                    End If
                End If
            Next
        Else
            Call Me.toggleControl()
        End If


    End Sub

    Public Sub toggleControl()
        Me.tableHistory.Visible = False
    End Sub

End Class@


1.1.1.1
log
@no message
@
text
@@
