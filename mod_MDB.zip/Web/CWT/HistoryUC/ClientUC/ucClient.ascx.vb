head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.07.03;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.07.03;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Public Partial Class ucClient
    Inherits System.Web.UI.UserControl

    Public Shared SelectedValue As String
    Private CompanyBLL As BusinessLogicLayer.CompanyBLL
    Private ComPaymentBLL As BusinessLogicLayer.ComPaymentCardBLL
    Private CompanyMFBLL As BusinessLogicLayer.CompanyMFBLL
    Private ComReportBLL As BusinessLogicLayer.CompanyReportBLL
    Private ComReasonBLL As BusinessLogicLayer.ReasonCodeBLL
    Private ComPolicyBLL As BusinessLogicLayer.CompanyPolicyBLL
    Private HighRiskBLL As BusinessLogicLayer.HighRiskDestBLL
    Private ComAuxPriceBLL As BusinessLogicLayer.CompanyAuxPriceBLL
    Private HotelFeeBLL As BusinessLogicLayer.HotelFeeBLL
    Private SLABLL As BusinessLogicLayer.SLABLL
    Private ComServiceBLL As BusinessLogicLayer.CompanyServiceBLL
    Private ComIncidentBLL As BusinessLogicLayer.CompanyIncidentBLL
    Private ComCannedRemark As BusinessLogicLayer.CompanyCannedRemarkBLL
    Private LineDefBLL As BusinessLogicLayer.LineDefBLL
    Private AccountBLL As BusinessLogicLayer.CompanyAccountingBLL


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'Me.trBodyArea.Visible = False
        'Me.trBodyArea2.Visible = False
        'Me.trBodyArea3.Visible = False
        'Me.trBodyArea4.Visible = False
    End Sub

    Private Sub SetVisibleToFalse()
        Me.trBodyArea.Visible = False
        Me.trBodyArea2.Visible = False
        Me.trBodyArea3.Visible = False
        Me.trBodyArea4.Visible = False
    End Sub

    Public Sub LoadClientInfo()
        Dim ds As New DataSet
        SetVisibleToFalse()
        ddlParameter.Visible = True
        Me.txtParameter.Visible = True
        ddlParameter.Items.Clear()
        ddlParameter.Items.Add("Client Name")
        Me.CompanyBLL = New BusinessLogicLayer.CompanyBLL()
        ds = Me.CompanyBLL.GetTempClientInfo(txtParameter.Text, txtDateFrom.Text, txtDateTo.Text)
        If ds.Tables("ClientMaster").Rows.Count > 0 Then
            Me.lblDetail.Text = "Client Info Details"
            Me.trBodyArea.Visible = True
            With gdData
                .AutoGenerateColumns = True
                .DataSource = ds.Tables("ClientMaster")
                .DataBind()

            End With
            With Me.pgControl
                .GridID = Me.gdData.UniqueID
                .SetBindGrid()
            End With
        End If

        If ds.Tables.Count > 1 AndAlso ds.Tables("CWTContact").Rows.Count > 0 Then
            Me.trBodyArea2.Visible = True
            Me.lblDetail2.Text = "CWT Contact Details"
            With gdData2
                .AutoGenerateColumns = True
                .DataSource = ds.Tables("CWTContact")
                .DataBind()
            End With
            With Me.pgControl2
                .GridID = Me.gdData2.UniqueID
                .SetBindGrid()
            End With
        End If

        If ds.Tables.Count > 2 AndAlso ds.Tables("TM").Rows.Count > 0 Then
            Me.trBodyArea3.Visible = True
            Me.lblDetail3.Text = "TM Contact Details"
            With gdData3
                .AutoGenerateColumns = True
                .DataSource = ds.Tables("TM")
                .DataBind()
            End With
            With Me.pgControl3
                .GridID = Me.gdData3.UniqueID
                .SetBindGrid()
            End With
        End If
    End Sub

    Public Sub LoadBillingInfo()
        Dim ds As New DataSet
        SetVisibleToFalse()
        ddlParameter.Visible = True
        Me.txtParameter.Visible = True
        ddlParameter.Items.Clear()
        ddlParameter.Items.Add("Client Name")
        Me.CompanyBLL = New BusinessLogicLayer.CompanyBLL()

        ds = Me.CompanyBLL.GetTempBillingInfo(txtParameter.Text, txtDateFrom.Text, txtDateTo.Text)
        If ds.Tables("Address").Rows.Count > 0 Then
            Me.trBodyArea.Visible = True
            Me.lblDetail.Text = "Billing Address Details"
            With gdData
                .AutoGenerateColumns = True
                .DataSource = ds.Tables("Address")
                .DataBind()
            End With
            With Me.pgControl
                .GridID = Me.gdData.UniqueID
                .SetBindGrid()
            End With
        End If

        If ds.Tables.Count > 1 AndAlso ds.Tables("Email").Rows.Count > 0 Then
            Me.trBodyArea2.Visible = True
            Me.lblDetail2.Text = "Billing Email Details"
            With gdData2
                .AutoGenerateColumns = True
                .DataSource = ds.Tables("Email")
                .DataBind()
            End With
            With Me.pgControl2
                .GridID = Me.gdData2.UniqueID
                .SetBindGrid()
            End With
        End If

        If ds.Tables.Count > 2 AndAlso ds.Tables("Delivery").Rows.Count > 0 Then
            Me.trBodyArea3.Visible = True
            Me.lblDetail3.Text = "Delivery Details"
            With gdData3
                .AutoGenerateColumns = True
                .DataSource = ds.Tables("Delivery")
                .DataBind()
            End With
            With Me.pgControl3
                .GridID = Me.gdData3.UniqueID
                .SetBindGrid()
            End With
        End If

        If ds.Tables("Client").Rows.Count > 0 Then
            Me.trBodyArea4.Visible = True
            Me.lblDetail4.Text = "Client Billing Details"
            With gdData4
                .AutoGenerateColumns = True
                .DataSource = ds.Tables("Client")
                .DataBind()
            End With
            With Me.pgControl4
                .GridID = Me.gdData4.UniqueID
                .SetBindGrid()
            End With
        End If

    End Sub

    Public Sub LoadPaymentInfo()
        Dim ds As New DataSet
        SetVisibleToFalse()
        ddlParameter.Visible = True
        Me.txtParameter.Visible = True
        ddlParameter.Items.Clear()
        ddlParameter.Items.Add("Client Name")

        Me.ComPaymentBLL = New BusinessLogicLayer.ComPaymentCardBLL()

        ds = Me.ComPaymentBLL.GetTempPaymentInfo(txtParameter.Text, txtDateFrom.Text, txtDateTo.Text)
        If ds.Tables("Payment").Rows.Count > 0 Then
            Me.lblDetail.Text = "Payment Info Details"
            Me.trBodyArea.Visible = True
            With gdData
                .AutoGenerateColumns = True
                .DataSource = ds.Tables("Payment")
                .DataBind()
            End With
            With Me.pgControl
                .GridID = Me.gdData.UniqueID
                .SetBindGrid()
            End With

        End If
        
        'If ds.Tables.Count > 1 And ds.Tables("Client").Rows.Count > 0 Then
        '    Me.trBodyArea2.Visible = True
        '    Me.lblDetail2.Text = "Client Info Details"
        '    With gdData2
        '        .AutoGenerateColumns = True
        '        .DataSource = ds.Tables("Client")
        '        .DataBind()
        '    End With
        '    With Me.pgControl2
        '        .GridID = Me.gdData2.UniqueID
        '        .SetBindGrid()
        '    End With
        'End If

    End Sub

    Public Sub LoadMFInfo()
        Dim ds As New DataSet
        SetVisibleToFalse()
        ddlParameter.Visible = True
        Me.txtParameter.Visible = True
        ddlParameter.Items.Clear()
        ddlParameter.Items.Add("Client Name")

        Me.CompanyMFBLL = New BusinessLogicLayer.CompanyMFBLL
        ds = Me.CompanyMFBLL.GetTempMFInfo(txtParameter.Text, txtDateFrom.Text, txtDateTo.Text)
        If ds.Tables("Bank").Rows.Count > 0 Then
            Me.lblDetail.Text = "MF Bank Info Details"
            Me.trBodyArea.Visible = True
            With gdData
                .AutoGenerateColumns = True
                .DataSource = ds.Tables("Bank")
                .DataBind()
            End With
            With Me.pgControl
                .GridID = Me.gdData.UniqueID
                .SetBindGrid()
            End With
        End If
        If ds.Tables.Count > 1 And ds.Tables("CC").Rows.Count > 0 Then
            Me.trBodyArea2.Visible = True
            Me.lblDetail2.Text = "MF CC Info Details"
            With gdData2
                .AutoGenerateColumns = True
                .DataSource = ds.Tables("CC")
                .DataBind()
            End With
            With Me.pgControl2
                .GridID = Me.gdData2.UniqueID
                .SetBindGrid()
            End With
        End If
        If ds.Tables.Count > 2 And ds.Tables("Fee").Rows.Count > 0 Then
            Me.trBodyArea3.Visible = True
            Me.lblDetail3.Text = "MF Merchant Fee (Client Standard % and Apply Standard)"
            With gdData3
                .AutoGenerateColumns = True
                .DataSource = ds.Tables("Fee")
                .DataBind()
            End With
            With Me.pgControl3
                .GridID = Me.gdData3.UniqueID
                .SetBindGrid()
            End With
        End If
    End Sub

    Public Sub LoadMFProductInfo()
        Dim ds As New DataSet
        SetVisibleToFalse()
        ddlParameter.Visible = True
        Me.txtParameter.Visible = True
        ddlParameter.Items.Clear()
        ddlParameter.Items.Add("Client Name")

        Me.CompanyMFBLL = New BusinessLogicLayer.CompanyMFBLL
        ds = Me.CompanyMFBLL.GetTempMFProductInfo(txtParameter.Text, txtDateFrom.Text, txtDateTo.Text)
        If ds.Tables("Product").Rows.Count > 0 Then
            Me.lblDetail.Text = "MF Product Info Details"
            Me.trBodyArea.Visible = True
            With gdData
                .AutoGenerateColumns = True
                .DataSource = ds.Tables("Product")
                .DataBind()
            End With
            With Me.pgControl
                .GridID = Me.gdData.UniqueID
                .SetBindGrid()
            End With
        End If

        If ds.Tables.Count > 1 And ds.Tables("ProductApply").Rows.Count > 0 Then
            Me.trBodyArea2.Visible = True
            Me.lblDetail2.Text = "MF Product Apply Standard Details"
            With gdData2
                .AutoGenerateColumns = True
                .DataSource = ds.Tables("ProductApply")
                .DataBind()
            End With
            With Me.pgControl2
                .GridID = Me.gdData2.UniqueID
                .SetBindGrid()
            End With
        End If
    End Sub

    Public Sub LoadAccountData()
        Me.AccountBLL = New BusinessLogicLayer.CompanyAccountingBLL()
        Dim ds As New DataSet
        SetVisibleToFalse()
        ddlParameter.Visible = True
        Me.txtParameter.Visible = True
        ddlParameter.Items.Clear()
        ddlParameter.Items.Add("Client Name")

        ds = Me.AccountBLL.GetTempAccData(txtParameter.Text, txtDateFrom.Text, txtDateTo.Text)
        If ds.Tables("AccountingData").Rows.Count > 0 Then
            Me.lblDetail.Text = "Accounting Data"
            Me.trBodyArea.Visible = True
            With gdData
                .AutoGenerateColumns = True
                .DataSource = ds.Tables("AccountingData")
                .DataBind()
            End With
            With Me.pgControl
                .GridID = Me.gdData.UniqueID
                .SetBindGrid()
            End With
        End If
    End Sub

    Public Sub LoadReportingConfig()
        Dim ds As New DataSet
        SetVisibleToFalse()
        ddlParameter.Visible = True
        Me.txtParameter.Visible = True
        ddlParameter.Items.Clear()
        ddlParameter.Items.Add("Client Name")

        Me.ComReportBLL = New BusinessLogicLayer.CompanyReportBLL
        ds = Me.ComReportBLL.GetTempReportConfig(txtParameter.Text, txtDateFrom.Text, txtDateTo.Text)
        If ds.Tables("Config").Rows.Count > 0 Then
            Me.lblDetail.Text = "Report Configuration Details"
            Me.trBodyArea.Visible = True
            With gdData
                .AutoGenerateColumns = True
                .DataSource = ds.Tables("Config")
                .DataBind()
            End With
            With Me.pgControl
                .GridID = Me.gdData.UniqueID
                .SetBindGrid()
            End With
        End If
    End Sub

    Public Sub LoadReasonCode()
        Dim ds As New DataSet
        SetVisibleToFalse()
        ddlParameter.Visible = True
        Me.txtParameter.Visible = True
        ddlParameter.Items.Clear()
        ddlParameter.Items.Add("Client Name")

        Me.ComReasonBLL = New BusinessLogicLayer.ReasonCodeBLL
        ds = Me.ComReasonBLL.GetTempReasonCodeInfo(txtParameter.Text, txtDateFrom.Text, txtDateTo.Text)
        If ds.Tables("Setting").Rows.Count > 0 Then
            Me.trBodyArea.Visible = True
            Me.lblDetail.Text = "Reason Code Settings  Details"
            With gdData
                .AutoGenerateColumns = True
                .DataSource = ds.Tables("Setting")
                .DataBind()
            End With
            With Me.pgControl
                .GridID = Me.gdData.UniqueID
                .SetBindGrid()
            End With
        End If
        If ds.Tables.Count > 1 And ds.Tables("ClientCode").Rows.Count > 0 Then
            Me.trBodyArea2.Visible = True
            Me.lblDetail2.Text = "Client Reason Code Details"
            With gdData2
                .AutoGenerateColumns = True
                .DataSource = ds.Tables("ClientCode")
                .DataBind()
            End With
            With Me.pgControl2
                .GridID = Me.gdData2.UniqueID
                .SetBindGrid()
            End With
        End If
    End Sub

    Public Sub LoadClientReporting()
        Dim ds As New DataSet
        SetVisibleToFalse()
        ddlParameter.Visible = True
        Me.txtParameter.Visible = True
        ddlParameter.Items.Clear()
        ddlParameter.Items.Add("Client Name")
        Me.ComReportBLL = New BusinessLogicLayer.CompanyReportBLL
        ds = Me.ComReportBLL.GetTempReportClient(txtParameter.Text, txtDateFrom.Text, txtDateTo.Text)
        If ds.Tables("Reporting").Rows.Count > 0 Then
            Me.lblDetail.Text = "Client Reporting  Details"
            Me.trBodyArea.Visible = True
            With gdData
                .AutoGenerateColumns = True
                .DataSource = ds.Tables("Reporting")
                .DataBind()
            End With
            With Me.pgControl
                .GridID = Me.gdData.UniqueID
                .SetBindGrid()
            End With
        End If
        If ds.Tables.Count > 1 And ds.Tables("GDS").Rows.Count > 0 Then
            Me.trBodyArea2.Visible = True
            Me.lblDetail2.Text = "GDS Mapping Details"
            With gdData2
                .AutoGenerateColumns = True
                .DataSource = ds.Tables("GDS")
                .DataBind()
            End With
            With Me.pgControl2
                .GridID = Me.gdData2.UniqueID
                .SetBindGrid()
            End With
        End If

        If ds.Tables.Count > 2 And ds.Tables("ReportDropDown").Rows.Count > 0 Then
            Me.trBodyArea3.Visible = True
            Me.lblDetail3.Text = "Reporting Drop Down Details"
            With gdData3
                .AutoGenerateColumns = True
                .DataSource = ds.Tables("ReportDropDown")
                .DataBind()
            End With
            With Me.pgControl3
                .GridID = Me.gdData3.UniqueID
                .SetBindGrid()
            End With
        End If
    End Sub

    Public Sub LoadPolicyAirInfo()
        Dim ds As New DataSet
        SetVisibleToFalse()
        ddlParameter.Visible = True
        Me.txtParameter.Visible = True
        ddlParameter.Items.Clear()
        ddlParameter.Items.Add("Client Name")
        Me.ComPolicyBLL = New BusinessLogicLayer.CompanyPolicyBLL
        ds = Me.ComPolicyBLL.GetTempAirPolicyInfo(txtParameter.Text, txtDateFrom.Text, txtDateTo.Text)
        If ds.Tables("AirClass").Rows.Count > 0 Then
            Me.lblDetail.Text = "Air Class  Details"
            Me.trBodyArea.Visible = True
            With gdData
                .AutoGenerateColumns = True
                .DataSource = ds.Tables("AirClass")
                .DataBind()
            End With
            With Me.pgControl
                .GridID = Me.gdData.UniqueID
                .SetBindGrid()
            End With
        End If
        If ds.Tables.Count > 1 And ds.Tables("AirPolicy").Rows.Count > 0 Then
            Me.trBodyArea2.Visible = True
            Me.lblDetail2.Text = "Air Policy Details"
            With gdData2
                .AutoGenerateColumns = True
                .DataSource = ds.Tables("AirPolicy")
                .DataBind()
            End With
            With Me.pgControl2
                .GridID = Me.gdData2.UniqueID
                .SetBindGrid()
            End With
        End If
    End Sub

    Public Sub LoadHighRisk()
        Dim ds As New DataSet
        SetVisibleToFalse()
        ddlParameter.Visible = True
        Me.txtParameter.Visible = True
        ddlParameter.Items.Clear()
        ddlParameter.Items.Add("Client Name")
        Me.HighRiskBLL = New BusinessLogicLayer.HighRiskDestBLL
        ds = Me.HighRiskBLL.GetTempHighRisk(txtParameter.Text, txtDateFrom.Text, txtDateTo.Text)
        If ds.Tables("RiskAirline").Rows.Count > 0 Then
            Me.lblDetail.Text = "High Risk Airline Details"
            Me.trBodyArea.Visible = True
            With gdData
                .AutoGenerateColumns = True
                .DataSource = ds.Tables("RiskAirline")
                .DataBind()
            End With
            With Me.pgControl
                .GridID = Me.gdData.UniqueID
                .SetBindGrid()
            End With
        End If
        If ds.Tables.Count > 1 And ds.Tables("RiskDes").Rows.Count > 0 Then
            Me.trBodyArea2.Visible = True
            Me.lblDetail2.Text = "High Risk Cities Details"
            With gdData2
                .AutoGenerateColumns = True
                .DataSource = ds.Tables("RiskDes")
                .DataBind()
            End With
            With Me.pgControl2
                .GridID = Me.gdData2.UniqueID
                .SetBindGrid()
            End With
        End If
    End Sub

    Public Sub LoadHotelPolicyInfo()
        Dim ds As New DataSet
        SetVisibleToFalse()
        ddlParameter.Visible = True
        Me.txtParameter.Visible = True
        ddlParameter.Items.Clear()
        ddlParameter.Items.Add("Client Name")
        Me.ComPolicyBLL = New BusinessLogicLayer.CompanyPolicyBLL
        ds = Me.ComPolicyBLL.GetTempHotelInfo(txtParameter.Text, txtDateFrom.Text, txtDateTo.Text)
        If ds.Tables("Room").Rows.Count > 0 Then
            Me.lblDetail.Text = "Client Hotel Room Details"
            Me.trBodyArea.Visible = True
            With gdData
                .AutoGenerateColumns = True
                .DataSource = ds.Tables("Room")
                .DataBind()
            End With
            With Me.pgControl
                .GridID = Me.gdData.UniqueID
                .SetBindGrid()
            End With
        End If
        If ds.Tables.Count > 1 And ds.Tables("Policy").Rows.Count > 0 Then
            Me.trBodyArea2.Visible = True
            Me.lblDetail2.Text = "Client Hotel Gen Policy Details"
            With gdData2
                .AutoGenerateColumns = True
                .DataSource = ds.Tables("Policy")
                .DataBind()
            End With
            With Me.pgControl2
                .GridID = Me.gdData2.UniqueID
                .SetBindGrid()
            End With
        End If
    End Sub

    Public Sub LoadCarInfo()
        Dim ds As New DataSet
        SetVisibleToFalse()
        ddlParameter.Visible = True
        Me.txtParameter.Visible = True
        ddlParameter.Items.Clear()
        ddlParameter.Items.Add("Client Name")
        Me.ComPolicyBLL = New BusinessLogicLayer.CompanyPolicyBLL
        ds = Me.ComPolicyBLL.GetTempCarInfo(txtParameter.Text, txtDateFrom.Text, txtDateTo.Text)
        If ds.Tables("CarType").Rows.Count > 0 Then
            Me.lblDetail.Text = "Client Car Type Details"
            Me.trBodyArea.Visible = True
            With gdData
                .AutoGenerateColumns = True
                .DataSource = ds.Tables("CarType")
                .DataBind()
            End With
            With Me.pgControl
                .GridID = Me.gdData.UniqueID
                .SetBindGrid()
            End With
        End If
        If ds.Tables.Count > 1 And ds.Tables("Policy").Rows.Count > 0 Then
            Me.trBodyArea2.Visible = True
            Me.lblDetail2.Text = "Client Car Gen Policy Details"
            With gdData2
                .AutoGenerateColumns = True
                .DataSource = ds.Tables("Policy")
                .DataBind()
            End With
            With Me.pgControl2
                .GridID = Me.gdData2.UniqueID
                .SetBindGrid()
            End With
        End If
    End Sub

    Public Sub LoadAuxInfo()
        Dim ds As New DataSet
        SetVisibleToFalse()
        ddlParameter.Visible = True
        Me.txtParameter.Visible = True
        ddlParameter.Items.Clear()
        ddlParameter.Items.Add("Client Name")
        Me.ComPolicyBLL = New BusinessLogicLayer.CompanyPolicyBLL
        ds = Me.ComPolicyBLL.GetTempAuxInfo(txtParameter.Text, txtDateFrom.Text, txtDateTo.Text)
        If ds.Tables("Aux").Rows.Count > 0 Then
            Me.lblDetail.Text = "Client Auxiliary Details"
            Me.trBodyArea.Visible = True
            With gdData
                .AutoGenerateColumns = True
                .DataSource = ds.Tables("Aux")
                .DataBind()
            End With
            With Me.pgControl
                .GridID = Me.gdData.UniqueID
                .SetBindGrid()
            End With
        End If
    End Sub

    Public Sub LoadPricingClientHotelInfo()
        Dim ds As New DataSet
        SetVisibleToFalse()
        ddlParameter.Visible = True
        Me.txtParameter.Visible = True
        ddlParameter.Items.Clear()
        ddlParameter.Items.Add("Client Name")
        Me.HotelFeeBLL = New BusinessLogicLayer.HotelFeeBLL
        ds = Me.HotelFeeBLL.GetTempHotelClientFee(txtParameter.Text, txtDateFrom.Text, txtDateTo.Text)
        If ds.Tables("HotelClient").Rows.Count > 0 Then
            Me.lblDetail.Text = "Client Hotel Fee Details"
            Me.trBodyArea.Visible = True
            With gdData
                .AutoGenerateColumns = True
                .DataSource = ds.Tables("HotelClient")
                .DataBind()
            End With
            With Me.pgControl
                .GridID = Me.gdData.UniqueID
                .SetBindGrid()
            End With
        End If
    End Sub

    Public Sub LoadPricingAuxInfo()
        Dim ds As New DataSet
        SetVisibleToFalse()
        ddlParameter.Visible = True
        Me.txtParameter.Visible = True
        ddlParameter.Items.Clear()
        ddlParameter.Items.Add("Client Name")
        Me.ComAuxPriceBLL = New BusinessLogicLayer.CompanyAuxPriceBLL
        ds = Me.ComAuxPriceBLL.GetTempAuxFeeInfo(txtParameter.Text, txtDateFrom.Text, txtDateTo.Text)
        If ds.Tables("AuxFee").Rows.Count > 0 Then
            Me.lblDetail.Text = "Client Pricing Auxiliary Details"
            Me.trBodyArea.Visible = True
            With gdData
                .AutoGenerateColumns = True
                .DataSource = ds.Tables("AuxFee")
                .DataBind()
            End With
            With Me.pgControl
                .GridID = Me.gdData.UniqueID
                .SetBindGrid()
            End With
        End If
    End Sub

    Public Sub LoadSLAInfo()
        Dim ds As New DataSet
        SetVisibleToFalse()
        ddlParameter.Visible = True
        Me.txtParameter.Visible = True
        ddlParameter.Items.Clear()
        ddlParameter.Items.Add("Client Name")
        Me.SLABLL = New BusinessLogicLayer.SLABLL
        ds = Me.SLABLL.GetTempSLA(txtParameter.Text, txtDateFrom.Text, txtDateTo.Text)
        If ds.Tables("SLA").Rows.Count > 0 Then
            Me.lblDetail.Text = "Client SLA Details"
            Me.trBodyArea.Visible = True
            With gdData
                .AutoGenerateColumns = True
                .DataSource = ds.Tables("SLA")
                .DataBind()
            End With
            With Me.pgControl
                .GridID = Me.gdData.UniqueID
                .SetBindGrid()
            End With
        End If
    End Sub

    Public Sub LoadServiceConfigInfo()
        Dim ds As New DataSet
        SetVisibleToFalse()
        ddlParameter.Visible = True
        Me.txtParameter.Visible = True
        ddlParameter.Items.Clear()
        ddlParameter.Items.Add("Client Name")
        Me.ComServiceBLL = New BusinessLogicLayer.CompanyServiceBLL
        ds = Me.ComServiceBLL.GetTempServiceConfigInfo(txtParameter.Text, txtDateFrom.Text, txtDateTo.Text)
        If ds.Tables("Service").Rows.Count > 0 Then
            Me.lblDetail.Text = "Client Service Configuration Details"
            Me.trBodyArea.Visible = True
            With gdData
                .AutoGenerateColumns = True
                .DataSource = ds.Tables("Service")
                .DataBind()
            End With
            With Me.pgControl
                .GridID = Me.gdData.UniqueID
                .SetBindGrid()
            End With
        End If
    End Sub

    Public Sub LoadTAInfo()
        Dim ds As New DataSet
        SetVisibleToFalse()
        ddlParameter.Visible = True
        Me.txtParameter.Visible = True
        ddlParameter.Items.Clear()
        ddlParameter.Items.Add("Client Name")
        Me.ComPolicyBLL = New BusinessLogicLayer.CompanyPolicyBLL
        ds = Me.ComPolicyBLL.GetTempTAInfo(txtParameter.Text, txtDateFrom.Text, txtDateTo.Text)
        If ds.Tables("TA").Rows.Count > 0 Then
            Me.lblDetail.Text = "Client Travel Authorization Details"
            Me.trBodyArea.Visible = True
            With gdData
                .AutoGenerateColumns = True
                .DataSource = ds.Tables("TA")
                .DataBind()
            End With
            With Me.pgControl
                .GridID = Me.gdData.UniqueID
                .SetBindGrid()
            End With
        End If
    End Sub

    Public Sub LoadIncidentInfo()
        Dim ds As New DataSet
        SetVisibleToFalse()
        ddlParameter.Visible = True
        Me.txtParameter.Visible = True
        ddlParameter.Items.Clear()
        ddlParameter.Items.Add("Client Name")
        Me.ComIncidentBLL = New BusinessLogicLayer.CompanyIncidentBLL
        ds = Me.ComIncidentBLL.GetTempIncidentInfo(txtParameter.Text, txtDateFrom.Text, txtDateTo.Text)
        If ds.Tables("Incident").Rows.Count > 0 Then
            Me.lblDetail.Text = "Client Incident Management Details"
            Me.trBodyArea.Visible = True
            With gdData
                .AutoGenerateColumns = True
                .DataSource = ds.Tables("Incident")
                .DataBind()
            End With
            With Me.pgControl
                .GridID = Me.gdData.UniqueID
                .SetBindGrid()
            End With
        End If
    End Sub

    Public Sub LoadCannedRemarkInfo()
        Dim ds As New DataSet
        SetVisibleToFalse()
        ddlParameter.Visible = True
        Me.txtParameter.Visible = True
        ddlParameter.Items.Clear()
        ddlParameter.Items.Add("Client Name")
        Me.ComCannedRemark = New BusinessLogicLayer.CompanyCannedRemarkBLL
        ds = Me.ComCannedRemark.GetTempCannedRemarkInfo(txtParameter.Text, txtDateFrom.Text, txtDateTo.Text)
        If ds.Tables("Remark").Rows.Count > 0 Then
            Me.lblDetail.Text = "Client Canned Remark Details"
            Me.trBodyArea.Visible = True
            With gdData
                .AutoGenerateColumns = True
                .DataSource = ds.Tables("Remark")
                .DataBind()
            End With
            With Me.pgControl
                .GridID = Me.gdData.UniqueID
                .SetBindGrid()
            End With
        End If
    End Sub

    Public Sub LoadPCCInfo()
        Dim ds As New DataSet
        SetVisibleToFalse()
        ddlParameter.Visible = True
        Me.txtParameter.Visible = True
        ddlParameter.Items.Clear()
        ddlParameter.Items.Add("Client Name")
        Me.CompanyBLL = New BusinessLogicLayer.CompanyBLL
        ds = Me.CompanyBLL.GetTempPCCInfo(txtParameter.Text, txtDateFrom.Text, txtDateTo.Text)
        If ds.Tables("PCC").Rows.Count > 0 Then
            Me.lblDetail.Text = "Client PCC Details"
            Me.trBodyArea.Visible = True
            With gdData
                .AutoGenerateColumns = True
                .DataSource = ds.Tables("PCC")
                .DataBind()
            End With
            With Me.pgControl
                .GridID = Me.gdData.UniqueID
                .SetBindGrid()
            End With
        End If
    End Sub

    Public Sub LoadGDSInfo()
        Dim ds As New DataSet
        SetVisibleToFalse()
        ddlParameter.Visible = True
        Me.txtParameter.Visible = True
        ddlParameter.Items.Clear()
        ddlParameter.Items.Add("Client Name")
        Me.LineDefBLL = New BusinessLogicLayer.LineDefBLL
        ds = Me.LineDefBLL.GetTempGDSInfo(txtParameter.Text, txtDateFrom.Text, txtDateTo.Text)
        If ds.Tables("GDS").Rows.Count > 0 Then
            Me.lblDetail.Text = "Client GDS Details"
            Me.trBodyArea.Visible = True
            With gdData
                .AutoGenerateColumns = True
                .DataSource = ds.Tables("GDS")
                .DataBind()
            End With
            With Me.pgControl
                .GridID = Me.gdData.UniqueID
                .SetBindGrid()
            End With
        End If
    End Sub

    Public Sub SetSelectedValue(ByVal Type As String)
        SelectedValue = Type
    End Sub

    Public Sub SetTextToEmpty()
        Me.txtParameter.Text = ""
        Me.txtDateFrom.Text = ""
        Me.txtDateTo.Text = ""
    End Sub


    Private Sub LoadData(ByVal Type As String)
        Select Case Type
            Case "ClientInfo"
                Me.LoadClientInfo()
            Case "Billing"
                Me.LoadBillingInfo()
            Case "Payment"
                Me.LoadPaymentInfo()
            Case "Application"
                Me.LoadMFInfo()
            Case "Product"
                Me.LoadMFProductInfo()
            Case "AccountingData"
                LoadAccountData()
            Case "Config"
                LoadReportingConfig()
            Case "ReasonCode"
                Me.LoadReasonCode()
            Case "ClientReporting"
                Me.LoadClientReporting()
            Case "AirGeneral&Class"
                Me.LoadPolicyAirInfo()
            Case "HighRisk"
                Me.LoadHighRisk()
            Case "Hotel"
                Me.LoadHotelPolicyInfo()
            Case "Car"
                Me.LoadCarInfo()
            Case "Auxiliary"
                Me.LoadAuxInfo()
            Case "Pricing-Aux"
                Me.LoadPricingAuxInfo()
            Case "Pricing-HotelFee"
                Me.LoadPricingClientHotelInfo()
            Case "SLA"
                Me.LoadSLAInfo()
            Case "Services"
                Me.LoadServiceConfigInfo()
            Case "Approval"
                Me.LoadTAInfo()
            Case "Incident"
                Me.LoadIncidentInfo()
            Case "CannedRemark"
                Me.LoadCannedRemarkInfo()
            Case "PCCConfiguration"
                Me.LoadPCCInfo()
            Case "GDSMapping"
                Me.LoadGDSInfo()
        End Select
    End Sub
    Protected Sub btnSearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSearch.Click
        LoadData(SelectedValue)
    End Sub
End Class@


1.1.1.1
log
@no message
@
text
@@
