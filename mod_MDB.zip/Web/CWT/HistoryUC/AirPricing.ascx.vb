head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.07.02;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.07.02;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Public Partial Class PricingAir
    Inherits System.Web.UI.UserControl

    Private BLL As BusinessLogicLayer.AirPricingBLL
    Private BLL2 As BusinessLogicLayer.StaffBLL
    Private BLL3 As BusinessLogicLayer.tblFunctionBLL

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.BLL = New BusinessLogicLayer.AirPricingBLL()
        Me.BLL2 = New BusinessLogicLayer.StaffBLL()
        Me.BLL3 = New BusinessLogicLayer.tblFunctionBLL()

        If Not IsPostBack Then
            LoadAirPricingFormula()
            LoadAirPricingVariables()
            SetDDL()
        End If
    End Sub

    Public Sub LoadAirPricingFormula()
        Dim dt As DataTable
        dt = Me.BLL.getTempAirPricingFormula()
        With Me.GridView1
            .DataSource = dt
            .DataBind()
        End With
        With Me.pgControl1
            .GridID = Me.GridView1.UniqueID
            .SetBindGrid()
        End With
        With Me.GridView2
            .DataSource = dt
            .DataBind()
        End With
        With Me.pgControl2
            .GridID = Me.GridView2.UniqueID
            .SetBindGrid()
        End With
        With Me.GridView3
            .DataSource = dt
            .DataBind()
        End With
        With Me.pgControl3
            .GridID = Me.GridView3.UniqueID
            .SetBindGrid()
        End With
    End Sub

    Public Sub LoadAirPricingVariables()
        Dim dt As DataTable
        dt = Me.BLL.getTempAirPricingVariables()
        With Me.gdData
            .DataSource = dt
            .DataBind()
            With Me.pgControl
                .GridID = Me.gdData.UniqueID
                .SetBindGrid()
            End With
        End With
    End Sub

    Public Sub SetDDL()
        Me.ddlParameter.Items.Add("AirPricingName")
    End Sub

    Private Function GetStyle(ByVal index As Integer) As String
        Dim retVal As String = ""
        Dim ActiveStyle As String = "TabHeader-Active"
        Dim ItemStyle As String = "TabHeader"
        If Me.tabPages.ActiveTab.ID = Me.tabPages.Tabs.Item(index).ID Then
            retVal = ActiveStyle
        Else
            retVal = ItemStyle
        End If
        Return retVal
    End Function

    Private Sub ToggleTabStyle()
        Me.divInt.Attributes.Add("class", Me.GetStyle(0))
        Me.divDom.Attributes.Add("class", Me.GetStyle(1))
        Me.divLCC.Attributes.Add("class", Me.GetStyle(2))

    End Sub

    Protected Sub tabPages_ActiveTabChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tabPages.ActiveTabChanged
        ToggleTabStyle()
    End Sub

    Protected Sub btnSearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSearch.Click
        GetAirPricingByName()
    End Sub

    Public Sub GetAirPricingByName()
        Dim dt As DataTable
        Dim dt2 As DataTable
        Dim PricingID As String = ""
        dt = Me.BLL.getTempAirPricingFormulaByName(Me.txtParameter.Text, Me.txtDateFrom.Text, Me.txtDateTo.Text)
        With Me.GridView1
            .DataSource = dt
            .DataBind()
        End With
        With Me.pgControl1
            .GridID = Me.GridView1.UniqueID
            .SetBindGrid()
        End With
        With Me.GridView2
            .DataSource = dt
            .DataBind()
        End With
        With Me.pgControl2
            .GridID = Me.GridView2.UniqueID
            .SetBindGrid()
        End With
        With Me.GridView3
            .DataSource = dt
            .DataBind()
        End With
        With Me.pgControl3
            .GridID = Me.GridView3.UniqueID
            .SetBindGrid()
        End With

        If Me.txtParameter.Text <> "" And dt.Rows.Count > 0 Then
            PricingID = dt.Rows(0).Item("AirPricingID")
        Else
            PricingID = ""
        End If
        dt2 = Me.BLL.getTempAirPricingVariablesByID(PricingID, Me.txtDateFrom.Text, Me.txtDateTo.Text)
        With Me.gdData
            .DataSource = dt2
            .DataBind()
            With Me.pgControl
                .GridID = Me.gdData.UniqueID
                .SetBindGrid()
            End With
        End With
       
    End Sub

    Protected Sub gdData_RowDataBound(ByVal sender As System.Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gdData.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            If e.Row.RowIndex = 0 Then
                e.Row.Style.Add("height", "40px")
            End If
        End If

    End Sub
End Class@


1.1.1.1
log
@no message
@
text
@@
