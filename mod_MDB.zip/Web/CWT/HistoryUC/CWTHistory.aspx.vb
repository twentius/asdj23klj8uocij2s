head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.07.03;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.07.03;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Public Partial Class CWTHistory
    Inherits System.Web.UI.Page

    Private BLL2 As BusinessLogicLayer.StaffBLL
    Private BLL3 As BusinessLogicLayer.tblFunctionBLL
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.BLL2 = New BusinessLogicLayer.StaffBLL()
        Me.BLL3 = New BusinessLogicLayer.tblFunctionBLL()
        If ddlField.SelectedValue.ToString = "Fee-Air" Then
            ddlField2.Visible = True
        Else
            ddlField2.Visible = False
        End If
        AccessControl("History")

    End Sub

    Protected Sub ddlField_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.ucCWT1.SetTextToEmpty()
        If Me.ddlField.SelectedValue.ToString() <> "0" And ddlField.SelectedValue.ToString <> "Pricing-Air" Then
            Me.ucCWT1.Visible = True
            Me.ucAirPrice.Visible = False
            LoadData(ddlField.SelectedValue.ToString())
        ElseIf ddlField.SelectedValue.ToString = "Pricing-Air" Then
            Me.ucCWT1.Visible = False
            Me.ucAirPrice.Visible = True
            LoadData(ddlField.SelectedValue.ToString())
        Else
            Me.ucCWT1.Visible = False
            Me.ucAirPrice.Visible = False
        End If
    End Sub

    Private Sub LoadData(ByVal Type)
        Select Case Type
            Case "User"
                Me.ucCWT1.LoadUserData()
            Case "Role"
                Me.ucCWT1.LoadRoleData()
            Case "Config Instances"
                Me.ucCWT1.LoadCountryConfig()
            Case "PCC Config"
                Me.ucCWT1.LoadPCCConfiguration()
            Case "Agent & Division"
                Me.ucCWT1.LoadAgentDivision()
            Case "Remark"
                Me.ucCWT1.LoadRemark()
            Case "Holiday"
                Me.ucCWT1.LoadHoliday()
            Case "Product"
                Me.ucCWT1.LoadProduct()
            Case "Pricing-Air"
                Me.ucCWT1.Visible = False
                Me.ucAirPrice.Visible = True
                Me.ucAirPrice.SetDDL()
                Me.ucAirPrice.GetAirPricingByName()
            Case "Pricing-Auxiliary"
                Me.ucCWT1.LoadPricingAuxiliary()
            Case "Fee-Air"
                ddlField2.Visible = True
                Me.ucCWT1.LoadFeeAir(ddlField2.SelectedValue.ToString())
            Case "Fee-Aux"
                Me.ucCWT1.LoadFeeAuxiliary()
            Case "Fee-Hotel"
                Me.ucCWT1.LoadHotelFee()
            Case "Airport"
                Me.ucCWT1.LoadAirpotCity()
            Case "Canned Remark"
                Me.ucCWT1.LoadTempCannedRemark()
            Case "GDSLineDef"
                Me.ucCWT1.LoadGDSLineDef()
            Case "Aux Custom Field"
                Me.ucCWT1.LoadAuxCustomField()
        End Select
        Me.ucCWT1.SetSelectedValue(Type, ddlField2.SelectedValue.ToString())
    End Sub

    Protected Sub ddlField2_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        ddlField2.Visible = True
        Me.ucCWT1.SetSelectedValue("Fee-Air", ddlField2.SelectedValue.ToString())
        Me.ucCWT1.LoadFeeAir(ddlField2.SelectedValue.ToString())
    End Sub

    Private Sub AccessControl(ByVal title As String)

        Dim userName As String
        Dim oDatatable As DataTable
        Dim oDataTable2 As DataTable

        Static roleID As String

        userName = ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName
        oDatatable = Me.BLL2.GetUserByID(userName)

        If oDatatable.Rows.Count > 0 Then
            roleID = oDatatable.Rows(0).Item("RoleID").ToString
        End If

        oDataTable2 = Me.BLL3.GetUserRole2(roleID)
        If oDataTable2.Rows.Count > 0 Then
            For k As Integer = 0 To oDataTable2.Rows.Count - 1
                If oDataTable2.Rows(k).Item("functionGroup") = "0" Then
                    If Not oDataTable2.Rows(k).Item("Role") = "Super Admin" Then
                        If oDataTable2.Rows(k).Item("functionName").ToString = title Then
                            Call Me.toggleControl()

                        End If
                    End If
                End If
            Next
        Else
            Call Me.toggleControl()
        End If


    End Sub

    Public Sub toggleControl()
        Me.tableHistory.Visible = False
    End Sub
End Class@


1.1.1.1
log
@no message
@
text
@@
