head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.07.01;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.07.01;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Public Partial Class WebForm1
    Inherits System.Web.UI.Page

    Private BLL2 As BusinessLogicLayer.StaffBLL
    Private BLL3 As BusinessLogicLayer.tblFunctionBLL
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.BLL2 = New BusinessLogicLayer.StaffBLL()
        Me.BLL3 = New BusinessLogicLayer.tblFunctionBLL()
        AccessControl("History")
        If Not IsPostBack Then
            Call Me.SetControlVisibility(ddlField.Text)
        End If

    End Sub


    Protected Sub ddlField_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Call Me.SetControlVisibility(ddlField.Text)
    End Sub


    Public Sub SetControlVisibility(ByVal Type As String)

        Select Case Type
            Case "0"
                Me.ucCWTAirPricing1.Visible = False
                Me.ucClientAirPricing1.Visible = False
                Me.ddlFee.Visible = False
                Me.ucFeeByCoupon1.Visible = False
                Me.ucConditionalMarkup1.Visible = False
                Me.ucFeeByTicket1.Visible = False
                Me.ucFeeByPNR1.Visible = False
                Me.ucSuppAirlineComm1.Visible = False
                Me.ucAgentDivision1.Visible = True
            Case "1"
                Me.ucAgentDivision1.Visible = False
                Me.ucClientAirPricing1.Visible = False
                Me.ddlFee.Visible = False
                Me.ucFeeByCoupon1.Visible = False
                Me.ucConditionalMarkup1.Visible = False
                Me.ucFeeByTicket1.Visible = False
                Me.ucFeeByPNR1.Visible = False
                Me.ucSuppAirlineComm1.Visible = False
                Me.ucCWTAirPricing1.Visible = True
            Case "2"
                Me.ucAgentDivision1.Visible = False
                Me.ucCWTAirPricing1.Visible = False
                Me.ucClientAirPricing1.Visible = False
                Me.ddlFee.Visible = True
                Me.ucFeeByCoupon1.Visible = False
                Me.ucConditionalMarkup1.Visible = False
                Me.ucFeeByTicket1.Visible = False
                Me.ucFeeByPNR1.Visible = False
                Me.ucSuppAirlineComm1.Visible = False
                CWTAirFee()
            Case "3"
                Me.ucAgentDivision1.Visible = False
                Me.ucCWTAirPricing1.Visible = False
                Me.ddlFee.Visible = False
                Me.ucFeeByCoupon1.Visible = False
                Me.ucConditionalMarkup1.Visible = False
                Me.ucFeeByTicket1.Visible = False
                Me.ucFeeByPNR1.Visible = False
                Me.ucAgentDivision1.Visible = False
                Me.ucSuppAirlineComm1.Visible = False
                Me.ucClientAirPricing1.Visible = True
            Case "4"
                Me.ucAgentDivision1.Visible = False
                Me.ucCWTAirPricing1.Visible = False
                Me.ddlFee.Visible = False
                Me.ucFeeByCoupon1.Visible = False
                Me.ucConditionalMarkup1.Visible = False
                Me.ucFeeByTicket1.Visible = False
                Me.ucFeeByPNR1.Visible = False
                Me.ucAgentDivision1.Visible = False
                Me.ucClientAirPricing1.Visible = False
                Me.ucSuppAirlineComm1.Visible = True

        End Select

    End Sub

    Protected Sub btnSearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Call Me.SetControlVisibility(ddlField.Text)
        If ddlField.Text = "2" Then
            Call Me.CWTAirFee()
        End If

    End Sub

    Protected Sub ddlFee_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Call Me.CWTAirFee()
    End Sub

    Public Sub CWTAirFee()
        Select Case ddlFee.Text
            Case "0"
                Me.ucFeeByCoupon1.Visible = False
                Me.ucConditionalMarkup1.Visible = False
                Me.ucFeeByTicket1.Visible = False
                Me.ucFeeByPNR1.Visible = True
            Case "1"
                Me.ucFeeByCoupon1.Visible = False
                Me.ucConditionalMarkup1.Visible = False
                Me.ucFeeByTicket1.Visible = True
                Me.ucFeeByPNR1.Visible = False
            Case "2"
                Me.ucFeeByCoupon1.Visible = True
                Me.ucConditionalMarkup1.Visible = False
                Me.ucFeeByTicket1.Visible = False
                Me.ucFeeByPNR1.Visible = False
            Case "3"
                Me.ucFeeByCoupon1.Visible = False
                Me.ucConditionalMarkup1.Visible = True
                Me.ucFeeByTicket1.Visible = False
                Me.ucFeeByPNR1.Visible = False
        End Select
    End Sub

    Private Sub AccessControl(ByVal title As String)

        Dim userName As String
        Dim oDatatable As DataTable
        Dim oDataTable2 As DataTable

        Static roleID As String

        userName = ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName
        oDatatable = Me.BLL2.GetUserByID(userName)

        If oDatatable.Rows.Count > 0 Then
            roleID = oDatatable.Rows(0).Item("RoleID").ToString
        End If

        oDataTable2 = Me.BLL3.GetUserRole2(roleID)
        If oDataTable2.Rows.Count > 0 Then
            For k As Integer = 0 To oDataTable2.Rows.Count - 1
                If oDataTable2.Rows(k).Item("functionGroup") = "0" Then
                    If Not oDataTable2.Rows(k).Item("Role") = "Super Admin" Then
                        If oDataTable2.Rows(k).Item("functionName").ToString = title Then
                            Call Me.toggleControl()

                        End If
                    End If
                End If
            Next
        Else
            Call Me.toggleControl()
        End If


    End Sub

    Public Sub toggleControl()
        tblContentArea.Visible = False
    End Sub

End Class@


1.1.1.1
log
@no message
@
text
@@
