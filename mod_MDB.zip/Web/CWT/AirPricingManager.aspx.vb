head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.07.00;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.07.00;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@
Partial Class Web_CWT_AirPricingManager
    Inherits BasePage

    Private BLL As BusinessLogicLayer.AirPricingBLL
    Private BLL2 As BusinessLogicLayer.StaffBLL
    Private BLL3 As BusinessLogicLayer.tblFunctionBLL

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.BLL = New BusinessLogicLayer.AirPricingBLL()
        Me.BLL2 = New BusinessLogicLayer.StaffBLL()
        Me.BLL3 = New BusinessLogicLayer.tblFunctionBLL()

        If Not IsPostBack Then
            Call Me.LoadDataGrid()
        End If

        Call Me.AccessControl("Pricing")
    End Sub

    Private Sub AccessControl(ByVal title As String)

        Dim userName As String
        Dim oDatatable As DataTable
        Dim oDataTable2 As DataTable

        Static roleID As String

        userName = ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName
        oDatatable = Me.BLL2.GetUserByID(userName)

        If oDatatable.Rows.Count > 0 Then
            roleID = oDatatable.Rows(0).Item("RoleID").ToString
        End If

        oDataTable2 = Me.BLL3.GetUserRole(roleID)
        If oDataTable2.Rows.Count > 0 Then
            For k As Integer = 0 To oDataTable2.Rows.Count - 1
                If oDataTable2.Rows(k).Item("functionGroup") = "0" Then
                    If oDataTable2.Rows(k).Item("Permission") = "V" Then
                        If oDataTable2.Rows(k).Item("functionName").ToString = title Then
                            Call Me.toggleControl()

                        End If
                    End If
                End If

            Next

        End If


    End Sub

    Private Sub toggleControl()
        'Dim btnDelete As CWTCustomControls.CWTLinkButton


        Me.hrefAdd.Enabled = False

        'For i As Integer = 0 To Me.gdData.Rows.Count - 1
        '    btnDelete = Me.gdData.Rows(i).FindControl("hrefDelete")
        '    btnDelete.Enabled = False

        'Next
    End Sub

    Private Sub LoadDataGrid()
        Dim oDataTable As DataTable
        oDataTable = Me.BLL.GetAirPriceList()
        With Me.gdData
            .DataSource = oDataTable
            .DataBind()
        End With
        With Me.pgControl
            .GridID = Me.gdData.UniqueID
            .SetBindGrid()
        End With
    End Sub

    Private Function ValidatePricingInUsed(ByVal AirPicingID As String) As Boolean
        Dim oDataTable As DataTable
        Dim retVal As Boolean = False
        oDataTable = Me.BLL.getPricingInUsed(AirPicingID)

        If oDataTable IsNot Nothing AndAlso oDataTable.Rows.Count > 0 Then
            retVal = True
        Else
            retVal = False
        End If


        Return retVal

    End Function

    Private Sub DeletePricing(ByVal AirPricingID As String)

        If Not Me.ValidatePricingInUsed(AirPricingID) Then
            Me.BLL.DeleteAirPricing(AirPricingID)
        Else
            Me.lblMsgBox.Text = "pricing is in used, please remove from clients"
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.ajaxMsgBox.Show()
            Exit Sub

        End If
        Call Me.LoadDataGrid()
    End Sub

#Region "Control Event"
    Public Sub gdData_Command(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.CommandEventArgs)
        Select Case e.CommandName
            Case "DeleteItem"
                Call Me.DeletePricing(e.CommandArgument)
        End Select
        Call Me.LoadDataGrid()
    End Sub

    Protected Sub gdData_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gdData.RowDataBound
        Dim cwtLinkBtn As CWTCustomControls.CWTLinkButton
        cwtLinkBtn = TryCast(e.Row.FindControl("hrefDelete"), CWTCustomControls.CWTLinkButton)
        If cwtLinkBtn IsNot Nothing Then
            cwtLinkBtn.Attributes.Add("onclick", "return confirm('Item will delete, continue?');")
        End If
    End Sub
#End Region

End Class
@


1.1.1.1
log
@no message
@
text
@@
