head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.55;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.55;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@﻿// JScript File
function openPopupWindows(url,ww,hh){
    var popupWin = window.open(url,"popupWin",'menubar=1,resizable=1,scrollbars=1,width='+ww+',height='+hh);
//    alert((screen.width-ww)/2);
    popupWin.moveTo((screen.width-ww)/2,(screen.height-hh)/2);
    popupWin.focus();
}

function RefreshPage(){
    window.location.reload(false);
}

function saveCaret(elem){
  if(elem.isTextEdit){
    elem.caretPos = document.selection.createRange();
  }
}
function getCaretPos(elem,formula){
    if(!elem.isTextEdit){
        return;
    }
    if(elem.caretPos){
        var orig = elem.value;
        var caretPos = elem.caretPos;
        caretPos.text = formula;
    }else{
        elem.value += formula;
    }
}
//===   regist prototypes
if(!Array.indexOf){
    Array.prototype.IndexOf = function(value){
                                    for (var i=0; i < this.length; i++) {
                                        if (this[i] == value) {
                                            return i;
                                        }
                                    }
                                    return -1;
                                };

}
 @


1.1.1.1
log
@no message
@
text
@@
