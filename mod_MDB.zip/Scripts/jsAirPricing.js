head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.55;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.55;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@﻿// JScript File
var txtCalcID;
var txtCalcName;
var hidAirCalcName;
var btnGetInfo;
//
var txtFeeID;
var txtFeeName;
var hidFeeName;
var txtFeeType;
//
var txtAddOnID;
var txtAddOnName;
var hidAddOnName;
//
function setCalcText(id,name){
    document.all.item(txtCalcName).value=name;
    document.all.item(hidAirCalcName).value=name;
    document.all.item(txtCalcID).value=id;
    document.all.item(btnGetInfo).click();
}
function setFeeText(id,name,type){
    document.all.item(txtFeeName).value=name;
    document.all.item(hidFeeName).value=name;
    document.all.item(txtFeeID).value=id;
    document.all.item(txtFeeType).value=type;
}
function setAddOnText(id,name){
    document.all.item(txtAddOnName).value=name;
    document.all.item(hidAddOnName).value=name;
    document.all.item(txtAddOnID).value=id;
}@


1.1.1.1
log
@no message
@
text
@@
