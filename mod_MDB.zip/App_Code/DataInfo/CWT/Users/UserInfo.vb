head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic

Namespace DataInfo

    <Serializable()> _
    Public Class UserInfo
        Inherits BaseDataInfo

        Public [ID] As String
        Public Country As String
        '//
        Public Title As String
        Public FirstName As String
        Public LastName As String
        Public UserName As String
        Public Password As String
        Public Email As String
        '//
        Public PhoneCode As String
        Public AltPhoneCode As String
        Public MobileCode As String
        Public FaxCode As String
        Public Phone As String
        Public AltPhone As String
        Public Mobile As String
        Public Fax As String
        '// Linked Properties
        Public DivID As String
        Public RoleID As String
        '//
        Public JobTitle As String
        Public Remark As String

        Public Status As Boolean

    End Class

End Namespace
@


1.1.1.1
log
@no message
@
text
@@
