head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic
Imports System.Collections.Generic
Imports System.IO
Imports System.Runtime.Serialization.Formatters.Binary

Namespace DataInfo

#Region "Base"
    <Serializable()> _
    Public Class AirFeeInfo
        Inherits BaseDataInfo

        Public FeeID As String
        Public FeeName As String

        Public Enum AirFeeManagerType
            FeeByPNR = 0
            FeeByTicket = 1
            FeeByCoupon = 2
            ConditionalMarkUp = 3
        End Enum

    End Class
#End Region

#Region "Coupon"
    Public Class CouponInfo

        Public StartCoupon As Double
        Public EndCoupon As Double
        Public Type As String
        Public FeeAmt As Double
        Public Threshold As Double

    End Class

    <Serializable()> _
    Public Class TransCouponInfo
        Inherits AirFeeInfo

        Public CouponList As List(Of CouponInfo)

        Public Sub New()
            Me.CouponList = New List(Of CouponInfo)
        End Sub

    End Class
#End Region

#Region "Conditional"
    Public Class ConditionalInfo

        Public StartAmount As Double
        Public EndAmount As Double
        Public FeeAmt As Double

    End Class

    <Serializable()> _
    Public Class TransConditionalInfo
        Inherits AirFeeInfo

        Public ConditionalList As List(Of ConditionalInfo)

        Public Sub New()
            Me.ConditionalList = New List(Of ConditionalInfo)
        End Sub

    End Class
#End Region

#Region "PNR"
    <Serializable()> _
    Public Class RegionDataInfo

        Public RegionCode As String
        Public RegionName As String

    End Class

    <Serializable()> _
    Public Class CountryDataInfo

        Public LinkRegion As RegionDataInfo
        Public CountryCode As String
        Public CountryName As String

        Public Sub New()
            Me.LinkRegion = New RegionDataInfo()
        End Sub

    End Class

    <Serializable()> _
    Public Class CityDataInfo

        Public LinkCountry As CountryDataInfo
        Public CityCode As String
        Public CityName As String

        Public Sub New()
            Me.LinkCountry = New CountryDataInfo()
        End Sub

    End Class

    <Serializable()> _
    Public Class PNRItemInfo
        Implements System.ICloneable

        Public RegionSelectedItems As List(Of RegionDataInfo)
        Public CountrySelectedItems As List(Of CountryDataInfo)
        Public CitySelectedItems As List(Of CityDataInfo)
        Public FareFrom As Double = 0
        Public FareTo As Double = 0
        Public FareAmt As Double = 0
        Public ApplyMode As ApplyByItem = ApplyByItem.Region
        Public IsApplyAll As Boolean = False
        Public IsExtraFee As Boolean = False

        Public Sub New()
            RegionSelectedItems = New List(Of RegionDataInfo)
            CountrySelectedItems = New List(Of CountryDataInfo)
            CitySelectedItems = New List(Of CityDataInfo)
        End Sub

        Public ReadOnly Property RegionString() As String
            Get
                Dim retVal As New StringBuilder()
                For i As Integer = 0 To Me.RegionSelectedItems.Count - 1
                    If i > 0 Then
                        retVal.Append(",")
                    End If
                    retVal.Append(Util.LimitTheString(Me.RegionSelectedItems(i).RegionCode))
                Next
                Return retVal.ToString
            End Get
        End Property

        Public ReadOnly Property CountryString() As String
            Get
                Dim retVal As New StringBuilder()
                For i As Integer = 0 To Me.CountrySelectedItems.Count - 1
                    If i > 0 Then
                        retVal.Append(",")
                    End If
                    retVal.Append(Util.LimitTheString(Me.CountrySelectedItems(i).CountryCode))
                Next
                Return retVal.ToString
            End Get
        End Property

        Public ReadOnly Property CityString() As String
            Get
                Dim retVal As New StringBuilder()
                For i As Integer = 0 To Me.CitySelectedItems.Count - 1
                    If i > 0 Then
                        retVal.Append(",")
                    End If
                    retVal.Append(Util.LimitTheString(Me.CitySelectedItems(i).CityCode))
                Next
                Return retVal.ToString
            End Get
        End Property

        Public ReadOnly Property RegionSQLString() As String
            Get
                Dim retVal As New StringBuilder()
                For i As Integer = 0 To Me.RegionSelectedItems.Count - 1
                    If i > 0 Then
                        retVal.Append(";")
                    End If
                    retVal.Append(Me.RegionSelectedItems(i).RegionCode)
                Next
                Return retVal.ToString
            End Get
        End Property

        Public ReadOnly Property CountrySQLString() As String
            Get
                Dim retVal As New StringBuilder()
                For i As Integer = 0 To Me.CountrySelectedItems.Count - 1
                    If i > 0 Then
                        retVal.Append(";")
                    End If
                    retVal.Append(Me.CountrySelectedItems(i).CountryCode)
                Next
                Return retVal.ToString
            End Get
        End Property

        Public ReadOnly Property CitySQLString() As String
            Get
                Dim retVal As New StringBuilder()
                For i As Integer = 0 To Me.CitySelectedItems.Count - 1
                    If i > 0 Then
                        retVal.Append(";")
                    End If
                    retVal.Append(Me.CitySelectedItems(i).CityCode)
                Next
                Return retVal.ToString
            End Get
        End Property

        Public Function ToRegionTable() As DataTable
            Dim dt As New DataTable()
            Dim dr As DataRow
            With dt
                .Columns.Add(New DataColumn("RegionCode"))
                .Columns.Add(New DataColumn("Region"))
                For i As Integer = 0 To Me.RegionSelectedItems.Count - 1
                    dr = .NewRow()
                    dr("RegionCode") = Me.RegionSelectedItems(i).RegionCode
                    dr("Region") = Me.RegionSelectedItems(i).RegionName
                    .Rows.Add(dr)
                Next
            End With
            Return dt
        End Function
        Public Function ToCountryTable(Optional ByVal ByRegionCode As String = "") As DataTable
            Dim dt As New DataTable()
            Dim dr As DataRow
            With dt
                .Columns.Add(New DataColumn("RegionCode"))
                .Columns.Add(New DataColumn("CountryCode"))
                .Columns.Add(New DataColumn("Region"))
                .Columns.Add(New DataColumn("Country"))
                For i As Integer = 0 To Me.CountrySelectedItems.Count - 1
                    If Me.CountrySelectedItems(i).LinkRegion.RegionCode <> ByRegionCode Then
                        Continue For
                    End If
                    dr = .NewRow()
                    dr("RegionCode") = Me.CountrySelectedItems(i).LinkRegion.RegionCode
                    dr("CountryCode") = Me.CountrySelectedItems(i).CountryCode
                    dr("Region") = Me.CountrySelectedItems(i).LinkRegion.RegionName
                    dr("Country") = Me.CountrySelectedItems(i).CountryName
                    .Rows.Add(dr)
                Next
            End With
            Return dt
        End Function
        Public Function ToCityTable(Optional ByVal ByCountryCode As String = "") As DataTable
            Dim dt As New DataTable()
            Dim dr As DataRow
            With dt
                .Columns.Add(New DataColumn("RegionCode"))
                .Columns.Add(New DataColumn("CountryCode"))
                .Columns.Add(New DataColumn("CityCode"))
                .Columns.Add(New DataColumn("Region"))
                .Columns.Add(New DataColumn("Country"))
                .Columns.Add(New DataColumn("City"))
                For i As Integer = 0 To Me.CitySelectedItems.Count - 1
                    If ByCountryCode <> "" Then
                        If Me.CitySelectedItems(i).LinkCountry.CountryCode <> ByCountryCode Then
                            Continue For
                        End If
                    End If
                    dr = .NewRow()
                    dr("RegionCode") = Me.CitySelectedItems(i).LinkCountry.LinkRegion.RegionCode
                    dr("CountryCode") = Me.CitySelectedItems(i).LinkCountry.CountryCode
                    dr("CityCode") = Me.CitySelectedItems(i).CityCode
                    dr("Region") = Me.CitySelectedItems(i).LinkCountry.LinkRegion.RegionName
                    dr("Country") = Me.CitySelectedItems(i).LinkCountry.CountryName
                    dr("City") = Me.CitySelectedItems(i).CityName
                    .Rows.Add(dr)
                Next
            End With
            Return dt
        End Function

        Public Function RegionIndexOf(ByVal key As String) As Integer
            Dim retVal As Integer = -1
            For i As Integer = 0 To Me.RegionSelectedItems.Count - 1
                If Me.RegionSelectedItems(i).RegionCode = key Then
                    retVal = i
                    Exit For
                End If
            Next
            Return retVal
        End Function
        Public Function CountryIndexOf(ByVal key As String) As Integer
            Dim retVal As Integer = -1
            For i As Integer = 0 To Me.CountrySelectedItems.Count - 1
                If Me.CountrySelectedItems(i).CountryCode = key Then
                    retVal = i
                    Exit For
                End If
            Next
            Return retVal
        End Function
        Public Function CityIndexOf(ByVal key As String) As Integer
            Dim retVal As Integer = -1
            For i As Integer = 0 To Me.CitySelectedItems.Count - 1
                If Me.CitySelectedItems(i).CityCode = key Then
                    retVal = i
                    Exit For
                End If
            Next
            Return retVal
        End Function

        Public Function ShallowClone() As Object Implements System.ICloneable.Clone
            Return Me.MemberwiseClone()
        End Function

        Public Function DeepClone() As PNRItemInfo
            ' Create a "deep" clone of 
            ' an object. That is, copy not only 
            ' the object and its pointers
            ' to other objects, but create 
            ' copies of all the subsidiary 
            ' objects as well. This code even 
            ' handles recursive relationships.

            Dim ms As New MemoryStream()
            Dim objResult As PNRItemInfo = Nothing

            Try
                Dim bf As New BinaryFormatter()
                bf.Serialize(ms, Me)

                ' Rewind back to the beginning 
                ' of the memory stream. 
                ' Deserialize the data, then
                ' close the memory stream.
                ms.Position = 0
                objResult = bf.Deserialize(ms)
            Finally
                ms.Close()
            End Try
            Return objResult
        End Function

        Public Enum ApplyByItem
            Region = 0
            Country = 1
            City = 2
        End Enum

    End Class

    <Serializable()> _
    Public Class TransPNRInfo
        Inherits AirFeeInfo

        Public PNRList As List(Of PNRItemInfo)

        Public Sub New()
            Me.PNRList = New List(Of PNRItemInfo)
        End Sub

    End Class
#End Region

#Region "Ticket"
    <Serializable()> _
    Public Class TicketItemInfo
        Inherits PNRItemInfo

        Public MinAmt As Double
        Public MaxAmt As Double
        Public ExtraAmt As Double
        Public PerAmt As Integer
        Public OperatorAmt As TicketOperator = TicketOperator.Multiply

        Public Enum TicketOperator
            Multiply
            Divide
        End Enum

    End Class

    <Serializable()> _
    Public Class TransTicketInfo
        Inherits AirFeeInfo

        Public TicketList As List(Of TicketItemInfo)

        Public Sub New()
            Me.TicketList = New List(Of TicketItemInfo)
        End Sub

    End Class
#End Region

End Namespace

@


1.1.1.1
log
@no message
@
text
@@
