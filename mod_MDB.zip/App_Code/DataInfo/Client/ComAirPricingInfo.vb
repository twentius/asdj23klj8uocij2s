head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic
Imports System.Collections.Generic

Namespace DataInfo
    <Serializable()> _
    Public Class ComAirPricingInfo
        Inherits BaseDataInfo

        Public ClientID As String
        Public [ID] As String
        Public DCInt As Double
        Public DCDom As Double
        Public DCIntDollar As Double
        Public DCDomDollar As Double
        Public GSTInt As Double
        Public GSTDom As Double
        Public MarkUpInt As Double
        Public MarkUpDom As Double
        Public MarkUpIntDollar As Double
        Public MarkUpDomDollar As Double
        Public FuelInt As Double
        Public FuelDom As Double
        Public FeeIDInt As Double
        Public FeeIDDom As Double
        Public AddOnIDInt As Double
        Public AddOnIDDom As Double
        Public FeeIntType As DataInfo.AirFeeInfo.AirFeeManagerType
        Public FeeDomType As DataInfo.AirFeeInfo.AirFeeManagerType
        '//
        Public UsedDCInt As Boolean
        Public UsedDCDom As Boolean
        Public UsedDCIntDollar As Boolean
        Public UsedDCDomDollar As Boolean
        Public UsedGSTInt As Boolean
        Public UsedGSTDom As Boolean
        Public UsedMarkUpInt As Boolean
        Public UsedMarkUpDom As Boolean
        Public UsedMarkUpIntDollar As Boolean
        Public UsedMarkUpDomDollar As Boolean
        Public UsedFuelInt As Boolean
        Public UsedFuelDom As Boolean
        Public UsedFeeInt As Boolean
        Public UsedConditionInt As Boolean
        Public UsedFeeDom As Boolean
        Public UsedConditionDom As Boolean
        '//
        Public OverrideDCInt As Boolean
        Public OverrideDCDom As Boolean
        Public OverrideDCIntDollar As Boolean
        Public OverrideDCDomDollar As Boolean
        Public OverrideGSTInt As Boolean
        Public OverrideGSTDom As Boolean
        Public OverrideMarkUpInt As Boolean
        Public OverrideMarkUpDom As Boolean
        Public OverrideMarkUpIntDollar As Boolean
        Public OverrideMarkUpDomDollar As Boolean
        Public OverrideFuelInt As Boolean
        Public OverrideFuelDom As Boolean
        'Public OverrideFeeInt As Boolean
        'Public OverrideConditionInt As Boolean
        'Public OverrideFeeDom As Boolean
        'Public OverrideConditionDom As Boolean

    End Class
End Namespace
@


1.1.1.1
log
@no message
@
text
@@
