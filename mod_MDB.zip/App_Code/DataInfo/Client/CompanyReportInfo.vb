head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic
Imports System.Collections.Generic

Namespace DataInfo

    <Serializable()> _
    Public Class DroplistInfo

        Public Value As String = ""
        Public Description As String = ""

    End Class

    <Serializable()> _
    Public Class UDFReportInfo
        Inherits BaseDataInfo

        Public ClientID As String
        Public [ID] As String
        Public Description As String
        Public FieldType As Integer
        Public Mandatory As String
        Public DataType As String
        Public Min As String
        Public Max As String
        Public SampleValue As String

        Public GDSFormat As List(Of String)
        Public Droplist As List(Of DroplistInfo)

        Public Sub New()
            Me.GDSFormat = New List(Of String)
            Me.Droplist = New List(Of DroplistInfo)
        End Sub

    End Class

End Namespace@


1.1.1.1
log
@no message
@
text
@@
