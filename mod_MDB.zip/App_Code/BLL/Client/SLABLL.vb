head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic

Namespace BusinessLogicLayer
    Public Class SLABLL

        Private DataAccess As DataAccessLayer.SLADAL

        Public Sub New()
            Me.DataAccess = New DataAccessLayer.SLADAL()
        End Sub

        Public Function GetSLATopicList() As DataTable
            Return Me.DataAccess.GetSLATopicList()
        End Function

        Public Function GetSLAData(ByVal ClientID As String) As DataTable
            Return Me.DataAccess.GetSLAData(ClientID)
        End Function

        Public Function UpdateSLA(ByVal info As DataInfo.CompanySLAInfo) As Integer
            Return Me.DataAccess.UpdateSLA(info)
        End Function

    End Class
End Namespace

@


1.1.1.1
log
@no message
@
text
@@
