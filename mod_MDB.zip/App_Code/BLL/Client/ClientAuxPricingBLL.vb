head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic

Namespace BusinessLogicLayer
    Public Class ClientAuxPricingBLL

        Private DataAccess As DataAccessLayer.ClientAuxPricingDAL

        Public Sub New()
            Me.DataAccess = New DataAccessLayer.ClientAuxPricingDAL()
        End Sub

        Public Function GetProductList() As DataTable
            Return Me.DataAccess.GetProductList()
        End Function

        Public Function GetAuxPricingList(ByVal ProductID As String) As DataTable
            Return Me.DataAccess.GetAuxPricingList(ProductID)
        End Function

        Public Function GetAuxPricingByID(ByVal AuxFeeID As String) As DataTable
            Return Me.DataAccess.GetAuxPricingByID(AuxFeeID)
        End Function

        Public Function GetAuxClientFee(ByVal ClientID As String) As DataTable
            Return Me.DataAccess.GetAuxClientFee(ClientID)
        End Function

        Public Function UpdateAuxClientFee(ByVal info As DataInfo.ClientAuxPricingInfo) As Integer
            Return Me.DataAccess.UpdateAuxClientFee(info)
        End Function

    End Class
End Namespace

@


1.1.1.1
log
@no message
@
text
@@
