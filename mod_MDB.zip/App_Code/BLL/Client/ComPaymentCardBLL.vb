head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic

Namespace BusinessLogicLayer
    Public Class ComPaymentCardBLL

        Private DataAccess As DataAccessLayer.ComPaymentCardDAL

        Public Sub New()
            Me.DataAccess = New DataAccessLayer.ComPaymentCardDAL()
        End Sub

        Public Function GetCardList() As DataTable
            Return Me.DataAccess.GetCardList()
        End Function

        Public Function GetCardValidateFormat(ByVal CCCode As String) As DataTable
            Return Me.DataAccess.GetCardValidateFormat(CCCode)
        End Function

        Public Function GetClientCard(ByVal ClientID As String) As DataTable
            Return Me.DataAccess.GetClientCard(ClientID)
        End Function

        Public Function GetPaymentMode(ByVal ClientID As String) As String
            Return Me.DataAccess.GetPaymentMode(ClientID)
        End Function

        Public Function GetReferToProfile(ByVal ClientID As String) As Boolean
            Return Me.DataAccess.GetReferToProfile(ClientID)
        End Function

        Public Function UpdatePaymentCard(ByVal info As DataInfo.CompanyPayCardInfo) As Integer
            Return Me.DataAccess.UpdatePaymentCard(info)
        End Function

    End Class
End Namespace

@


1.1.1.1
log
@no message
@
text
@@
