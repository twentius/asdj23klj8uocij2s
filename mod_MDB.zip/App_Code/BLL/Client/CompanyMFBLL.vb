head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic

Namespace BusinessLogicLayer
    Public Class CompanyMFBLL

        Private DataAccess As DataAccessLayer.CompanyMFDAL

        Public Sub New()
            Me.DataAccess = New DataAccessLayer.CompanyMFDAL
        End Sub

        Public Function IsApplyStdMFCC(ByVal ClientID As String) As Boolean
            Return Me.DataAccess.IsApplyStdMFCC(ClientID)
        End Function

        Public Function IsApplyStdMFBank(ByVal ClientID As String) As Boolean
            Return Me.DataAccess.IsApplyStdMFBank(ClientID)
        End Function

        Public Function IsApplyStdMFProduct(ByVal ClientID As String) As Boolean
            Return Me.DataAccess.IsApplyStdMFProduct(ClientID)
        End Function

        Public Function GetStandardMF(ByVal ClientID As String) As Double
            Return Me.DataAccess.GetStandardMF(ClientID)
        End Function

        Public Function GetClientMFCC(ByVal ClientID As String) As DataTable
            Return Me.DataAccess.GetClientMFCC(ClientID)
        End Function

        Public Function GetClientMFBank(ByVal ClientID As String) As DataTable
            Return Me.DataAccess.GetClientMFBank(ClientID)
        End Function

        Public Function GetClientMFProduct(ByVal ClientID As String) As DataTable
            Return Me.DataAccess.GetClientMFProduct(ClientID)
        End Function

        Public Function GetMFCCList() As DataTable
            Return Me.DataAccess.GetMFCCList
        End Function

        Public Function GetMFBankList() As DataTable
            Return Me.DataAccess.GetMFBankList()
        End Function

        Public Function GetMFProductList() As DataTable
            Return Me.DataAccess.GetMFProductList()
        End Function

        Public Function SaveStandardMF(ByVal ClientID As String, ByVal MF As Double) As Integer
            Return Me.DataAccess.SaveStandardMF(ClientID, MF)
        End Function

        Public Function SaveMFCC(ByVal info As DataInfo.CompanyMFInfo) As Integer
            Return Me.DataAccess.SaveMFCC(info)
        End Function

        Public Function SaveMFBank(ByVal info As DataInfo.CompanyMFInfo) As Integer
            Return Me.DataAccess.SaveMFBank(info)
        End Function

        Public Function SaveMFProduct(ByVal info As DataInfo.CompanyMFInfo) As Integer
            Return Me.DataAccess.SaveMFProduct(info)
        End Function

    End Class
End Namespace

@


1.1.1.1
log
@no message
@
text
@@
