head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic

Namespace BusinessLogicLayer
    Public Class CompanyBLL

        Private DataAccess As DataAccessLayer.CompanyDAL

        Public Sub New()
            Me.DataAccess = New DataAccessLayer.CompanyDAL
        End Sub

        Public Function GetCompanyList(ByVal ClientName As String, ByVal AffGroup As String, ByVal IncInActive As Boolean) As DataTable
            Return Me.DataAccess.GetCompanyList(ClientName, AffGroup, IncInActive)
        End Function

        Public Function GetClientName(ByVal ClientName As String) As String()
            Return Me.DataAccess.GetClientName(ClientName)
        End Function

        Public Function GetAffiliateName(ByVal AffiliateName As String) As String()
            Return Me.DataAccess.GetAffiliateName(AffiliateName)
        End Function

        Public Function GetCompayInfo(ByVal ClientID As String) As DataSet
            Return Me.DataAccess.GetCompayInfo(ClientID)
        End Function

        Public Function IsExistName(ByVal ClientName As String, ByVal ID As String) As Boolean
            Return Me.DataAccess.IsExistName(ClientName, ID)
        End Function

        Public Function UpdateCompany(ByRef info As DataInfo.CompanyInfo) As Integer
            Return Me.DataAccess.UpdateCompany(info)
        End Function

        Public Function GetBillingData(ByVal ClientID As String) As DataSet
            Return Me.DataAccess.GetBillingData(ClientID)
        End Function

        Public Function UpdateBillingAddress(ByVal info As DataInfo.BillingAddressDataInfo) As Integer
            Return Me.DataAccess.UpdateBillingAddress(info)
        End Function

    End Class
End Namespace
@


1.1.1.1
log
@no message
@
text
@@
