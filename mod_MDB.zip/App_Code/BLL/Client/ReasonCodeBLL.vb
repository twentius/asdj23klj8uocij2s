head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic

Namespace BusinessLogicLayer
    Public Class ReasonCodeBLL

        Private DataAccess As DataAccessLayer.ReasonCodeDAL

        Public Sub New()
            Me.DataAccess = New DataAccessLayer.ReasonCodeDAL()
        End Sub

        Public Function GetReasonCodeList(ByVal ClientID As String) As DataTable
            Return Me.DataAccess.GetReasonCodeList(ClientID)
        End Function

        Public Function GetReasonCodeByID(ByVal ProductCode As String, ByVal Type As String) As DataTable
            Return Me.DataAccess.GetReasonCodeByID(ProductCode, Type)
        End Function

        Public Function GetClientReasonCode(ByVal ClientID As String, ByVal ProductCode As String, ByVal Type As String) As DataTable
            Return Me.DataAccess.GetClientReasonCode(ClientID, ProductCode, Type)
        End Function

        Public Function IsApplyStd(ByVal ClientID As String, ByVal ProductCode As String, ByVal Type As String) As Boolean
            Return Me.DataAccess.IsApplyStd(ClientID, ProductCode, Type)
        End Function

        Public Function GetReasonDescByCode(ByVal CRCodeID As String) As String
            Return Me.DataAccess.GetReasonDescByCode(CRCodeID)
        End Function

        Public Function UpdateReasonCode(ByVal info As DataInfo.CompanyReasonInfo) As Integer
            Return Me.DataAccess.UpdateReasonCode(info)
        End Function

    End Class
End Namespace

@


1.1.1.1
log
@no message
@
text
@@
