head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic

Namespace BusinessLogicLayer
    Public Class CompanyPolicyBLL

        Private DataAccess As DataAccessLayer.CompanyPolicyDAL

        Public Sub New()
            Me.DataAccess = New DataAccessLayer.CompanyPolicyDAL()
        End Sub

#Region "Air"
        Public Function GetAirClassList() As DataTable
            Return Me.DataAccess.GetAirClassList()
        End Function

        Public Function GetAirPolicyData(ByVal ClientID As String) As DataTable
            Return Me.DataAccess.GetAirPolicyData(ClientID)
        End Function

        Public Function GetAirClassData(ByVal ClientID As String) As DataTable
            Return Me.DataAccess.GetAirClassData(ClientID)
        End Function

        Public Function UpdateAirPolicy(ByVal info As DataInfo.CompanyPolicyInfo) As Integer
            Return Me.DataAccess.UpdateAirPolicy(info)
        End Function
#End Region

#Region "Hotel"
        Public Function GetHotelClassList() As DataTable
            Return Me.DataAccess.GetHotelClassList()
        End Function

        Public Function GetHotelPolicyData(ByVal ClientID As String) As DataTable
            Return Me.DataAccess.GetHotelPolicyData(ClientID)
        End Function

        Public Function GetHotelClassData(ByVal ClientID As String) As DataTable
            Return Me.DataAccess.GetHotelClassData(ClientID)
        End Function

        Public Function UpdateHotelPolicy(ByVal info As DataInfo.CompanyPolicyInfo) As Integer
            Return Me.DataAccess.UpdateHotelPolicy(info)
        End Function
#End Region

#Region "Car"
        Public Function GetCarClassList() As DataTable
            Return Me.DataAccess.GetCarClassList()
        End Function

        Public Function GetCarPolicyData(ByVal ClientID As String) As DataTable
            Return Me.DataAccess.GetCarPolicyData(ClientID)
        End Function

        Public Function GetCarClassData(ByVal ClientID As String) As DataTable
            Return Me.DataAccess.GetCarClassData(ClientID)
        End Function

        Public Function UpdateCarPolicy(ByVal info As DataInfo.CompanyPolicyInfo) As Integer
            Return Me.DataAccess.UpdateCarPolicy(info)
        End Function
#End Region

#Region "Auxiliary"
        Public Function GetAuxPolicyData(ByVal ClientID As String) As DataTable
            Return Me.DataAccess.GetAuxPolicyData(ClientID)
        End Function

        Public Function UpdateAuxPolicy(ByVal info As DataInfo.CompanyPolicyInfo) As Integer
            Return Me.DataAccess.UpdateAuxPolicy(info)
        End Function
#End Region

#Region "TA"
        Public Function GetTAClassData(ByVal ClientID As String) As DataTable
            Return Me.DataAccess.GetTAClassData(ClientID)
        End Function

        Public Function UpdateTAPolicy(ByVal info As DataInfo.CompanyPolicyInfo) As Integer
            Return Me.DataAccess.UpdateTAPolicy(info)
        End Function
#End Region

    End Class
End Namespace

@


1.1.1.1
log
@no message
@
text
@@
