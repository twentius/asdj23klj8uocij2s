head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic

Namespace BusinessLogicLayer
Public Class CompanyReportBLL

        Private DataAccess As DataAccessLayer.CompanyReportDAL

        Public Sub New()
            Me.DataAccess = New DataAccessLayer.CompanyReportDAL()
        End Sub

        Public Function GetReportConfig(ByVal ClientID As String) As DataTable
            Return Me.DataAccess.GetReportConfig(ClientID)
        End Function

        Public Function GetStandardReport(ByVal ClientID As String) As Boolean
            Return Me.DataAccess.GetStandardReport(ClientID)
        End Function

        Public Function GetClientDefineReport(ByVal ClientID As String) As Boolean
            Return Me.DataAccess.GetClientDefineReport(ClientID)
        End Function

        Public Function UpdateReportConfig(ByVal info As DataInfo.CompanyInfo) As Integer
            Return Me.DataAccess.UpdateReportConfig(info)
        End Function

        Public Function GetUDFReportList(ByVal ClientID As String, ByVal ReportingListID As String) As DataTable
            Return Me.DataAccess.GetUDFReportList(ClientID, ReportingListID)
        End Function

        Public Function GetDroplistCount(ByVal ClientID As String, ByVal ReportingListID As String) As Integer
            Return Me.DataAccess.GetDroplistCount(ReportingListID)
        End Function

        Public Function GetUDFReportGDS(ByVal ReportingListID As String) As DataTable
            Return Me.DataAccess.GetUDFReportGDS(ReportingListID)
        End Function

        Public Function GetUDFReportDropList(ByVal ReportingListID As String) As DataTable
            Return Me.DataAccess.GetUDFReportDropList(ReportingListID)
        End Function

        Public Function IsExistName(ByVal FieldName As String, ByVal ID As String, ByVal ClientID As String) As Boolean
            Return Me.DataAccess.IsExistName(FieldName, ID, ClientID)
        End Function

        Public Function GetMinDropValue(ByVal ReportingListID As String) As Integer
            Return Me.DataAccess.GetMinDropValue(ReportingListID)
        End Function

        Public Function GetMaxDropValue(ByVal ReportingListID As String) As Integer
            Return Me.DataAccess.GetMaxDropValue(ReportingListID)
        End Function

        Public Function GetMinValue(ByVal ReportingListID As String) As Integer
            Return Me.DataAccess.GetMinValue(ReportingListID)
        End Function

        Public Function GetMaxValue(ByVal ReportingListID As String) As Integer
            Return Me.DataAccess.GetMaxValue(ReportingListID)
        End Function

        Public Function UpdateUDFReport(ByVal info As DataInfo.UDFReportInfo) As Integer
            Return Me.DataAccess.UpdateUDFReport(info)
        End Function

        Public Function UpdateUDFDropList(ByVal info As DataInfo.UDFReportInfo) As Integer
            Return Me.DataAccess.UpdateUDFDropList(info)
        End Function

        Public Function DeleteUDFReport(ByVal ClientID As String, ByVal ReportingListID As String) As Integer
            Return Me.DataAccess.DeleteUDFReport(ClientID, ReportingListID)
        End Function

    End Class
End Namespace
@


1.1.1.1
log
@no message
@
text
@@
