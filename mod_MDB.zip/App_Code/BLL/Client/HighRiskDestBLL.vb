head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic

Namespace BusinessLogicLayer
    Public Class HighRiskDestBLL

        Private DataAccess As DataAccessLayer.HighRiskDestDAL

        Public Sub New()
            Me.DataAccess = New DataAccessLayer.HighRiskDestDAL()
        End Sub

        Public Function GetCityList() As DataTable
            Return Me.DataAccess.GetCityList()
        End Function

        Public Function GetAirlineList() As DataTable
            Return Me.DataAccess.GetAirlineList()
        End Function

        Public Function GetHighRiskDestination(ByVal ClientID As String) As DataTable
            Return Me.DataAccess.GetHighRiskDestination(ClientID)
        End Function

        Public Function GetHighRiskAirline(ByVal ClientID As String) As DataTable
            Return Me.DataAccess.GetHighRiskAirline(ClientID)
        End Function

        Public Function UpdateHighRiskDest(ByVal info As DataInfo.HighRiskInfo) As Integer
            Return Me.DataAccess.UpdateHighRiskDest(info)
        End Function

        Public Function UpdateHighRiskAir(ByVal info As DataInfo.HighRiskInfo) As Integer
            Return Me.DataAccess.UpdateHighRiskAir(info)
        End Function

    End Class
End Namespace










@


1.1.1.1
log
@no message
@
text
@@
