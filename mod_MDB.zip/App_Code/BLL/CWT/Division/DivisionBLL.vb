head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic

Namespace BusinessLogicLayer

    Public Class DivisionBLL

        Private DataAccess As DataAccessLayer.DivisionDAL

        Public Sub New()
            Me.DataAccess = New DataAccessLayer.DivisionDAL()
        End Sub

        Public Function GetDivisionAgentTree() As DataTable
            Return Me.DataAccess.GetDivisionAgentTree()
        End Function

        Public Function GetDivisionList() As DataTable
            Return Me.DataAccess.GetDivisionList()
        End Function

        Public Function GetDivisionByID(ByVal DivisionID As String) As DataTable
            Return Me.DataAccess.GetDivisionByID(DivisionID)
        End Function

        Public Function UpdateDivision(ByVal info As DataInfo.DivisionInfo) As Integer
            Return Me.DataAccess.UpdateDivision(info)
        End Function


        Public Function GetAgentByID(ByVal AgentID As String) As DataTable
            Return Me.DataAccess.GetAgentByID(AgentID)
        End Function

        Public Function UpdateAgent(ByVal info As DataInfo.AgentInfo) As Integer
            Return Me.DataAccess.UpdateAgent(info)
        End Function

    End Class

End Namespace

@


1.1.1.1
log
@no message
@
text
@@
