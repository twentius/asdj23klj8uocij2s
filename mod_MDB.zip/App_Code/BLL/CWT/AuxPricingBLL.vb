head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic

Namespace BusinessLogicLayer
    Public Class AuxPricingBLL

        Private DataAccess As DataAccessLayer.AuxPricingDAL

        Public Sub New()
            Me.DataAccess = New DataAccessLayer.AuxPricingDAL()
        End Sub

        Public Function GetProductList() As DataTable
            Return Me.DataAccess.GetProductList()
        End Function

        Public Function GetAuxPricingList(ByVal Name As String, ByVal ProductID As String) As DataTable
            Return Me.DataAccess.GetAuxPricingList(Name, ProductID)
        End Function

        Public Function GetAuxPricingByID(ByVal FeeID As String) As DataTable
            Return Me.DataAccess.GetAuxPricingByID(FeeID)
        End Function

        Public Function UpdateAuxPrice(ByVal info As DataInfo.AuxFeeInfo) As Integer
            Return Me.DataAccess.UpdateAuxPrice(info)
        End Function

        Public Function IsExistName(ByVal FeeName As String, ByVal ProductID As String) As Boolean
            Return Me.DataAccess.IsExistName(FeeName, ProductID)
        End Function

    End Class
End Namespace


@


1.1.1.1
log
@no message
@
text
@@
