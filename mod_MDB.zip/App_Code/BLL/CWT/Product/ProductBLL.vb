head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic
Namespace BusinessLogicLayer
    Public Class ProductBLL

        Private DataAccess As DataAccessLayer.ProductDAL

        Public Sub New()
            Me.DataAccess = New DataAccessLayer.ProductDAL
        End Sub

        Public Function GetProductData() As DataTable
            Return Me.DataAccess.GetProductData()
        End Function

        Public Function GetProductType() As DataTable
            Return Me.DataAccess.GetProductType()
        End Function

        Public Function getProductByNumber(ByVal Number As Integer) As DataTable
            Return Me.DataAccess.GetProductByNumber(Number)
        End Function
        Public Function DeleteProductByNumber(ByVal Number As Integer) As Integer
            Return Me.DataAccess.DeleteProductByNumber(Number)
        End Function
        Public Function InsertProduct(ByVal Number As Integer, ByVal Name As String, ByVal GDSCode As String, ByVal Type As String, ByVal RequireCDR As Boolean, ByVal RequireTicket As Boolean, ByVal GST As String) As Integer
            Return Me.DataAccess.InsertProduct(Number, Name, GDSCode, Type, RequireCDR, RequireTicket, GST)
        End Function
        Public Function UpdateProductByNumber(ByVal Number As Integer, ByVal Name As String, ByVal GDSCode As String, ByVal Type As String, ByVal RequireCDR As Boolean, ByVal RequireTicket As Boolean, ByVal GST As String) As Integer
            Return Me.DataAccess.UpdateProductByNumber(Number, Name, GDSCode, Type, RequireCDR, RequireTicket, GST)
        End Function
    End Class
End Namespace

@


1.1.1.1
log
@no message
@
text
@@
