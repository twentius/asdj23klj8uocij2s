head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic
Imports System.Collections.Generic

Namespace BusinessLogicLayer
    Public Class ConfigurationBLL

        Private DataAccess As DataAccessLayer.ConfigurationDAL

        Public Sub New()
            Me.DataAccess = New DataAccessLayer.ConfigurationDAL
        End Sub

        Public Function GetRegion(ByVal IsInCity As Boolean, Optional ByVal FilterOutList As String = "") As DataTable
            Return Me.DataAccess.GetRegion(IsInCity, FilterOutList)
        End Function

        Public Function GetCountry() As DataTable
            Return Me.DataAccess.GetCountry()
        End Function

        Public Function GetCountryByRegion(ByVal RegionCode As String, Optional ByVal FilterOutList As String = "") As DataTable
            Return Me.DataAccess.GetCountryByRegion(RegionCode, FilterOutList)
        End Function

        Public Function GetCity(ByVal CountryCode As String, Optional ByVal FilterOutList As String = "") As DataTable
            Return Me.DataAccess.GetCity(CountryCode, FilterOutList)
        End Function

        Public Function GetCountryByCity(ByVal CityCode As String) As String
            Return Me.DataAccess.GetCountryByCity(CityCode)
        End Function

        Public Function GetCurrency() As DataTable
            Return Me.DataAccess.GetCurrency()
        End Function

        Public Function GetGDS() As DataTable
            Return Me.DataAccess.GetGDS()
        End Function

        Public Function IsExistName(ByVal Name As String, ByVal ID As String) As Boolean
            Return Me.DataAccess.IsExistName(Name, ID)
        End Function

        Public Function GetRegionByID(ByVal ItemID As String) As DataTable
            Return Me.DataAccess.GetRegionByID(ItemID)
        End Function

        Public Function GetCountryByID(ByVal ItemID As String) As DataTable
            Return Me.DataAccess.GetCountryByID(ItemID)
        End Function

        Public Function GetCityByID(ByVal ItemID As String) As DataTable
            Return Me.DataAccess.GetCityByID(ItemID)
        End Function

        Public Function GetConfigurationData() As DataTable
            Return Me.DataAccess.GetConfigurationData()
        End Function
        Public Function getConfigurationByConfiguration(ByVal ConfigurationID As Integer) As DataTable
            Return Me.DataAccess.GetConfigurationByConfigurationID(ConfigurationID)
        End Function
        Public Function DeleteConfigurationByConfiguration(ByVal ConfigurationID As Integer) As Integer
            Return Me.DataAccess.DeleteConfigurationByConfigurationID(ConfigurationID)
        End Function
        Public Function InsertConfiguration(ByVal ConfigurationDesc As String, ByVal GDS As String _
, ByVal BookingPCC As String, ByVal ProfilePCC As String, ByVal FarePCC As String, ByVal Currency As String, ByVal CityCode As String, ByVal TicketPCC As String _
, ByVal TicketAddress As String, ByVal ItinPCC As String, ByVal ItinAddress As String, ByVal ItinDYO As String, ByVal InvPCC As String, ByVal InvAddress As String, ByVal InvDYO As String _
, ByVal MirPCC As String, ByVal MirAddress As String, ByVal DecimalPlc As String) As Integer
            Return Me.DataAccess.InsertConfiguration(ConfigurationDesc, GDS, BookingPCC, ProfilePCC, FarePCC, Currency, CityCode, TicketPCC, TicketAddress, ItinPCC, ItinAddress, ItinDYO, InvPCC, InvAddress, InvDYO, MirPCC, MirAddress, DecimalPlc)
        End Function
        Public Function UpdateConfigurationByConfiguration(ByVal ConfigurationID As Integer, ByVal ConfigurationDesc As String, ByVal GDS As String _
, ByVal BookingPCC As String, ByVal ProfilePCC As String, ByVal FarePCC As String, ByVal Currency As String, ByVal CityCode As String, ByVal TicketPCC As String _
, ByVal TicketAddress As String, ByVal ItinPCC As String, ByVal ItinAddress As String, ByVal ItinDYO As String, ByVal InvPCC As String, ByVal InvAddress As String, ByVal InvDYO As String _
, ByVal MirPCC As String, ByVal MirAddress As String, ByVal DecimalPlc As String) As Integer
            Return Me.DataAccess.UpdateConfigurationByConfigurationID(ConfigurationID, ConfigurationDesc, GDS, BookingPCC, ProfilePCC, FarePCC, Currency, CityCode, TicketPCC, TicketAddress, ItinPCC, ItinAddress, ItinDYO, InvPCC, InvAddress, InvDYO, MirPCC, MirAddress, DecimalPlc)
        End Function

    End Class
End Namespace



@


1.1.1.1
log
@no message
@
text
@@
