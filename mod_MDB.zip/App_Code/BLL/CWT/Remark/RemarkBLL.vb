head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic

Namespace BusinessLogicLayer
    Public Class RemarkBLL

        Private DataAccess As DataAccessLayer.RemarkDAL

        Public Sub New()
            Me.DataAccess = New DataAccessLayer.RemarkDAL()
        End Sub

        Public Function GetLocation() As DataTable
            Return Me.DataAccess.GetLocation()
        End Function
        Public Function GetRemarkType(ByVal location As String) As DataTable
            Return Me.DataAccess.GetRemarkType(location)
        End Function
        Public Function GetSubType1(ByVal location As String, ByVal type As String) As DataTable
            Return Me.DataAccess.GetSubType1(location, type)
        End Function
        Public Function GetSubType2(ByVal location As String, ByVal type As String, ByVal subtype1 As String) As DataTable
            Return Me.DataAccess.GetSubType2(location, type, subtype1)
        End Function
        Public Function GetCountryList() As DataTable
            Return Me.DataAccess.GetCountryList()
        End Function
        Public Function GetCountryName(ByVal Code As String) As String
            Return Me.DataAccess.GetCountryName(Code)
        End Function

        Public Function GetRemarkInfoByCode(ByVal RemarkCode As String) As DataTable
            Return Me.DataAccess.GetRemarkInfoByCode(RemarkCode)
        End Function

        Public Function GetRemarkList(ByVal location As String, ByVal type As String, ByVal SubType1 As String, ByVal SubType2 As String, ByVal RefValue1 As String) As DataTable
            Return Me.DataAccess.GetRemarkList(location, type, SubType1, SubType2, RefValue1)
        End Function

        Public Function GetRemarkCode(ByVal location As String, ByVal type As String, ByVal SubType1 As String, ByVal SubType2 As String) As String
            Return Me.DataAccess.GetRemarkCode(location, type, SubType1, SubType2)
        End Function

        Public Function GetRemarkByID(ByVal SeqNo As String) As DataTable
            Return Me.DataAccess.GetRemarkByID(SeqNo)
        End Function

        Public Function UpdateRemark(ByVal info As DataInfo.RemarkInfo) As Integer
            Return Me.DataAccess.UpdateRemark(info)
        End Function

        Public Function DeleteRemark(ByVal SeqNo As String) As Integer
            Return Me.DataAccess.DeleteRemark(SeqNo)
        End Function

    End Class
End Namespace

@


1.1.1.1
log
@no message
@
text
@@
