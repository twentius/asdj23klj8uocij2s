head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic

Namespace BusinessLogicLayer

    Public Class tblFunctionBLL

        Private DataAccess As DataAccessLayer.tblFunctionDA

        Public Sub New()
            Me.DataAccess = New DataAccessLayer.tblFunctionDA
        End Sub

        Public Function GetUserRole(ByVal RoleID As Integer) As DataTable
            Return Me.DataAccess.getAllData(RoleID)
        End Function

        Public Function SaveData(ByVal dt As DataTable, ByVal RoleID As Integer) As Integer
            Return Me.DataAccess.SaveData(dt, RoleID)
        End Function

        Public Function GetUserLevelByUrl(ByVal url As String) As CWTCustomControls.UserLevelControl
            Return Me.DataAccess.GetUserLevelByUrl(url)
        End Function

        Public Function GetFunctionGroup(ByVal url As String) As Util.TabNameType
            Return Me.DataAccess.GetFunctionGroup(url)
        End Function

    End Class

End Namespace

@


1.1.1.1
log
@no message
@
text
@@
