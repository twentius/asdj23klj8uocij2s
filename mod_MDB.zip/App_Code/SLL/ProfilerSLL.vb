head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic
Imports System.Collections.Generic

Namespace ServiceLogicLayer

    <Serializable()> _
    Public Class ProfilerSLL

        Public Shared ReadOnly Property CurrentRuntimePage() As Page
            Get
                Dim RuntimePage As Page = CType(HttpContext.Current.CurrentHandler, Page)
                Return RuntimePage
            End Get
        End Property

        Public Shared ReadOnly Property OnlineUserList() As List(Of String)
            Get
                Return TryCast(CurrentRuntimePage.Application.Item("OnlineUserList"), List(Of String))
            End Get
        End Property

        Public Shared Sub CreateProfiler()
            CurrentRuntimePage.Application.Add("OnlineUserList", New System.Collections.Generic.List(Of String))
        End Sub

        Public Shared Sub LogOnProfile(ByVal UserName As String)
            Dim BLL As New BusinessLogicLayer.StaffBLL()
            If CurrentRuntimePage.Application("OnlineUserList") Is Nothing Then
                CreateProfiler()
            End If
            CurrentRuntimePage.Session("CurrentProfile") = New DataInfo.LoginProfileInfo()
            With CurrentProfile
                .UserName = UserName
                .RoleID = BLL.GetDataColumnByID("RoleID", UserName).ToString
                .LoginTime = Now
            End With
            OnlineUserList.Add(UserName)
        End Sub

        Public Shared Sub LogOffProfile(ByVal UserName As String)
            OnlineUserList.Remove(UserName)
        End Sub

        Public Shared ReadOnly Property CurrentProfile() As DataInfo.LoginProfileInfo
            Get
                Return TryCast(CurrentRuntimePage.Session("CurrentProfile"), DataInfo.LoginProfileInfo)
            End Get
        End Property

    End Class

End Namespace




@


1.1.1.1
log
@no message
@
text
@@
