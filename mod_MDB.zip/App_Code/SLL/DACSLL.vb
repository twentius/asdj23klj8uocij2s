head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic
Imports System.Collections.Generic

Namespace ServiceLogicLayer

    <Serializable()> _
    Public Class DACSLL

        Public Shared Sub SetConnection(ByVal svr As String, ByVal db As String, ByVal usr As String, ByVal pwd As String)
            ProfilerSLL.CurrentRuntimePage.Session("cn") = Util.CreateConnection(svr, db, usr, pwd)
        End Sub

        Public Shared ReadOnly Property ConnectionString() As String
            Get
                Dim retVal As String = ""
                retVal = Util.DBNullToText(ProfilerSLL.CurrentRuntimePage.Session("cn"))
                Return retVal
            End Get
        End Property

    End Class

End Namespace


@


1.1.1.1
log
@no message
@
text
@@
