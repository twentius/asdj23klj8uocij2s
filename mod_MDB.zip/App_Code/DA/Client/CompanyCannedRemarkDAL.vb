head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic
Imports System.Collections.Generic

Namespace DataAccessLayer
    Public Class CompanyCannedRemarkDAL
        Inherits BaseDA

        Public Function GetCannedRemark() As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblClientCannedRemark"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetStandardRemark(ByVal ClientID As String) As Boolean
            Dim retVal As Boolean
            With Me.MySQLParser
                .TableName = "tblClientMaster"
                With .Columns
                    .Clear()
                    .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("ClientCannedRemark")
                End With
                retVal = Util.DBNullToFalse(.ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar))
            End With
            Return retVal
        End Function

        Public Function UpdateCannedRemark(ByVal info As DataInfo.CompanyCannedRemarkInfo) As Integer
            Dim EffectRow As Integer = 1
            Try
                With Me.MySQLParser
                    .OpenConnection()
                    .BeginTran()
                    .TableName = "tblClientCannedRemark"
                    With .Columns
                        .Clear()
                        .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    End With
                    .ExecuteDelete()
                    .TableName = "tblClientMaster"
                    With .Columns
                        .Clear()
                        .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        .Add("ClientCannedRemark", info.ApplyStd, SqlBuilder.SQLParserDataType.spBoolean)
                    End With
                    .ExecuteUpdate()
                    '//
                    If EffectRow > 0 Then
                        '// 
                        .TableName = "tblClientCannedRemark"
                        For i As Integer = 0 To info.Remarks.Count - 1
                            With .Columns
                                .Clear()
                                .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum)
                                .Add("CCRID", i + 1, SqlBuilder.SQLParserDataType.spNum)
                                .Add("LoadtoPNR", info.Remarks(i).LoadToPNR, SqlBuilder.SQLParserDataType.spBoolean)
                                .Add("CannedRemark", info.Remarks(i).Remark)
                            End With
                            EffectRow = .ExecuteInsert()
                            If EffectRow <= 0 Then
                                Exit For
                            End If
                        Next
                    End If
                End With
                If EffectRow > 0 Then
                    Me.MySQLParser.CommitTran()
                Else
                    Me.MySQLParser.RollbackTran()
                End If
            Catch ex As Exception
                EffectRow = -1
                Me.MySQLParser.RollbackTran()
            Finally
                Me.MySQLParser.CloseConnection()
            End Try
            Return EffectRow
        End Function

    End Class
End Namespace

@


1.1.1.1
log
@no message
@
text
@@
