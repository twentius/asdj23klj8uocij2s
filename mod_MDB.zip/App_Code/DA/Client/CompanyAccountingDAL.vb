head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic
Imports System.Collections.Generic

Namespace DataAccessLayer
    Public Class CompanyAccountingDAL
        Inherits BaseDA

        Public Function GetCompanyAccountingData(ByVal ClientID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .TableName = "tblClientMaster"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function UpdateCompanyAccounting(ByVal info As DataInfo.CompanyAccountingInfo) As Integer
            Dim EffectRow As Integer
            Try
                With Me.MySQLParser
                    .TableName = "tblClientMaster"
                    With .Columns
                        .Clear()
                        .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        Select Case info.PreferedAccType
                            Case DataInfo.CompanyAccountingInfo.AccountType.Business
                                .Add("PreferredAccountingNo", "B")
                            Case DataInfo.CompanyAccountingInfo.AccountType.Leisure
                                .Add("PreferredAccountingNo", "L")
                            Case DataInfo.CompanyAccountingInfo.AccountType.MICE
                                .Add("PreferredAccountingNo", "M")
                        End Select
                        .Add("ClientNumber", info.AccNoBiz)
                        .Add("LeisureClientNo", info.AccNoLeisure)
                        .Add("MICEClientNo", info.AccNoMice)
                        .Add("DivisionNo", info.DivNo)
                        .Add("AccountingField1", info.FieldName1)
                        .Add("AccountingField2", info.FieldName2)
                        .Add("AccountingField3", info.FieldName3)
                        .Add("AccountingField4", info.FieldName4)
                        .Add("AccountingField5", info.FieldName5)
                        .Add("AccountingValue1", info.FieldValue1)
                        .Add("AccountingValue2", info.FieldValue2)
                        .Add("AccountingValue3", info.FieldValue3)
                        .Add("AccountingValue4", info.FieldValue4)
                        .Add("AccountingValue5", info.FieldValue5)
                    End With
                    EffectRow = .ExecuteUpdate()
                End With
            Catch ex As Exception
                EffectRow = -1
            End Try
            Return EffectRow
        End Function

    End Class
End Namespace


@


1.1.1.1
log
@no message
@
text
@@
