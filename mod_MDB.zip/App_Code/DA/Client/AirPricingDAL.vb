head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic
Imports System.Collections.Generic

Namespace DataAccessLayer
    Public Class ComAirPricingDAL
        Inherits BaseDA

        Public Function GetComAirPricingData(ByVal ClientID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .TableName = "tblClientPricing"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetUsageVariables(ByVal AirPricingID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .TableName = "tblAirPricingVariables"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("AirPricingID", AirPricingID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function UpdateComAirPricing(ByVal info As DataInfo.ComAirPricingInfo) As Integer
            Dim EffectRow As Integer = -1
            Try
                With Me.MySQLParser
                    .TableName = "tblClientPricing"
                    With .Columns
                        .Clear()
                        .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum, (info.PageMode = Global.TransactionMode.UpdateMode))
                        .Add("AirPricingID", info.ID)
                        Select Case info.FeeIntType
                            Case DataInfo.AirFeeInfo.AirFeeManagerType.FeeByTicket
                                .Add("TransFeeOptionInt", "T")
                            Case DataInfo.AirFeeInfo.AirFeeManagerType.FeeByCoupon
                                .Add("TransFeeOptionInt", "C")
                            Case Else
                                .Add("TransFeeOptionInt", "P")
                        End Select
                        Select Case info.FeeDomType
                            Case DataInfo.AirFeeInfo.AirFeeManagerType.FeeByTicket
                                .Add("TransFeeOptionDom", "T")
                            Case DataInfo.AirFeeInfo.AirFeeManagerType.FeeByCoupon
                                .Add("TransFeeOptionDom", "C")
                            Case Else
                                .Add("TransFeeOptionDom", "P")
                        End Select
                        .Add("TransFeeIDInt", info.FeeIDInt)
                        .Add("TransFeeIDDom", info.FeeIDDom)
                        .Add("AddOnMarkupIDInt", info.AddOnIDInt)
                        .Add("AddOnMarkupIDDom", info.AddOnIDDom)
                        '//
                        .Add("DiscountInt", info.DCInt, SqlBuilder.SQLParserDataType.spNum)
                        .Add("DiscountDom", info.DCDom, SqlBuilder.SQLParserDataType.spNum)
                        .Add("DiscountIntDollar", info.DCInt, SqlBuilder.SQLParserDataType.spNum)
                        .Add("DiscountDomDollar", info.DCDom, SqlBuilder.SQLParserDataType.spNum)
                        .Add("GSTInt", info.GSTInt, SqlBuilder.SQLParserDataType.spNum)
                        .Add("GSTDom", info.GSTDom, SqlBuilder.SQLParserDataType.spNum)
                        .Add("MarkUpInt", info.MarkUpInt, SqlBuilder.SQLParserDataType.spNum)
                        .Add("MarkUpDom", info.MarkUpDom, SqlBuilder.SQLParserDataType.spNum)
                        .Add("MarkUpIntDollar", info.MarkUpIntDollar, SqlBuilder.SQLParserDataType.spNum)
                        .Add("MarkUpDomDollar", info.MarkUpDomDollar, SqlBuilder.SQLParserDataType.spNum)
                        .Add("FuelChargeInt", info.FuelInt, SqlBuilder.SQLParserDataType.spNum)
                        .Add("FuelChargeDom", info.FuelDom, SqlBuilder.SQLParserDataType.spNum)
                        '//
                        '.Add("UsedDiscountInt", info.UsedDCInt, SqlBuilder.SQLParserDataType.spBoolean)
                        '.Add("UsedDiscountDom", info.UsedDCDom, SqlBuilder.SQLParserDataType.spBoolean)
                        '.Add("UsedDiscountIntDollar", info.UsedDCIntDollar, SqlBuilder.SQLParserDataType.spBoolean)
                        '.Add("UsedDiscountDomDollar", info.UsedDCDomDollar, SqlBuilder.SQLParserDataType.spBoolean)
                        '.Add("UsedGSTInt", info.UsedGSTInt, SqlBuilder.SQLParserDataType.spBoolean)
                        '.Add("UsedGSTDom", info.UsedGSTDom, SqlBuilder.SQLParserDataType.spBoolean)
                        '.Add("UsedMarkUpInt", info.UsedMarkUpInt, SqlBuilder.SQLParserDataType.spBoolean)
                        '.Add("UsedMarkUpDom", info.UsedMarkUpDom, SqlBuilder.SQLParserDataType.spBoolean)
                        '.Add("UsedMarkUpIntDollar", info.UsedMarkUpIntDollar, SqlBuilder.SQLParserDataType.spBoolean)
                        '.Add("UsedMarkUpDomDollar", info.UsedMarkUpDomDollar, SqlBuilder.SQLParserDataType.spBoolean)
                        '.Add("UsedFuelChargeInt", info.UsedFuelInt, SqlBuilder.SQLParserDataType.spBoolean)
                        '.Add("UsedFuelChargeDom", info.UsedFuelDom, SqlBuilder.SQLParserDataType.spBoolean)
                        '//
                        .Add("OverrideDiscountInt", info.OverrideDCInt, SqlBuilder.SQLParserDataType.spBoolean)
                        .Add("OverrideDiscountDom", info.OverrideDCDom, SqlBuilder.SQLParserDataType.spBoolean)
                        .Add("OverrideDiscountIntDollar", info.OverrideDCIntDollar, SqlBuilder.SQLParserDataType.spBoolean)
                        .Add("OverrideDiscountDomDollar", info.OverrideDCDomDollar, SqlBuilder.SQLParserDataType.spBoolean)
                        .Add("OverrideGSTInt", info.OverrideGSTInt, SqlBuilder.SQLParserDataType.spBoolean)
                        .Add("OverrideGSTDom", info.OverrideGSTDom, SqlBuilder.SQLParserDataType.spBoolean)
                        .Add("OverrideMarkUpInt", info.OverrideMarkUpInt, SqlBuilder.SQLParserDataType.spBoolean)
                        .Add("OverrideMarkUpDom", info.OverrideMarkUpDom, SqlBuilder.SQLParserDataType.spBoolean)
                        .Add("OverrideMarkUpIntDollar", info.OverrideMarkUpIntDollar, SqlBuilder.SQLParserDataType.spBoolean)
                        .Add("OverrideMarkUpDomDollar", info.OverrideMarkUpDomDollar, SqlBuilder.SQLParserDataType.spBoolean)
                        .Add("OverrideFuelChargeInt", info.OverrideFuelInt, SqlBuilder.SQLParserDataType.spBoolean)
                        .Add("OverrideFuelChargeDom", info.OverrideFuelDom, SqlBuilder.SQLParserDataType.spBoolean)
                    End With
                    If info.PageMode = Global.TransactionMode.AddNewMode Then
                        EffectRow = .ExecuteInsert()
                    Else
                        EffectRow = .ExecuteUpdate()
                    End If
                End With
            Catch ex As Exception
                EffectRow = -1
                Me.MySQLParser.RollbackTran()
            End Try
            Return EffectRow
        End Function

    End Class
End Namespace


@


1.1.1.1
log
@no message
@
text
@@
