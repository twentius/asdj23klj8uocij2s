head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic
Imports System.Collections.Generic

Namespace DataAccessLayer
    Public Class CompanyMFDAL
        Inherits BaseDA

        Public Function IsApplyStdMFCC(ByVal ClientID As String) As Boolean
            'ApplyMFCC
            Dim retVal As Boolean = False
            Dim retObj As Object = 0
            With Me.MySQLParser
                .TableName = "tblClientMaster"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("ApplyMFCC")
                End With
                retObj = .ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar)
            End With
            If Not IsDBNull(retObj) Then
                retVal = CBool(retObj)
            End If
            Return retVal
        End Function

        Public Function IsApplyStdMFBank(ByVal ClientID As String) As Boolean
            'ApplyMFCC
            Dim retVal As Boolean = False
            Dim retObj As Object = 0
            With Me.MySQLParser
                .TableName = "tblClientMaster"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("ApplyMFBank")
                End With
                retObj = .ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar)
            End With
            If Not IsDBNull(retObj) Then
                retVal = CBool(retObj)
            End If
            Return retVal
        End Function

        Public Function IsApplyStdMFProduct(ByVal ClientID As String) As Boolean
            'ApplyMFCC
            Dim retVal As Boolean = False
            Dim retObj As Object = 0
            With Me.MySQLParser
                .TableName = "tblClientMaster"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("StandardMFProduct")
                End With
                retObj = .ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar)
            End With
            If Not IsDBNull(retObj) Then
                retVal = CBool(retObj)
            End If
            Return retVal
        End Function

        Public Function GetClientMFCC(ByVal ClientID As String) As DataTable
            Dim dt As DataTable
            Dim sql As New StringBuilder()
            sql.AppendLine("declare @@db_name nvarchar(100);")
            sql.AppendLine("set @@db_name=db_name();")
            sql.AppendLine("exec " + Util.StandardDB("sp_CWT_GetMFCCSettings") + "  @@db_name,'dbo'," + Util.LimitTheString(ClientID) + "")
            dt = Me.MySQLParser.ExecuteDataTable(sql.ToString())
            Return dt
        End Function

        Public Function GetClientMFBank(ByVal ClientID As String) As DataTable
            'Dim dt As DataTable
            'Dim sql As New StringBuilder()
            'sql.AppendLine("declare @@db_name nvarchar(100);")
            'sql.AppendLine("set @@db_name=db_name();")
            'sql.AppendLine("exec " + Util.StandardDB("sp_CWT_GetMFBankSettings") + "  @@db_name,'dbo'," + Util.LimitTheString(ClientID) + "")
            'dt = Me.MySQLParser.ExecuteDataTable(sql.ToString())
            'Return dt
            Dim dt As DataTable
            With Me.MySQLParser
                .TableName = "tblMFByBank"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("MFBankID")
                    .Add("CCNumber")
                    .Add("Percentage")
                End With
                dt = .ExecuteDataTable(.SQLSelect() + " order by CCNumber")
            End With
            Return dt
        End Function

        Public Function GetClientMFProduct(ByVal ClientID As String) As DataTable
            Dim dt As DataTable
            Dim sql As New StringBuilder()
            sql.AppendLine("declare @@db_name nvarchar(100);")
            sql.AppendLine("set @@db_name=db_name();")
            sql.AppendLine("exec " + Util.StandardDB("sp_CWT_GetMFProductSettings") + "  @@db_name,'dbo'," + Util.LimitTheString(ClientID) + "")
            dt = Me.MySQLParser.ExecuteDataTable(sql.ToString())
            Return dt
        End Function

        Public Function GetStandardMF(ByVal ClientID As String) As Double
            Dim retVal As Double = 0
            Dim retObj As Object = 0
            With Me.MySQLParser
                .TableName = "tblClientMaster"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("MerchantFee")
                End With
                retObj = .ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar)
            End With
            retVal = Util.DBNullToZero(retObj)
            Return retVal
        End Function

        '// Default
        Public Function GetMFCCList() As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .TableName = "tblMFByCC"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("Standard", True, SqlBuilder.SQLParserDataType.spBoolean, True)
                    .Add("*")
                    .Add("(select top 1 CCDescription from " + Util.StandardDB("tblPaymentType") + " where CCCode=Vendor) as VendorText")
                End With
                dt = .ExecuteDataTable(.SQLSelect() + " order by VendorText")
            End With
            Return dt
        End Function

        Public Function GetMFBankList() As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .TableName = "tblMFByBank"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("Standard", True, SqlBuilder.SQLParserDataType.spBoolean, True)
                    .Add("MFBankID")
                    .Add("CCNumber")
                    .Add("Percentage")
                End With
                dt = .ExecuteDataTable(.SQLSelect() + " order by CCNumber")
            End With
            Return dt
        End Function

        Public Function GetMFProductList() As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .TableName = "tblMFByProduct m inner join tblProducts p on m.ProductCode=p.Number"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("Standard", True, SqlBuilder.SQLParserDataType.spBoolean, True)
                    .Add("p.Name,m.*")
                End With
                dt = .ExecuteDataTable(.SQLSelect() + " order by p.Name")
            End With
            Return dt
        End Function

        Public Function SaveStandardMF(ByVal ClientID As String, ByVal MF As Double) As Integer
            Dim EffectRow As Integer
            Try
                With Me.MySQLParser
                    .TableName = "tblClientMaster"
                    With .Columns
                        .Clear()
                        .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        .Add("MerchantFee", MF, SqlBuilder.SQLParserDataType.spNum)
                    End With
                    EffectRow = .ExecuteUpdate()
                End With
            Catch ex As Exception
                EffectRow = -1
            End Try
            Return EffectRow
        End Function

        Public Function SaveMFCC(ByVal info As DataInfo.CompanyMFInfo) As Integer
            Dim EffectRow As Integer
            Try
                With Me.MySQLParser
                    .TableName = "tblClientMaster"
                    With .Columns
                        .Clear()
                        .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        .Add("ApplyMFCC", info.ApplyStdCC, SqlBuilder.SQLParserDataType.spBoolean)
                    End With
                    .ExecuteUpdate()
                    .TableName = "tblMFByCC"
                    With .Columns
                        .Clear()
                        .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        .Add("ClientID", "NULL", SqlBuilder.SQLParserDataType.spFunction, True, "is not")
                    End With
                    .ExecuteDelete()
                    For i As Integer = 0 To info.CreditCards.Count - 1
                        With .Columns
                            .Clear()
                            .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum)
                            .Add("Vendor", info.CreditCards(i).Vendor)
                            .Add("Percentage", info.CreditCards(i).MFFee, SqlBuilder.SQLParserDataType.spNum)
                            .Add("Standard", False, SqlBuilder.SQLParserDataType.spBoolean)
                        End With
                        EffectRow = .ExecuteInsert()
                        If EffectRow <= 0 Then
                            Exit For
                        End If
                    Next
                End With
            Catch ex As Exception
                EffectRow = -1
            End Try
            Return EffectRow
        End Function

        Public Function SaveMFBank(ByVal info As DataInfo.CompanyMFInfo) As Integer
            Dim EffectRow As Integer = 1
            Try
                With Me.MySQLParser
                    .TableName = "tblClientMaster"
                    With .Columns
                        .Clear()
                        .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        .Add("ApplyMFBank", info.ApplyStdBank, SqlBuilder.SQLParserDataType.spBoolean)
                    End With
                    .ExecuteUpdate()
                    .TableName = "tblMFByBank"
                    With .Columns
                        .Clear()
                        .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        .Add("ClientID", "NULL", SqlBuilder.SQLParserDataType.spFunction, True, "is not")
                    End With
                    .ExecuteDelete()
                    For i As Integer = 0 To info.BankCards.Count - 1
                        With .Columns
                            .Clear()
                            .Add("MFBankID", i + 1, SqlBuilder.SQLParserDataType.spNum)
                            .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum)
                            .Add("CCNumber", info.BankCards(i).CCnumber)
                            .Add("Percentage", info.BankCards(i).MFFee, SqlBuilder.SQLParserDataType.spNum)
                            .Add("Standard", False, SqlBuilder.SQLParserDataType.spBoolean)
                        End With
                        EffectRow = .ExecuteInsert()
                        If EffectRow <= 0 Then
                            Exit For
                        End If
                    Next
                End With
            Catch ex As Exception
                EffectRow = -1
            End Try
            Return EffectRow
        End Function

        Public Function SaveMFProduct(ByVal info As DataInfo.CompanyMFInfo) As Integer
            Dim EffectRow As Integer
            Try
                With Me.MySQLParser
                    .TableName = "tblClientMaster"
                    With .Columns
                        .Clear()
                        .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        .Add("StandardMFProduct", info.ApplyStdProduct, SqlBuilder.SQLParserDataType.spBoolean)
                    End With
                    .ExecuteUpdate()
                    .TableName = "tblMFByProduct"
                    With .Columns
                        .Clear()
                        .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        .Add("ClientID", "NULL", SqlBuilder.SQLParserDataType.spFunction, True, "is not")
                    End With
                    .ExecuteDelete()
                    For i As Integer = 0 To info.ProductMF.Count - 1
                        With .Columns
                            .Clear()
                            .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum)
                            .Add("ProductCode", info.ProductMF(i).ProductCode)
                            .Add("SubjectToMF", info.ProductMF(i).SubjectToMF, SqlBuilder.SQLParserDataType.spBoolean)
                            .Add("Standard", False, SqlBuilder.SQLParserDataType.spBoolean)
                        End With
                        EffectRow = .ExecuteInsert()
                        If EffectRow <= 0 Then
                            Exit For
                        End If
                    Next
                End With
            Catch ex As Exception
                EffectRow = -1
            End Try
            Return EffectRow
        End Function

    End Class
End Namespace

@


1.1.1.1
log
@no message
@
text
@@
