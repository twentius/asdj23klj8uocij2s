head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic
Imports System.Collections.Generic

Namespace DataAccessLayer
    Public Class HighRiskDestDAL
        Inherits BaseDA

        Public Function GetCityList() As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .TableName = Util.StandardDB("tblCity")
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("*")
                    .Add("CountryCode+' > '+City as CityCaption")
                    .Add("0 as IsRisk")
                End With
                dt = .ExecuteDataTable(.SQLSelect() + " order by City")
            End With
            Return dt
        End Function

        Public Function GetAirlineList() As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .TableName = Util.StandardDB("tblAirlines")
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("*")
                    .Add("0 as IsRisk")
                End With
                dt = .ExecuteDataTable(.SQLSelect() + " order by AirlineDescription")
            End With
            Return dt
        End Function

        Public Function GetHighRiskDestination(ByVal ClientID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .TableName = "tblHighRisk h"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("h.ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("h.CountryCode")
                    .Add("h.CityCode")
                    .Add("(select Top 1 City from " + Util.StandardDB("tblCity") + " where CityCode=h.CityCode) as City")
                    .Add("(select Top 1 CountryName from " + Util.StandardDB("tblCountry") + " where CountryCode=h.CountryCode) as CountryName")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetHighRiskAirline(ByVal ClientID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .TableName = "tblHighRiskAirline"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("AirlineCode")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function UpdateHighRiskDest(ByVal info As DataInfo.HighRiskInfo) As Integer
            Dim EffectRow As Integer = 1
            Try
                With Me.MySQLParser
                    .TableName = "tblHighRisk"
                    With .Columns
                        .Clear()
                        .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    End With
                    .ExecuteDelete()
                    For i As Integer = 0 To info.HighRiskDest.Count - 1
                        With .Columns
                            .Clear()
                            .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum)
                            .Add("CityCode", info.HighRiskDest(i).CityCode)
                            .Add("CountryCode", info.HighRiskDest(i).CountryCode)
                        End With
                        EffectRow = .ExecuteInsert()
                        If EffectRow <= 0 Then
                            Exit For
                        End If
                    Next
                End With
            Catch ex As Exception
                EffectRow = -1
            End Try
            Return EffectRow
        End Function

        Public Function UpdateHighRiskAir(ByVal info As DataInfo.HighRiskInfo) As Integer
            Dim EffectRow As Integer = 1
            Try
                With Me.MySQLParser
                    .TableName = "tblHighRiskAirline"
                    With .Columns
                        .Clear()
                        .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    End With
                    .ExecuteDelete()
                    For i As Integer = 0 To info.HighRiskAirList.Count - 1
                        With .Columns
                            .Clear()
                            .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum)
                            .Add("AirlineCode", info.HighRiskAirList(i).ToString)
                        End With
                        EffectRow = .ExecuteInsert()
                        If EffectRow <= 0 Then
                            Exit For
                        End If
                    Next
                End With
            Catch ex As Exception
                EffectRow = -1
            End Try
            Return EffectRow
        End Function

    End Class
End Namespace








@


1.1.1.1
log
@no message
@
text
@@
