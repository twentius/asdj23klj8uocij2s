head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic
Imports System.Collections.Generic

Namespace DataAccessLayer
    Public Class ReasonCodeDAL
        Inherits BaseDA

        Public Function GetReasonCodeList(ByVal ClientID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .TableName = "tblStandardReasonCode r"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("distinct r.ProductType,r.[Type]")
                    .Add("(case r.[Type] when 'R' then 'Realized saving' else 'Missed saving' end) as TypeName")
                    .Add("isnull((select ApplyStd from tblReasonCodeSettings where ProductType=r.ProductType and [Type]=r.[Type] and ClientID=" + Util.LimitTheString(ClientID) + "),0) as ApplyStd")
                End With
                dt = .ExecuteDataTable(.SQLSelect() + " order by r.ProductType")
            End With
            Return dt
        End Function

        Public Function GetReasonCodeByID(ByVal ClientID As String, ByVal ProductType As String, ByVal Type As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .TableName = "tblStandardReasonCode r"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("r.ProductType", ProductType, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("r.[Type]", Type, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("r.CRCodeID", "(select CRCodeID from tblClientReasonCode where ClientID=" + ClientID + ")", SqlBuilder.SQLParserDataType.spFunction, True, "not in")
                    .Add("r.*")
                    .Add("(case r.[Type] when 'R' then 'Realized saving' else 'Missed saving' end) as TypeName")
                End With
                dt = .ExecuteDataTable(.SQLSelect() + " order by r.ProductType")
            End With
            Return dt
        End Function

        Public Function GetReasonCodeByID(ByVal ProductType As String, ByVal Type As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .TableName = "tblStandardReasonCode r"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("r.ProductType", ProductType, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("r.[Type]", Type, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("r.*")
                    .Add("(case r.[Type] when 'R' then 'Realized saving' else 'Missed saving' end) as TypeName")
                End With
                dt = .ExecuteDataTable(.SQLSelect() + " order by r.ProductType")
            End With
            Return dt
        End Function

        Public Function GetClientReasonCode(ByVal ClientID As String, ByVal ProductType As String, ByVal Type As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .TableName = "tblClientReasonCode c inner join tblStandardReasonCode s on c.CRCodeID=s.CRCodeID"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("c.ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("s.ProductType", ProductType, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("s.[Type]", Type, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("c.*")
                    .Add("s.ReasonCode")
                    .Add("s.ProductType")
                    .Add("s.[Type]")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function IsApplyStd(ByVal ClientID As String, ByVal ProductType As String, ByVal Type As String) As Boolean
            Dim retVal As Boolean
            Dim retObject As Object
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblReasonCodeSettings"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("ProductType", ProductType, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("[Type]", Type, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("ApplyStd")
                End With
                retObject = .ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar)
            End With
            retVal = CBool(Util.DBNullToZero(retObject))
            Return retVal
        End Function

        Public Function GetReasonDescByCode(ByVal CRCodeID As String) As String
            Dim retVal As String
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblStandardReasonCode"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("CRCodeID", CRCodeID, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("Description")
                End With
                retVal = .ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar)
            End With
            Return retVal
        End Function

        Private Function GetReasonCodeKeyID(ByVal ClientID As String, ByVal CRCodeID As String) As String
            Dim retVal As String = ""
            Dim retObj As Object
            With Me.MySQLParser
                .TableName = "tblClientReasonCode"
                With .Columns
                    .Clear()
                    .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("CRCodeID", CRCodeID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("ClientRCodeID")
                End With
                retObj = .ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar)
                If retObj IsNot Nothing Then
                    retVal = Util.DBNullToText(retObj.ToString)
                End If
            End With
            Return retVal
        End Function

        Public Function UpdateReasonCode(ByVal info As DataInfo.CompanyReasonInfo) As Integer
            Dim EffectRow As Integer = 1
            'Dim IsUpdate As Boolean
            'Dim KeyID As String = ""
            Try
                With Me.MySQLParser
                    .TableName = "tblReasonCodeSettings"
                    With .Columns
                        .Clear()
                        .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        .Add("ProductType", info.ProductType, SqlBuilder.SQLParserDataType.spText, True)
                        .Add("[Type]", info.ReasonType, SqlBuilder.SQLParserDataType.spText, True)
                    End With
                    .ExecuteDelete()
                    With .Columns
                        .Clear()
                        .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum)
                        .Add("ProductType", info.ProductType)
                        .Add("[Type]", info.ReasonType, SqlBuilder.SQLParserDataType.spText)
                        .Add("ApplyStd", info.ApplyStd, SqlBuilder.SQLParserDataType.spBoolean)
                    End With
                    EffectRow = .ExecuteInsert()
                    .TableName = "tblClientReasonCode"
                    With .Columns
                        .Clear()
                        .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    End With
                    .ExecuteDelete()
                    For i As Integer = 0 To info.ReasonList.Count - 1
                        'KeyID = Me.GetReasonCodeKeyID(info.ClientID, info.ReasonList(i).CRCodeID)
                        .TableName = "tblClientReasonCode"
                        'IsUpdate = (KeyID <> "")
                        With .Columns
                            .Clear()
                            .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum)
                            .Add("CRCodeID", info.ReasonList(i).CRCodeID, SqlBuilder.SQLParserDataType.spNum)
                            .Add("Description", info.ReasonList(i).Description)
                        End With
                        EffectRow = .ExecuteInsert()
                        If EffectRow <= 0 Then
                            Exit For
                        End If
                    Next
                End With
            Catch ex As Exception
                EffectRow = -1
            End Try
            Return EffectRow
        End Function

    End Class
End Namespace

@


1.1.1.1
log
@no message
@
text
@@
