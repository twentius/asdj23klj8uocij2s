head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic
Imports System.Collections.Generic

Namespace DataAccessLayer
    Public Class CompanyDAL
        Inherits BaseDA

        Public Function GetCompanyList(ByVal ClientName As String, ByVal AffGroup As String, ByVal IncInActive As Boolean) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblClientMaster"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("ClientName", "%" + ClientName + "%", SqlBuilder.SQLParserDataType.spText, True, "LIKE")
                    .Add("AffiliateName", "%" + AffGroup + "%", SqlBuilder.SQLParserDataType.spText, True, "LIKE")
                    If Not IncInActive Then .Add("Status", True, SqlBuilder.SQLParserDataType.spBoolean, True)
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetClientName(ByVal ClientName As String) As String()
            Dim dt As DataTable
            Dim retVal As New List(Of String)
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblClientMaster"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("ClientName", ClientName + "%", SqlBuilder.SQLParserDataType.spText, True, "LIKE")
                    .Add("Distinct ClientName")
                End With
                dt = .ExecuteDataTable()
            End With
            If dt IsNot Nothing AndAlso dt.Rows.Count > 0 Then
                For i As Integer = 0 To dt.Rows.Count - 1
                    retVal.Add(dt.Rows(i).Item("ClientName").ToString)
                Next
            End If
            Return retVal.ToArray
        End Function

        Public Function IsExistName(ByVal ClientName As String, ByVal ID As String) As Boolean
            Dim retVal As Boolean
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblClientMaster"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("ClientName", ClientName, SqlBuilder.SQLParserDataType.spText, True)
                    If ID <> "" Then .Add("ClientID", ID, SqlBuilder.SQLParserDataType.spText, True, "<>")
                    .Add("count(*) as RecordCount")
                End With
                retVal = (Util.DBNullToZero(.ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar)) > 0)
            End With
            Return retVal
        End Function

        Public Function GetAffiliateName(ByVal AffiliateName As String) As String()
            Dim dt As DataTable
            Dim retVal As New List(Of String)
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblClientMaster"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("AffiliateName", AffiliateName + "%", SqlBuilder.SQLParserDataType.spText, True, "LIKE")
                    .Add("Distinct AffiliateName")
                End With
                dt = .ExecuteDataTable()
            End With
            If dt IsNot Nothing AndAlso dt.Rows.Count > 0 Then
                For i As Integer = 0 To dt.Rows.Count - 1
                    retVal.Add(dt.Rows(i).Item("AffiliateName").ToString)
                Next
            End If
            Return retVal.ToArray
        End Function

        Public Function GetCompayInfo(ByVal ClientID As String) As DataSet
            Dim ds As New DataSet()
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblClientMaster"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
                dt.TableName = "Company"
                ds.Tables.Add(dt)
                '// CWT Contact
                .TableName = "tblCWTContact"
                dt = .ExecuteDataTable(.SQLSelect + " order by ContactID")
                dt.TableName = "CWT"
                ds.Tables.Add(dt)
                '// Client Contact
                .TableName = "tblTM"
                dt = .ExecuteDataTable(.SQLSelect + " order by TMSequenceNo")
                dt.TableName = "Client"
                ds.Tables.Add(dt)
            End With
            Return ds
        End Function

        Public Function UpdateCompany(ByRef info As DataInfo.CompanyInfo) As Integer
            Dim EffectRow As Integer = -1
            Try
                With Me.MySQLParser
                    .OpenConnection()
                    .BeginTran()
                    .TableName = "tblClientMaster"
                    With .Columns
                        .Clear()
                        If info.PageMode = Global.TransactionMode.UpdateMode Then
                            .Add("ClientID", info.ID, SqlBuilder.SQLParserDataType.spNum, True)
                        End If
                        If info.CurrentWebMode = DataInfo.CompanyInfo.WebMode.GeneralInfo Then
                            .Add("ClientName", info.Name)
                            '.Add("ClientType", info.Type)
                            .Add("EntityName", info.EntityName)
                            .Add("AffiliateName", info.AffName)
                            .Add("BizPhoneLocalCode", info.BizPhoneCode)
                            .Add("BizPhoneNumber", info.BizPhoneNo)
                            .Add("BizFaxLocalCode", info.FaxPhoneCode)
                            .Add("BizFaxNumber", info.FaxPhoneNo)
                            .Add("Email", info.Email)
                            .Add("Address1", info.Address1)
                            .Add("Address2", info.Address2)
                            .Add("Address3", info.Address3)
                            .Add("Address4", info.Address4)
                            .Add("Address5", info.Address5)
                            .Add("ActivateDate", info.ActivateDate, SqlBuilder.SQLParserDataType.spDate)
                            .Add("Status", info.Status, SqlBuilder.SQLParserDataType.spBoolean)
                        End If
                    End With

                    Select Case info.PageMode
                        Case Global.TransactionMode.AddNewMode
                            EffectRow = .ExecuteInsert()
                            info.ID = .GetLastIdentity
                        Case Global.TransactionMode.UpdateMode
                            If info.CurrentWebMode = DataInfo.CompanyInfo.WebMode.GeneralInfo Then
                                EffectRow = .ExecuteUpdate()
                            Else
                                EffectRow = 1
                            End If
                            '// CWT Contact
                            If info.CurrentWebMode = DataInfo.CompanyInfo.WebMode.CWTContact Then
                                .TableName = "tblCWTContact"
                                With .Columns
                                    .Clear()
                                    .Add("ClientID", info.ID, SqlBuilder.SQLParserDataType.spNum, True)
                                End With
                                .ExecuteDelete()
                            End If
                            '// Client Contact
                            If info.CurrentWebMode = DataInfo.CompanyInfo.WebMode.ClientContact Then
                                .TableName = "tblTM"
                                With .Columns
                                    .Clear()
                                    .Add("ClientID", info.ID, SqlBuilder.SQLParserDataType.spNum, True)
                                End With
                                .ExecuteDelete()
                            End If
                    End Select
                    If info.CurrentWebMode = DataInfo.CompanyInfo.WebMode.CWTContact AndAlso EffectRow > 0 Then
                        '// CWT Contacts
                        .TableName = "tblCWTContact"
                        For i As Integer = 0 To info.CWTUserID.Count - 1
                            With .Columns
                                .Clear()
                                .Add("ClientID", info.ID, SqlBuilder.SQLParserDataType.spNum)
                                .Add("ContactID", i + 1, SqlBuilder.SQLParserDataType.spNum)
                                .Add("UserID", info.CWTUserID.Item(i))
                            End With
                            EffectRow = .ExecuteInsert()
                            If EffectRow <= 0 Then
                                Exit For
                            End If
                        Next
                    End If
                    If info.CurrentWebMode = DataInfo.CompanyInfo.WebMode.ClientContact AndAlso EffectRow > 0 Then
                        '// Client Contacts
                        .TableName = "tblTM"
                        For i As Integer = 0 To info.ClientContact.Count - 1
                            With .Columns
                                .Clear()
                                .Add("ClientID", info.ID, SqlBuilder.SQLParserDataType.spNum)
                                .Add("TMID", i + 1, SqlBuilder.SQLParserDataType.spNum)
                                .Add("TMSequenceNo", i + 1, SqlBuilder.SQLParserDataType.spNum)
                                .Add("Title", info.ClientContact.Item(i).Title)
                                .Add("FirstName", info.ClientContact.Item(i).FirstName)
                                .Add("LastName", info.ClientContact.Item(i).LastName)
                                .Add("LocalCode", info.ClientContact.Item(i).PhoneCode)
                                .Add("LocalCodeMobile", info.ClientContact.Item(i).MobileCode)
                                .Add("LocalCodeFax", info.ClientContact.Item(i).FaxCode)
                                .Add("Phone", info.ClientContact.Item(i).Phone)
                                .Add("Mobile", info.ClientContact.Item(i).Mobile)
                                .Add("Fax", info.ClientContact.Item(i).Fax)
                                .Add("Email", info.ClientContact.Item(i).Email)
                                .Add("JobTitle", info.ClientContact.Item(i).JobTitle)
                            End With
                            EffectRow = .ExecuteInsert()
                            If EffectRow <= 0 Then
                                Exit For
                            End If
                        Next
                    End If
                End With
                If EffectRow > 0 Then
                    Me.MySQLParser.CommitTran()
                Else
                    Me.MySQLParser.RollbackTran()
                End If
            Catch ex As Exception
                EffectRow = -1
                Me.MySQLParser.RollbackTran()
            Finally
                Me.MySQLParser.CloseConnection()
            End Try
            Return EffectRow
        End Function

        Public Function GetBillingData(ByVal ClientID As String) As DataSet
            Dim ds As New DataSet()
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblClientMaster"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
                dt.TableName = "Company"
                ds.Tables.Add(dt)
                '// Email
                .TableName = "tblBillingEmail"
                dt = .ExecuteDataTable()
                dt.TableName = "Email"
                ds.Tables.Add(dt)
                '// Billing
                .TableName = "tblBillingAddress"
                dt = .ExecuteDataTable()
                dt.TableName = "Billing"
                ds.Tables.Add(dt)
                '// Delivery
                .TableName = "tblDelivery"
                dt = .ExecuteDataTable()
                dt.TableName = "Delivery"
                ds.Tables.Add(dt)
            End With
            Return ds
        End Function

        Public Function UpdateBillingAddress(ByVal info As DataInfo.BillingAddressDataInfo) As Integer
            Dim EffectRow As Integer = 1
            Try
                With Me.MySQLParser
                    .OpenConnection()
                    .BeginTran()
                    .TableName = "tblClientMaster"
                    With .Columns
                        .Clear()
                        .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        .Add("BillingMode", info.BillMode, SqlBuilder.SQLParserDataType.spNum)
                        Select Case info.BillMode
                            Case DataInfo.BillingAddressDataInfo.BillingMode.eInvoice
                                .Add("InvEmailToTraveler", info.EmailReferToProfile, SqlBuilder.SQLParserDataType.spBoolean)
                        End Select
                        .Add("InvDelAddrToTraveler", info.DelAddrReferToProfile, SqlBuilder.SQLParserDataType.spBoolean)
                        If Not info.DelAddrReferToProfile Then
                            .Add("SameasBilling", info.SameAsBillAddress, SqlBuilder.SQLParserDataType.spBoolean)
                        End If
                    End With
                    .ExecuteUpdate()
                    '//
                    .TableName = "tblBillingEmail"
                    With .Columns
                        .Clear()
                        .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    End With
                    .ExecuteDelete()
                    '//
                    .TableName = "tblBillingAddress"
                    .ExecuteDelete()
                    '//
                    .TableName = "tblDelivery"
                    .ExecuteDelete()
                    '// CWT Contacts
                    .TableName = "tblBillingEmail"
                    For i As Integer = 0 To info.EmailList.Count - 1
                        With .Columns
                            .Clear()
                            .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum)
                            .Add("BillingID", i + 1, SqlBuilder.SQLParserDataType.spNum)
                            .Add("BillingEmail", info.EmailList.Item(i).Email)
                            .Add("Preferred", info.EmailList.Item(i).Prefered, SqlBuilder.SQLParserDataType.spBoolean)
                        End With
                        EffectRow = .ExecuteInsert()
                        If EffectRow <= 0 Then
                            Exit For
                        End If
                    Next
                    If EffectRow > 0 Then
                        '// Client Contacts
                        .TableName = "tblBillingAddress"
                        For i As Integer = 0 To info.BillingAddrList.Count - 1
                            With .Columns
                                .Clear()
                                .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum)
                                .Add("BillingID", i + 1, SqlBuilder.SQLParserDataType.spNum)
                                .Add("BillingAddr1", info.BillingAddrList.Item(i).Address1)
                                .Add("BillingAddr2", info.BillingAddrList.Item(i).Address2)
                                .Add("BillingAddr3", info.BillingAddrList.Item(i).Address3)
                                .Add("BillingAddr4", info.BillingAddrList.Item(i).Address4)
                                .Add("BillingAddr5", info.BillingAddrList.Item(i).Address5)
                                .Add("BillingAddr6", info.BillingAddrList.Item(i).Address6)
                                .Add("Preferred", info.BillingAddrList.Item(i).Prefered, SqlBuilder.SQLParserDataType.spBoolean)
                            End With
                            EffectRow = .ExecuteInsert()
                            If EffectRow <= 0 Then
                                Exit For
                            End If
                        Next
                    End If
                    If Not info.SameAsBillAddress AndAlso Not info.DelAddrReferToProfile AndAlso EffectRow > 0 Then
                        '// Client Contacts
                        .TableName = "tblDelivery"
                        For i As Integer = 0 To info.DelAddrList.Count - 1
                            With .Columns
                                .Clear()
                                .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum)
                                .Add("DeliveryID", i + 1, SqlBuilder.SQLParserDataType.spNum)
                                .Add("DeliveryAddr1", info.DelAddrList.Item(i).Address1)
                                .Add("DeliveryAddr2", info.DelAddrList.Item(i).Address2)
                                .Add("DeliveryAddr3", info.DelAddrList.Item(i).Address3)
                                .Add("DeliveryAddr4", info.DelAddrList.Item(i).Address4)
                                .Add("DeliveryAddr5", info.DelAddrList.Item(i).Address5)
                                .Add("DeliveryAddr6", info.DelAddrList.Item(i).Address6)
                                .Add("Preferred", info.DelAddrList.Item(i).Prefered, SqlBuilder.SQLParserDataType.spBoolean)
                            End With
                            EffectRow = .ExecuteInsert()
                            If EffectRow <= 0 Then
                                Exit For
                            End If
                        Next
                    End If
                End With
                If EffectRow > 0 Then
                    Me.MySQLParser.CommitTran()
                Else
                    Me.MySQLParser.RollbackTran()
                End If
            Catch ex As Exception
                EffectRow = -1
                Me.MySQLParser.RollbackTran()
            Finally
                Me.MySQLParser.CloseConnection()
            End Try
            Return EffectRow
        End Function

    End Class
End Namespace

@


1.1.1.1
log
@no message
@
text
@@
