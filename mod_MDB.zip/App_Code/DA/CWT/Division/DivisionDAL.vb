head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic

Namespace DataAccessLayer

    Public Class DivisionDAL
        Inherits BaseDA

        Public Function GetDivisionAgentTree() As DataTable
            Dim oDataTable As DataTable
            With Me.MySQLParser
                .TableName = "tblDivision d left join tblAgent a on d.divisionid=a.divisionid"
                With .Columns
                    .Clear()
                    .IncludeKey = False
                    .Add("a.*")
                    .Add("d.DivisionID as DivID")
                    .Add("d.DivisionDesc")
                End With
                oDataTable = .ExecuteDataTable(.SQLSelect() + " order by d.DivisionDesc,a.AgentID")
            End With
            Return oDataTable
        End Function

        Public Function GetDivisionList() As DataTable
            Dim oDataTable As DataTable
            With Me.MySQLParser
                .TableName = "tblDivision"
                With .Columns
                    .Clear()
                    .IncludeKey = False
                    .Add("*")
                End With
                oDataTable = .ExecuteDataTable(.SQLSelect() + " order by DivisionDesc")
            End With
            Return oDataTable
        End Function

        Public Function GetDivisionByID(ByVal DivisionID As String) As DataTable
            Dim oDataTable As DataTable
            With Me.MySQLParser
                .TableName = "tblDivision"
                With .Columns
                    .Clear()
                    .IncludeKey = False
                    .Add("DivisionID", DivisionID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("*")
                End With
                oDataTable = .ExecuteDataTable(.SQLSelect())
            End With
            Return oDataTable
        End Function

        Public Function UpdateDivision(ByVal info As DataInfo.DivisionInfo) As Integer
            Dim EffectRow As Integer
            Dim pwdManager As New Securities.DataEncryption()
            Dim encPassword As String = ""
            'Dim oSql As String
            'Dim KeyID As String
            Try
                With Me.MySQLParser
                    .TableName = "tblDivision"
                    With .Columns
                        .Clear()
                        .Add("DivisionID", info.ID, SqlBuilder.SQLParserDataType.spNum, (info.PageMode = Global.TransactionMode.UpdateMode))
                        .Add("DivisionDesc", info.Name)
                        '.Add("JobTitle", info.JobTitle)
                        .Add("Status", info.Status, SqlBuilder.SQLParserDataType.spBoolean)
                    End With

                    Select Case info.PageMode
                        Case Global.TransactionMode.AddNewMode
                            EffectRow = .ExecuteInsert()
                        Case Global.TransactionMode.UpdateMode
                            EffectRow = .ExecuteUpdate()
                    End Select
                End With
            Catch ex As Exception
                EffectRow = -1
            End Try
            Return EffectRow
        End Function

        Public Function GetAgentByID(ByVal AgentID As String) As DataTable
            Dim oDataTable As DataTable
            With Me.MySQLParser
                .TableName = "tblAgent"
                With .Columns
                    .Clear()
                    .IncludeKey = False
                    .Add("AgentID", AgentID, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("*")
                End With
                oDataTable = .ExecuteDataTable(.SQLSelect())
            End With
            Return oDataTable
        End Function

        Public Function UpdateAgent(ByVal info As DataInfo.AgentInfo) As Integer
            Dim EffectRow As Integer
            Try
                With Me.MySQLParser
                    .TableName = "tblAgent"
                    With .Columns
                        .Clear()
                        .Add("AgentID", info.UserName, SqlBuilder.SQLParserDataType.spText, (info.PageMode = Global.TransactionMode.UpdateMode))
                        .Add("DivisionID", info.DivID)
                        .Add("Title", info.Title)
                        .Add("FirstName", info.FirstName)
                        .Add("LastName", info.LastName)
                        .Add("BizPhoneLocalCode", info.BizPhoneCode)
                        .Add("BizPhone", info.BizPhoneNo)
                        .Add("AgentEmail", info.Email)
                        .Add("JobTitle", info.JobTitle)
                        .Add("SignOn", info.SignOn)
                        .Add("BackOfficeCode", info.BackOfficeCode)
                        .Add("QueuePCC1", info.QueuePCC1)
                        .Add("QueuePCC2", info.QueuePCC2)
                        .Add("QueuePCC3", info.QueuePCC3)
                        .Add("QueueNumber1", info.QueuePCC1)
                        .Add("QueueNumber2", info.QueueNo2)
                        .Add("QueueNumber3", info.QueueNo3)
                        .Add("Status", info.Status, SqlBuilder.SQLParserDataType.spBoolean)
                    End With

                    Select Case info.PageMode
                        Case Global.TransactionMode.AddNewMode
                            EffectRow = .ExecuteInsert()
                        Case Global.TransactionMode.UpdateMode
                            EffectRow = .ExecuteUpdate()
                    End Select
                End With
            Catch ex As Exception
                EffectRow = -1
            End Try
            Return EffectRow
        End Function

    End Class

End Namespace@


1.1.1.1
log
@no message
@
text
@@
