head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic
Namespace DataAccessLayer
    Public Class ProductDAL
        Inherits BaseDA

        Public Function GetProductType() As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = Util.StandardDB("tblProductType")
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetProductData() As DataTable
            Dim oDataTable As DataTable
            With Me.MySQLParser
                .TableName = "tblProducts p inner join " + Util.StandardDB("tblProductType") + " t on p.[Type]=t.ProductTypeCode"
                With .Columns
                    .Clear()
                    .Add("p.*")
                    .Add("t.ProductTypeName as typeName")
                End With
                oDataTable = .ExecuteDataTable()
            End With
            Return oDataTable
        End Function
        Public Function GetProductByNumber(ByVal Number As Integer) As DataTable
            Dim oDataTable As DataTable
            With Me.MySQLParser
                .TableName = "tblProducts p inner join " + Util.StandardDB("tblProductType") + " t on p.[Type]=t.ProductTypeCode"
                With .Columns
                    .Clear()
                    .Add("Number", Number, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("p.*")
                    .Add("t.ProductTypeName as typeName")
                End With
                oDataTable = .ExecuteDataTable()
            End With
            Return oDataTable
        End Function
        Public Function InsertProduct(ByVal Number As Integer, ByVal Name As String, ByVal GDSCode As String, ByVal Type As String, ByVal RequireCDR As Boolean, ByVal RequireTicket As Boolean, ByVal GST As String) As Integer
            Dim EffectRow As Integer
            With Me.MySQLParser
                .TableName = "tblProducts"
                With .Columns
                    .Clear()
                    .Add("Number", Number, SqlBuilder.SQLParserDataType.spNum)
                    .Add("Name", Name)
                    .Add("GDSCode", GDSCode)
                    .Add("Type", Type)
                    '.Add("TktPrefix", TktPrefix)
                    '.Add("TktFormat", TktFormat)
                    .Add("RequireCDR", RequireCDR, SqlBuilder.SQLParserDataType.spBoolean)
                    .Add("RequireTicket", RequireTicket, SqlBuilder.SQLParserDataType.spBoolean)
                    .Add("GST", GST)
                End With
                EffectRow = .ExecuteInsert()
            End With
            Return EffectRow
        End Function
        Public Function DeleteProductByNumber(ByVal Number As Integer) As Integer
            Dim EffectRow As Integer
            With Me.MySQLParser
                .TableName = "tblProducts"
                With .Columns
                    .Clear()
                    .Add("Number", Number, SqlBuilder.SQLParserDataType.spNum, True)
                End With
                EffectRow = .ExecuteDelete()
            End With
            Return EffectRow
        End Function
        Public Function UpdateProductByNumber(ByVal Number As Integer, ByVal Name As String, ByVal GDSCode As String, ByVal Type As String, ByVal RequireCDR As Boolean, ByVal RequireTicket As Boolean, ByVal GST As String) As Integer
            Dim EffectRow As Integer
            With Me.MySQLParser
                .TableName = "tblProducts"
                With .Columns
                    .Clear()
                    .IncludeKey = False
                    .Add("Number", Number, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("Name", Name)
                    .Add("GDSCode", GDSCode)
                    .Add("Type", Type)
                    '.Add("TktPrefix", TktPrefix)
                    '.Add("TktFormat", TktFormat)
                    .Add("RequireCDR", RequireCDR, SqlBuilder.SQLParserDataType.spBoolean)
                    .Add("RequireTicket", RequireTicket, SqlBuilder.SQLParserDataType.spBoolean)
                    .Add("GST", GST)
                End With

                EffectRow = .ExecuteUpdate()
            End With
            Return EffectRow
        End Function
    End Class
End Namespace

@


1.1.1.1
log
@no message
@
text
@@
