head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic

Namespace DataAccessLayer

    Public Class StaffRoleDA
        Inherits BaseDA

        Public Function GetUserRole() As DataTable
            Dim oDataTable As DataTable
            With Me.MySQLParser
                .TableName = "tblStaffRole"
                With .Columns
                    .Add("*")
                End With
                oDataTable = .ExecuteDataTable()
            End With
            Return oDataTable
        End Function

        Public Function GetUserRoleByRoleID(ByVal RoleID As Integer) As DataTable
            Dim oDataTable As DataTable
            With Me.MySQLParser
                .TableName = "tblStaffRole"
                With .Columns
                    .Clear()
                    .Add("RoleID", RoleID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("*")
                End With
                oDataTable = .ExecuteDataTable()
            End With
            Return oDataTable
        End Function

        Public Function InsertRole(ByVal RoleName As String) As Integer
            Dim EffectRow As Integer
            With Me.MySQLParser
                .TableName = "tblStaffRole"
                With .Columns
                    .Clear()
                    .Add("Role", RoleName)
                End With
                EffectRow = .ExecuteInsert()
            End With
            Return EffectRow
        End Function

        Public Function UpdateRoleByRoleID(ByVal RoleID As Integer, ByVal RoleName As String) As Integer
            Dim EffectRow As Integer
            With Me.MySQLParser
                .TableName = "tblStaffRole"
                With .Columns
                    .Clear()
                    .Add("RoleID", RoleID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("Role", "Admin", SqlBuilder.SQLParserDataType.spText, True, "<>")
                    .Add("Role", RoleName)
                End With
                EffectRow = .ExecuteUpdate()
            End With
            Return EffectRow
        End Function

        Public Function DeleteRoleByRoleID(ByVal RoleID As Integer) As Integer
            Dim EffectRow As Integer
            With Me.MySQLParser
                .TableName = "tblStaffRole"
                With .Columns
                    .Clear()
                    .Add("RoleID", RoleID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("Role", "Admin", SqlBuilder.SQLParserDataType.spText, True, "<>")
                End With
                EffectRow = .ExecuteDelete()
            End With
            Return EffectRow
        End Function

    End Class

End Namespace

@


1.1.1.1
log
@no message
@
text
@@
