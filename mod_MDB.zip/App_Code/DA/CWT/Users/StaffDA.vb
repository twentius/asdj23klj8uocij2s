head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic
Imports System.Collections.Generic

Namespace DataAccessLayer

    Public Class StaffDA
        Inherits BaseDA

        Public Function IsExistUser(ByVal UserName As String) As Boolean
            Dim EffectRow As Integer
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "TblAdminUsers"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("AdminUserID", UserName, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("Status", True, SqlBuilder.SQLParserDataType.spBoolean, True)
                    .Add("Count(*) as NumRec")
                End With
                EffectRow = .ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar)
            End With
            Return (EffectRow > 0)
        End Function

        Public Function GetDepartment() As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = Util.StandardDB("tblDepartment")
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetUserList(ByVal FirstName As String, ByVal LastName As String, ByVal IncInactive As Boolean) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "TblAdminUsers u LEFT JOIN tblStaffRole r on u.roleid=r.roleid"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("u.AdminUserID", "admin", SqlBuilder.SQLParserDataType.spText, True, "<>")
                    If FirstName <> "" Then .Add("u.FirstName", "%" + FirstName + "%", SqlBuilder.SQLParserDataType.spText, True, "LIKE")
                    If LastName <> "" Then .Add("u.LastName", "%" + LastName + "%", SqlBuilder.SQLParserDataType.spText, True, "LIKE")
                    If Not IncInactive Then .Add("u.Status", True, SqlBuilder.SQLParserDataType.spBoolean, True)
                    .Add("u.*")
                    .Add("r.Role")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetUserByID(ByVal UserName As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "TblAdminUsers"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("AdminUserID", UserName, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetDataColumnByID(ByVal Column As String, ByVal UserName As String) As Object
            Dim retVal As Object
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "TblAdminUsers"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("AdminUserID", UserName, SqlBuilder.SQLParserDataType.spText, True)
                    .Add(Column)
                End With
                retVal = .ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar, CommandType.Text)
            End With
            Return retVal
        End Function

        Public Function UpdateUser(ByVal info As DataInfo.UserInfo) As Integer
            Dim EffectRow As Integer
            'Dim pwdManager As New Securities.DataEncryption()
            'Dim encPassword As String = ""
            'Dim oSql As String
            'Dim KeyID As String
            Try
                With Me.MySQLParser
                    '.OpenConnection()
                    '.BeginTran()
                    .TableName = "TblAdminUsers"
                    With .Columns
                        .Clear()
                        '.Add("Country", info.Country)
                        .Add("AdminUserID", info.UserName, SqlBuilder.SQLParserDataType.spText, (info.PageMode = Global.TransactionMode.UpdateMode))
                        'If info.Password <> "" Then
                        '    encPassword = pwdManager.EncryptText(info.Password)
                        '    .Add("Password", encPassword)
                        'End If
                        .Add("Title", info.Title)
                        .Add("FirstName", info.FirstName)
                        .Add("LastName", info.LastName)
                        .Add("PhoneLocalCode", info.PhoneCode)
                        .Add("MobileLocalCode", info.MobileCode)
                        .Add("AlternateLocalCode", info.AltPhoneCode)
                        .Add("PhoneNumber", info.Phone)
                        .Add("MobileNumber", info.Mobile)
                        .Add("Department", info.DivID)
                        .Add("AlternatePhone", info.AltPhone)
                        .Add("Remark", info.Remark)
                        .Add("RoleID", info.RoleID)
                        .Add("EmailAddress", info.Email)
                        .Add("JobTitle", info.JobTitle)
                        .Add("Status", info.Status, SqlBuilder.SQLParserDataType.spBoolean)
                    End With

                    Select Case info.PageMode
                        Case Global.TransactionMode.AddNewMode
                            EffectRow = .ExecuteInsert()
                        Case Global.TransactionMode.UpdateMode
                            EffectRow = .ExecuteUpdate()
                    End Select
                    'If EffectRow > 0 Then
                    '    oSql = "select @@@@Identity as NewID"
                    '    KeyID = Me.MySQLParser.ExecuteCommand(oSql, SqlBuilder.SQLParserExecuteType.ExecuteScalar, CommandType.Text)
                    '    .TableName = "tblStaffContact"
                    '    With .Columns
                    '        .Clear()
                    '        .Add("StaffID", KeyID)
                    '        .Add("StaffPhone", info.Phone)
                    '        .Add("StaffAltPhone", info.AltPhone)
                    '        .Add("StaffMobile", info.Mobile)
                    '        .Add("StaffEmail", info.Email)
                    '    End With
                    '    EffectRow = .ExecuteInsert()
                    'End If
                    '//
                    'If EffectRow > 0 Then
                    '    .CommitTran()
                    'Else
                    '    .RollbackTran()
                    'End If
                End With
            Catch ex As Exception
                EffectRow = -1
                'Me.MySQLParser.RollbackTran()
                'Finally
                '    Me.MySQLParser.CloseConnection()
            End Try
            Return EffectRow
        End Function

        Public Function ChangePassword(ByVal UserName As String, ByVal NewPassword As String) As Integer
            Dim EffectRow As Integer
            Dim pwdManager As New Securities.DataEncryption()
            Dim encPassword As String = ""
            With Me.MySQLParser
                .TableName = "TblAdminUsers"
                With .Columns
                    .Clear()
                    .Add("AdminUserID", UserName, SqlBuilder.SQLParserDataType.spText, True)
                    encPassword = pwdManager.EncryptText(NewPassword)
                    .Add("Password", encPassword)
                End With
                EffectRow = .ExecuteUpdate()
            End With
            Return EffectRow
        End Function

        Public Function ChangeEmail(ByVal UserName As String, ByVal NewEmail As String) As Integer
            Dim EffectRow As Integer
            With Me.MySQLParser
                .TableName = "TblAdminUsers"
                With .Columns
                    .Clear()
                    .Add("AdminUserID", UserName, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("EmailAddress", NewEmail)
                End With
                EffectRow = .ExecuteUpdate()
            End With
            Return EffectRow
        End Function

        Public Function GetFirstName(ByVal FirstName As String) As String()
            Dim dt As DataTable
            Dim retVal As New List(Of String)
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "TblAdminUsers"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("FirstName", FirstName + "%", SqlBuilder.SQLParserDataType.spText, True, "LIKE")
                    .Add("Distinct FirstName")
                End With
                dt = .ExecuteDataTable()
            End With
            If dt IsNot Nothing AndAlso dt.Rows.Count > 0 Then
                For i As Integer = 0 To dt.Rows.Count - 1
                    retVal.Add(dt.Rows(i).Item("FirstName").ToString)
                Next
            End If
            Return retVal.ToArray
        End Function

        Public Function GetLastName(ByVal LastName As String) As String()
            Dim dt As DataTable
            Dim retVal As New List(Of String)
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "TblAdminUsers"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("LastName", LastName + "%", SqlBuilder.SQLParserDataType.spText, True, "LIKE")
                    .Add("Distinct LastName")
                End With
                dt = .ExecuteDataTable()
            End With
            If dt IsNot Nothing AndAlso dt.Rows.Count > 0 Then
                For i As Integer = 0 To dt.Rows.Count - 1
                    retVal.Add(dt.Rows(i).Item("LastName").ToString)
                Next
            End If
            Return retVal.ToArray
        End Function

    End Class

End Namespace
@


1.1.1.1
log
@no message
@
text
@@
