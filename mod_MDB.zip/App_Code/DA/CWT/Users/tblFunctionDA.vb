head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic

Namespace DataAccessLayer
    Public Class tblFunctionDA
        Inherits BaseDA

        Public Function getAllData(ByVal RoleID As Integer) As DataTable
            Dim oDataTable As DataTable
            Dim query As New StringBuilder
            query.AppendLine(" select temp.functionGroup,temp.functionName,temp.RoleID,temp.Role,")
            query.AppendLine("isnull(permission,'N') as permission")
            query.AppendLine(" from(")
            query.AppendLine(" select f.functionGroup,f.GroupName as functionName,r.RoleID,r.Role")
            query.AppendLine(" from tblFunctionGroup f,tblStaffRole r left outer join tblPermission p on r.roleid=p.roleid")
            query.AppendLine(" where(r.roleid = " + RoleID.ToString() + ") group by f.functionGroup,f.GroupName,r.RoleID,r.Role)temp left outer join tblPermission p on temp.roleid = p.RoleID and temp.functionGroup = p.functionGroup")
            With Me.MySQLParser
                oDataTable = .ExecuteDataTable(query.ToString())
            End With
            Return oDataTable
        End Function

        'Public Function GetAccessByPath(ByVal RoleID As Integer, ByVal PathURL As String) As DataTable
        '    Dim oDataTable As DataTable
        '    Dim query As New StringBuilder
        '    query.AppendLine(" select temp.functionID,temp.functionName,temp.pathurl,temp.RoleID,temp.Role,")
        '    query.AppendLine("isnull(permission,'N') as permission")
        '    query.AppendLine(" from(")
        '    query.AppendLine(" select f.functionID,f.functionName,min(f.pathurl) as pathurl,r.RoleID,r.Role")
        '    query.AppendLine(" from tblFunctions f,tblStaffRole r left outer join tblPermission p on r.roleid=p.roleid")
        '    query.AppendLine(" where(r.roleid = " + RoleID.ToString() + ") and f.AuthenRequired=1 and f.AdminRequired=0 ")
        '    query.AppendLine(" and f.pathurl=" + Util.LimitTheString(PathURL))
        '    query.AppendLine(" group by f.functionID,f.functionName,r.RoleID,r.Role)temp left outer join tblPermission p on temp.roleid = p.RoleID and temp.functionid = p.functionid")
        '    With Me.MySQLParser
        '        oDataTable = .ExecuteDataTable(query.ToString())
        '    End With
        '    Return oDataTable
        'End Function

        Public Function GetFunctionGroup(ByVal url As String) As Util.TabNameType
            Dim retVal As Util.TabNameType = Util.TabNameType.CWTData
            Dim oDataTable As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblFunctionGroup g inner join tblFunctions f on g.functiongroup=f.functiongroup"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("f.PathURL", url, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("g.*")
                End With
                oDataTable = .ExecuteDataTable()
                If oDataTable IsNot Nothing AndAlso oDataTable.Rows.Count > 0 Then
                    retVal = Util.DBNullToZero(oDataTable.Rows(0).Item("functiongroup"))
                End If
            End With
            Return retVal
        End Function

        Public Function SaveData(ByVal dt As DataTable, ByVal RoleID As Integer) As Integer
			Dim EffectRow As Integer
            'Try
            With Me.MySQLParser
                '.OpenConnection()
                '.BeginTran()
                .TableName = "tblPermission"
                With .Columns
                    .Clear()
                    .Add("RoleID", RoleID, SqlBuilder.SQLParserDataType.spNum, True)
                End With
                EffectRow = .ExecuteDelete()
                'If EffectRow > 0 Then
                For Each r As DataRow In dt.Rows
                    .TableName = "tblPermission"
                    With .Columns
                        .Clear()
                        .Add("FunctionID", r("FunctionID").ToString())
                        .Add("RoleID", RoleID, SqlBuilder.SQLParserDataType.spNum, True)
                        .Add("Permission", r("Permission").ToString())
                        '.Add("Role", "Admin", SqlBuilder.SQLParserDataType.spText, True, "<>")
                    End With
                    EffectRow = .ExecuteInsert()
                    'If Not EffectRow > 0 Then
                    '    Exit For
                    'End If
                Next
                'End If
            End With
            'If EffectRow > 0 Then
            '	Me.MySQLParser.CommitTran()
            'Else
            '	Me.MySQLParser.RollbackTran()
            'End If
            Return EffectRow
            'Catch ex As Exception
            '	Me.MySQLParser.RollbackTran()
            'Finally
            '	Me.MySQLParser.CloseConnection()
            'End Try
        End Function

        Public Function GetUserLevelByUrl(ByVal url As String) As CWTCustomControls.UserLevelControl
            Dim retVal As CWTCustomControls.UserLevelControl = CWTCustomControls.UserLevelControl.None
            Dim oDataTable As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblFunctions f inner join tblPermission p on f.FunctionGroup=p.FunctionGroup"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("f.PathURL", url, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("p.RoleID", ServiceLogicLayer.ProfilerSLL.CurrentProfile.RoleID, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("p.*")
                End With
                oDataTable = .ExecuteDataTable()
                If oDataTable IsNot Nothing AndAlso oDataTable.Rows.Count > 0 Then
                    Select Case oDataTable.Rows(0).Item("Permission")
                        Case "F"
                            retVal = CWTCustomControls.UserLevelControl.FullFunctional
                        Case "V"
                            retVal = CWTCustomControls.UserLevelControl.ViewOnly
                        Case "N"
                            retVal = CWTCustomControls.UserLevelControl.None
                    End Select
                End If
            End With
            Return retVal
        End Function

    End Class
End Namespace

@


1.1.1.1
log
@no message
@
text
@@
