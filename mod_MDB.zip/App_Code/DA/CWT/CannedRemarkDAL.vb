head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic
Imports System.Collections.Generic

Namespace DataAccessLayer
    Public Class CannedRemarkDAL
        Inherits BaseDA

        Public Function GetCannedRemark() As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblCannedRemark"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function UpdateCannedRemark(ByVal info As DataInfo.CannedRemarkInfo) As Integer
            Dim EffectRow As Integer = 1
            Try
                With Me.MySQLParser
                    .TableName = "tblCannedRemark"
                    .ExecuteDeleteAll()
                    For i As Integer = 0 To info.Remarks.Count - 1
                        With .Columns
                            .Clear()
                            .Add("CannedID", i + 1, SqlBuilder.SQLParserDataType.spNum)
                            .Add("CannedRmk", info.Remarks(i))
                        End With
                        EffectRow = .ExecuteInsert()
                        If EffectRow <= 0 Then
                            Exit For
                        End If
                    Next
                End With
            Catch ex As Exception
                EffectRow = -1
            End Try
            Return EffectRow
        End Function
    End Class

End Namespace





@


1.1.1.1
log
@no message
@
text
@@
