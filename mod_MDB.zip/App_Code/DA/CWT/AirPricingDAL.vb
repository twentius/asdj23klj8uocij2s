head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic
Imports System.Collections.Generic

Namespace DataAccessLayer
    Public Class AirPricingDAL
        Inherits BaseDA

        Public Function GetAirVariablesList() As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = Util.StandardDB("tblAirVariables")
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetAirOperatorList() As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = Util.StandardDB("tblAirOperator")
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetUsageAirVariables() As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = Util.StandardDB("tblAirVariables")
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("FieldID", "(3,4,5,6,7,9,10,11)", SqlBuilder.SQLParserDataType.spFunction, True, "in")
                    .Add("FieldID")
                    .Add("FieldName")
                    .Add("1 as Usage")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetUsageAirVariables(ByVal AirPricingID As String, ByVal IsInt As Boolean) As DataTable
            Dim dt As DataTable
            Dim IsIntVal As String
            If IsInt Then
                IsIntVal = "1"
            Else
                IsIntVal = "0"
            End If
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = Util.StandardDB("tblAirVariables") + " a left join tblAirPricingVariables p on a.FieldID=p.FieldID and isint=" + IsIntVal + " and AirPricingID=" + AirPricingID
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("a.FieldID", "(3,4,5,6,7,9,10,11)", SqlBuilder.SQLParserDataType.spFunction, True, "in")
                    .Add("a.FieldID")
                    .Add("a.FieldName")
                    .Add("(case when p.FieldID  is not null then 1 else 0 end) as Usage")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetAirPriceList() As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblAirPricingFormula a"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("a.AirPricingID")
                    .Add("a.AirPricingName")
                    .Add("(select count(AirPricingID) from tblClientPricing where AirPricingID=a.AirPricingID) as InUse")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetAirPriceData(ByVal RecordID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblAirPricingFormula "
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("AirPricingID", RecordID, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function UpdateAirPrice(ByVal info As DataInfo.AirPriceInfo) As Integer
            Dim EffectRow As Integer
            Try
                With Me.MySQLParser
                    .OpenConnection()
                    .BeginTran()
                    .TableName = "tblAirPricingFormula"
                    With .Columns
                        .Clear()
                        If info.ID <> "" Then .Add("AirPricingID", info.ID, SqlBuilder.SQLParserDataType.spNum, True)
                        .Add("AirPricingName", info.Name)
                        .Add("IntTotalAirCom", info.IntFomula.AirCom)
                        .Add("IntTotalMarkUp", info.IntFomula.MarkUp)
                        .Add("IntTotalDiscount", info.IntFomula.Discount)
                        .Add("IntTotalGST", info.IntFomula.GST)
                        .Add("IntTotalFare", info.IntFomula.Fare)
                        .Add("IntFuelChargeOption", info.IntFomula.FuelChargeOption)
                        .Add("IntMFFeeNetRemit", info.IntFomula.MFFeeNetRemit)
                        .Add("IntMFFeeNoneNetRemit", info.IntFomula.MFFeeNonNetRemit)
                        .Add("IntApplyFee", info.IntFomula.ApplyFee, SqlBuilder.SQLParserDataType.spBoolean)
                        .Add("DomSameAsInt", info.DomSameAsInt, SqlBuilder.SQLParserDataType.spBoolean)
                        If Not info.DomSameAsInt Then
                            .Add("DomTotalAirCom", info.DomFomula.AirCom)
                            .Add("DomTotalMarkUp", info.DomFomula.MarkUp)
                            .Add("DomTotalDiscount", info.DomFomula.Discount)
                            .Add("DomTotalGST", info.DomFomula.GST)
                            .Add("DomTotalFare", info.DomFomula.Fare)
                            .Add("DomFuelChargeOption", info.DomFomula.FuelChargeOption)
                            .Add("DomMFFeeNetRemit", info.DomFomula.MFFeeNetRemit)
                            .Add("DomMFFeeNoneNetRemit", info.DomFomula.MFFeeNonNetRemit)
                            .Add("DomApplyFee", info.DomFomula.ApplyFee, SqlBuilder.SQLParserDataType.spBoolean)
                        Else
                            '.Add("DomTotalAirCom", info.IntFomula.AirCom)
                            '.Add("DomTotalMarkUp", info.IntFomula.MarkUp)
                            '.Add("DomTotalDiscount", info.IntFomula.Discount)
                            '.Add("DomTotalGST", info.IntFomula.GST)
                            '.Add("DomTotalFare", info.IntFomula.Fare)
                            '.Add("DomFuelChargeOption", info.IntFomula.FuelChargeOption)
                            '.Add("DomMFFeeNetRemit", info.IntFomula.MFFeeNetRemit)
                            '.Add("DomMFFeeNoneNetRemit", info.IntFomula.MFFeeNonNetRemit)
                            '.Add("DomApplyFee", info.IntFomula.ApplyFee, SqlBuilder.SQLParserDataType.spBoolean)
                        End If
                    End With

                    Select Case info.PageMode
                        Case Global.TransactionMode.AddNewMode
                            EffectRow = .ExecuteInsert()
                            info.ID = .GetLastIdentity
                        Case Global.TransactionMode.UpdateMode
                            EffectRow = .ExecuteUpdate()
                            '//
                            .TableName = "tblAirPricingVariables"
                            With .Columns
                                .Clear()
                                .Add("AirPricingID", info.ID, SqlBuilder.SQLParserDataType.spNum, True)
                            End With
                            .ExecuteDelete()
                    End Select
                    If EffectRow > 0 Then
                        For i As Integer = 0 To info.IntFomula.UsageList.Count - 1
                            .TableName = "tblAirPricingVariables"
                            With .Columns
                                .Clear()
                                .Add("AirPricingID", info.ID, SqlBuilder.SQLParserDataType.spNum)
                                .Add("FieldID", info.IntFomula.UsageList(i), SqlBuilder.SQLParserDataType.spNum)
                                .Add("IsInt", True, SqlBuilder.SQLParserDataType.spBoolean)
                            End With
                            EffectRow = .ExecuteInsert()
                            If EffectRow <= 0 Then
                                Exit For
                            End If
                        Next
                        If EffectRow > 0 AndAlso Not info.DomSameAsInt Then
                            For i As Integer = 0 To info.DomFomula.UsageList.Count - 1
                                .TableName = "tblAirPricingVariables"
                                With .Columns
                                    .Clear()
                                    .Add("AirPricingID", info.ID, SqlBuilder.SQLParserDataType.spNum)
                                    .Add("FieldID", info.DomFomula.UsageList(i), SqlBuilder.SQLParserDataType.spNum)
                                    .Add("IsInt", False, SqlBuilder.SQLParserDataType.spBoolean)
                                End With
                                EffectRow = .ExecuteInsert()
                                If EffectRow <= 0 Then
                                    Exit For
                                End If
                            Next
                        End If
                    End If
                End With
                If EffectRow > 0 Then
                    Me.MySQLParser.CommitTran()
                Else
                    Me.MySQLParser.RollbackTran()
                End If
            Catch ex As Exception
                EffectRow = -1
                Me.MySQLParser.RollbackTran()
            Finally
                Me.MySQLParser.CloseConnection()
            End Try
            Return EffectRow
        End Function

    End Class
End Namespace


@


1.1.1.1
log
@no message
@
text
@@
