head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic
Imports System.Collections.Generic

Namespace DataAccessLayer
    Public Class AuxPricingDAL
        Inherits BaseDA

        Public Function GetProductList() As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblProducts"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetAuxPricingList(ByVal Name As String, ByVal ProductID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblAuxFee"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    If Name <> "" Then
                        .Add("FeeName", "%" + Name + "%", SqlBuilder.SQLParserDataType.spText, True, "LIKE")
                    End If
                    If ProductID <> "" Then
                        .Add("ApplytoProduct", ProductID, SqlBuilder.SQLParserDataType.spNum, True)
                    End If
                    .Add("*")
                    .Add("(select top 1 p.[Name] from tblProducts p where p.[Number]=FeeProduct) as FeeProductName")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function IsExistName(ByVal FeeName As String, ByVal ProductID As String) As Boolean
            Dim retVal As Boolean
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblAuxFee"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    If ProductID <> "" Then .Add("ApplytoProduct", ProductID, SqlBuilder.SQLParserDataType.spText, True, "<>")
                    .Add("FeeName", FeeName, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("count(*) as RecordCount")
                End With
                retVal = (Util.DBNullToZero(.ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar)) > 0)
            End With
            Return retVal
        End Function

        Public Function GetAuxPricingByID(ByVal FeeID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblAuxFee"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("AuxFeeID", FeeID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("*")
                    .Add("(select top 1 p.[Name] from tblProducts p where p.[Number]=ApplytoProduct) as ApplytoProductName")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function UpdateAuxPrice(ByVal info As DataInfo.AuxFeeInfo) As Integer
            Dim EffectRow As Integer
            Try
                With Me.MySQLParser
                    .TableName = "tblAuxFee"
                    With .Columns
                        .Clear()
                        If info.ID <> "" Then .Add("AuxFeeID", info.ID, SqlBuilder.SQLParserDataType.spNum, True)
                        .Add("FeeName", info.Name)
                        .Add("ApplytoProduct", info.ApplyProduct, SqlBuilder.SQLParserDataType.spNum)
                        .Add("FeeAmount", info.FeeAmount, SqlBuilder.SQLParserDataType.spNum)
                        .Add("FeeProduct", info.FeeProduct, SqlBuilder.SQLParserDataType.spNum)
                    End With

                    Select Case info.PageMode
                        Case Global.TransactionMode.AddNewMode
                            EffectRow = .ExecuteInsert()
                        Case Global.TransactionMode.UpdateMode
                            EffectRow = .ExecuteUpdate()
                    End Select
                End With
            Catch ex As Exception
                EffectRow = -1
            End Try
            Return EffectRow
        End Function

    End Class
End Namespace

@


1.1.1.1
log
@no message
@
text
@@
