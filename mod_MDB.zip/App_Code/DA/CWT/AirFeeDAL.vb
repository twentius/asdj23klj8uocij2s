head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic
Imports System.Collections.Generic

Namespace DataAccessLayer
    Public Class AirFeeDAL
        Inherits BaseDA

#Region "General"
        Public Function GetFeeList(ByVal FeeName As String, ByVal FeeType As DataInfo.AirFeeInfo.AirFeeManagerType) As DataTable
            Dim dt As DataTable
            Dim tblName As String = ""
            Dim FeeTypeName As String
            Select Case FeeType
                Case DataInfo.AirFeeInfo.AirFeeManagerType.FeeByPNR
                    tblName = "tblFeeByPNR f"
                    FeeTypeName = "P"
                Case DataInfo.AirFeeInfo.AirFeeManagerType.FeeByTicket
                    tblName = "tblFeeByTicket f"
                    FeeTypeName = "T"
                Case DataInfo.AirFeeInfo.AirFeeManagerType.FeeByCoupon
                    tblName = "tblFeeByCoupon f"
                    FeeTypeName = "C"
                Case DataInfo.AirFeeInfo.AirFeeManagerType.ConditionalMarkUp
                    tblName = "tblFeeByConditional f"
                    FeeTypeName = "A"
                Case Else
                    Return (New DataTable)
            End Select
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = tblName
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    If FeeName <> "" Then .Add("f.FeeName", "%" + FeeName + "%", SqlBuilder.SQLParserDataType.spText, True, "LIKE")
                    .Add("f.*")
                    .Add("(select count(*) from tblClientPricing where (TransFeeIDInt=f.FeeID and TransFeeOptionInt=" + Util.LimitTheString(FeeTypeName) + ") or (TransFeeIDDom=f.FeeID and TransFeeOptionDom=" + Util.LimitTheString(FeeTypeName) + ") ) as InUse")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetFeeName(ByVal FeeName As String, ByVal FeeType As String) As String()
            Dim dt As DataTable
            Dim tblName As String = ""
            Dim retVal As New List(Of String)
            Select Case FeeType
                Case DataInfo.AirFeeInfo.AirFeeManagerType.FeeByPNR.ToString
                    tblName = "tblFeeByPNR"
                Case DataInfo.AirFeeInfo.AirFeeManagerType.FeeByTicket.ToString
                    tblName = "tblFeeByTicket"
                Case DataInfo.AirFeeInfo.AirFeeManagerType.FeeByCoupon.ToString
                    tblName = "tblFeeByCoupon"
                Case DataInfo.AirFeeInfo.AirFeeManagerType.ConditionalMarkUp.ToString
                    tblName = "tblFeeByConditional"
                Case Else
                    Return retVal.ToArray
            End Select
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = tblName
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("FeeName", FeeName + "%", SqlBuilder.SQLParserDataType.spText, True, "LIKE")
                    .Add("Distinct FeeName")
                End With
                dt = .ExecuteDataTable()
            End With
            If dt IsNot Nothing AndAlso dt.Rows.Count > 0 Then
                For i As Integer = 0 To dt.Rows.Count - 1
                    retVal.Add(dt.Rows(i).Item("FeeName").ToString)
                Next
            End If
            Return retVal.ToArray
        End Function

        Public Function GetFeeNameByID(ByVal FeeID As String, ByVal FeeType As DataInfo.AirFeeInfo.AirFeeManagerType) As String
            Dim retVal As String = ""
            Dim tblName As String = ""
            Select Case FeeType
                Case DataInfo.AirFeeInfo.AirFeeManagerType.FeeByPNR
                    tblName = "tblFeeByPNR"
                Case DataInfo.AirFeeInfo.AirFeeManagerType.FeeByTicket
                    tblName = "tblFeeByTicket"
                Case DataInfo.AirFeeInfo.AirFeeManagerType.FeeByCoupon
                    tblName = "tblFeeByCoupon"
                Case DataInfo.AirFeeInfo.AirFeeManagerType.ConditionalMarkUp
                    tblName = "tblFeeByConditional"
                Case Else
                    Return ""
            End Select
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = tblName
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("FeeID", FeeID, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("FeeName")
                End With
                retVal = .ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar)
            End With
            Return retVal
        End Function

        Public Function GetAirCalcName(ByVal AirPricingID As String) As String
            Dim retVal As String = ""
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblAirPricingFormula "
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("AirPricingID", AirPricingID, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("AirPricingName")
                End With
                retVal = .ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar)
            End With
            Return retVal
        End Function

        Public Function IsExistName(ByVal FeeName As String, ByVal ID As String, ByVal FeeType As DataInfo.AirFeeInfo.AirFeeManagerType) As Boolean
            Dim retVal As Boolean
            Dim tblName As String = ""
            Dim rCount As Integer
            Select Case FeeType
                Case DataInfo.AirFeeInfo.AirFeeManagerType.FeeByPNR
                    tblName = "tblFeeByPNR"
                Case DataInfo.AirFeeInfo.AirFeeManagerType.FeeByTicket
                    tblName = "tblFeeByTicket"
                Case DataInfo.AirFeeInfo.AirFeeManagerType.FeeByCoupon
                    tblName = "tblFeeByCoupon"
                Case DataInfo.AirFeeInfo.AirFeeManagerType.ConditionalMarkUp
                    tblName = "tblFeeByConditional"
                Case Else
                    Return False
            End Select
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = tblName
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("FeeName", FeeName, SqlBuilder.SQLParserDataType.spText, True)
                    If ID <> "" Then .Add("FeeID", ID, SqlBuilder.SQLParserDataType.spText, True, "<>")
                    .Add("count(*) as RecordCount")
                End With
                rCount = Util.DBNullToZero(.ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar))
                retVal = (rCount > 0)
            End With
            Return retVal
        End Function
#End Region

#Region "Coupon"
        Public Function GetFeeByCouponData(ByVal FeeID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblTransactionFeebyCoupon"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("FeeID", FeeID, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function UpdateFeeByCouponData(ByVal info As DataInfo.TransCouponInfo) As Integer
            Dim EffectRow As Integer
            Try
                With Me.MySQLParser
                    .OpenConnection()
                    .BeginTran()
                    .TableName = "tblTransactionFeebyCoupon"
                    With .Columns
                        .Clear()
                        .Add("FeeID", info.FeeID, SqlBuilder.SQLParserDataType.spNum, True)
                    End With
                    .ExecuteDelete()
                    '//
                    .TableName = "tblFeeByCoupon"
                    With .Columns
                        .Clear()
                        If info.PageMode = Global.TransactionMode.UpdateMode Then
                            .Add("FeeID", info.FeeID, SqlBuilder.SQLParserDataType.spNum, True)
                        End If
                        .Add("FeeName", info.FeeName)
                    End With

                    Select Case info.PageMode
                        Case Global.TransactionMode.AddNewMode
                            EffectRow = .ExecuteInsert()
                            info.FeeID = .GetLastIdentity
                        Case Global.TransactionMode.UpdateMode
                            EffectRow = .ExecuteUpdate()
                    End Select
                    If EffectRow > 0 Then
                        '// 
                        .TableName = "tblTransactionFeebyCoupon"
                        For i As Integer = 0 To info.CouponList.Count - 1
                            With .Columns
                                .Clear()
                                .Add("FeeID", info.FeeID, SqlBuilder.SQLParserDataType.spNum)
                                .Add("TransID", i + 1, SqlBuilder.SQLParserDataType.spNum)
                                .Add("Type", info.CouponList(i).Type)
                                .Add("StartCoupon", info.CouponList(i).StartCoupon, SqlBuilder.SQLParserDataType.spNum)
                                .Add("EndCoupon", info.CouponList(i).EndCoupon, SqlBuilder.SQLParserDataType.spNum)
                                .Add("Threshold", info.CouponList(i).Threshold, SqlBuilder.SQLParserDataType.spNum)
                                .Add("TFAmount", info.CouponList(i).FeeAmt, SqlBuilder.SQLParserDataType.spNum)
                            End With
                            EffectRow = .ExecuteInsert()
                            If EffectRow <= 0 Then
                                Exit For
                            End If
                        Next
                    End If
                End With
                If EffectRow > 0 Then
                    Me.MySQLParser.CommitTran()
                Else
                    Me.MySQLParser.RollbackTran()
                End If
            Catch ex As Exception
                EffectRow = -1
                Me.MySQLParser.RollbackTran()
            Finally
                Me.MySQLParser.CloseConnection()
            End Try
            Return EffectRow
        End Function
#End Region

#Region "Conditional"
        Public Function GetFeeByConditionalData(ByVal FeeID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblConditionalMarkup"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("FeeID", FeeID, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function UpdateFeeByConditionalData(ByVal info As DataInfo.TransConditionalInfo) As Integer
            Dim EffectRow As Integer
            Try
                With Me.MySQLParser
                    .OpenConnection()
                    .BeginTran()
                    .TableName = "tblConditionalMarkup"
                    With .Columns
                        .Clear()
                        .Add("FeeID", info.FeeID, SqlBuilder.SQLParserDataType.spNum, True)
                    End With
                    .ExecuteDelete()
                    '//
                    .TableName = "tblFeeByConditional"
                    With .Columns
                        .Clear()
                        If info.PageMode = Global.TransactionMode.UpdateMode Then
                            .Add("FeeID", info.FeeID, SqlBuilder.SQLParserDataType.spNum, True)
                        End If
                        .Add("FeeName", info.FeeName)
                    End With

                    Select Case info.PageMode
                        Case Global.TransactionMode.AddNewMode
                            EffectRow = .ExecuteInsert()
                            info.FeeID = .GetLastIdentity
                        Case Global.TransactionMode.UpdateMode
                            EffectRow = .ExecuteUpdate()
                    End Select
                    If EffectRow > 0 Then
                        '// 
                        .TableName = "tblConditionalMarkup"
                        For i As Integer = 0 To info.ConditionalList.Count - 1
                            With .Columns
                                .Clear()
                                .Add("FeeID", info.FeeID, SqlBuilder.SQLParserDataType.spNum)
                                .Add("TransID", i + 1, SqlBuilder.SQLParserDataType.spNum)
                                .Add("StartAmount", info.ConditionalList(i).StartAmount, SqlBuilder.SQLParserDataType.spNum)
                                .Add("EndAmount", info.ConditionalList(i).EndAmount, SqlBuilder.SQLParserDataType.spNum)
                                .Add("MarkUpAmont", info.ConditionalList(i).FeeAmt, SqlBuilder.SQLParserDataType.spNum)
                            End With
                            EffectRow = .ExecuteInsert()
                            If EffectRow <= 0 Then
                                Exit For
                            End If
                        Next
                    End If
                End With
                If EffectRow > 0 Then
                    Me.MySQLParser.CommitTran()
                Else
                    Me.MySQLParser.RollbackTran()
                End If
            Catch ex As Exception
                EffectRow = -1
                Me.MySQLParser.RollbackTran()
            Finally
                Me.MySQLParser.CloseConnection()
            End Try
            Return EffectRow
        End Function
#End Region

#Region "PNR"
        Public Function GetFeeByPNRData(ByVal FeeID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblTransactionFeebyPNR"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("FeeID", FeeID, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function UpdateFeeByPNRData(ByVal info As DataInfo.TransPNRInfo) As Integer
            Dim EffectRow As Integer
            Try
                With Me.MySQLParser
                    .OpenConnection()
                    .BeginTran()
                    .TableName = "tblTransactionFeebyPNR"
                    If info.PageMode = Global.TransactionMode.UpdateMode Then
                        With .Columns
                            .Clear()
                            .Add("FeeID", info.FeeID, SqlBuilder.SQLParserDataType.spNum, True)
                        End With
                        .ExecuteDelete()
                    End If
                    '//
                    .TableName = "tblFeeByPNR"
                    With .Columns
                        .Clear()
                        If info.PageMode = Global.TransactionMode.UpdateMode Then
                            .Add("FeeID", info.FeeID, SqlBuilder.SQLParserDataType.spNum, True)
                        End If
                        .Add("FeeName", info.FeeName)
                    End With

                    Select Case info.PageMode
                        Case Global.TransactionMode.AddNewMode
                            EffectRow = .ExecuteInsert()
                            info.FeeID = .GetLastIdentity
                        Case Global.TransactionMode.UpdateMode
                            EffectRow = .ExecuteUpdate()
                    End Select
                    If EffectRow > 0 Then
                        '// 
                        .TableName = "tblTransactionFeebyPNR"
                        For i As Integer = 0 To info.PNRList.Count - 1
                            With .Columns
                                .Clear()
                                .Add("FeeID", info.FeeID, SqlBuilder.SQLParserDataType.spNum)
                                .Add("TransID", i + 1, SqlBuilder.SQLParserDataType.spNum)
                                .Add("ApplyAll", info.PNRList(i).IsApplyAll, SqlBuilder.SQLParserDataType.spBoolean)
                                .Add("TerritoryType", info.PNRList(i).ApplyMode)
                                Select Case info.PNRList(i).ApplyMode
                                    Case DataInfo.PNRItemInfo.ApplyByItem.Region
                                        .Add("TerritoryCode", info.PNRList(i).RegionSQLString)
                                    Case DataInfo.PNRItemInfo.ApplyByItem.Country
                                        .Add("TerritoryCode", info.PNRList(i).CountrySQLString)
                                    Case DataInfo.PNRItemInfo.ApplyByItem.City
                                        .Add("TerritoryCode", info.PNRList(i).CitySQLString)
                                End Select
                                .Add("StartAmount", info.PNRList(i).FareFrom, SqlBuilder.SQLParserDataType.spNum)
                                .Add("EndAmount", info.PNRList(i).FareTo, SqlBuilder.SQLParserDataType.spNum)
                                .Add("TFAmount", info.PNRList(i).FareAmt, SqlBuilder.SQLParserDataType.spNum)
                            End With
                            EffectRow = .ExecuteInsert()
                            If EffectRow <= 0 Then
                                Exit For
                            End If
                        Next
                    End If
                End With
                If EffectRow > 0 Then
                    Me.MySQLParser.CommitTran()
                Else
                    Me.MySQLParser.RollbackTran()
                End If
            Catch ex As Exception
                EffectRow = -1
                Me.MySQLParser.RollbackTran()
            Finally
                Me.MySQLParser.CloseConnection()
            End Try
            Return EffectRow
        End Function
#End Region

#Region "Ticket"
        Public Function GetFeeByTicketData(ByVal FeeID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblTransactionFeebyTicket"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("FeeID", FeeID, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function UpdateFeeByTicketData(ByVal info As DataInfo.TransTicketInfo) As Integer
            Dim EffectRow As Integer
            Try
                With Me.MySQLParser
                    .OpenConnection()
                    .BeginTran()
                    .TableName = "tblTransactionFeebyTicket"
                    If info.PageMode = Global.TransactionMode.UpdateMode Then
                        With .Columns
                            .Clear()
                            .Add("FeeID", info.FeeID, SqlBuilder.SQLParserDataType.spNum, True)
                        End With
                        .ExecuteDelete()
                    End If
                    '//
                    .TableName = "tblFeeByTicket"
                    With .Columns
                        .Clear()
                        If info.PageMode = Global.TransactionMode.UpdateMode Then
                            .Add("FeeID", info.FeeID, SqlBuilder.SQLParserDataType.spNum, True)
                        End If
                        .Add("FeeName", info.FeeName)
                    End With

                    Select Case info.PageMode
                        Case Global.TransactionMode.AddNewMode
                            EffectRow = .ExecuteInsert()
                            info.FeeID = .GetLastIdentity
                        Case Global.TransactionMode.UpdateMode
                            EffectRow = .ExecuteUpdate()
                    End Select
                    If EffectRow > 0 Then
                        '// 
                        .TableName = "tblTransactionFeebyTicket"
                        For i As Integer = 0 To info.TicketList.Count - 1
                            With .Columns
                                .Clear()
                                .Add("FeeID", info.FeeID, SqlBuilder.SQLParserDataType.spNum)
                                .Add("TransID", i + 1, SqlBuilder.SQLParserDataType.spNum)
                                .Add("ApplyAll", info.TicketList(i).IsApplyAll, SqlBuilder.SQLParserDataType.spBoolean)
                                .Add("ExtraFee", info.TicketList(i).IsExtraFee, SqlBuilder.SQLParserDataType.spBoolean)
                                .Add("TerritoryType", info.TicketList(i).ApplyMode)
                                Select Case info.TicketList(i).ApplyMode
                                    Case DataInfo.PNRItemInfo.ApplyByItem.Region
                                        .Add("TerritoryCode", info.TicketList(i).RegionSQLString)
                                    Case DataInfo.PNRItemInfo.ApplyByItem.Country
                                        .Add("TerritoryCode", info.TicketList(i).CountrySQLString)
                                    Case DataInfo.PNRItemInfo.ApplyByItem.City
                                        .Add("TerritoryCode", info.TicketList(i).CitySQLString)
                                End Select
                                .Add("StartAmount", info.TicketList(i).FareFrom, SqlBuilder.SQLParserDataType.spNum)
                                .Add("EndAmount", info.TicketList(i).FareTo, SqlBuilder.SQLParserDataType.spNum)
                                .Add("TFAmount", info.TicketList(i).FareAmt, SqlBuilder.SQLParserDataType.spNum)
                                .Add("ExtraAmount", info.TicketList(i).ExtraAmt, SqlBuilder.SQLParserDataType.spNum)
                                .Add("MinAmount", info.TicketList(i).MinAmt, SqlBuilder.SQLParserDataType.spNum)
                                .Add("MaxAmount", info.TicketList(i).MaxAmt, SqlBuilder.SQLParserDataType.spNum)
                                .Add("PerAmount", info.TicketList(i).PerAmt, SqlBuilder.SQLParserDataType.spNum)
                                .Add("[Operator]", info.TicketList(i).OperatorAmt)
                            End With
                            EffectRow = .ExecuteInsert()
                            If EffectRow <= 0 Then
                                Exit For
                            End If
                        Next
                    End If
                End With
                If EffectRow > 0 Then
                    Me.MySQLParser.CommitTran()
                Else
                    Me.MySQLParser.RollbackTran()
                End If
            Catch ex As Exception
                EffectRow = -1
                Me.MySQLParser.RollbackTran()
            Finally
                Me.MySQLParser.CloseConnection()
            End Try
            Return EffectRow
        End Function
#End Region

    End Class
End Namespace


@


1.1.1.1
log
@no message
@
text
@@
