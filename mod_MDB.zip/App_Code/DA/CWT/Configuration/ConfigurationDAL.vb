head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic
Imports System.Collections.Generic

Namespace DataAccessLayer
    Public Class ConfigurationDAL
        Inherits BaseDA

        Public Function GetRegion(ByVal IsInCity As Boolean, Optional ByVal FilterOutList As String = "") As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = Util.StandardDB("tblRegion")
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    If IsInCity Then
                        .Add("RegionCode", "(select RegionCode from " + Util.StandardDB("tblCity") + ")", SqlBuilder.SQLParserDataType.spFunction, True, "in")
                    End If
                    If FilterOutList <> "" Then .Add("RegionCode", "(" + FilterOutList + ")", SqlBuilder.SQLParserDataType.spFunction, True, "not in")
                    .Add("*")
                End With
                dt = .ExecuteDataTable(.SQLSelect + " order by Description")
            End With
            Return dt
        End Function

        Public Function GetCountry(ByVal IsInCity As Boolean) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = Util.StandardDB("tblCountry")
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    If IsInCity Then
                        .Add("CountryCode", "(select CountryCode from " + Util.StandardDB("tblCity") + ")", SqlBuilder.SQLParserDataType.spFunction, True, "in")
                    End If
                    .Add("*")
                End With
                dt = .ExecuteDataTable(.SQLSelect + " order by CountryName")
            End With
            Return dt
        End Function

        Public Function GetCountry() As DataTable
            Return Me.GetCountry(True)
        End Function

        Public Function GetCountryByCity(ByVal CityCode As String) As String
            Dim retVal As String
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = Util.StandardDB("tblCity")
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("CityCode", CityCode, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("CountryCode")
                End With
                retVal = .ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar)
            End With
            Return retVal
        End Function

        Public Function GetCountryByRegion(ByVal RegionCode As String, Optional ByVal FilterOutList As String = "") As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = Util.StandardDB("tblCountry")
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("CountryCode", "(select CountryCode from " + Util.StandardDB("tblCity") + " WHERE RegionCode=" + Util.LimitTheString(RegionCode) + ")", SqlBuilder.SQLParserDataType.spFunction, True, "in")
                    If FilterOutList <> "" Then .Add("CountryCode", "(" + FilterOutList + ")", SqlBuilder.SQLParserDataType.spFunction, True, "not in")
                    .Add("*")
                End With
                dt = .ExecuteDataTable(.SQLSelect + " order by CountryName")
            End With
            Return dt
        End Function

        Public Function GetCity(ByVal CountryCode As String, ByVal FilterOutList As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = Util.StandardDB("tblCity")
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("CountryCode", CountryCode, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("countrycode", "NULL", SqlBuilder.SQLParserDataType.spFunction, True, "is not")
                    .Add("regioncode", "NULL", SqlBuilder.SQLParserDataType.spFunction, True, "is not")
                    If FilterOutList <> "" Then .Add("CityCode", "(" + FilterOutList + ")", SqlBuilder.SQLParserDataType.spFunction, True, "not in")
                    .Add("*")
                End With
                dt = .ExecuteDataTable(.SQLSelect + " order by City")
            End With
            Return dt
        End Function

        Public Function GetCurrency() As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = Util.StandardDB("tblCurrency")
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("*")
                End With
                dt = .ExecuteDataTable(.SQLSelect + " order by CurrencyName")
            End With
            Return dt
        End Function

        Public Function GetGDS() As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = Util.StandardDB("tblGDS")
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("*")
                End With
                dt = .ExecuteDataTable(.SQLSelect + " order by GDSName")
            End With
            Return dt
        End Function

        Public Function IsExistName(ByVal Name As String, ByVal ID As String) As Boolean
            Dim EffectRow As Integer
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblConfiguration"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("ConfigurationDesc", Name, SqlBuilder.SQLParserDataType.spText, True)
                    If ID <> "" Then .Add("ConfigurationID", ID, SqlBuilder.SQLParserDataType.spText, True, "<>")
                    .Add("Count(*) as NumRec")
                End With
                EffectRow = .ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar)
            End With
            Return (EffectRow > 0)
        End Function

        Public Function GetRegionByID(ByVal ItemID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = Util.StandardDB("tblCity") + " a"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("RegionCode", ItemID, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("a.countrycode", "NULL", SqlBuilder.SQLParserDataType.spFunction, True, "is not")
                    .Add("a.regioncode", "NULL", SqlBuilder.SQLParserDataType.spFunction, True, "is not")
                    .Add("DISTINCT RegionCode")
                    .Add("(select top 1 Description from " + Util.StandardDB("tblRegion") + " where regioncode=a.regioncode) as RegionName")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetCountryByID(ByVal ItemID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = Util.StandardDB("tblCity") + " a"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("CountryCode", ItemID, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("a.countrycode", "NULL", SqlBuilder.SQLParserDataType.spFunction, True, "is not")
                    .Add("a.regioncode", "NULL", SqlBuilder.SQLParserDataType.spFunction, True, "is not")
                    .Add("DISTINCT RegionCode")
                    .Add("CountryCode")
                    .Add("(select top 1 countryname from " + Util.StandardDB("tblCountry") + " where countrycode=a.countrycode) as CountryName")
                    .Add("(select top 1 Description from " + Util.StandardDB("tblRegion") + " where regioncode=a.regioncode) as RegionName")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetCityByID(ByVal ItemID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = Util.StandardDB("tblCity") + " a"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("CityCode", ItemID, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("a.countrycode", "NULL", SqlBuilder.SQLParserDataType.spFunction, True, "is not")
                    .Add("a.regioncode", "NULL", SqlBuilder.SQLParserDataType.spFunction, True, "is not")
                    .Add("DISTINCT RegionCode")
                    .Add("CountryCode")
                    .Add("CityCode")
                    .Add("City")
                    .Add("(select top 1 countryname from " + Util.StandardDB("tblCountry") + " where countrycode=a.countrycode) as CountryName")
                    .Add("(select top 1 Description from " + Util.StandardDB("tblRegion") + " where regioncode=a.regioncode) as RegionName")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetConfigurationData() As DataTable
            Dim oDataTable As DataTable
            Dim query As New StringBuilder
            query.Append(" select *")
            query.Append(" from tblConfiguration")
            With Me.MySQLParser
                oDataTable = .ExecuteDataTable(query.ToString())
            End With
            Return oDataTable
        End Function
        Public Function GetConfigurationByConfigurationID(ByVal ConfigurationID As Integer) As DataTable
            Dim oDataTable As DataTable
            Dim query As New StringBuilder
            query.Append(" select *")
            query.Append(" from tblConfiguration")
            query.Append(" where(ConfigurationID = " + ConfigurationID.ToString() + ")")

            With Me.MySQLParser
                oDataTable = .ExecuteDataTable(query.ToString())
            End With
            Return oDataTable
        End Function
        Public Function UpdateConfigurationByConfigurationID(ByVal ConfigurationID As Integer, ByVal ConfigurationDesc As String, ByVal GDS As String _
, ByVal BookingPCC As String, ByVal ProfilePCC As String, ByVal FarePCC As String, ByVal Currency As String, ByVal CityCode As String, ByVal TicketPCC As String _
, ByVal TicketAddress As String, ByVal ItinPCC As String, ByVal ItinAddress As String, ByVal ItinDYO As String, ByVal InvPCC As String, ByVal InvAddress As String, ByVal InvDYO As String _
, ByVal MirPCC As String, ByVal MirAddress As String, ByVal DecimalPlc As String) As Integer
            Dim EffectRow As Integer
            With Me.MySQLParser
                .TableName = "tblConfiguration"
                With .Columns
                    .Clear()
                    .IncludeKey = False
                    .Add("ConfigurationID", ConfigurationID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("ConfigurationDesc", ConfigurationDesc)
                    .Add("GDS", GDS)
                    .Add("BookingPCC", BookingPCC)
                    .Add("ProfilePCC", ProfilePCC)
                    .Add("FarePCC", FarePCC)
                    '.Add("Currency", Currency)
                    .Add("CityCode", CityCode)
                    .Add("TicketPCC", TicketPCC)
                    .Add("TicketAddress", TicketAddress)
                    .Add("ItinPCC", ItinPCC)
                    .Add("ItinAddress", ItinAddress)
                    .Add("ItinDYO", ItinDYO)
                    .Add("InvPCC", InvPCC)
                    .Add("InvAddress", InvAddress)
                    .Add("InvDYO", InvDYO)
                    .Add("MirPCC", MirPCC)
                    .Add("MIRAddress", MirAddress)
                    '.Add("DecimalPlc", DecimalPlc, SqlBuilder.SQLParserDataType.spNum)
                End With

                EffectRow = .ExecuteUpdate()
            End With
            Return EffectRow
        End Function
        Public Function DeleteConfigurationByConfigurationID(ByVal ConfigurationID As Integer) As Integer
            Dim EffectRow As Integer
            With Me.MySQLParser
                .TableName = "tblConfiguration"
                With .Columns
                    .Clear()
                    .Add("ConfigurationID", ConfigurationID, SqlBuilder.SQLParserDataType.spNum, True)
                End With
                EffectRow = .ExecuteDelete()
            End With
            Return EffectRow
        End Function
        Public Function InsertConfiguration(ByVal ConfigurationDesc As String, ByVal GDS As String _
, ByVal BookingPCC As String, ByVal ProfilePCC As String, ByVal FarePCC As String, ByVal Currency As String, ByVal CityCode As String, ByVal TicketPCC As String _
, ByVal TicketAddress As String, ByVal ItinPCC As String, ByVal ItinAddress As String, ByVal ItinDYO As String, ByVal InvPCC As String, ByVal InvAddress As String, ByVal InvDYO As String _
, ByVal MirPCC As String, ByVal MirAddress As String, ByVal DecimalPlc As String) As Integer
            Dim EffectRow As Integer
            With Me.MySQLParser
                .TableName = "tblConfiguration"
                With .Columns
                    .Clear()
                    .Add("ConfigurationDesc", ConfigurationDesc)
                    .Add("GDS", GDS)
                    .Add("BookingPCC", BookingPCC)
                    .Add("ProfilePCC", ProfilePCC)
                    .Add("FarePCC", FarePCC)
                    '.Add("Currency", Currency)
                    .Add("CityCode", CityCode)
                    .Add("TicketPCC", TicketPCC)
                    .Add("TicketAddress", TicketAddress)
                    .Add("ItinPCC", ItinPCC)
                    .Add("ItinAddress", ItinAddress)
                    .Add("ItinDYO", ItinDYO)
                    .Add("InvPCC", InvPCC)
                    .Add("InvAddress", InvAddress)
                    .Add("InvDYO", InvDYO)
                    .Add("MirPCC", MirPCC)
                    .Add("MIRAddress", MirAddress)
                    '.Add("DecimalPlc", DecimalPlc, SqlBuilder.SQLParserDataType.spNum)
                End With
                EffectRow = .ExecuteInsert()
            End With
            Return EffectRow
        End Function

    End Class
End Namespace

@


1.1.1.1
log
@no message
@
text
@@
