head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic
Imports System.Collections.Generic

Namespace DataAccessLayer
    Public Class LineDefDAL
        Inherits BaseDA

        Public Function GetGDSList() As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = Util.StandardDB("tblGDS")
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetLineDefList(ByVal LineDefName As String, ByVal GDS As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = Util.StandardDB("tblCSP_LineDefMaster") + " d " + _
                             "inner join (select MAX(VersionNumber) as VersionNumber,LineDefMasterID from " + Util.StandardDB("tblCSP_LineDefVersion") + " group by LineDefMasterID) f on d.LineDefMasterID=f.LineDefMasterID " + _
                             "inner join " + Util.StandardDB("tblCSP_LineDefVersion") + " v on f.LineDefMasterID=v.LineDefMasterID and f.VersionNumber=v.VersionNumber"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    If LineDefName <> "" Then .Add("d.LineDefName", "%" + LineDefName + "%", SqlBuilder.SQLParserDataType.spText, True, "LIKE")
                    .Add("d.*")
                    .Add("v.VersionNumber")
                    .Add("v.Active")
                End With
                dt = .ExecuteDataTable(.SQLSelect + " order by d.LineDefMasterID")
            End With
            Return dt
        End Function

        Public Function GetDataTypeList() As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = Util.StandardDB("tblCSP_SchemaType")
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetDataCategoryList(ByVal TypeID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = Util.StandardDB("tblCSP_SchemaCategory")
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("SchemaTypeID", TypeID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetDataSchemaList(ByVal CatID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = Util.StandardDB("tblCSP_Schema")
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("SchemaCatID", CatID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetCommandList() As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = Util.StandardDB("tblCSP_DataType")
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetLineNumber() As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = Util.StandardDB("tblCSP_LineDefTemplate")
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetLineDefByID(ByVal MasterID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = Util.StandardDB("tblCSP_LineDefMaster") + " d inner join " + Util.StandardDB("tblCSP_LineDefVersion") + " v on d.LineDefMasterID=v.LineDefMasterID"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("d.LineDefMasterID", MasterID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("d.*")
                    .Add("v.LineDefVersionID")
                    .Add("v.VersionNumber")
                    .Add("v.AlertEmail")
                    .Add("v.Active")
                End With
                dt = .ExecuteDataTable(.SQLSelect + " order by VersionNumber DESC")
            End With
            Return dt
        End Function

        Public Function GetLienDefDetailByID(ByVal MasterID As String, ByVal PageIndex As String) As DataTable
            Dim dt As DataTable
            Dim oSql As String = ""
            oSql = "exec " + Util.StandardDB("sp_CSP_GetLineDefDetail") + " " + MasterID + "," + PageIndex
            With Me.MySQLParser
                dt = .ExecuteDataTable(oSql)
            End With
            Return dt
        End Function

        Public Function UpdateLineDefMaster(ByVal info As DataInfo.LineDefInfo) As Integer
            Dim EffectRow As Integer
            Dim VersionNo As String = ""
            Try
                With Me.MySQLParser
                    .OpenConnection()
                    .BeginTran()
                    If info.PageMode = Global.TransactionMode.AddNewMode Then
                        .TableName = Util.StandardDB("tblCSP_LineDefMaster")
                        With .Columns
                            .Clear()
                            .Add("GDSNumber", info.GDS)
                            .Add("LineDefName", info.LineDefName)
                        End With
                        EffectRow = .ExecuteInsert()
                        info.MasterID = .GetLastIdentity
                        VersionNo = .GetNextRunning("LineDefVersionNo", info.MasterID)
                    Else
                        VersionNo = info.VersionNumber
                    End If
                    '//
                    .TableName = Util.StandardDB("tblCSP_LineDefVersion")
                    With .Columns
                        .Clear()
                        .Add("LineDefMasterID", info.MasterID, SqlBuilder.SQLParserDataType.spNum, (info.PageMode = Global.TransactionMode.UpdateMode))
                        .Add("VersionNumber", VersionNo, SqlBuilder.SQLParserDataType.spNum, (info.PageMode = Global.TransactionMode.UpdateMode))
                        .Add("AlertEmail", info.AlertEmail)
                        .Add("Active", info.Active, SqlBuilder.SQLParserDataType.spBoolean)
                        .Add("UpdatedBy", info.UserID)
                        .Add("UpdatedDate", "getdate()", SqlBuilder.SQLParserDataType.spFunction)
                    End With
                    If info.PageMode = Global.TransactionMode.AddNewMode Then
                        EffectRow = .ExecuteInsert()
                    Else
                        EffectRow = .ExecuteUpdate()
                    End If
                    '//
                End With
                If EffectRow > 0 Then
                    Me.MySQLParser.CommitTran()
                Else
                    Me.MySQLParser.RollbackTran()
                End If
            Catch ex As Exception
                EffectRow = -1
                Me.MySQLParser.RollbackTran()
            Finally
                Me.MySQLParser.CloseConnection()
            End Try
            Return EffectRow
        End Function

        Public Function UpdateLineDetail(ByVal info As DataInfo.LineDefInfo) As Integer
            Dim EffectRow As Integer = 1
            Dim StRecord As Integer
            Dim EndRecord As Integer
            Try
                With Me.MySQLParser
                    .OpenConnection()
                    .BeginTran()
                    .TableName = Util.StandardDB("tblCSP_LineDef")
                    '//
                    StRecord = ((info.CurrentPage - 1) * 40) + 1
                    EndRecord = StRecord + 39
                    '//
                    With .Columns
                        .Clear()
                        .Add("LineNumber", StRecord.ToString, SqlBuilder.SQLParserDataType.spFunction, True, ">=")
                        .Add("LineNumber", EndRecord.ToString, SqlBuilder.SQLParserDataType.spFunction, True, "<=")
                        .Add("LineDefVersionID", info.VersionID, SqlBuilder.SQLParserDataType.spNum, True)
                    End With
                    .ExecuteDelete()
                    For i As Integer = 0 To info.Lines.Count - 1
                        With .Columns
                            .Clear()
                            '.Add("LineDefVersionID", info.VersionID, SqlBuilder.SQLParserDataType.spNum, IsUpdate)
                            .Add("LineDefVersionID", info.VersionID, SqlBuilder.SQLParserDataType.spNum)
                            .Add("LineNumber", info.Lines(i).LineNumber, SqlBuilder.SQLParserDataType.spNum)
                            .Add("MoveType", info.Lines(i).MoveType)
                            .Add("SecondaryInd", info.Lines(i).SecondInd)
                            .Add("TertiaryInd", info.Lines(i).ThirdInd)
                            .Add("DataTypeValue", info.Lines(i).Command)
                            .Add("Qualifier", info.Lines(i).Qualifier)
                            .Add("FormatString", info.Lines(i).FormatString)
                            .Add("Remark", info.Lines(i).Remark)
                        End With
                        EffectRow = .ExecuteInsert()
                        If EffectRow <= 0 Then
                            Exit For
                        End If
                    Next
                End With
                If EffectRow > 0 Then
                    Me.MySQLParser.CommitTran()
                Else
                    Me.MySQLParser.RollbackTran()
                End If
            Catch ex As Exception
                EffectRow = -1
                Me.MySQLParser.RollbackTran()
            Finally
                Me.MySQLParser.CloseConnection()
            End Try
            Return EffectRow
        End Function

        Public Function CreateNewVersion(ByVal MasterID As String, ByVal VersionID As String, ByVal VersionNumber As String, ByVal UserID As String) As Integer
            Dim EffectRow As Integer = 1
            Dim oSql As String = ""
            'Dim OldVersion As String
            Dim NewVersion As String
            Try
                With Me.MySQLParser
                    .OpenConnection()
                    .BeginTran()
                    '// Get Lastest Version
                    'oSql = "select MAX(VersionNumber) from " + Util.StandardDB("tblCSP_LineDefVersion") + " where LineDefMasterID=" + MasterID
                    'OldVersion = .ExecuteCommand(oSql, SqlBuilder.SQLParserExecuteType.ExecuteScalar)
                    '// Make running
                    NewVersion = .GetNextRunning("LineDefVersionNo", MasterID)
                    '// Cloning
                    oSql = "exec " + Util.StandardDB("sp_CSP_CreateNewVersion") + " " + MasterID + "," _
                           + VersionID + "," _
                           + VersionNumber + "," _
                           + NewVersion + "," _
                           + Util.LimitTheString(UserID)
                    .ExecuteCommand(oSql, SqlBuilder.SQLParserExecuteType.ExecuteNonQuery)
                End With
                Me.MySQLParser.CommitTran()
            Catch ex As Exception
                EffectRow = -1
                Me.MySQLParser.RollbackTran()
            Finally
                Me.MySQLParser.CloseConnection()
            End Try
            Return EffectRow
        End Function

    End Class
End Namespace


@


1.1.1.1
log
@no message
@
text
@@
