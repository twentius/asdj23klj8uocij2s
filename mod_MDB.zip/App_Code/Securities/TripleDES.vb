head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports System.IO
Imports System.Text
Imports System.Security.Cryptography

Namespace Securities

    Friend Class TripleDES
        ' define the triple des provider
        Private m_des As New TripleDESCryptoServiceProvider
        ' define the string handler
        Private m_utf8 As New UTF8Encoding
        ' define the local property arrays
        Private m_key() As Byte
        Private m_iv() As Byte

        Public Sub New(ByVal key() As Byte, ByVal iv() As Byte)
            Me.m_key = key
            Me.m_iv = iv
        End Sub

        Public Function Encrypt(ByVal input() As Byte) As Byte()
            Return Transform(input, m_des.CreateEncryptor(m_key, m_iv))
        End Function

        Public Function Decrypt(ByVal input() As Byte) As Byte()
            Return Transform(input, m_des.CreateDecryptor(m_key, m_iv))
        End Function

        Public Function Encrypt(ByVal text As String) As String
            Dim input() As Byte = m_utf8.GetBytes(text)
            Dim output() As Byte = Transform(input, _
                            m_des.CreateEncryptor(m_key, m_iv))
            Return Convert.ToBase64String(output)
        End Function

        Public Function Decrypt(ByVal text As String) As String
            Dim input() As Byte = Convert.FromBase64String(text)
            Dim output() As Byte = Transform(input, _
                             m_des.CreateDecryptor(m_key, m_iv))
            Return m_utf8.GetString(output)
        End Function

        Private Function Transform(ByVal input() As Byte, _
            ByVal CryptoTransform As ICryptoTransform) As Byte()
            ' create the necessary streams
            Dim memStream As MemoryStream = New MemoryStream
            Dim cryptStream As CryptoStream = New _
                CryptoStream(memStream, CryptoTransform, _
                CryptoStreamMode.Write)
            ' transform the bytes as requested
            cryptStream.Write(input, 0, input.Length)
            cryptStream.FlushFinalBlock()
            ' Read the memory stream and convert it back into byte array
            memStream.Position = 0
            Dim result(CType(memStream.Length - 1, System.Int32)) As Byte
            memStream.Read(result, 0, CType(result.Length, System.Int32))
            ' close and release the streams
            memStream.Close()
            cryptStream.Close()
            ' hand back the encrypted buffer
            Return result
        End Function

    End Class

    Public Class DataEncryption
        Private ReadOnly key() As Byte = _
                                      {1, 5, 3, 5, 5, 5, 7, 5, 9, 5, 11, 5, 13, 5, _
                                      15, 5, 17, 5, 19, 5, 21, 5, 23, 5}
        Private ReadOnly iv() As Byte = {5, 7, 5, 5, 5, 3, 5, 1}

        Private des As New TripleDES(key, iv)


        Public Function EncryptText(ByVal Text As String) As String
            Return Me.des.Encrypt(Text)
        End Function

        Public Function DecryptText(ByVal EncryptedText As String) As String
            Return Me.des.Decrypt(EncryptedText)
        End Function

    End Class

End Namespace

@


1.1.1.1
log
@no message
@
text
@@
