head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic

<Serializable()> _
Public Class BaseDataInfo

    Public PageMode As TransactionMode

    Public Shared ReadOnly TRUE_STATE As String = "Y"
    Public Shared ReadOnly FALSE_STATE As String = "N"

End Class
@


1.1.1.1
log
@no message
@
text
@@
