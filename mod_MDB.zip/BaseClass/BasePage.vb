head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.05.09;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic

Public Class BasePage
    Inherits System.Web.UI.Page

    Protected usrInfo As New CWTCustomControls.CWTPermissionInfo()

    'Public Event ReadPermissionInfo(ByVal sender As Object, ByVal e As System.EventArgs)

    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.PreRender
        '//
        With Me.usrInfo
            .AuthenRequired = False
        End With
        Call Me.SetUserLevel()
        'Call Me.SetControlLevel()
        'RaiseEvent ReadPermissionInfo(sender, e)
    End Sub


    Public Sub SetUserLevel()
        Dim BLL As New BusinessLogicLayer.tblFunctionBLL()
        Dim url As String
        Dim level As CWTCustomControls.UserLevelControl
        If ServiceLogicLayer.ProfilerSLL.CurrentProfile Is Nothing Then
            Response.Redirect(CWTMasterDB.Util.GetAppConfig("RootPath") + "/Login.aspx", True)
        End If
        'url = Me.Request.ServerVariables("SCRIPT_NAME").Replace(CWTMasterDB.Util.GetAppConfig("RootPath"), "")
        url = Util.GetCurrentURL()
        level = BLL.GetUserLevelByUrl(url)
        Me.usrInfo.UserLevel = level
    End Sub

    'Private Sub SetControlLevel()
    '    'Dim c As WebControl
    '    Dim obj As New Object()
    '    obj(0) = CType(Me.usrInfo, Object)
    '    'For Each key As String In Me.ctrlList.Keys
    '    'c = TryCast(Me.ctrlList(key), WebControl)
    '    For Each c As WebControl In Me.Controls
    '        If c IsNot Nothing Then
    '            If c.GetType.Namespace = "CWTCustomControls" Then
    '                Call CallByName(c, "PermissionInfo", CallType.Set, obj)
    '            End If
    '        End If
    '    Next
    'End Sub

    Public Property CurrentPageMode() As TransactionMode
        Get
            Dim retVal As TransactionMode
            If Me.ViewState("_CurrentPageMode") IsNot Nothing Then
                retVal = Me.ViewState("_CurrentPageMode")
            End If
            Return retVal
        End Get
        Set(ByVal value As TransactionMode)
            Me.ViewState("_CurrentPageMode") = value
        End Set
    End Property

    Public ReadOnly Property CurrentClientID() As String
        Get
            Dim retVal As String = ""
            If ServiceLogicLayer.CompanySLL.CurrentCompany Is Nothing Then
                Response.Redirect("CompanySearch.aspx", True)
            Else
                retVal = ServiceLogicLayer.CompanySLL.CurrentCompany
            End If
            Return retVal
        End Get
    End Property

End Class












@


1.1.1.1
log
@no message
@
text
@@
