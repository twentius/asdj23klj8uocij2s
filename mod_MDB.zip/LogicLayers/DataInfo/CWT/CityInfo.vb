head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.24;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.24;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic
Imports System.Collections.Generic

Namespace DataInfo
    Public Class CityInfo
        Inherits BaseDataInfo

        Public AirportCode As String
        Public Airport As String
        Public Type As String
        Public City As String
        Public CityCode As String
        Public CountryCode As String
        Public CoTerminal As String
        Public DiffGMT As Integer
        Public CountrySubDivCode As String
        Public RegionCode As String
        Public IATAArea As String
        Public Latitude As Single
        Public Longtitude As Single

    End Class
End Namespace

@


1.1.1.1
log
@no message
@
text
@@
