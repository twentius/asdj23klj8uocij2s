head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.24;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.24;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic

Namespace DataInfo
    Public Class CountryInfo
        Inherits BaseDataInfo

        Public KeyID As String
        Public ConfigurationID As String
        Public Currency As String
        'Public GST As Integer
        Public DecimalPt As Integer
        Public RoundUnit As Integer
        Public DefaultTkAll As Boolean = False
        Public DefaultTktTicket As Boolean = False
        Public DefaultTktItin As Boolean = False
        Public DefaultTktInv As Boolean = False
        Public DefaultTktMir As Boolean = False

    End Class
End Namespace

@


1.1.1.1
log
@no message
@
text
@@
