head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.24;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.24;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic
Imports System.Collections.Generic

Namespace DataInfo
    <Serializable()> _
    Public Class PriceFormulaInfo

        Public AirCom As String
        Public MarkUp As String
        Public Discount As String
        Public GST As String
        Public ORCommission As String
        Public OrCommission2 As String
        'Public ManagementFee As String
        Public Fare As String
        Public NetFare As String
        Public Fee As String
        Public MFFee As String
        Public MFFeeTF As String
        Public SellingFare As String
        Public Charge As String
        Public DDLFeeApply As String
        'Public ApplyFee As Boolean
        Public ApplyMarkUp As Boolean
        Public MgtFeeApply As Boolean
        Public FuelChargeOption As String

        Public UsageList As List(Of String)

        Public Sub New()
            UsageList = New List(Of String)
        End Sub

    End Class

    <Serializable()> _
    Public Class AirPriceInfo
        Inherits BaseDataInfo

        Public [ID] As String
        Public Name As String
        Public DomSameAsInt As Boolean
        Public LCCSameAsInt As Boolean
        Public IntFomula As PriceFormulaInfo
        Public DomFomula As PriceFormulaInfo
        Public LCCFomula As PriceFormulaInfo

    End Class
End Namespace

@


1.1.1.1
log
@no message
@
text
@@
