head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.24;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.24;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic

Namespace DataInfo

    <Serializable()> _
    Public Class DivisionInfo
        Inherits BaseDataInfo

        Public [ID] As String
        'Public Country As String
        'Public Number As String
        Public Name As String
        'Public Phone As String
        'Public Fax As String
        'Public Mobile As String
        'Public Email As String
        Public Status As Boolean

    End Class

    <Serializable()> _
    Public Class AgentInfo
        Inherits BaseDataInfo

        ' Public AgentID As String

        Public Country As String
        '//
        Public Title As String
        Public FirstName As String
        Public LastName As String
        Public UserName As String
        Public Email As String
        Public BizPhoneCode As String
        Public BizPhoneNo As String
        '//
        Public Phone As String
        Public AltPhone As String
        Public Mobile As String

        Public SignOn As String
        Public BackOfficeCode As String
        Public QueuePCC1 As String
        Public QueuePCC2 As String
        Public QueuePCC3 As String
        Public QueueNo1 As String
        Public QueueNo2 As String
        Public QueueNo3 As String

        '// Linked Properties
        Public DivID As String
        '//
        Public JobTitle As String
        Public Remark As String

        Public Status As Boolean

    End Class
    <Serializable()> _
    Public Class DivisionAgentInfo
        Inherits BaseDataInfo
        Public DivisionID As String
        Public AgentID As String

        Public AgentItem As List(Of AgentInfo)
        Public DivisionItem As List(Of DivisionInfo)


        Public Sub New()
            AgentItem = New List(Of AgentInfo)
            DivisionItem = New List(Of DivisionInfo)
        End Sub
    End Class

End Namespace


@


1.1.1.1
log
@no message
@
text
@@
