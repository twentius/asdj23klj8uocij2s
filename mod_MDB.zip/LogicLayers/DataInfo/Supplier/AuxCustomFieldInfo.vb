head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.24;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.24;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic
Imports System.Collections.Generic

Namespace DataInfo
    <Serializable()> _
    Public Class AuxCustomFieldCmd

        Public DataTypeID As String
        Public Format As String

    End Class

    <Serializable()> _
    Public Class AuxCustomFieldEO

        Public Sequence As Integer
        Public Format As String

    End Class

    <Serializable()> _
    Public Class AuxCustomFieldInfo
        Inherits BaseDataInfo

        Public [ID] As String
        Public [Name] As String
        Public SequenceNumber As Integer
        Public ProductNumber As String
        Public [Type] As String
        Public Location As String
        Public DefaultValue As String
        Public Mandatory As Boolean
        Public DropList As List(Of String)
        Public Command As List(Of AuxCustomFieldCmd)
        Public EO As List(Of AuxCustomFieldEO)

        Public Sub New()
            Me.DropList = New List(Of String)
            Me.Command = New List(Of AuxCustomFieldCmd)
            Me.EO = New List(Of AuxCustomFieldEO)
        End Sub

    End Class
End Namespace
@


1.1.1.1
log
@no message
@
text
@@
