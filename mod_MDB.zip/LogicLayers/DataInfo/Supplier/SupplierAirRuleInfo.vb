head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.24;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.24;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic
Imports System.Collections.Generic

Namespace DataInfo

    

    <Serializable()> _
    Public Class SupplierAirComInfo

        Public OriginType As String
        Public DestinationType As String
        Public Origin As String
        Public Destination As String
        Public FeeType As String
        Public Amount As Double
        Public FareType As String
        Public AirCommID As String

    End Class

    <Serializable()> _
   Public Class ClientTabInfo

        Public TabTypeCL As String
        Public CL_ClientID As Integer
        Public CCType As String
        Public passThrough As String
        Public RemarkID As String
        Public vendorCode As String
        
        ''Diner Card
        'Public DCTypePassThroughUATP_CL As String
        'Public DCCCardUATP_CL As String
        'Public DCRemarkUATP_CL As String
        'Public DCTypePassThroughNRCC_CL As String
        'Public DCCCardNRCC_CL As String
        'Public DCRemarkNRCC_CL As String
        ''AirPlus
        'Public TPTypePassThroughUATP_CL As String
        'Public TPCCardUATP_CL As String
        'Public TPRemarkUATP_CL As String
        'Public TPTypePassThroughNRCC_CL As String
        'Public TPCCardNRCC_CL As String
        'Public TPRemarkNRCC_CL As String
        ''Master Card
        'Public CATypePassThroughUATP_CL As String
        'Public CACCardUATP_CL As String
        'Public CARemarkUATP_CL As String
        'Public CATypePassThroughNRCC_CL As String
        'Public CACCardNRCC_CL As String
        'Public CARemarkNRCC_CL As String
        ''Visa
        'Public VITypePassThroughUATP_CL As String
        'Public VICCardUATP_CL As String
        'Public VIRemarkUATP_CL As String
        'Public VITypePassThroughNRCC_CL As String
        'Public VICCardNRCC_CL As String
        'Public VIRemarkNRCC_CL As String

    End Class

    <Serializable()> _
    Public Class SupplierAirRuleInfo
        Inherits BaseDataInfo

        Public AirlineCode As String
        '// CWT Tab
        Public TabTypeCWT As String
        'Amex
        Public AxTypePassThroughUATP As String
        Public AxCCardUATP As String
        Public AxRemarkUATP As String
        Public AxTypePassThroughNRCC As String
        Public AxCCardNRCC As String
        Public AxRemarkNRCC As String
        'Diner Card
        Public DCTypePassThroughUATP As String
        Public DCCCardUATP As String
        Public DCRemarkUATP As String
        Public DCTypePassThroughNRCC As String
        Public DCCCardNRCC As String
        Public DCRemarkNRCC As String
        'AirPlus
        Public TPTypePassThroughUATP As String
        Public TPCCardUATP As String
        Public TPRemarkUATP As String
        Public TPTypePassThroughNRCC As String
        Public TPCCardNRCC As String
        Public TPRemarkNRCC As String
        'Master Card
        Public CATypePassThroughUATP As String
        Public CACCardUATP As String
        Public CARemarkUATP As String
        Public CATypePassThroughNRCC As String
        Public CACCardNRCC As String
        Public CARemarkNRCC As String
        'Visa
        Public VITypePassThroughUATP As String
        Public VICCardUATP As String
        Public VIRemarkUATP As String
        Public VITypePassThroughNRCC As String
        Public VICCardNRCC As String
        Public VIRemarkNRCC As String

        '//Client Tab
        




        Public SupplierAirCC As SupplierAirCCInfo
        Public Items As List(Of SupplierAirComInfo)
        Public ClientItem As List(Of ClientTabInfo)


        Public Sub New()
            Items = New List(Of SupplierAirComInfo)
            ClientItem = New List(Of ClientTabInfo)
            SupplierAirCC = New SupplierAirCCInfo()
        End Sub

    End Class

    <Serializable()> _
    Public Class SupplierAirCCInfo

        Public PUBFareCards As List(Of String)
        Public SpecialFareCards As List(Of String)
        Public CCCFCards As List(Of String)
        Public FuelCharge As Double
        Public SkipAqua As Boolean
        Public IncludeYQComm As Boolean

        Public Sub New()
            PUBFareCards = New List(Of String)
            SpecialFareCards = New List(Of String)
            CCCFCards = New List(Of String)
        End Sub

    End Class
End Namespace




@


1.1.1.1
log
@no message
@
text
@@
