head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.24;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.24;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic
Imports System.Collections.Generic

Namespace DataInfo
    <Serializable()> _
    Public Class VendorContactMethodInfo

        Public MethodType As String
        Public MethodValue As String
        Public IsPrefer As Boolean

    End Class

    <Serializable()> _
    Public Class SupplierVendorInfo
        Inherits BaseDataInfo

        Public [Name] As String
        Public [Number] As String
        Public InterfaceCode As String
        Public ContractPerson As String
        Public Address As String
        Public PostalCode As String
        Public City As String
        Public State As String
        Public Country As String
        Public VendorType As String
        Public RequireEO As Boolean
        Public RequireAdvance As Boolean
        Public Contacts As List(Of VendorContactMethodInfo)
        Public Products As List(Of String)
        Public HotelFee As Boolean

        Public Sub New()
            Me.Contacts = New List(Of VendorContactMethodInfo)
            Me.Products = New List(Of String)
        End Sub

    End Class
End Namespace

@


1.1.1.1
log
@no message
@
text
@@
