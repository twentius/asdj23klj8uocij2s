head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.24;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.24;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic
Imports System.Collections.Generic

Namespace DataInfo

    <Serializable()> _
    Public Class CompanyAccountingInfo
        Inherits BaseDataInfo

        Public ClientID As String
        Public AccNoBiz As String
        Public AccNoLeisure As String
        Public AccNoMice As String
        Public DivNo As String
        Public FieldName1 As String
        Public FieldValue1 As String
        Public FieldName2 As String
        Public FieldValue2 As String
        Public FieldName3 As String
        Public FieldValue3 As String
        Public FieldName4 As String
        Public FieldValue4 As String
        Public FieldName5 As String
        Public FieldValue5 As String
        Public PreferedAccType As AccountType = AccountType.Business

        Public Enum AccountType
            Business
            Leisure
            MICE
        End Enum

    End Class

End Namespace
@


1.1.1.1
log
@no message
@
text
@@
