head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.24;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.24;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic
Imports System.Collections.Generic

Namespace DataInfo

    <Serializable()> _
    Public Class CreditCardInfo

        Public Vendor As String
        Public MFFee As Double

    End Class

    <Serializable()> _
    Public Class BankCardInfo

        Public CCnumber As String
        Public MFFee As Double

    End Class

    <Serializable()> _
    Public Class ProductMFInfo

        Public ProductCode As String
        Public SubjectToMF As Boolean

    End Class

    <Serializable()> _
    Public Class CompanyMFInfo
        Inherits BaseDataInfo

        Public ClientID As String
        Public ApplyStdCC As Boolean
        Public ApplyStdBank As Boolean
        Public ApplyStdProduct As Boolean
        Public CreditCards As List(Of CreditCardInfo)
        Public BankCards As List(Of BankCardInfo)
        Public ProductMF As List(Of ProductMFInfo)

        Public Sub New()
            Me.CreditCards = New List(Of CreditCardInfo)
            Me.BankCards = New List(Of BankCardInfo)
            Me.ProductMF = New List(Of ProductMFInfo)
        End Sub

    End Class


End Namespace



@


1.1.1.1
log
@no message
@
text
@@
