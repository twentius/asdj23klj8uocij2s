head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.24;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.24;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic
Imports System.Collections.Generic

Namespace DataInfo
    <Serializable()> _
    Public Class PaymentCardInfo

        Public Vendor As String
        Public Number As String
        Public ExpiryDate As String
        Public PrefAir As Boolean
        Public PrefHotel As Boolean
        Public PrefCar As Boolean

    End Class

    <Serializable()> _
    Public Class AirIntDataInfo

        Public CCVendor As String
        Public CCNum As String
        Public Name As String
        Public ExpiryDate As String

    End Class

    <Serializable()> _
    Public Class AirDomDataInfo

        Public CCVendor As String
        Public CCNum As String
        Public Name As String
        Public ExpiryDate As String

    End Class

    <Serializable()> _
    Public Class AirLccDataInfo

        Public CCVendor As String
        Public CCNum As String
        Public Name As String
        Public ExpiryDate As String

    End Class

    <Serializable()> _
    Public Class HotelDataInfo

        Public CCVendor As String
        Public CCNum As String
        Public Name As String
        Public ExpiryDate As String

    End Class

    <Serializable()> _
   Public Class CarDataInfo

        Public CCVendor As String
        Public CCNum As String
        Public Name As String
        Public ExpiryDate As String

    End Class

    <Serializable()> _
    Public Class AuxDataInfo

        Public CCVendor As String
        Public CCNum As String
        Public Name As String
        Public ExpiryDate As String

    End Class

    <Serializable()> _
    Public Class CompanyPayCardInfo
        Inherits BaseDataInfo

        Public ClientID As String
        Public AirIntPayMode As String
        Public AirDomPayMode As String
        Public AirLccPayMode As String
        Public HotelPayMode As String
        Public CarPayMode As String
        Public AuxPayMode As String
        Public PayMode As PaymentMode
        Public CardList As List(Of PaymentCardInfo)
        Public AirIntList As New List(Of AirIntDataInfo)
        Public AirDomList As New List(Of AirDomDataInfo)
        Public AirLccList As New List(Of AirLccDataInfo)
        Public HotelList As New List(Of HotelDataInfo)
        Public CarList As New List(Of CarDataInfo)
        Public AuxList As New List(Of AuxDataInfo)
        Public ReferToProfile As Boolean

        Public Enum PaymentMode
            Invoice = 0
            CreditCard = 1
        End Enum

        Public Sub New()
            Me.CardList = New List(Of PaymentCardInfo)

            Me.ReferToProfile = False
        End Sub


    End Class
End Namespace


@


1.1.1.1
log
@no message
@
text
@@
