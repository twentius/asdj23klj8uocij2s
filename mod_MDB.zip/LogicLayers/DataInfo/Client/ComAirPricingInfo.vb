head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.24;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.24;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic
Imports System.Collections.Generic
Imports System.IO
Imports System.Runtime.Serialization.Formatters.Binary

Namespace DataInfo
    <Serializable()> _
    Public Class PriceVariablesInfo

        Public FieldID As String
        Public FieldName As String
        Public FieldValue As String
        Public TripType As String
        Public Override As Boolean

    End Class

    <Serializable()> _
    Public Class FeeVariablesInfo
        Inherits PriceVariablesInfo

        Public FeeName As String
        Public FeeType As String

    End Class

    <Serializable()> _
    Public Class AddOnVariablesInfo
        Inherits PriceVariablesInfo

        Public FeeName As String

        Public ReadOnly Property FeeType()
            Get
                Return "A"
            End Get
        End Property

    End Class

    <Serializable()> _
    Public Class ComAirPricingSettingsInfo
        Implements System.ICloneable

        Public HaveFee As Boolean
        Public HaveAddOn As Boolean
        Public Variables As List(Of PriceVariablesInfo)
        Public Fee As FeeVariablesInfo
        Public AddOn As AddOnVariablesInfo

        Public Sub New()
            Me.Variables = New List(Of PriceVariablesInfo)
            Me.Fee = New FeeVariablesInfo()
            Me.AddOn = New AddOnVariablesInfo()
        End Sub

        Public Function ToVariablesTable() As DataTable
            Dim dt As New DataTable()
            Dim dr As DataRow
            With dt
                .Columns.Add(New DataColumn("FieldID"))
                .Columns.Add(New DataColumn("Value"))
                .Columns.Add(New DataColumn("FieldName"))
                .Columns.Add(New DataColumn("Override", GetType(Boolean)))
                For i As Integer = 0 To Me.Variables.Count - 1
                    dr = .NewRow()
                    dr("FieldID") = Me.Variables(i).FieldID
                    dr("Value") = Me.Variables(i).FieldValue
                    dr("FieldName") = Me.Variables(i).FieldName
                    dr("Override") = Me.Variables(i).Override
                    .Rows.Add(dr)
                Next
            End With
            Return dt
        End Function

        Public Function ShallowClone() As Object Implements System.ICloneable.Clone
            Return Me.MemberwiseClone()
        End Function

        Public Function DeepClone() As ComAirPricingSettingsInfo
            ' Create a "deep" clone of 
            ' an object. That is, copy not only 
            ' the object and its pointers
            ' to other objects, but create 
            ' copies of all the subsidiary 
            ' objects as well. This code even 
            ' handles recursive relationships.

            Dim ms As New MemoryStream()
            Dim objResult As ComAirPricingSettingsInfo = Nothing

            Try
                Dim bf As New BinaryFormatter()
                bf.Serialize(ms, Me)

                ' Rewind back to the beginning 
                ' of the memory stream. 
                ' Deserialize the data, then
                ' close the memory stream.
                ms.Position = 0
                objResult = bf.Deserialize(ms)
            Finally
                ms.Close()
            End Try
            Return objResult
        End Function

    End Class

    <Serializable()> _
    Public Class ComAirPricingInfo
        Inherits BaseDataInfo

        Public ClientID As String
        Public CMPID As String
        Public [ID] As String
        Public ExemptGovTax As Boolean

        Public IntSetting As ComAirPricingSettingsInfo
        Public DomSetting As ComAirPricingSettingsInfo
        Public LccSetting As ComAirPricingSettingsInfo

        Public Sub New()
            Me.IntSetting = New ComAirPricingSettingsInfo()
            Me.DomSetting = New ComAirPricingSettingsInfo()
            Me.LccSetting = New ComAirPricingSettingsInfo()
        End Sub

    End Class
End Namespace
@


1.1.1.1
log
@no message
@
text
@@
