head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.24;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.24;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic
Imports System.Collections.Generic

Namespace DataInfo

    <Serializable()> _
    Public Class BaseItemClassInfo

        Public TravellerType As String
        Public PreferredClass As String
        Public Remark As String

    End Class

    <Serializable()> _
    Public Class AirClassInfo
        Inherits BaseItemClassInfo

        Public StFlyTime As String
        Public EndFlyTime As String
        Public TimeOperator As String

    End Class

    <Serializable()> _
    Public Class TAInfo
        Inherits BaseItemClassInfo

        Public RequiredTA As Boolean

    End Class

    <Serializable()> _
    Public Class CompanyPolicyInfo
        Inherits BaseDataInfo

        Public ClientID As String
        Public CurrentWebMode As WebMode
        Public PolicyLines As List(Of String)
        Public AirClassList As List(Of AirClassInfo)
        Public HotelClassList As List(Of BaseItemClassInfo)
        Public CarClassList As List(Of BaseItemClassInfo)
        Public TAList As List(Of TAInfo)

        Public Enum MathOperator
            lt
            lteq
            eq
            Between
            gteq
            gt
        End Enum

        Public Enum WebMode
            PolicyLine
            ClassPolicy
        End Enum

        Public Sub New()
            Me.PolicyLines = New List(Of String)
            Me.HotelClassList = New List(Of BaseItemClassInfo)
            Me.CarClassList = New List(Of BaseItemClassInfo)
            Me.AirClassList = New List(Of AirClassInfo)
            Me.TAList = New List(Of TAInfo)
        End Sub

    End Class

End Namespace
@


1.1.1.1
log
@no message
@
text
@@
