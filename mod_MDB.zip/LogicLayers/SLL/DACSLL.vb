head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.24;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.24;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic
Imports System.Collections.Generic

Namespace ServiceLogicLayer

    <Serializable()> _
    Public Class DACSLL

        Public Shared Sub SetConfigKeyID(ByVal KeyID As String)
            ProfilerSLL.CurrentRuntimePage.Session("keyid") = KeyID
        End Sub

        Public Shared Sub SetConnection(ByVal svr As String, ByVal db As String, ByVal usr As String, ByVal pwd As String)
            ProfilerSLL.CurrentRuntimePage.Session("cn") = CWTMasterDB.Util.CreateConnection(svr, db, usr, pwd)
            ProfilerSLL.CurrentRuntimePage.Session("svr") = svr
        End Sub

        Public Shared ReadOnly Property ConnectionString() As String
            Get
                Dim retVal As String = ""
                retVal = CWTMasterDB.Util.DBNullToText(ProfilerSLL.CurrentRuntimePage.Session("cn"))
                Return retVal
            End Get
        End Property

        Public Shared ReadOnly Property CurrentKeyID() As String
            Get
                Dim retVal As String = ""
                retVal = CWTMasterDB.Util.DBNullToText(ProfilerSLL.CurrentRuntimePage.Session("keyid"))
                Return retVal
            End Get
        End Property

        Public Shared ReadOnly Property CurrentServer() As String
            Get
                Dim retVal As String = ""
                retVal = CWTMasterDB.Util.DBNullToText(ProfilerSLL.CurrentRuntimePage.Session("svr"))
                Return retVal
            End Get
        End Property

    End Class

End Namespace


@


1.1.1.1
log
@no message
@
text
@@
