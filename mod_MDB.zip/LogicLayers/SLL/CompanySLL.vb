head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.24;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.24;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic
Imports System.Collections.Generic

Namespace ServiceLogicLayer

    <Serializable()> _
    Public Class CompanySLL

        Public Shared Sub SetCurrentCompany(ByVal CompanyID As String)
            ProfilerSLL.CurrentRuntimePage.Session("CurrentCompany") = CompanyID
        End Sub

        Public Shared ReadOnly Property CurrentCompany() As String
            Get
                Dim retVal As String = ""
                retVal = CWTMasterDB.Util.DBNullToText(ProfilerSLL.CurrentRuntimePage.Session("CurrentCompany"))
                Return retVal
            End Get
        End Property

    End Class

End Namespace



@


1.1.1.1
log
@no message
@
text
@@
