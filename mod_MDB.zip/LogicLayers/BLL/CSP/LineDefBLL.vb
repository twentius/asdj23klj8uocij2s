head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.20;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.20;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic

Namespace BusinessLogicLayer
    Public Class LineDefBLL

        Private DataAccess As DataAccessLayer.LineDefDAL

        Public Sub New()
            Me.DataAccess = New DataAccessLayer.LineDefDAL()
        End Sub

        Public Function GetGDSList() As DataTable
            Return Me.DataAccess.GetGDSList()
        End Function

        Public Function GetLineDefList(ByVal LineDefName As String, ByVal GDS As String) As DataTable
            Return Me.DataAccess.GetLineDefList(LineDefName, GDS)
        End Function

        Public Function GetLineDefByID(ByVal MasterID As String) As DataTable
            Return Me.DataAccess.GetLineDefByID(MasterID)
        End Function

        Public Function GetLienDefDetailByID(ByVal MasterID As String, ByVal PageIndex As String) As DataTable
            Return Me.DataAccess.GetLienDefDetailByID(MasterID, PageIndex)
        End Function

        Public Function GetDataTypeList() As DataTable
            Return Me.DataAccess.GetDataTypeList()
        End Function

        Public Function GetDataCategoryList(ByVal TypeID As String) As DataTable
            Return Me.DataAccess.GetDataCategoryList(TypeID)
        End Function

        Public Function GetDataSchemaList(ByVal CatID As String) As DataTable
            Return Me.DataAccess.GetDataSchemaList(CatID)
        End Function

        Public Function GetCommandList() As DataTable
            Return Me.DataAccess.GetCommandList()
        End Function

        Public Function GetLineNumber() As DataTable
            Return Me.DataAccess.GetLineNumber()
        End Function

        Public Function UpdateLineDefMaster(ByVal info As DataInfo.LineDefInfo) As Integer
            Return Me.DataAccess.UpdateLineDefMaster(info)
        End Function

        Public Function UpdateLineDetail(ByVal info As DataInfo.LineDefInfo) As Integer
            Return Me.DataAccess.UpdateLineDetail(info)
        End Function

        Public Function CreateNewVersion(ByVal MasterID As String, ByVal VersionID As String, ByVal VersionNumber As String, ByVal UserID As String) As Integer
            Return Me.DataAccess.CreateNewVersion(MasterID, VersionID, VersionNumber, UserID)
        End Function

        Public Function GetLineDefMasterList() As DataTable
            Return Me.DataAccess.GetLineDefMasterList()
        End Function

        Public Function GetGDSMappingByClientID(ByVal KeyID As String, ByVal ClientID As String) As DataTable
            Return Me.DataAccess.GetGDSMappingByClientID(KeyID, ClientID)
        End Function

        Public Function UpdateGDSMapping(ByVal info As DataInfo.GDSMappingClientInfo) As Integer
            Return Me.DataAccess.UpdateGDSMapping(info)
        End Function
        Public Function CheckDuplicate(ByVal profilePCC As String, ByVal profileName As String, ByVal configID As Integer) As DataTable
            Return Me.DataAccess.CheckDuplicate(profilePCC, profileName, configID)
        End Function

        Public Function GetTempLineDef(Optional ByVal LineDefName As String = "", Optional ByVal DateFrom As String = "", Optional ByVal DateTo As String = "")
            Return Me.DataAccess.GetTempLineDef(LineDefName, DateFrom, DateTo)
        End Function

        Public Function GetTempGDSInfo(Optional ByVal Name As String = "", Optional ByVal DateFrom As String = "", Optional ByVal DateTo As String = "")
            Return Me.DataAccess.GetTempGDSMapping(Name, DateFrom, DateTo)
        End Function

    End Class
End Namespace


@


1.1.1.1
log
@no message
@
text
@@
