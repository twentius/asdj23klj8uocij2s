head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.20;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.20;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic

Namespace BusinessLogicLayer
    Public Class CompanyServiceBLL

        Private DataAccess As DataAccessLayer.CompanyServiceDAL

        Public Sub New()
            Me.DataAccess = New DataAccessLayer.CompanyServiceDAL()
        End Sub

        Public Function GetServiceProgramList(ByVal Product As String) As DataTable
            Return Me.DataAccess.GetServiceProgramList(Product)
        End Function

        Public Function GetCompanyServiceData(ByVal ClientID As String) As DataTable
            Return Me.DataAccess.GetCompanyServiceData(ClientID)
        End Function

        Public Function UpdateCompanyService(ByVal info As DataInfo.CompanyServiceInfo) As Integer
            Return Me.DataAccess.UpdateCompanyService(info)
        End Function

        Public Function GetTempServiceConfigInfo(Optional ByVal Name As String = "", Optional ByVal DateFrom As String = "", Optional ByVal DateTo As String = "") As DataSet
            Return Me.DataAccess.GetTempClientServiceConfigInfo(Name, DateFrom, DateTo)
        End Function
    End Class
End Namespace


@


1.1.1.1
log
@no message
@
text
@@
