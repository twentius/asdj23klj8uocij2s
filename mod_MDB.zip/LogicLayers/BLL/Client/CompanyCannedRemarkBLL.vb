head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.20;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.20;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic

Namespace BusinessLogicLayer
    Public Class CompanyCannedRemarkBLL

        Private DataAccess As DataAccessLayer.CompanyCannedRemarkDAL

        Public Sub New()
            Me.DataAccess = New DataAccessLayer.CompanyCannedRemarkDAL()
        End Sub

        Public Function GetCannedRemark(ByVal clientID As String) As DataTable
            Return Me.DataAccess.GetCannedRemark(clientID)
        End Function

        Public Function GetStandardRemark(ByVal ClientID As String) As Boolean
            Return Me.DataAccess.GetStandardRemark(ClientID)
        End Function

        Public Function UpdateCannedRemark(ByVal info As DataInfo.CompanyCannedRemarkInfo) As Integer
            Return Me.DataAccess.UpdateCannedRemark(info)
        End Function

        Public Function GetTempCannedRemarkInfo(Optional ByVal Name As String = "", Optional ByVal DateFrom As String = "", Optional ByVal DateTo As String = "") As DataSet
            Return Me.DataAccess.GetTempCannedRemarkInfo(Name, DateFrom, DateTo)
        End Function

    End Class
End Namespace

@


1.1.1.1
log
@no message
@
text
@@
