head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.20;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.20;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic

Namespace BusinessLogicLayer
    Public Class ComAirPricingBLL

        Private DataAccess As DataAccessLayer.ComAirPricingDAL

        Public Sub New()
            Me.DataAccess = New DataAccessLayer.ComAirPricingDAL()
        End Sub

        Public Function GetComAirPricingData(ByVal ClientID As String) As DataTable
            Return Me.DataAccess.GetComAirPricingData(ClientID)
        End Function

        Public Function GetUsageVariables(ByVal AirPricingID As String) As DataTable
            Return Me.DataAccess.GetUsageVariables(AirPricingID)
        End Function

        Public Function GetAirPriceVariables(ByVal TripType As String, ByVal PricingID As Integer) As DataTable
            Return Me.DataAccess.GetAirPriceVariables(TripType, PricingID)
        End Function

        Public Function GetClientMasterAirPrice(ByVal ClientID As String) As DataTable
            Return Me.DataAccess.GetClientMasterAirPrice(ClientID)
        End Function

        Public Function GetClientAirPriceVariables(ByVal TripType As String, ByVal ClientID As String) As DataTable
            Return Me.DataAccess.GetClientAirPriceVariables(TripType, ClientID)
        End Function

        Public Function GetFieldIDByProgramName(ByVal ProgramName As String) As String
            Return Me.DataAccess.GetFieldIDByProgramName(ProgramName)
        End Function

        Public Function GetCMPIDByClientID(ByVal ClientID) As String
            Return Me.DataAccess.GetCMPIDByClientID(ClientID)
        End Function

        Public Function GetClientMasterPricing(ByVal ClientID As String) As DataTable
            Return Me.DataAccess.GetClientMasterPricing(ClientID)
        End Function

        Public Function GetSettingPricing(ByVal AirPricingID As String) As DataTable
            Return Me.DataAccess.GetSettingPricing(AirPricingID)
        End Function

        Public Function GetClientFeeData(ByVal CMPID As String, ByVal TripType As String, ByVal FieldID As String) As DataTable
            Return Me.DataAccess.GetClientFeeData(CMPID, TripType, FieldID)
        End Function

        Public Function UpdateComAirPricing(ByVal info As DataInfo.ComAirPricingInfo) As Integer
            Return Me.DataAccess.UpdateComAirPricing(info)
        End Function

        Public Function GetTempClientAirPricing() As DataTable
            Return Me.DataAccess.GetTempClientAirPricing()
        End Function

        Public Function GetTempClientMasterAirPricing() As DataTable
            Return Me.DataAccess.GetTempClientMasterAirPricing()
        End Function

        Public Function GetTempClientPricingByID(Optional ByVal ID As String = "", Optional ByVal DateFrom As String = "", Optional ByVal DateTo As String = "") As DataTable
            Return Me.DataAccess.GetTempClientPricingByID(ID, DateFrom, DateTo)
        End Function

        Public Function GetTempClientMasterPricingByID(Optional ByVal ID As String = "", Optional ByVal DateFrom As String = "", Optional ByVal DateTo As String = "") As DataTable
            Return Me.DataAccess.GetTempClientMasterPricingByID(ID, DateFrom, DateTo)
        End Function

    End Class
End Namespace

@


1.1.1.1
log
@no message
@
text
@@
