head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.20;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.20;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic

Namespace BusinessLogicLayer
    Public Class AuxPricingBLL

        Private DataAccess As DataAccessLayer.AuxPricingDAL

        Public Sub New()
            Me.DataAccess = New DataAccessLayer.AuxPricingDAL()
        End Sub

        Public Function GetProductList() As DataTable
            Return Me.DataAccess.GetProductList()
        End Function

        Public Function GetVendorList(ByVal ProductID) As DataTable
            Return Me.DataAccess.GetVendorList(ProductID)
        End Function

        Public Function GetAuxPricingList(ByVal Name As String, ByVal ProductID As String) As DataTable
            Return Me.DataAccess.GetAuxPricingList(Name, ProductID)
        End Function

        Public Function GetAuxPricingByID(ByVal FeeID As String) As DataTable
            Return Me.DataAccess.GetAuxPricingByID(FeeID)
        End Function

        Public Function GetFeeProductsByName(ByVal Name As String) As DataTable
            Return Me.DataAccess.GetFeeProductNameByID(Name)
        End Function

        Public Function UpdateAuxPrice(ByVal info As DataInfo.AuxFeeInfo) As Integer
            If info.FeeProduct = "feeall" Then
                info.FeeProduct = "all"
            End If
            Return Me.DataAccess.UpdateAuxPrice(info)
        End Function

        Public Function GetVendorNumberByName(ByVal Name As String)
            Return Me.DataAccess.GetVendorNumberByName(Name)
        End Function

        Public Function GetVendorNameByNumber(ByVal Number As String) As DataTable
            Return Me.DataAccess.GetVendorNameByNumber(Number)
        End Function

        Public Function DeleteFuelCharge(ByVal AuxFeeID As Integer) As Integer
            Return Me.DataAccess.DeleteFuelCharge(AuxFeeID)
        End Function

        Public Function IsExistName(ByVal FeeName As String, ByVal FeeID As String, ByVal ProductID As String, ByVal VendorID As String) As Boolean
            Return Me.DataAccess.IsExistName(FeeName, FeeID, ProductID, VendorID)
        End Function

        Public Function GetTempFeeAux(Optional ByVal FeeName As String = "", Optional ByVal dateFrom As String = "", Optional ByVal dateTo As String = "") As DataSet
            Return Me.DataAccess.GetTempAuxFee(FeeName, dateFrom, dateTo)
        End Function

    End Class
End Namespace


@


1.1.1.1
log
@no message
@
text
@@
