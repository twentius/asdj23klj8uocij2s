head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.20;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.20;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic

Namespace BusinessLogicLayer
    Public Class HotelContractBLL

        Private DataAccess As DataAccessLayer.HotelContractDAL

        Public Sub New()
            Me.DataAccess = New DataAccessLayer.HotelContractDAL()
        End Sub

        Public Function GetClient(Optional ByVal clientID As String = "", Optional ByVal ClientNum As String = "", Optional ByVal GroupName As String = "", Optional ByVal Name As String = "", Optional ByVal ApplyStd As Boolean = True) As DataTable
            Return Me.DataAccess.GetClient(clientID, ClientNum, GroupName, Name, ApplyStd)
        End Function


        Public Function GetClientName(Optional ByVal clientID As String = "") As DataTable
            Return Me.DataAccess.GetClientName(clientID)
        End Function

        Public Function GetRateType(ByVal Type As String) As DataTable
            Return Me.DataAccess.GetRateType(Type)
        End Function

        Public Function UpdateHotelContract(ByVal info As DataInfo.HotelContractInfo) As Integer
            Return Me.DataAccess.UpdateHotelContract(info)
        End Function

        Public Function UpdateHotelContract2(ByVal info As DataInfo.HotelContractInfo) As Integer
            Return Me.DataAccess.UpdateHotelContract2(info)
        End Function

        Public Function getHotelRank(ByVal ID As String) As DataTable
            Return Me.DataAccess.getHotelRank(ID)
        End Function

        Public Function getHotelRankID() As DataTable
            Return Me.DataAccess.getHotelRankID()
        End Function


    End Class
End Namespace

@


1.1.1.1
log
@no message
@
text
@@
