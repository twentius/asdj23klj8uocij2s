head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.20;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.20;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic

Namespace BusinessLogicLayer
    Public Class SupplierAirlinrContBLL

        Private DataAccess As DataAccessLayer.SupplierAirlinrContDAL

        Public Sub New()
            Me.DataAccess = New DataAccessLayer.SupplierAirlinrContDAL()
        End Sub

        Public Function GetClientAirContData(ByVal ClientID As String) As DataTable
            Return Me.DataAccess.GetClientAirContData(ClientID)
        End Function

        Public Function UpdateClientAirCont(ByVal info As DataInfo.SupplierAirContractInfo) As Integer
            Return Me.DataAccess.UpdateClientAirCont(info)
        End Function

        Public Function GetTempAirlineContactInfo(Optional ByVal Name As String = "", Optional ByVal DateFrom As String = "", Optional ByVal DateTo As String = "")
            Return Me.DataAccess.GetTempAirlineContactInfo(Name, DateFrom, DateTo)
        End Function

    End Class
End Namespace

@


1.1.1.1
log
@no message
@
text
@@
