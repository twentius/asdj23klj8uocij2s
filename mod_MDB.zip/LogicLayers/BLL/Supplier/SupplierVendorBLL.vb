head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.20;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.20;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic

Namespace BusinessLogicLayer
    Public Class SupplierVendorBLL

        Private DataAccess As DataAccessLayer.SupplierVendorDAL

        Public Sub New()
            Me.DataAccess = New DataAccessLayer.SupplierVendorDAL()
        End Sub

        Public Function GetVendorList(ByVal VendorName As String) As DataTable
            Return Me.DataAccess.GetVendorList(VendorName)
        End Function

        Public Function GetTravComVendorList(ByVal VendorNumber As String, ByVal VendorName As String, ByVal configKey As String) As DataTable
            Return Me.DataAccess.GetTravComVendorList(VendorNumber, VendorName, configKey)
        End Function

        Public Function GetVendorInfo(ByVal VendorNumber As String, ByVal configKey As String) As DataTable
            Return Me.DataAccess.GetVendorInfo(VendorNumber, configKey)
        End Function

        Public Function GetVendor(ByVal VendorNumber As String, ByVal configKey As String) As DataTable
            Return Me.DataAccess.GetVendor(VendorNumber, configKey)
        End Function


        Public Function GetVendorDataByID(ByVal VendorNumber As String) As DataTable
            Return Me.DataAccess.GetVendorDataByID(VendorNumber)
        End Function

        Public Function GetVendorContactByID(ByVal VendorNumber As String) As DataTable
            Return Me.DataAccess.GetVendorContactByID(VendorNumber)
        End Function

        Public Function GetProductList(ByVal FilterOutList As String) As DataTable
            Return Me.DataAccess.GetProductList(FilterOutList)
        End Function

        Public Function GetVendorProduct(ByVal VendorNumber As String) As DataTable
            Return Me.DataAccess.GetVendorProduct(VendorNumber)
        End Function

        Public Function IsExistCode(ByVal VendorNumber As String) As Boolean
            Return Me.DataAccess.IsExistCode(VendorNumber)
        End Function

        Public Function UpdateVendor(ByVal info As DataInfo.SupplierVendorInfo) As Integer
            Return Me.DataAccess.UpdateVendor(info)
        End Function

        Public Function DeleteVendorField(ByVal VendorNumber As String) As String
            Return Me.DataAccess.DeleteVendorField(VendorNumber)
        End Function

        Public Function GetHotelFee() As Boolean
            Return Me.DataAccess.checkHotelFee()
        End Function

        Public Function GetTempVendorInfo(Optional ByVal Name As String = "", Optional ByVal DateFrom As String = "", Optional ByVal DateTo As String = "")
            Return Me.DataAccess.GetTempVendorInfo(Name, DateFrom, DateTo)
        End Function

    End Class
End Namespace











@


1.1.1.1
log
@no message
@
text
@@
