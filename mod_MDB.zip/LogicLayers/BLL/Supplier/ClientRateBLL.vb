head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.20;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.20;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic

Namespace BusinessLogicLayer
    Public Class ClientRateBLL

        Private DataAccess As DataAccessLayer.ClientRateDAL

        Public Sub New()
            Me.DataAccess = New DataAccessLayer.ClientRateDAL()
        End Sub


        Public Function GetClientRate(Optional ByVal ClientID As String = "", Optional ByVal HarpClienID As String = "", Optional ByVal isCWT As Boolean = False, Optional ByVal RateCodeID As String = "") As DataTable
            Return Me.DataAccess.GetClientRate(ClientID, HarpClienID, isCWT, RateCodeID)
        End Function

        Public Function GetGDS() As DataTable
            Return Me.DataAccess.GetGDS()
        End Function

        Public Function GetClient(Optional ByVal clientID As String = "") As DataTable
            Return Me.DataAccess.GetClient(clientID)
        End Function

        Public Function GetHarpClient(ByVal GDS As String) As DataTable
            Return Me.DataAccess.GetHarpClient(GDS)
        End Function

        Public Function InsertClientRate(ByVal info As DataInfo.ClientRateInfo()) As Integer
            Return Me.DataAccess.InsertClientRate(info)
        End Function

        Public Function DeteleRateCode(ByVal RateCodeID As String) As Integer
            Return Me.DataAccess.DeteleRateCode(RateCodeID)
        End Function

        Public Function SearchClientRate(ByVal groupName As String, ByVal ClientNum As String, ByVal ClientName As String, ByVal IsCWT As Boolean) As DataTable
            Return Me.DataAccess.SearchClientRate(groupName, ClientNum, ClientName, IsCWT)
        End Function

        Public Function SearchClientRate2() As DataTable
            Return Me.DataAccess.SearchClientRate2()
        End Function

        Public Function GetFlitterGDS(ByVal GDS As String, ByVal GDSRateCode As String) As DataTable
            Return Me.DataAccess.FlitterHarpClientID(GDS, GDSRateCode)
        End Function

        Public Function GetGDSCodeByGDS(ByVal GDSID As String) As DataTable
            Return Me.DataAccess.GetGDSRateCodeByHarpClientName(GDSID)
        End Function

        Public Function GetHarpRateCode(ByVal HarpClientName As String, ByVal GDSID As String, ByVal GDSRateCode As String) As DataTable
            Return Me.DataAccess.GetHarpRateCode(HarpClientName, GDSID, GDSRateCode)
        End Function

        Public Function GetHarpClientID(ByVal HarpClientName As String, ByVal HarpRateCode As String, ByVal GDSRateCode As String) As DataTable
            Return Me.DataAccess.GetHarpClientID(HarpClientName, HarpRateCode, GDSRateCode)
        End Function

        Public Function GetRateInfoByHarpClientID(ByVal HarpClientID As String) As DataTable
            Return Me.DataAccess.GetRateInfoByHarpClientID(HarpClientID)
        End Function

        Public Function GetHarpClientNameByHarpClientID(ByVal HarpClientID As String) As DataTable
            Return Me.DataAccess.GetHarpClientNameByHarpClientID(HarpClientID)
        End Function

        Public Function GetTempClientRateCodeInfo(Optional ByVal Name As String = "", Optional ByVal DateFrom As String = "", Optional ByVal DateTo As String = "")
            Return Me.DataAccess.GetTempClientRateCode(Name, DateFrom, DateTo)
        End Function
    End Class
End Namespace

@


1.1.1.1
log
@no message
@
text
@@
