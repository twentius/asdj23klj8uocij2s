head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.20;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.20;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic

Namespace BusinessLogicLayer
    Public Class SupplierAirRuleBLL

        Private DataAccess As DataAccessLayer.SupplierAirRuleDAL

        Public Sub New()
            Me.DataAccess = New DataAccessLayer.SupplierAirRuleDAL()
        End Sub

        Public Function GetCCList(ByVal AirlineCode As String, ByVal CCType As String) As DataTable
            Return Me.DataAccess.GetCCList(AirlineCode, CCType)
        End Function

        Public Function GetAirlineRuleByCode(ByVal AirlineCode As String) As DataTable
            Return Me.DataAccess.GetAirlineRuleByCode(AirlineCode)
        End Function

        Public Function GetAirlineByCode(ByVal AirlineCode As String) As String
            Return Me.DataAccess.GetAirlineByCode(AirlineCode)
        End Function

        Public Function GetAirComByCode(ByVal AirlineCode As String) As DataTable
            Return Me.DataAccess.GetAirComByCode(AirlineCode)
        End Function

        Public Function GetRegionByID(ByVal RegionCode As String) As String
            Return Me.DataAccess.GetRegionByID(RegionCode)
        End Function

        Public Function GetCountryByID(ByVal CountryCode As String) As String
            Return Me.DataAccess.GetCountryByID(CountryCode)
        End Function

        Public Function GetCityByID(ByVal CityCode As String) As String
            Return Me.DataAccess.GetCityByID(CityCode)
        End Function

        Public Function GetRegionByCountry(ByVal CountryCode As String) As String
            Return Me.DataAccess.GetRegionByCountry(CountryCode)
        End Function

        Public Function GetRegionByCity(ByVal CityCode As String) As String
            Return Me.DataAccess.GetRegionByCity(CityCode)
        End Function

        Public Function GetCountryByCity(ByVal CityCode As String) As String
            Return Me.DataAccess.GetCountryByCity(CityCode)
        End Function

        Public Function GetAirlineCCDetail(ByVal AirlineCode As String, ByVal TabType As String) As DataTable
            Return Me.DataAccess.GetAirlineCCDetail(AirlineCode, TabType)
        End Function

        Public Function GetAirlineCCDetail2(ByVal AirlineCode As String, ByVal TabType As String) As DataTable
            Return Me.DataAccess.GetAirlineCCDetail2(AirlineCode, TabType)
        End Function

        Public Function GetClient() As DataTable
            Return Me.DataAccess.GetClient()
        End Function

        Public Function UpdateAirRule(ByVal info As DataInfo.SupplierAirRuleInfo, ByVal chkClientData As Boolean) As Integer
            Return Me.DataAccess.UpdateAirRule(info, chkClientData)
        End Function

        Public Function GetTempAirlineComm() As DataTable
            Return Me.DataAccess.GetTempAirlineComm()
        End Function

        Public Function GetTempAirlineCommByAirlineCode(Optional ByVal AirlineCode As String = "", Optional ByVal DateFrom As String = "", Optional ByVal DateTo As String = "") As DataTable
            Return Me.DataAccess.GetTempAirlineCommByAirlineCode(AirlineCode, DateFrom, DateTo)
        End Function

        Public Function GetTempAirlineRule() As DataTable
            Return Me.DataAccess.GetTempAirlineRule()
        End Function

        Public Function GetTempAirlineRuleByAirlineCode(Optional ByVal AirlineCode As String = "", Optional ByVal DateFrom As String = "", Optional ByVal DateTo As String = "") As DataTable
            Return Me.DataAccess.GetTempAirlineRuleByAirlineCode(AirlineCode, DateFrom, DateTo)
        End Function

        Public Function GetTempAirlineCCByAirlineCode(Optional ByVal AirlineCode As String = "", Optional ByVal DateFrom As String = "", Optional ByVal DateTo As String = "") As DataTable
            Return Me.DataAccess.GetTempAirlineCCByAirlineCode(AirlineCode, DateFrom, DateTo)
        End Function

    End Class
End Namespace

@


1.1.1.1
log
@no message
@
text
@@
