head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.20;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.20;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic

Namespace BusinessLogicLayer
    Public Class AuxChargeBLL

        Private DataAccess As DataAccessLayer.AuxChargeDAL

        Public Sub New()
            Me.DataAccess = New DataAccessLayer.AuxChargeDAL()
        End Sub

        Public Function GetProductList() As DataTable
            Return Me.DataAccess.GetProductList()
        End Function

        Public Function GetVendorList(ByVal ProductID As String) As DataTable
            Return Me.DataAccess.GetVendorList(ProductID)
        End Function

        Public Function GetAuxChargeList(ByVal ProductID As String) As DataTable
            Return Me.DataAccess.GetAuxChargeList(ProductID)
        End Function

        Public Function GetVendorNumber(ByVal VendorName) As DataTable
            Return Me.DataAccess.GetVendorNumber(VendorName)
        End Function

        Public Function DeleteFuelCharge(ByVal AuxVendorChargeID As Integer) As Integer
            Return Me.DataAccess.DeleteFuelCharge(AuxVendorChargeID)
        End Function

        Public Function GetAuxChargeByID(ByVal FeeID As String) As DataTable
            Return Me.DataAccess.GetAuxChargeByID(FeeID)
        End Function

        Public Function UpdateAuxCharge(ByVal info As DataInfo.AuxChargeInfo) As Integer
            Return Me.DataAccess.UpdateAuxCharge(info)
        End Function

        Public Function GetTempAuxCharge(Optional ByVal ProductName As String = "", Optional ByVal DateFrom As String = "", Optional ByVal DateTo As String = "") As DataSet
            Return Me.DataAccess.GetTempAuxCharge(ProductName, DateFrom, DateTo)
        End Function


    End Class
End Namespace

@


1.1.1.1
log
@no message
@
text
@@
