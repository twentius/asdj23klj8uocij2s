head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.20;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.20;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic

Namespace BusinessLogicLayer
    Public Class AuxCustomFieldBLL

        Private DataAccess As DataAccessLayer.AuxCustomFieldDAL

        Public Sub New()
            Me.DataAccess = New DataAccessLayer.AuxCustomFieldDAL()
        End Sub

        Public Function GetProductList() As DataTable
            Return Me.DataAccess.GetProductList()
        End Function

        ' Public Function GetCommandList() As DataTable
        'Return Me.DataAccess.GetCommandList()
        'End Function

        Public Function GetCommandData(ByVal FieldID As String) As DataTable
            Return Me.DataAccess.GetCommandData(FieldID)
        End Function

        Public Function GetEOData(ByVal FieldID As String) As DataTable
            Return Me.DataAccess.GetEOData(FieldID)
        End Function

        Public Function LoadDropListByID(ByVal FieldID As String) As DataTable
            Return Me.DataAccess.LoadDropListByID(FieldID)
        End Function

        Public Function GetDataByID(ByVal FieldID As String) As DataTable
            Return Me.DataAccess.GetDataByID(FieldID)
        End Function

        Public Function GetAuxCustomFieldList(ByVal Name As String, ByVal ProductID As String) As DataTable
            Return Me.DataAccess.GetAuxCustomFieldList(Name, ProductID)
        End Function
        Public Function GetAuxCustSeqNum(ByVal ProductID As String) As DataTable
            Return Me.DataAccess.GetAuxCustSeqNum(ProductID)
        End Function
        Public Function GetAuxCustSeqNum2(ByVal AuxCustID As String) As DataTable
            Return Me.DataAccess.GetAuxCustSeqNum2(AuxCustID)
        End Function

        Public Function GetRemainSeqNum(ByVal ProID As String) As DataTable
            Return Me.DataAccess.GetRemainSeqNum(ProID)
        End Function

        Public Function GetAuxCustSeqNum3(ByVal AuxCustID As String) As DataTable
            Return Me.DataAccess.GetAuxCustSeqNum3(AuxCustID)
        End Function

        Public Function UpdateSeq(ByVal Seq As String, ByVal AuxID As String) As String
            Return Me.DataAccess.UpdateSeq(Seq, AuxID)
        End Function


        Public Function UpdateAuxCustomField(ByVal info As DataInfo.AuxCustomFieldInfo) As Integer
            Return Me.DataAccess.UpdateAuxCustomField(info)
        End Function

        Public Function DeleteAuxCustField(ByVal AuxCustomControlID As Integer) As Integer
            Return Me.DataAccess.DeleteAuxCustField(AuxCustomControlID)
        End Function

        Public Function GetTempAuxCustomField(Optional ByVal CustomFieldName As String = "", Optional ByVal DateFrom As String = "", Optional ByVal DateTo As String = "")
            Return Me.DataAccess.GetTempAuxCustom(CustomFieldName, DateFrom, DateTo)
        End Function


    End Class
End Namespace















@


1.1.1.1
log
@no message
@
text
@@
