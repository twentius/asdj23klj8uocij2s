head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.20;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.20;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic

Namespace BusinessLogicLayer
    Public Class StdAirlineBLL

        Private DataAccess As DataAccessLayer.StdAirlineDAL

        Public Sub New()
            Me.DataAccess = New DataAccessLayer.StdAirlineDAL()
        End Sub

        Public Function GetAirlineList(ByVal AirlineName As String) As DataTable
            Return Me.DataAccess.GetAirlineList(AirlineName)
        End Function

        Public Function GetAirlineByCode(ByVal AirlineCode As String) As DataTable
            Return Me.DataAccess.GetAirlineByCode(AirlineCode)
        End Function

        Public Function IsExistCode(ByVal AirlineCode As String) As Boolean
            Return Me.DataAccess.IsExistCode(AirlineCode)
        End Function

        Public Function UpdateAirline(ByVal info As DataInfo.StdAirlineInfo) As Integer
            Return Me.DataAccess.UpdateAirline(info)
        End Function

        Public Function GetTempAirlineInfo(Optional ByVal Code As String = "", Optional ByVal DateFrom As String = "", Optional ByVal DateTo As String = "")
            Return Me.DataAccess.GetTempAirlineInfo(Code, DateFrom, DateTo)
        End Function

    End Class

End Namespace


@


1.1.1.1
log
@no message
@
text
@@
