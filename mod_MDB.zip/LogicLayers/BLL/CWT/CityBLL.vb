head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.20;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.20;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic

Namespace BusinessLogicLayer
    Public Class CityBLL

        Private DataAccess As DataAccessLayer.CityDAL

        Public Sub New()
            Me.DataAccess = New DataAccessLayer.CityDAL()
        End Sub

        Public Function IsExistName(ByVal ID As String) As Boolean
            Return Me.DataAccess.IsExistName(ID)
        End Function

        Public Function GetCityList(ByVal ID As String, ByVal CityCode As String) As DataTable
            Return Me.DataAccess.GetCityList(ID, CityCode)
        End Function

        Public Function GetRegionList() As DataTable
            Return Me.DataAccess.GetRegionList()
        End Function

        Public Function GetCountryList() As DataTable
            Return Me.DataAccess.GetCountryList()
        End Function

        Public Function GetCityTypeList() As DataTable
            Return Me.DataAccess.GetCityTypeList()
        End Function

        Public Function GetCityByAirportCode(ByVal AirportCode As String) As DataTable
            Return Me.DataAccess.GetCityByAirportCode(AirportCode)
        End Function

        Public Function DeleteCityByCode(ByVal AirportCode As String) As Integer
            Return Me.DataAccess.DeleteCityByCode(AirportCode)
        End Function

        Public Function UpdateCity(ByVal info As DataInfo.CityInfo) As Integer
            Return Me.DataAccess.UpdateCity(info)
        End Function

        Public Function GetTempAirportCity(Optional ByVal AirportName As String = "", Optional ByVal DateFrom As String = "", Optional ByVal DateTo As String = "") As DataSet
            Return Me.DataAccess.GetTempAirportCity(AirportName, DateFrom, DateTo)
        End Function

    End Class
End Namespace

@


1.1.1.1
log
@no message
@
text
@@
