head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.20;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.20;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic

Namespace BusinessLogicLayer
    Public Class DivisionBLL

        Private DataAccess As DataAccessLayer.DivisionDAL

        Public Sub New()
            Me.DataAccess = New DataAccessLayer.DivisionDAL()
        End Sub

        Public Function GetDivisionAgentTree() As DataTable
            Return Me.DataAccess.GetDivisionAgentTree()
        End Function

        Public Function GetDivisionList2(ByVal divisionID As String, ByVal divisionName As String, ByVal uid As String, ByVal agentName As String, ByVal SignOn As String) As DataTable
            Return Me.DataAccess.GetDivisionList2(divisionID, divisionName, uid, agentName, SignOn)
        End Function

        Public Function GetDivisionList() As DataTable
            Return Me.DataAccess.GetDivisionList()
        End Function

        Public Function GetDivisionByID(ByVal DivisionID As String) As DataTable
            Return Me.DataAccess.GetDivisionByID(DivisionID)
        End Function

        Public Function GetTempAgent() As DataTable
            Return Me.DataAccess.GetTempAgent()
        End Function

        Public Function GetTempDivision() As DataTable
            Return Me.DataAccess.GetTempDivision()
        End Function

        Public Function GetTempAgentByID(Optional ByVal ID As String = "", Optional ByVal DateFrom As String = "", Optional ByVal DateTo As String = "") As DataTable
            Return Me.DataAccess.GetTempAgentByID(ID, DateFrom, DateTo)
        End Function

        Public Function GetTempDivisionByID(Optional ByVal ID As String = "", Optional ByVal DateFrom As String = "", Optional ByVal DateTo As String = "") As DataTable
            Return Me.DataAccess.GetTempDivisionByID(ID, DateFrom, DateTo)
        End Function

        Public Function UpdateDivision(ByVal info As DataInfo.DivisionInfo) As Integer
            Return Me.DataAccess.UpdateDivision(info)
        End Function

        Public Function GetAgentByID(ByVal AgentID As String) As DataTable
            Return Me.DataAccess.GetAgentByID(AgentID)
        End Function

        Public Function GetAgentByID2(ByVal DivisionID As String, Optional ByVal AgentName As String = "", Optional ByVal AgentID As String = "") As DataTable
            Return Me.DataAccess.GetAgentByID2(DivisionID, AgentName, AgentID)
        End Function
        'Public Function GetAgentByID2(ByVal DivisionID As String) As DataTable
        '    Return Me.DataAccess.GetAgentByID2(DivisionID)
        'End Function

        Public Function IsExistCode(ByVal DivID As String) As Boolean
            Return Me.DataAccess.IsExistCode(DivID)
        End Function

        Public Function IsExistAgentID(ByVal AgentID As String) As Boolean
            Return Me.DataAccess.IsExistAgentID(AgentID)
        End Function

        Public Function UpdateAgent(ByVal info As DataInfo.DivisionAgentInfo) As Integer
            Return Me.DataAccess.UpdateAgent(info)
        End Function

        Public Function DeleteAgent(ByVal AgentID As String) As Integer
            Return Me.DataAccess.DeleteAgent(AgentID)
        End Function
    End Class

End Namespace

@


1.1.1.1
log
@no message
@
text
@@
