head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.20;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.20;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic

Namespace BusinessLogicLayer
    Public Class AirFeeBLL

        Private DataAccess As DataAccessLayer.AirFeeDAL

        Public Sub New()
            Me.DataAccess = New DataAccessLayer.AirFeeDAL()
        End Sub

#Region "General"
        Public Function GetFeeList(ByVal FeeName As String, ByVal FeeType As DataInfo.AirFeeInfo.AirFeeManagerType) As DataTable
            Return Me.DataAccess.GetFeeList(FeeName, FeeType)
        End Function

        Public Function GetFeeName(ByVal FeeName As String, ByVal FeeType As String) As String()
            Return Me.DataAccess.GetFeeName(FeeName, FeeType)
        End Function

        Public Function GetFeeNameByID(ByVal FeeID As String, ByVal FeeType As DataInfo.AirFeeInfo.AirFeeManagerType) As String
            Return Me.DataAccess.GetFeeNameByID(FeeID, FeeType)
        End Function

        Public Function GetAirCalcName(ByVal AirPricingID As String) As String
            Return Me.DataAccess.GetAirCalcName(AirPricingID)
        End Function

        Public Function IsExistName(ByVal FeeName As String, ByVal ID As String, ByVal FeeType As DataInfo.AirFeeInfo.AirFeeManagerType) As Boolean
            Return Me.DataAccess.IsExistName(FeeName, ID, FeeType)
        End Function
#End Region

#Region "Coupon"
        Public Function GetFeeByCouponData(ByVal FeeID As String) As DataTable
            Return Me.DataAccess.GetFeeByCouponData(FeeID)
        End Function

        Public Function UpdateFeeByCouponData(ByVal info As DataInfo.TransCouponInfo) As Integer
            Return Me.DataAccess.UpdateFeeByCouponData(info)
        End Function
#End Region

#Region "Conditional"
        Public Function GetFeeByConditionalData(ByVal FeeID As String) As DataTable
            Return Me.DataAccess.GetFeeByConditionalData(FeeID)
        End Function

        Public Function UpdateFeeByConditionalData(ByVal info As DataInfo.TransConditionalInfo) As Integer
            Return Me.DataAccess.UpdateFeeByConditionalData(info)
        End Function
#End Region

#Region "PNR"
        Public Function GetFeeByPNRData(ByVal FeeID As String) As DataTable
            Return Me.DataAccess.GetFeeByPNRData(FeeID)
        End Function

        Public Function UpdateFeeByPNRData(ByVal info As DataInfo.TransPNRInfo) As Integer
            Return Me.DataAccess.UpdateFeeByPNRData(info)
        End Function
#End Region

#Region "Ticket"
        Public Function GetFeeByTicketData(ByVal FeeID As String) As DataTable
            Return Me.DataAccess.GetFeeByTicketData(FeeID)
        End Function

        Public Function UpdateFeeByTicketData(ByVal info As DataInfo.TransTicketInfo) As String
            Return Me.DataAccess.UpdateFeeByTicketData(info)
        End Function
#End Region

#Region "TempFee"
        Public Function GetTempFeeData(ByVal Type) As DataTable
            Return Me.DataAccess.GetTempFeeData(Type)
        End Function

        Public Function GetTempTransactionFeeData(ByVal Type) As DataTable
            Return Me.DataAccess.GetTempTransactionFeeData(Type)
        End Function

        Public Function GetTempFeeDataByName(Optional ByVal Name As String = "", Optional ByVal Type As String = "", Optional ByVal DateFrom As String = "", Optional ByVal DateTo As String = "") As DataTable
            Return Me.DataAccess.GetTempFeeDataByName(Name, Type, DateFrom, DateTo)
        End Function

        Public Function GetTempTransactionFeeDataByName(Optional ByVal Name As String = "", Optional ByVal Type As String = "", Optional ByVal DateFrom As String = "", Optional ByVal DateTo As String = "") As DataTable
            Return Me.DataAccess.GetTempTransactionFeeDataByName(Name, Type, DateFrom, DateTo)
        End Function
#End Region

    End Class
End Namespace

@


1.1.1.1
log
@no message
@
text
@@
