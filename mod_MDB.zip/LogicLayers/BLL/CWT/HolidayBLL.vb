head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.20;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.20;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic
Namespace BusinessLogicLayer
    Public Class HolidayBLL
        Private DataAccess As DataAccessLayer.HolidayDAL
        Public Sub New()
            Me.DataAccess = New DataAccessLayer.HolidayDAL
        End Sub
        Public Function GetHolidayData(Optional ByVal HolidayDate As String = Nothing) As DataTable
            Return Me.DataAccess.GetHolidayData(HolidayDate)
        End Function
        Public Function getHolidayByHolidayID(ByVal HolidayID As Integer) As DataTable
            Return Me.DataAccess.GetHolidayByHolidayID(HolidayID)
        End Function
        Public Function DeleteHolidayByHolidayID(ByVal HolidayID As Integer) As Integer
            Return Me.DataAccess.DeleteHolidayByHolidayID(HolidayID)
        End Function
        Public Function InsertHoliday(ByVal HolidayDate As Date, ByVal HolidayName As String) As Integer
            Return Me.DataAccess.InsertHoliday(HolidayDate, HolidayName)
        End Function
        Public Function UpdateHolidayByHolidayID(ByVal HolidayID As Integer, ByVal HolidayDate As String, ByVal HolidayName As String) As Integer
            Return Me.DataAccess.UpdateHolidayByHolidayID(HolidayID, HolidayDate, HolidayName)
        End Function

        Public Function GetTempHoliday(Optional ByVal DateFrom As String = "", Optional ByVal DateTo As String = "") As DataSet
            Return Me.DataAccess.GetTempHoliday(DateFrom, DateTo)
        End Function
    End Class
End Namespace

@


1.1.1.1
log
@no message
@
text
@@
