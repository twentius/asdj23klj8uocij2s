head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.20;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.20;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic

Namespace BusinessLogicLayer

    Public Class StaffRoleBLL

        Private DataAccess As DataAccessLayer.StaffRoleDA

        Public Sub New()
            Me.DataAccess = New DataAccessLayer.StaffRoleDA()
        End Sub

        Public Function GetUserRole() As DataTable
            Return Me.DataAccess.GetUserRole()
        End Function

        Public Function GetUserRoleByRoleID(ByVal RoleID As Integer) As DataTable
            Return Me.DataAccess.GetUserRoleByRoleID(RoleID)
        End Function

        Public Function InsertRole(ByVal RoleName As String) As Integer
            Return Me.DataAccess.InsertRole(RoleName)
        End Function

        Public Function UpdateRoleByRoleID(ByVal RoleID As Integer, ByVal RoleName As String) As Integer
            Return Me.DataAccess.UpdateRoleByRoleID(RoleID, RoleName)
        End Function

        Public Function DeleteRoleByRoleID(ByVal RoleID As Integer) As Integer
            Return Me.DataAccess.DeleteRoleByRoleID(RoleID)
        End Function

        Public Function GetTempRoleDataByRoleName(Optional ByVal RoleName As String = "", Optional ByVal dateFrom As String = "", Optional ByVal dateTo As String = "") As DataSet
            Return Me.DataAccess.GetTempRoleByRoleName(RoleName, dateFrom, dateTo)
        End Function

    End Class

End Namespace


@


1.1.1.1
log
@no message
@
text
@@
