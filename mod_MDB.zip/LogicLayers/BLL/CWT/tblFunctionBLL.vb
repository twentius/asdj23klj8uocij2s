head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.20;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.20;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic

Namespace BusinessLogicLayer

    Public Class tblFunctionBLL

        Private DataAccess As DataAccessLayer.tblFunctionDA

        Public Sub New()
            Me.DataAccess = New DataAccessLayer.tblFunctionDA
        End Sub

        Public Function GetLinkList(ByVal FunctionID As Integer, ByVal WMode As String) As DataTable
            Return Me.DataAccess.GetLinkList(FunctionID, WMode)
        End Function

        Public Function GetUserRole(ByVal RoleID As Integer) As DataTable
            Return Me.DataAccess.getAllData(RoleID)
        End Function

        Public Function GetUserRole2(ByVal RoleID As Integer) As DataTable
            Return Me.DataAccess.getAllData2(RoleID)
        End Function

        Public Function GetPermission() As DataTable
            Return Me.DataAccess.GetPermission()
        End Function


        Public Function SaveData(ByVal info As DataInfo.PermissionServiceInfo) As Integer
            Return Me.DataAccess.SaveData(info)
        End Function

        Public Function GetUserLevelByUrl(ByVal url As String) As CWTCustomControls.UserLevelControl
            Return Me.DataAccess.GetUserLevelByUrl(url)
        End Function

        Public Function GetFunctionGroup(ByVal url As String) As CWTMasterDB.Util.TabNameType
            Return Me.DataAccess.GetFunctionGroup(url)
        End Function

        Public Function GetFunctionIDByUrl(ByVal url As String) As Integer
            Return Me.DataAccess.GetFunctionIDByUrl(url)
        End Function

        Public Function GetTempPermissionByRoleName(Optional ByVal RoleName As String = "", Optional ByVal DateFrom As String = "", Optional ByVal DateTo As String = "") As DataSet
            Return Me.DataAccess.GetTempPermissionValue(RoleName, DateFrom, DateTo)
        End Function

        Public Function GetTempCountryConfig(ByVal DateFrom As String, ByVal DateTo As String) As DataSet
            Return Me.DataAccess.GetTempCountryConfig(DateFrom, DateTo)
        End Function


    End Class

End Namespace

@


1.1.1.1
log
@no message
@
text
@@
