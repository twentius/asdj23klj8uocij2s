head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.20;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.20;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic

Namespace BusinessLogicLayer
    Public Class AirlineBLL

        Private DataAccess As DataAccessLayer.AirlineDAL

        Public Sub New()
            Me.DataAccess = New DataAccessLayer.AirlineDAL()
        End Sub

        Public Function GetAirlineList() As DataTable
            Return Me.DataAccess.GetAirlineList()
        End Function

        Public Function GetAirlineList(ByVal AirlineName As String) As DataTable
            Return Me.DataAccess.GetAirlineList(AirlineName)
        End Function

        Public Function GetAirlineFuelData(ByVal AirlineCode As String) As DataTable
            Return Me.DataAccess.GetAirlineFuelData(AirlineCode)
        End Function

        Public Function GetAirlineName(ByVal AirlineName As String) As String()
            Return Me.DataAccess.GetAirlineName(AirlineName)
        End Function

        Public Function DeleteAirlineFuelByCode(ByVal AirlineCode As Integer) As Integer
            Return Me.DataAccess.DeleteAirlineFuelByCode(AirlineCode)
        End Function

        Public Function UpdateAirlineFuel(ByVal info As DataInfo.AirlineInfo) As Integer
            Return Me.DataAccess.UpdateAirlineFuel(info)
        End Function

    End Class
End Namespace

@


1.1.1.1
log
@no message
@
text
@@
