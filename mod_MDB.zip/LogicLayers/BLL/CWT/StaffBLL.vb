head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.20;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.20;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic

Namespace BusinessLogicLayer

    Public Class StaffBLL

        Private DataAccess As DataAccessLayer.StaffDA

        Public Sub New()
            Me.DataAccess = New DataAccessLayer.StaffDA()
        End Sub

        Public Function GetDepartment() As DataTable
            Return Me.DataAccess.GetDepartment()
        End Function

        Public Function GetUserList(ByVal FirstName As String, ByVal LastName As String, ByVal IncInactive As Boolean) As DataTable
            Return Me.DataAccess.GetUserList(FirstName, LastName, IncInactive)
        End Function

        Public Function GetDataColumnByID(ByVal Column As String, ByVal UserName As String) As Object
            Return Me.DataAccess.GetDataColumnByID(Column, UserName)
        End Function

        Public Function GetUserByID(ByVal UserName As String) As DataTable
            Return Me.DataAccess.GetUserByID(UserName)
        End Function

        Public Function GetCWTContact(ByVal UserName As String, ByVal clientID As String) As DataTable
            Return Me.DataAccess.GetCWTContact(UserName, clientID)
        End Function

        Public Function IsExistUser(ByVal UserName As String) As Boolean
            Return Me.DataAccess.IsExistUser(UserName)
        End Function

        Public Function ChangePassword(ByVal UserName As String, ByVal NewPassword As String) As Integer
            Return Me.DataAccess.ChangePassword(UserName, NewPassword)
        End Function

        Public Function ChangeEmail(ByVal UserName As String, ByVal NewEmail As String) As Integer
            Return Me.DataAccess.ChangeEmail(UserName, NewEmail)
        End Function

        Public Function UpdateUser(ByVal info As DataInfo.UserInfo) As Integer
            Return Me.DataAccess.UpdateUser(info)
        End Function

        Public Function GetFirstName(ByVal FirstName As String) As String()
            Return Me.DataAccess.GetFirstName(FirstName)
        End Function

        Public Function GetLastName(ByVal LastName As String) As String()
            Return Me.DataAccess.GetLastName(LastName)
        End Function

        Public Function GetTempUser(Optional ByVal UserID As String = "", Optional ByVal DateFrom As String = "", Optional ByVal DateTo As String = "") As DataSet
            Return Me.DataAccess.GetTempUserByID(UserID, DateFrom, DateTo)
        End Function


    End Class

End Namespace


@


1.1.1.1
log
@no message
@
text
@@
