head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.20;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.20;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic

Namespace BusinessLogicLayer
    Public Class AirPricingBLL

        Private DataAccess As DataAccessLayer.AirPricingDAL

        Public Sub New()
            Me.DataAccess = New DataAccessLayer.AirPricingDAL()
        End Sub

        Public Function GetAirVariablesList() As DataTable
            Return Me.DataAccess.GetAirVariablesList()
        End Function

        Public Function GetAirVariableGroups() As DataTable
            Return Me.DataAccess.GetAirVariableGroups()
        End Function

        Public Function GetAirOperatorList() As DataTable
            Return Me.DataAccess.GetAirOperatorList()
        End Function

        Public Function GetUsageAirVariables() As DataTable
            Return Me.DataAccess.GetUsageAirVariables()
        End Function

        Public Function GetUsageAirVariables(ByVal AirPricingID As String, ByVal IsInt As Boolean) As DataTable
            Return Me.DataAccess.GetUsageAirVariables(AirPricingID, IsInt)
        End Function

        Public Function GetAirPriceList() As DataTable
            Return Me.DataAccess.GetAirPriceList()
        End Function

        Public Function GetAirPriceData(ByVal RecordID As String) As DataTable
            Return Me.DataAccess.GetAirPriceData(RecordID)
        End Function

        Public Function IsExistName(ByVal Name As String, ByVal ID As String) As Boolean
            Return Me.DataAccess.IsExistName(Name, ID)
        End Function

        Public Function UpdateAirPrice(ByVal info As DataInfo.AirPriceInfo) As Integer
            Return Me.DataAccess.UpdateAirPrice(info)
        End Function

        Public Function DeleteAirPricing(ByVal AirPricingID As String) As Integer
            Return Me.DataAccess.DeleteAirPricing(AirPricingID)
        End Function

        Public Function getPricingInUsed(ByVal AirPricingID As String) As DataTable
            Return Me.DataAccess.getPricingInUsed(AirPricingID)
        End Function

        'Public Function getTempAirPricingFormula() As DataTable
        '    Return Me.DataAccess.GetTempAirPricingFormula()
        'End Function

        'Public Function getTempAirPricingFormulaInt() As DataTable
        '    Return Me.DataAccess.GetTempAirPricingFormulaInt()
        'End Function


        'Public Function getTempAirPricingVariables() As DataTable
        '    Return Me.DataAccess.GetTempAirPricingVariables()
        'End Function

        'Public Function getTempAirPricingFormulaByName(Optional ByVal Name As String = "", Optional ByVal DateFrom As String = "", Optional ByVal DateTo As String = "") As DataTable
        '    Return Me.DataAccess.GetTempAirPricingFormulaByName(Name, DateFrom, DateTo)
        'End Function

        Public Function getTempAirPricingFormulaByNameInt(Optional ByVal Name As String = "", Optional ByVal DateFrom As String = "", Optional ByVal DateTo As String = "") As DataTable
            Return Me.DataAccess.GetTempAirPricingFormulaByNameInt(Name, DateFrom, DateTo)
        End Function

        Public Function getTempAirPricingFormulaByNameDom(Optional ByVal Name As String = "", Optional ByVal DateFrom As String = "", Optional ByVal DateTo As String = "") As DataTable
            Return Me.DataAccess.GetTempAirPricingFormulaByNameDom(Name, DateFrom, DateTo)
        End Function

        Public Function getTempAirPricingFormulaByNameLCC(Optional ByVal Name As String = "", Optional ByVal DateFrom As String = "", Optional ByVal DateTo As String = "") As DataTable
            Return Me.DataAccess.GetTempAirPricingFormulaByNameLCC(Name, DateFrom, DateTo)
        End Function

        'Public Function getTempAirPricingVariablesByID(Optional ByVal Name As String = "", Optional ByVal DateFrom As String = "", Optional ByVal DateTo As String = "") As DataTable
        '    Return Me.DataAccess.GetTempAirPricingVariablesByName(Name, DateFrom, DateTo)
        'End Function


    End Class
End Namespace

@


1.1.1.1
log
@no message
@
text
@@
