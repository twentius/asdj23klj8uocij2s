head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.20;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.20;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic

Namespace BusinessLogicLayer
    Public Class CannedRemarkBLL

        Private DataAccess As DataAccessLayer.CannedRemarkDAL

        Public Sub New()
            Me.DataAccess = New DataAccessLayer.CannedRemarkDAL()
        End Sub

        Public Function GetCannedRemark() As DataTable
            Return Me.DataAccess.GetCannedRemark()
        End Function

        Public Function UpdateCannedRemark(ByVal info As DataInfo.CannedRemarkInfo) As Integer
            Return Me.DataAccess.UpdateCannedRemark(info)
        End Function

        Public Function GetTempCannedRemark(Optional ByVal DateFrom As String = "", Optional ByVal DateTo As String = "") As DataSet
            Return Me.DataAccess.GetTempCannedRemark(DateFrom, DateTo)
        End Function

    End Class
End Namespace

@


1.1.1.1
log
@no message
@
text
@@
