head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.20;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.20;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic

Namespace BusinessLogicLayer
    Public Class HotelFeeBLL

        Private DataAccess As DataAccessLayer.HotelFeeDAL

        Public Sub New()
            Me.DataAccess = New DataAccessLayer.HotelFeeDAL()
        End Sub

        Public Function GetHotelFeeByName(Optional ByVal Name As String = "")
            Return Me.DataAccess.GetHotelFeeByName(Name)
        End Function

        Public Function GetHotelName()
            Return Me.DataAccess.GetHotelFee()
        End Function

        Public Function DeleteHotelFee(ByVal Number As Integer)
            Return Me.DataAccess.DeleteHotelFee(Number)
        End Function

        Public Function InsertHotelFee(ByVal HotelFee As DataTable) As Integer
            Return Me.DataAccess.InsertFee(HotelFee)
        End Function

        Public Function GetFeeName()
            Return Me.DataAccess.GetFeeName()
        End Function

        Public Function GetClientFeeName(ByVal ClientID As String)
            Return Me.DataAccess.GetClientFeeName(ClientID)
        End Function

        Public Function SaveData(ByVal ClientID As Integer, ByVal FeeName As String) As Integer
            Return Me.DataAccess.SaveData(ClientID, FeeName)
        End Function

        Public Function UpdateHotelFee(ByVal HotelFee As DataTable)
            Return Me.DataAccess.UpdateHotelFee(HotelFee)
        End Function

        Public Function GetHotelByNumber(ByVal Number As Integer)
            Return Me.DataAccess.GetHotelByNumber(Number)
        End Function

        Public Function UpdateHotelFeeName(ByVal Number As Integer, ByVal FeeName As String) As Integer
            Return Me.DataAccess.UpdateHotelFeeName(Number, FeeName)
        End Function

        Public Function GetTempHotelFee(Optional ByVal HotelName As String = "", Optional ByVal DateFrom As String = "", Optional ByVal DateTo As String = "") As DataSet
            Return Me.DataAccess.GetTempHotelFee(HotelName, DateFrom, DateTo)
        End Function

        Public Function GetTempHotelClientFee(Optional ByVal Name As String = "", Optional ByVal DateFrom As String = "", Optional ByVal DateTo As String = "") As DataSet
            Return Me.DataAccess.GetTempClientHotelFee(Name, DateFrom, DateTo)
        End Function

    End Class
End Namespace@


1.1.1.1
log
@no message
@
text
@@
