head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.22;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.22;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic
Imports System.Collections.Generic

Namespace DataAccessLayer
    Public Class CompanyServiceDAL
        Inherits BaseDA

        Public Function GetServiceProgramList(ByVal Product As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .TableName = CWTMasterDB.Util.StandardDB("tblClientService")
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("Product", Product, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("SID")
                    .Add("isnull(Options,'No Option') as Options")
                End With
                dt = .ExecuteDataTable(.SQLSelect() + " order by Options")
            End With
            Return dt
        End Function

        Public Function GetCompanyServiceData(ByVal ClientID As String) As DataTable
            Dim dt As DataTable
            Dim oSql As String
            'oSql = "select * from (select distinct '' as SID,product,0 as status,IndexOrder from CWTStandardData.dbo.tblClientService " + _
            '    "where product not in (select product from tblClientServiceConfig where clientid=" + CWTMasterDB.Util.LimitTheString(ClientID) + ") " + _
            '    "union all " + _
            '    "select s.sid,s.product,c.status,s.IndexOrder from tblClientServiceConfig c " + _
            '    "inner join CWTStandardData.dbo.tblClientService s on c.sid=s.sid " + _
            '    "where clientid=" + CWTMasterDB.Util.LimitTheString(ClientID) + ") as SVList order by IndexOrder"

            oSql = "select Distinct * from ( " + _
                  "select Distinct p.Product,p.indexOrder,m.SID,m.Status from tblClientServiceConfig m " + _
                  "inner join CWTStandardData.dbo.tblClientService p on m.SID=p.sid " + _
                  "where m.ServiceDefault<>1 and  m.ClientID=" + CWTMasterDB.Util.LimitTheString(ClientID) + " " + _
                  "union all " + _
                  "select Distinct p.Product,p.indexOrder,m.SID,m.Status from tblClientServiceConfig m " + _
                  "inner join CWTStandardData.dbo.tblClientService p on m.SID=p.SID " + _
                  "where m.ServiceDefault=1 and m.SID not in " + _
                  "(select SID from tblClientServiceConfig " + _
                  "where ClientID=" + CWTMasterDB.Util.LimitTheString(ClientID) + ") and p.Product not in " + _
                  "(Select p.Product from tblClientServiceConfig m " + _
                  "inner join CWTStandardData.dbo.tblClientService p on m.SID=p.SID " + _
                  "where m.ClientID=" + CWTMasterDB.Util.LimitTheString(ClientID) + " )) as DumpList order by SID"

            dt = Me.MySQLParser.ExecuteDataTable(oSql)
            Return dt
        End Function

        Public Function UpdateCompanyService(ByVal info As DataInfo.CompanyServiceInfo) As Integer
            Dim EffectRow As Integer = 1
            Dim ClientServiceDT As DataTable
            Try
                ClientServiceDT = GetClientServiceConfig(info.ClientID)
                With Me.MySQLParser
                    .OpenConnection()
                    .BeginTran()
                    .TableName = "tblClientServiceConfig"
                    With .Columns
                        .Clear()
                        .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    End With
                    .ExecuteDelete()
                    '//
                    If EffectRow > 0 Then
                        '// 
                        .TableName = "tblClientServiceConfig"
                        For i As Integer = 0 To info.ProgramList.Count - 1
                            With .Columns
                                .Clear()
                                .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum)
                                .Add("SID", info.ProgramList(i).SID, SqlBuilder.SQLParserDataType.spNum)
                                .Add("Status", info.ProgramList(i).Status, SqlBuilder.SQLParserDataType.spBoolean)
                            End With
                            EffectRow = .ExecuteInsert()
                            If EffectRow <= 0 Then
                                Exit For
                            End If
                        Next
                    End If
                End With
                MatchClientServiceRecord(ClientServiceDT, info)
                If EffectRow > 0 Then
                    Me.MySQLParser.CommitTran()
                Else
                    Me.MySQLParser.RollbackTran()
                End If
            Catch ex As Exception
                EffectRow = -1
                Me.MySQLParser.RollbackTran()
            Finally
                Me.MySQLParser.CloseConnection()
            End Try
            Return EffectRow
        End Function

        Private Sub MatchClientServiceRecord(ByVal ClientServiceDT As DataTable, ByVal info As DataInfo.CompanyServiceInfo)
            Dim countDT As Integer
            Dim countInfo As Integer
            Dim effectRow As Integer
            Dim checkMatch As Boolean

            If ClientServiceDT.Rows.Count > 0 Then
                For countDT = 0 To ClientServiceDT.Rows.Count - 1
                    checkMatch = CheckClientServiceExists(ClientServiceDT.Rows(countDT), info)
                    If checkMatch = False Then

                        For countInfo = 0 To info.ProgramList.Count - 1
                            If ClientServiceDT.Rows(countDT).Item("ClientID").ToString() = info.ClientID And ClientServiceDT.Rows(countDT).Item("SID").ToString() = info.ProgramList(countInfo).SID Then
                                With Me.MySQLParser
                                    .TableName = "Temp_tblClientServiceConfig"
                                    With .Columns
                                        .Clear()
                                        .Add("ClientID", ClientServiceDT.Rows(countDT).Item("ClientID").ToString(), SqlBuilder.SQLParserDataType.spNum)
                                        .Add("SID", ClientServiceDT.Rows(countDT).Item("SID").ToString(), SqlBuilder.SQLParserDataType.spNum)
                                        .Add("Status", ClientServiceDT.Rows(countDT).Item("Status").ToString())
                                        .Add("DateModification", DateTime.Now)
                                        .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                        .Add("ValueTypeChanged", "Update")
                                    End With
                                    effectRow = .ExecuteInsert()

                                    'If ClientServiceDT.Rows(countDT).Item("SID").ToString() <> info.ProgramList(countInfo).SID Then
                                    '    .TableName = "Temp_tblClientServiceConfig"
                                    '    With .Columns
                                    '        .Clear()
                                    '        .Add("ClientID", info.ClientID.ToString(), SqlBuilder.SQLParserDataType.spNum)
                                    '        .Add("SID", info.ProgramList(countInfo).SID, SqlBuilder.SQLParserDataType.spNum)
                                    '        .Add("Status", info.ProgramList(countInfo).Status)
                                    '        .Add("DateModification", DateTime.Now)
                                    '        .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                    '        .Add("ValueTypeChanged", "Insert")
                                    '    End With
                                    '    effectRow = .ExecuteInsert()
                                    'End If
                                    Exit For
                                End With
                            End If
                        Next countInfo
                    End If
                Next countDT
            End If

            If info.ProgramList.Count > ClientServiceDT.Rows.Count Then
                For countInfo = countDT To info.ProgramList.Count - 1
                    With Me.MySQLParser
                        .TableName = "Temp_tblClientServiceConfig"
                        With .Columns
                            .Clear()
                            .Add("ClientID", info.ClientID.ToString(), SqlBuilder.SQLParserDataType.spNum)
                            .Add("SID", info.ProgramList(countInfo).SID, SqlBuilder.SQLParserDataType.spNum)
                            .Add("Status", info.ProgramList(countInfo).Status)
                            .Add("DateModification", DateTime.Now)
                            .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                            .Add("ValueTypeChanged", "Insert")
                        End With
                        effectRow = .ExecuteInsert()
                    End With
                Next countInfo
            End If
        End Sub



        Private Function CheckClientServiceExists(ByVal row As DataRow, ByVal info As DataInfo.CompanyServiceInfo) As Boolean
            Dim check As Boolean
            Dim countInfo As Integer

            For countInfo = 0 To info.ProgramList.Count - 1
                If row.Item("ClientID").ToString() = info.ClientID AndAlso row.Item("SID").ToString() = info.ProgramList(countInfo).SID AndAlso row.Item("Status").ToString() = info.ProgramList(countInfo).Status Then
                    check = True
                    Exit For
                End If
            Next countInfo

            Return check
        End Function

        Private Function GetClientServiceConfig(ByVal ClientID As String)
            Dim dt As DataTable
            With Me.MySQLParser
                .TableName = "tblClientServiceConfig"
                With .Columns
                    .Clear()
                    .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetTempClientServiceConfigInfo(Optional ByVal ClientName As String = "", Optional ByVal dateFrom As String = "", Optional ByVal dateTo As String = "") As DataSet
            '//Service Config DT
            Dim ServiceDT As DataTable
            Dim TempServiceDT As DataTable
            Dim ServiceMasterDT As DataTable

            Dim ClientID As String = ""
            Dim TempTable As DataTable
            Dim ClientIDArr(1) As String
            Dim count As Integer
            Dim count2 As Integer
            Dim ds As New DataSet
            Dim foundRow() As DataRow

            ClientIDArr(0) = "ClientID"
            ClientIDArr(1) = "SID"

            '//Get ClientID 
            If ClientName <> "" Then
                ClientID = GetClientIDByName(ClientName)
            End If

            With Me.MySQLParser
                .TableName = "Temp_tblClientServiceConfig c inner join " + CWTMasterDB.Util.StandardDB("tblClientService") + " s on c.SID=s.SID"
                With .Columns
                    .Clear()
                    If ClientName <> "" Then
                        If ClientID <> "" Then
                            .Add("c.ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        Else
                            .Add("c.ClientID", "-1", SqlBuilder.SQLParserDataType.spNum, True)
                        End If
                    End If
                    If dateFrom = dateTo Then
                        If dateFrom <> "" And dateTo <> "" Then
                            dateTo = dateTo + " 23:59:59:990"
                            .Add("c.DateModification", "convert(varchar,cast('" + dateFrom + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, ">")
                            .Add("c.DateModification", "convert(varchar,cast('" + dateTo + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, "<")
                        End If
                    Else
                        If dateFrom <> "" Then
                            .Add("c.DateModification", dateFrom, SqlBuilder.SQLParserDataType.spDate, True, ">")
                        End If
                        If dateTo <> "" Then
                            dateTo = dateTo + " 23:59:59:990"
                            .Add("c.DateModification", dateTo, SqlBuilder.SQLParserDataType.spText, True, "<=")
                        End If
                    End If
                    .Add("c.ClientID,s.SID,s.Product As ServiceName,c.Status,s.Options,c.DateModification,c.UserName,c.ValueTypeChanged")
                End With
                TempServiceDT = .ExecuteDataTable(.SQLSelect + " order by DateModification Desc")

                .TableName = "tblClientServiceConfig c inner join " + CWTMasterDB.Util.StandardDB("tblClientService") + " s on c.SID=s.SID"
                With .Columns
                    .Clear()
                    If ClientName <> "" Then
                        If ClientID <> "" Then
                            .Add("c.ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        Else
                            .Add("c.ClientID", "-1", SqlBuilder.SQLParserDataType.spNum, True)
                        End If
                    End If
                    .Add("c.ClientID,s.SID,s.Product As ServiceName,c.Status,s.Options")
                End With
                ServiceDT = .ExecuteDataTable()

                TempTable = TempServiceDT.DefaultView.ToTable(True, ClientIDArr)
                ServiceMasterDT = TempServiceDT.Clone()
                For count = 0 To TempTable.Rows.Count - 1
                    foundRow = ServiceDT.Select("ClientID='" + TempTable.Rows(count).Item("ClientID").ToString() + "' and SID='" + TempTable.Rows(count).Item("SID").ToString() + "'")
                    If foundRow.Length > 0 Then
                        For count2 = 0 To foundRow.Length - 1
                            ServiceMasterDT.ImportRow(foundRow(count2))
                        Next count2
                    End If
                Next
                ServiceMasterDT.AcceptChanges()
                ServiceMasterDT.Merge(TempServiceDT)
                ServiceMasterDT.TableName = "Service"
                ds.Tables.Add(ServiceMasterDT)
            End With
            Return ds
        End Function

        Public Function GetClientIDByName(ByVal ClientName As String) As String
            Dim retVal As String
            Dim retObj As Object
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblClientMaster"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("Name", ClientName, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("ClientID")
                End With
                retObj = .ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar, CommandType.Text)
                retVal = Util.DBNullToText(retObj)
            End With
            Return retVal
        End Function
    End Class
End Namespace

@


1.1.1.1
log
@no message
@
text
@@
