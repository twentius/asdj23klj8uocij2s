head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.20;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.20;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic
Imports System.Collections.Generic

Namespace DataAccessLayer
    Public Class CompanyAuxPriceDAL
        Inherits BaseDA

        Public Function GetAuxPricingList(ByVal ClientID As String, ByVal Name As String, ByVal ProductID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblAuxFee"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    If Name <> "" Then
                        .Add("FeeName", "%" + Name + "%", SqlBuilder.SQLParserDataType.spText, True, "LIKE")
                    End If
                    If ProductID <> "" Then
                        .Add("ApplytoProduct", ProductID, SqlBuilder.SQLParserDataType.spNum, True)
                    End If
                    .Add("*")
                    .Add("AuxFeeID", "(select AuxFeeID from tblAuxClientFee where ClientID=" + Util.LimitTheString(ClientID) + ")", SqlBuilder.SQLParserDataType.spFunction, True, "Not in")
                    .Add("(select top 1 p.[Name] from tblProducts p where p.[Number]=FeeProduct) as FeeProductName")
                    .Add("isnull((select top 1 v.VendorName from tblVendors v where v.VendorNumber=FeeVendorNumber),'All') as FeeVendorName")
                    .Add("(select top 1 p.[Name] from tblProducts p where p.[Number]=ApplytoProduct) as ApplytoProductName")
                    .Add("isnull((select top 1 v.[VendorName] from tblVendors v where v.VendorNumber=ApplytoVendor),'All') as ApplytoVendorName")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetSelectedAuxPricingByID(ByVal ClientID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblAuxClientFee c inner join tblAuxFee f on c.AuxFeeID=f.AuxFeeID"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("c.ClientID", ClientID, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("f.*")
                    .Add("(select top 1 p.[Name] from tblProducts p where p.[Number]=f.FeeProduct) as FeeProductName")
                    .Add("isnull((select top 1 v.VendorName from tblVendors v where v.VendorNumber=f.FeeVendorNumber),'All') as FeeVendorName")
                    .Add("(select top 1 p.[Name] from tblProducts p where p.[Number]=f.ApplytoProduct) as ApplytoProductName")
                    .Add("isnull((select top 1 v.[VendorName] from tblVendors v where v.VendorNumber=f.ApplytoVendor),'All') as ApplytoVendorName")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function UpdateSelectedItem(ByVal ClientID As String, ByVal ItemList As List(Of String)) As Integer
            Dim EffectRow As Integer = 1
            Try
                With Me.MySQLParser
                    .TableName = "tblAuxClientFee"
                    For i As Integer = 0 To ItemList.Count - 1
                        With .Columns
                            .Clear()
                            .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum)
                            .Add("AuxFeeID", ItemList(i), SqlBuilder.SQLParserDataType.spNum)
                        End With
                        EffectRow = .ExecuteInsert()
                        If EffectRow <= 0 Then
                            Exit For
                        End If
                        CallProcedure(ClientID, ItemList(i), "Insert", "sp_AuxClientFee")
                    Next
                End With
            Catch ex As Exception
                EffectRow = -1
            End Try
            Return EffectRow
        End Function

        Public Function DeleteItem(ByVal ClientID As String, ByVal AuxFeeID As String) As Integer
            Dim EffectRow As Integer = 1
            Try
                With Me.MySQLParser
                    .TableName = "tblAuxClientFee"
                    With .Columns
                        .Clear()
                        .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        .Add("AuxFeeID", AuxFeeID, SqlBuilder.SQLParserDataType.spNum, True)
                    End With
                    CallProcedure(ClientID, AuxFeeID, "Delete", "sp_AuxClientFee")
                    .ExecuteDelete()
                End With
            Catch ex As Exception
                EffectRow = -1
            End Try
            Return EffectRow
        End Function

        Public Function UpdateAuxPrice(ByVal info As DataInfo.AuxFeeInfo) As Integer
            Dim EffectRow As Integer
            Try
                With Me.MySQLParser
                    .TableName = "tblAuxFee"
                    With .Columns
                        .Clear()
                        If info.ID <> "" Then .Add("AuxFeeID", info.ID, SqlBuilder.SQLParserDataType.spNum, True)
                        .Add("FeeName", info.Name)
                        If info.PageMode = CWTMasterDB.TransactionMode.AddNewMode Then
                            .Add("ApplytoProduct", info.ApplyProduct, SqlBuilder.SQLParserDataType.spNum)
                            .Add("ApplytoVendor", info.ApplyVendor, SqlBuilder.SQLParserDataType.spText)
                        End If
                        .Add("FeeAmount", info.FeeAmount, SqlBuilder.SQLParserDataType.spNum)
                        .Add("FeeCommission", info.FeeAmount, SqlBuilder.SQLParserDataType.spNum)
                        .Add("FeeProduct", info.FeeProduct, SqlBuilder.SQLParserDataType.spNum)
                        .Add("FeeVendorNumber", info.FeeVendor, SqlBuilder.SQLParserDataType.spText)
                    End With

                    Select Case info.PageMode
                        Case CWTMasterDB.TransactionMode.AddNewMode
                            EffectRow = .ExecuteInsert()
                            info.ID = GetAuxFeeID()
                            CallProcedure("", info.ID, "Insert", "sp_AuxFee")
                        Case CWTMasterDB.TransactionMode.UpdateMode
                            CallProcedure("", info.ID, "Update", "sp_AuxFee")
                            EffectRow = .ExecuteUpdate()
                    End Select
                End With
            Catch ex As Exception
                EffectRow = -1
            End Try
            Return EffectRow
        End Function

        Private Sub CallProcedure(ByVal ClientID As String, ByVal AuxFeeID As String, ByVal Type As String, ByVal StoreProdType As String)
            With Me.MySQLParser
                If StoreProdType = "sp_AuxFee" Then
                    .ExecuteStoreProcedure("exec " + StoreProdType + " '" + AuxFeeID + "','" + ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName + "','" + Type + "'")
                Else
                    .ExecuteStoreProcedure("exec " + StoreProdType + " '" + AuxFeeID + "','" + ClientID + "','" + ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName + "','" + Type + "'")
                End If

            End With
        End Sub

        Public Function GetTempAuxFeeInfo(Optional ByVal ClientName As String = "", Optional ByVal dateFrom As String = "", Optional ByVal dateTo As String = "") As DataSet
            '//Aux Fee DT
            Dim AuxFeeDT As DataTable
            Dim TempAuxFeeDT As DataTable
            Dim AuxFeeMasterDT As DataTable

            Dim ClientID As String = ""
            Dim TempTable As DataTable
            Dim ClientIDArr(1) As String
            Dim count As Integer
            Dim count2 As Integer
            Dim ds As New DataSet
            Dim foundRow() As DataRow

            ClientIDArr(0) = "ClientID"
            ClientIDArr(1) = "FeeName"

            '//Get ClientID 
            If ClientName <> "" Then
                ClientID = GetClientIDByName(ClientName)
            End If
            With Me.MySQLParser
                .TableName = "Temp_tblAuxClientFee c inner join tblAuxFee f on c.AuxFeeID=f.AuxFeeID"
                With .Columns
                    .Clear()
                    If ClientName <> "" Then
                        If ClientID <> "" Then
                            .Add("c.ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        Else
                            .Add("c.ClientID", "-1", SqlBuilder.SQLParserDataType.spNum, True)
                        End If
                    End If
                    If dateFrom = dateTo Then
                        If dateFrom <> "" And dateTo <> "" Then
                            dateTo = dateTo + " 23:59:59:990"
                            .Add("c.DateModification", "convert(varchar,cast('" + dateFrom + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, ">")
                            .Add("c.DateModification", "convert(varchar,cast('" + dateTo + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, "<")
                        End If
                    Else
                        If dateFrom <> "" Then
                            .Add("c.DateModification", dateFrom, SqlBuilder.SQLParserDataType.spDate, True, ">")
                        End If
                        If dateTo <> "" Then
                            dateTo = dateTo + " 23:59:59:990"
                            .Add("DateModification", dateTo, SqlBuilder.SQLParserDataType.spText, True, "<=")
                        End If
                    End If
                    .Add("c.ClientID,f.FeeName,c.DateModification,c.UserName,c.ValueTypeChanged")
                End With
                TempAuxFeeDT = .ExecuteDataTable(.SQLSelect + " order by DateModification Desc")

                .TableName = "tblAuxClientFee c inner join tblAuxFee f on c.AuxFeeID=f.AuxFeeID"
                With .Columns
                    .Clear()
                    If ClientName <> "" Then
                        If ClientID <> "" Then
                            .Add("c.ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        Else
                            .Add("c.ClientID", "-1", SqlBuilder.SQLParserDataType.spNum, True)
                        End If
                    End If
                    .Add("c.ClientID,f.FeeName")
                End With
                AuxFeeDT = .ExecuteDataTable()

                TempTable = TempAuxFeeDT.DefaultView.ToTable(True, ClientIDArr)
                AuxFeeMasterDT = TempAuxFeeDT.Clone()
                For count = 0 To TempTable.Rows.Count - 1
                    foundRow = AuxFeeDT.Select("ClientID='" + TempTable.Rows(count).Item("ClientID").ToString() + "' and FeeName='" + TempTable.Rows(count).Item("FeeName").ToString() + "'")
                    If foundRow.Length > 0 Then
                        For count2 = 0 To foundRow.Length - 1
                            AuxFeeMasterDT.ImportRow(foundRow(count2))
                        Next count2
                    End If
                Next
                AuxFeeMasterDT.AcceptChanges()
                AuxFeeMasterDT.Merge(TempAuxFeeDT)
                AuxFeeMasterDT.TableName = "AuxFee"
                ds.Tables.Add(AuxFeeMasterDT)
            End With
            Return ds
        End Function

        Public Function GetClientIDByName(ByVal ClientName As String) As String
            Dim retVal As String
            Dim retObj As Object
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblClientMaster"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("Name", ClientName, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("ClientID")
                End With
                retObj = .ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar, CommandType.Text)
                retVal = Util.DBNullToText(retObj)
            End With
            Return retVal
        End Function

        Private Function GetAuxFeeID() As String
            Dim AuxFeeID As String
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblAuxFee"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("max(AuxFeeID)")
                End With
                AuxFeeID = .ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar, CommandType.Text)
            End With
            Return AuxFeeID
        End Function
    End Class
End Namespace

@


1.1.1.1
log
@no message
@
text
@@
