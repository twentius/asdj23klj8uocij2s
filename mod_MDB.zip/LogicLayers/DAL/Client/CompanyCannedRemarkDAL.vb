head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.20;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.20;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic
Imports System.Collections.Generic

Namespace DataAccessLayer
    Public Class CompanyCannedRemarkDAL
        Inherits BaseDA

        Public Function GetCannedRemark(ByVal clientId As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblClientCannedRemark cr inner join tblClientMaster cm on cr.ClientID = cm.ClientID"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("cr.ClientID", clientId, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("cr.*,cm.ClientCannedRemark As ApplyStandard")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetStandardRemark(ByVal ClientID As String) As Boolean
            Dim retVal As Boolean
            With Me.MySQLParser
                .TableName = "tblClientMaster"
                With .Columns
                    .Clear()
                    .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("ClientCannedRemark")
                End With
                retVal = CWTMasterDB.Util.DBNullToFalse(.ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar))
            End With
            Return retVal
        End Function

        Private Sub CallProcedure(ByVal ClientID As String, ByVal Type As String, ByVal StoreProdType As String)
            With Me.MySQLParser
                .ExecuteStoreProcedure("exec " + StoreProdType + " '" + ClientID + "','" + ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName + "','" + Type + "'")
            End With
        End Sub
        Public Function UpdateCannedRemark(ByVal info As DataInfo.CompanyCannedRemarkInfo) As Integer
            Dim EffectRow As Integer = 1
            Dim ClientRemark As DataTable
            Dim boolApplyStandard As Boolean = False
            Try
                ClientRemark = GetCannedRemark(info.ClientID)
                boolApplyStandard = GetStandardRemark(info.ClientID)

                With Me.MySQLParser
                    .OpenConnection()
                    .BeginTran()
                    .TableName = "tblClientCannedRemark"
                    With .Columns
                        .Clear()
                        .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    End With
                    .ExecuteDelete()
                    .TableName = "tblClientMaster"
                    With .Columns
                        .Clear()
                        .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        .Add("ClientCannedRemark", info.ApplyStd, SqlBuilder.SQLParserDataType.spBoolean)
                    End With
                    'CallProcedure(info.ClientID, "Update", "sp_ClientMaster")
                    .ExecuteUpdate()
                    '//
                    If EffectRow > 0 Then
                        '// 
                        .TableName = "tblClientCannedRemark"
                        For i As Integer = 0 To info.Remarks.Count - 1
                            With .Columns
                                .Clear()
                                .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum)
                                .Add("CCRID", i + 1, SqlBuilder.SQLParserDataType.spNum)
                                .Add("LoadtoPNR", info.Remarks(i).LoadToPNR, SqlBuilder.SQLParserDataType.spBoolean)
                                .Add("CannedRemark", info.Remarks(i).Remark, , , , True)
                            End With
                            EffectRow = .ExecuteInsert()
                            If EffectRow <= 0 Then
                                Exit For
                            End If
                        Next
                    End If
                End With
                MatchClientRemark(ClientRemark, info, boolApplyStandard)
                If EffectRow > 0 Then
                    Me.MySQLParser.CommitTran()
                Else
                    Me.MySQLParser.RollbackTran()
                End If
            Catch ex As Exception
                EffectRow = -1
                Me.MySQLParser.RollbackTran()
            Finally
                Me.MySQLParser.CloseConnection()
            End Try
            Return EffectRow
        End Function

        Private Sub MatchClientRemark(ByVal ClientRemarkDT As DataTable, ByVal info As DataInfo.CompanyCannedRemarkInfo, ByVal boolApplyStandard As Boolean)
            Dim countInfo As Integer
            Dim countDT As Integer
            Dim checkMatch As Boolean
            Dim effectRow As Integer

            If ClientRemarkDT.Rows.Count > 0 Then
                For countDT = 0 To ClientRemarkDT.Rows.Count - 1
                    checkMatch = CheckClientRemarkExist(ClientRemarkDT.Rows(countDT), info)
                    If checkMatch = False Then
                        For countInfo = 0 To info.Remarks.Count - 1
                            If ClientRemarkDT.Rows(countDT).Item("CCRID").ToString() = countInfo + 1 AndAlso ClientRemarkDT.Rows(countDT).Item("ClientID").ToString() = info.ClientID Then
                                With Me.MySQLParser
                                    .TableName = "Temp_tblClientCannedRemark"
                                    With .Columns
                                        .Clear()
                                        .Add("CCRID", ClientRemarkDT.Rows(countDT).Item("CCRID").ToString(), SqlBuilder.SQLParserDataType.spNum)
                                        .Add("ClientID", ClientRemarkDT.Rows(countDT).Item("ClientID").ToString(), SqlBuilder.SQLParserDataType.spNum)
                                        .Add("LoadtoPNR", ClientRemarkDT.Rows(countDT).Item("LoadtoPNR").ToString())
                                        .Add("CannedRemark", ClientRemarkDT.Rows(countDT).Item("CannedRemark").ToString(), SqlBuilder.SQLParserDataType.spText)
                                        .Add("ApplyStandard", ClientRemarkDT.Rows(countDT).Item("ApplyStandard").ToString(), SqlBuilder.SQLParserDataType.spBoolean)
                                        .Add("DateModification", DateTime.Now)
                                        .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                        .Add("ValueTypeChanged", "Update")
                                    End With
                                    effectRow = .ExecuteInsert()
                                    Exit For
                                End With
                            End If
                        Next countInfo

                        If ClientRemarkDT.Rows.Count > info.Remarks.Count Then
                            With Me.MySQLParser
                                .TableName = "Temp_tblClientCannedRemark"
                                With .Columns
                                    .Clear()
                                    .Add("CCRID", ClientRemarkDT.Rows(countDT).Item("CCRID").ToString(), SqlBuilder.SQLParserDataType.spNum)
                                    .Add("ClientID", ClientRemarkDT.Rows(countDT).Item("ClientID").ToString(), SqlBuilder.SQLParserDataType.spNum)
                                    .Add("LoadtoPNR", ClientRemarkDT.Rows(countDT).Item("LoadtoPNR").ToString())
                                    .Add("CannedRemark", ClientRemarkDT.Rows(countDT).Item("CannedRemark").ToString(), SqlBuilder.SQLParserDataType.spText)
                                    .Add("ApplyStandard", ClientRemarkDT.Rows(countDT).Item("ApplyStandard").ToString(), SqlBuilder.SQLParserDataType.spBoolean)
                                    .Add("DateModification", DateTime.Now)
                                    .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                    .Add("ValueTypeChanged", "Delete")
                                End With
                                effectRow = .ExecuteInsert()
                            End With
                        End If
                    End If
                Next countDT
            End If

            If info.Remarks.Count > ClientRemarkDT.Rows.Count Then
                For countInfo = countDT To info.Remarks.Count - 1
                    With Me.MySQLParser
                        .TableName = "Temp_tblClientCannedRemark"
                        With .Columns
                            .Clear()
                            .Add("CCRID", countInfo + 1, SqlBuilder.SQLParserDataType.spNum)
                            .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum)
                            .Add("LoadtoPNR", info.Remarks(countInfo).LoadToPNR)
                            .Add("CannedRemark", info.Remarks(countInfo).Remark, SqlBuilder.SQLParserDataType.spText)
                            .Add("ApplyStandard", info.ApplyStd, SqlBuilder.SQLParserDataType.spBoolean)
                            .Add("DateModification", DateTime.Now)
                            .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                            .Add("ValueTypeChanged", "Insert")
                        End With
                        effectRow = .ExecuteInsert()
                    End With
                Next countInfo
            End If

            'If GetStandardRemark(info.ClientID) Then
            '    For countInfo = 0 To info.Remarks.Count - 1
            '        With Me.MySQLParser
            '            .TableName = "Temp_tblClientCannedRemark"
            '            With .Columns
            '                .Clear()
            '                .Add("CCRID", countInfo + 1, SqlBuilder.SQLParserDataType.spNum)
            '                .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum)
            '                .Add("LoadtoPNR", info.Remarks(countInfo).LoadToPNR)
            '                .Add("CannedRemark", info.Remarks(countInfo).Remark, SqlBuilder.SQLParserDataType.spText)
            '                .Add("DateModification", DateTime.Now)
            '                .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
            '                .Add("ValueTypeChanged", "Insert")
            '            End With
            '            effectRow = .ExecuteInsert()
            '        End With
            '    Next countInfo
            'End If

            'If GetStandardRemark(info.ClientID) Then
            '    For countInfo = 0 To info.Remarks.Count - 1
            '        With Me.MySQLParser
            '            .TableName = "Temp_tblClientCannedRemark"
            '            With .Columns
            '                .Clear()
            '                .Add("CCRID", countInfo + 1, SqlBuilder.SQLParserDataType.spNum)
            '                .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum)
            '                .Add("LoadtoPNR", info.Remarks(countInfo).LoadToPNR)
            '                .Add("CannedRemark", info.Remarks(countInfo).Remark, SqlBuilder.SQLParserDataType.spText)
            '                .Add("DateModification", DateTime.Now)
            '                .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
            '                .Add("ValueTypeChanged", "Delete")
            '            End With
            '            effectRow = .ExecuteInsert()
            '        End With
            '    Next countInfo
            'End If
            If boolApplyStandard <> info.ApplyStd Then
                CheckApplyStd(info.ClientID, boolApplyStandard)
            End If

        End Sub

        Private Sub CheckApplyStd(ByVal ClientID As String, ByVal Apply As Boolean)
            Dim effectRow As Integer
            With Me.MySQLParser
                .TableName = "Temp_tblClientCannedRemark"
                With .Columns
                    .Clear()
                    .Add("CCRID", 1, SqlBuilder.SQLParserDataType.spNum)
                    .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum)
                    .Add("ApplyStandard", Apply, SqlBuilder.SQLParserDataType.spBoolean)
                    .Add("DateModification", DateTime.Now)
                    .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                    .Add("ValueTypeChanged", "Update")
                End With
                effectRow = .ExecuteInsert()
            End With
        End Sub

        Private Function CheckClientRemarkExist(ByVal row As DataRow, ByVal info As DataInfo.CompanyCannedRemarkInfo)
            Dim countInfo As Integer
            Dim check As Boolean
            For countInfo = 0 To info.Remarks.Count - 1
                If row.Item("CCRID").ToString() = countInfo + 1 AndAlso row.Item("ClientID").ToString() = info.ClientID AndAlso row.Item("LoadtoPNR").ToString() = info.Remarks(countInfo).LoadToPNR AndAlso row.Item("CannedRemark").ToString() = info.Remarks(countInfo).Remark Then
                    check = True
                    Exit For
                End If
            Next countInfo
            Return check
        End Function

        Public Function GetTempCannedRemarkInfo(Optional ByVal ClientName As String = "", Optional ByVal dateFrom As String = "", Optional ByVal dateTo As String = "") As DataSet
            '//Canned Remark
            Dim RemarkDT As DataTable
            Dim TempRemarkDT As DataTable
            Dim RemarkMasterDT As DataTable
            Dim ClientMasterDT As DataTable

            Dim ClientID As String = ""
            Dim TempTable As DataTable
            Dim ClientIDArr(1) As String
            Dim count As Integer
            Dim count2 As Integer
            Dim countClient As Integer
            Dim ds As New DataSet
            Dim foundRow() As DataRow

            ClientIDArr(0) = "ClientID"
            ClientIDArr(1) = "CCRID"
            '//Get ClientID 
            If ClientName <> "" Then
                ClientID = GetClientIDByName(ClientName)
            End If

            With Me.MySQLParser
                .TableName = "Temp_tblClientCannedRemark"
                With .Columns
                    .Clear()
                    If ClientName <> "" Then
                        If ClientID <> "" Then
                            .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        Else
                            .Add("ClientID", "-1", SqlBuilder.SQLParserDataType.spNum, True)
                        End If
                    End If
                    If dateFrom = dateTo Then
                        If dateFrom <> "" And dateTo <> "" Then
                            dateTo = dateTo + " 23:59:59:990"
                            .Add("DateModification", "convert(varchar,cast('" + dateFrom + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, ">")
                            .Add("DateModification", "convert(varchar,cast('" + dateTo + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, "<")
                        End If
                    Else
                        If dateFrom <> "" Then
                            .Add("DateModification", dateFrom, SqlBuilder.SQLParserDataType.spDate, True, ">")
                        End If
                        If dateTo <> "" Then
                            dateTo = dateTo + " 23:59:59:990"
                            .Add("DateModification", dateTo, SqlBuilder.SQLParserDataType.spText, True, "<=")
                        End If
                    End If
                    .Add("*")
                End With
                TempRemarkDT = .ExecuteDataTable(.SQLSelect + " order by DateModification Desc")

                .TableName = "tblClientCannedRemark cr inner join tblClientMaster cm on cr.ClientID = cm.ClientID"
                With .Columns
                    .Clear()
                    If ClientName <> "" Then
                        If ClientID <> "" Then
                            .Add("cr.ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        Else
                            .Add("cr.ClientID", "-1", SqlBuilder.SQLParserDataType.spNum, True)
                        End If
                    End If
                    '.Add("cr.CCRID,cm.ClientID,cr.LoadtoPNR,cr.CannedRemark,cm.ClientCannedRemark As ApplyStandard")
                    .Add("cr.*,cm.ClientCannedRemark As ApplyStandard")
                End With
                RemarkDT = .ExecuteDataTable()



                .TableName = "tblClientMaster"
                With .Columns
                    .Clear()
                    If ClientName <> "" Then
                        If ClientID <> "" Then
                            .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        Else
                            .Add("ClientID", "-1", SqlBuilder.SQLParserDataType.spNum, True)
                        End If
                    End If
                    '.Add("cr.CCRID,cm.ClientID,cr.LoadtoPNR,cr.CannedRemark,cm.ClientCannedRemark As ApplyStandard")
                    .Add("ClientID,ClientCannedRemark")
                End With
                ClientMasterDT = .ExecuteDataTable()

                TempTable = TempRemarkDT.DefaultView.ToTable(True, ClientIDArr)
                RemarkMasterDT = TempRemarkDT.Clone()
                For count = 0 To TempTable.Rows.Count - 1
                    foundRow = RemarkDT.Select("ClientID='" + TempTable.Rows(count).Item("ClientID").ToString() + "' and CCRID='" + TempTable.Rows(count).Item("CCRID").ToString() + "'")
                    If foundRow.Length > 0 Then
                        For count2 = 0 To foundRow.Length - 1
                            RemarkMasterDT.ImportRow(foundRow(count2))
                        Next count2
                    ElseIf foundRow.Length = 0 Then 'And TempTable.Rows(count).Item("CCRID").ToString() = "1" 
                        If ClientMasterDT.Rows.Count > 0 Then
                            Dim Row As DataRow = RemarkMasterDT.NewRow()
                            Row("CCRID") = TempTable.Rows(count).Item("CCRID").ToString()
                            Row("ClientID") = TempTable.Rows(count).Item("ClientID").ToString()
                            Row("LoadtoPNR") = False
                            Row("CannedRemark") = ""
                            For countClient = 0 To ClientMasterDT.Rows.Count - 1
                                If TempTable.Rows(count).Item("ClientID").ToString() = ClientMasterDT.Rows(countClient)("ClientID").ToString() Then
                                    Row("ApplyStandard") = ClientMasterDT.Rows(countClient)(1).ToString()
                                    Exit For
                                End If
                            Next countClient
                            RemarkMasterDT.Rows.Add(Row)
                        End If
                       
                    End If
                Next
                RemarkMasterDT.AcceptChanges()
                RemarkMasterDT.Merge(TempRemarkDT)
                RemarkMasterDT.TableName = "Remark"
                ds.Tables.Add(RemarkMasterDT)
            End With
            Return ds
        End Function

        Public Function GetClientIDByName(ByVal ClientName As String) As String
            Dim retVal As String
            Dim retObj As Object
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblClientMaster"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("Name", ClientName, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("ClientID")
                End With
                retObj = .ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar, CommandType.Text)
                retVal = Util.DBNullToText(retObj)
            End With
            Return retVal
        End Function
    End Class
End Namespace

@


1.1.1.1
log
@no message
@
text
@@
