head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.22;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.22;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic
Imports System.Collections.Generic

Namespace DataAccessLayer
    Public Class CompanyPolicyDAL
        Inherits BaseDA

#Region "Air"
        Public Function GetAirClassList() As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .TableName = CWTMasterDB.Util.StandardDB("tblClassCode")
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("*")
                End With
                dt = .ExecuteDataTable(.SQLSelect() + " order by ClassDescription")
            End With
            Return dt
        End Function

        Public Function GetAirPolicyData(ByVal ClientID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .TableName = "tblAirPolicy"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("*")
                End With
                dt = .ExecuteDataTable(.SQLSelect() + " order by AirPolicyID")
            End With
            Return dt
        End Function

        Public Function GetAirClassData(ByVal ClientID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .TableName = "tblAirClass"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("*")
                End With
                dt = .ExecuteDataTable(.SQLSelect() + " order by AirClassID")
            End With
            Return dt
        End Function

        Public Function UpdateAirPolicy(ByVal info As DataInfo.CompanyPolicyInfo) As Integer
            Dim EffectRow As Integer = 1
            Dim AirPolicyDt As New DataTable
            Dim AirClassDt As New DataTable
            Try
                AirClassDt = GetAirClass(info.ClientID)
                With Me.MySQLParser
                    '//
                    If info.CurrentWebMode = DataInfo.CompanyPolicyInfo.WebMode.ClassPolicy Then
                        .TableName = "tblAirClass"
                        With .Columns
                            .Clear()
                            .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        End With
                        .ExecuteDelete()
                        '// 
                        .TableName = "tblAirClass"
                        For i As Integer = 0 To info.AirClassList.Count - 1
                            With .Columns
                                .Clear()
                                .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum)
                                .Add("AirClassID", i + 1, SqlBuilder.SQLParserDataType.spNum)
                                .Add("TravelerType", info.AirClassList(i).TravellerType)
                                If info.AirClassList(i).TimeOperator = DataInfo.CompanyPolicyInfo.MathOperator.Between.ToString Then
                                    .Add("FlyingTime", info.AirClassList(i).StFlyTime)
                                End If
                                .Add("FlyingEndTime", info.AirClassList(i).EndFlyTime)
                                .Add("FlyingTimeType", info.AirClassList(i).TimeOperator, SqlBuilder.SQLParserDataType.spText, False, , True)
                                .Add("AirClass", info.AirClassList(i).PreferredClass)
                                .Add("Remarks", info.AirClassList(i).Remark)
                            End With
                            EffectRow = .ExecuteInsert()
                            If EffectRow <= 0 Then
                                Exit For
                            End If
                        Next
                    Else
                        AirPolicyDt = GetAirPolicy(info.ClientID)
                        .TableName = "tblAirPolicy"
                        With .Columns
                            .Clear()
                            .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        End With
                        .ExecuteDelete()
                        '//
                        .TableName = "tblAirPolicy"
                        For i As Integer = 0 To info.PolicyLines.Count - 1
                            With .Columns
                                .Clear()
                                .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum)
                                .Add("AirPolicyID", i + 1, SqlBuilder.SQLParserDataType.spNum)
                                .Add("PolicyLine", info.PolicyLines(i))
                            End With
                            EffectRow = .ExecuteInsert()
                            If EffectRow <= 0 Then
                                Exit For
                            End If
                        Next

                    End If
                End With

                If info.CurrentWebMode = DataInfo.CompanyPolicyInfo.WebMode.ClassPolicy Then
                    MatchRecord(AirClassDt, info, "AirClass")
                Else
                    MatchRecord(AirPolicyDt, info, "Policy")
                End If
                If EffectRow > 0 Then
                    Me.MySQLParser.CommitTran()
                Else
                    Me.MySQLParser.RollbackTran()
                End If
            Catch ex As Exception
                EffectRow = -1
                Me.MySQLParser.RollbackTran()
            Finally
                Me.MySQLParser.CloseConnection()
            End Try
            Return EffectRow
        End Function

        Private Function GetAirPolicy(ByVal ClientID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .TableName = "tblAirPolicy"
                With .Columns
                    .Clear()
                    .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Private Function GetAirClass(ByVal ClientID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .TableName = "tblAirClass"
                With .Columns
                    .Clear()
                    .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Private Sub MatchRecord(ByRef AirDT As DataTable, ByRef info As DataInfo.CompanyPolicyInfo, ByVal Type As String)
            Dim countDt As Integer
            Dim countInfo As Integer
            Dim checkMatch As Boolean
            Dim effectRow As Integer

            If AirDT.Rows.Count > 0 Then
                For countDt = 0 To AirDT.Rows.Count - 1
                    If Type = "Policy" Then
                        checkMatch = CheckExist(AirDT.Rows(countDt), info, "Policy")
                        If checkMatch = False Then
                            For countInfo = 0 To info.PolicyLines.Count - 1
                                If AirDT.Rows(countDt).Item("AirPolicyID") = countInfo + 1 And AirDT.Rows(countDt).Item("ClientID") = info.ClientID Then
                                    With Me.MySQLParser
                                        .TableName = "Temp_tblAirPolicy"
                                        With .Columns
                                            .Clear()
                                            .IncludeKey = False
                                            .Add("AirPolicyID", countInfo + 1, SqlBuilder.SQLParserDataType.spNum)
                                            .Add("ClientID", AirDT.Rows(countDt).Item("ClientID").ToString())
                                            .Add("PolicyLine", AirDT.Rows(countDt).Item("PolicyLine").ToString())
                                            .Add("DateModification", DateTime.Now)
                                            .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                            .Add("ValueTypeChanged", "Update")
                                        End With
                                        effectRow = .ExecuteInsert()
                                    End With
                                    Exit For
                                Else
                                    If AirDT.Rows.Count > info.PolicyLines.Count Then
                                        With Me.MySQLParser
                                            .TableName = "Temp_tblAirPolicy"
                                            With .Columns
                                                .Clear()
                                                .IncludeKey = False
                                                .Add("AirPolicyID", AirDT.Rows(countDt).Item("AirPolicyID").ToString(), SqlBuilder.SQLParserDataType.spNum)
                                                .Add("ClientID", AirDT.Rows(countDt).Item("ClientID").ToString())
                                                .Add("PolicyLine", AirDT.Rows(countDt).Item("PolicyLine").ToString())
                                                .Add("DateModification", DateTime.Now)
                                                .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                                .Add("ValueTypeChanged", "Delete")
                                            End With
                                            effectRow = .ExecuteInsert()
                                            Exit For
                                        End With
                                    End If
                                End If
                            Next countInfo
                          
                        End If

                        'AirClass
                    ElseIf Type = "AirClass" Then
                        checkMatch = CheckExist(AirDT.Rows(countDt), info, "AirClass")
                        If checkMatch = False Then
                            For countInfo = 0 To info.AirClassList.Count - 1
                                If AirDT.Rows(countDt).Item("AirClassID") = countInfo + 1 And AirDT.Rows(countDt).Item("ClientID") = info.ClientID Then
                                    With Me.MySQLParser
                                        .TableName = "Temp_tblAirClass"
                                        With .Columns
                                            .Clear()
                                            .IncludeKey = False
                                            .Add("AirClassID", countInfo + 1, SqlBuilder.SQLParserDataType.spNum)
                                            .Add("ClientID", AirDT.Rows(countDt).Item("ClientID").ToString())
                                            .Add("AirClass", AirDT.Rows(countDt).Item("AirClass").ToString())
                                            .Add("FlyingTimeType", AirDT.Rows(countDt).Item("FlyingTimeType").ToString(), SqlBuilder.SQLParserDataType.spText, False, , True)
                                            .Add("FlyingTime", AirDT.Rows(countDt).Item("FlyingTime").ToString())
                                            .Add("FlyingEndTime", AirDT.Rows(countDt).Item("FlyingEndTime").ToString())
                                            .Add("TravelerType", AirDT.Rows(countDt).Item("TravelerType").ToString())
                                            .Add("Remarks", AirDT.Rows(countDt).Item("Remarks").ToString())
                                            .Add("DateModification", DateTime.Now)
                                            .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                            .Add("ValueTypeChanged", "Update")
                                        End With
                                        effectRow = .ExecuteInsert()
                                    End With
                                    Exit For
                                Else
                                    If AirDT.Rows.Count > info.AirClassList.Count Then
                                        With Me.MySQLParser
                                            .TableName = "Temp_tblAirClass"
                                            With .Columns
                                                .Clear()
                                                .IncludeKey = False
                                                .Add("AirClassID", AirDT.Rows(countDt).Item("AirClassID").ToString(), SqlBuilder.SQLParserDataType.spNum)
                                                .Add("ClientID", AirDT.Rows(countDt).Item("ClientID").ToString())
                                                .Add("AirClass", AirDT.Rows(countDt).Item("AirClass").ToString())
                                                .Add("FlyingTimeType", AirDT.Rows(countDt).Item("FlyingTimeType").ToString(), SqlBuilder.SQLParserDataType.spText, False, , True)
                                                .Add("FlyingTime", AirDT.Rows(countDt).Item("FlyingTime").ToString())
                                                .Add("FlyingEndTime", AirDT.Rows(countDt).Item("FlyingEndTime").ToString())
                                                .Add("TravelerType", AirDT.Rows(countDt).Item("TravelerType").ToString())
                                                .Add("Remarks", AirDT.Rows(countDt).Item("Remarks").ToString())
                                                .Add("DateModification", DateTime.Now)
                                                .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                                .Add("ValueTypeChanged", "Delete")
                                            End With
                                            effectRow = .ExecuteInsert()
                                            Exit For
                                        End With
                                    End If
                                End If
                            Next countInfo
                           
                        End If
                    End If
                Next countDt
            End If


            If Type = "Policy" Then
                If info.PolicyLines.Count > countDt Then
                    For countInfo = countDt To info.PolicyLines.Count - 1
                        With Me.MySQLParser
                            .TableName = "Temp_tblAirPolicy"
                            With .Columns
                                .Clear()
                                .IncludeKey = False
                                .Add("AirPolicyID", countInfo + 1, SqlBuilder.SQLParserDataType.spNum)
                                .Add("ClientID", info.ClientID)
                                .Add("PolicyLine", info.PolicyLines(countInfo))
                                .Add("DateModification", DateTime.Now)
                                .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                .Add("ValueTypeChanged", "Insert")
                            End With
                            effectRow = .ExecuteInsert()
                        End With
                    Next
                End If
            ElseIf Type = "AirClass" Then
                If info.AirClassList.Count > countDt Then
                    For countInfo = countDt To info.AirClassList.Count - 1
                        With Me.MySQLParser
                            .TableName = "Temp_tblAirClass"
                            With .Columns
                                .Clear()
                                .IncludeKey = False
                                .Add("AirClassID", countInfo + 1, SqlBuilder.SQLParserDataType.spNum)
                                .Add("ClientID", info.ClientID)
                                .Add("AirClass", info.AirClassList(countInfo).PreferredClass)
                                .Add("FlyingTimeType", info.AirClassList(countInfo).TimeOperator)
                                If info.AirClassList(countInfo).TimeOperator = DataInfo.CompanyPolicyInfo.MathOperator.Between.ToString Then
                                    .Add("FlyingTime", info.AirClassList(countInfo).StFlyTime)
                                End If
                                .Add("FlyingEndTime", info.AirClassList(countInfo).EndFlyTime)
                                .Add("TravelerType", info.AirClassList(countInfo).TravellerType)
                                .Add("Remarks", info.AirClassList(countInfo).Remark)
                                .Add("DateModification", DateTime.Now)
                                .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                .Add("ValueTypeChanged", "Insert")
                            End With
                            effectRow = .ExecuteInsert()
                        End With
                    Next
                End If
            End If
        End Sub

        Private Function CheckExist(ByVal row As DataRow, ByRef info As DataInfo.CompanyPolicyInfo, ByVal Type As String)
            Dim countInfo As Integer
            Dim check As Boolean
            If Type = "Policy" Then
                For countInfo = 0 To info.PolicyLines.Count - 1
                    If row.Item("PolicyLine").ToString() = info.PolicyLines(countInfo) And row.Item("ClientID").ToString() = info.ClientID Then
                        check = True
                        Exit For
                    End If
                Next
            ElseIf Type = "AirClass" Then
                For countInfo = 0 To info.AirClassList.Count - 1
                    If row.Item("ClientID").ToString() = info.ClientID And row.Item("AirClass").ToString() = info.AirClassList(countInfo).PreferredClass And row.Item("FlyingTimeType").ToString() = info.AirClassList(countInfo).TimeOperator And row.Item("FlyingTime").ToString() = info.AirClassList(countInfo).StFlyTime And row.Item("FlyingEndTime").ToString() = info.AirClassList(countInfo).EndFlyTime And row.Item("TravelerType").ToString() = info.AirClassList(countInfo).TravellerType And row.Item("Remarks").ToString() = info.AirClassList(countInfo).Remark Then
                        check = True
                        Exit For
                    End If
                Next
            End If

            Return check
        End Function

        Public Function GetTempAirPolicy(Optional ByVal ClientName As String = "", Optional ByVal dateFrom As String = "", Optional ByVal dateTo As String = "") As DataSet
            '//Air Class
            Dim AirClassDT As DataTable
            Dim TempAirClassDT As DataTable
            Dim AirClassMasterDT As DataTable

            '//Air Policy
            Dim AirPolicyDT As DataTable
            Dim TempAirPolicyDT As DataTable
            Dim AirPolicyMasterDT As DataTable



            Dim ClientID As String = ""
            Dim TempTable As DataTable
            Dim AirClassArr(1) As String
            Dim AirPolicyArr(1) As String
            Dim count As Integer
            Dim ds As New DataSet
            Dim foundRow() As DataRow

            AirClassArr(0) = "ClientID"
            AirClassArr(1) = "AirClassID"
            AirPolicyArr(0) = "ClientID"
            AirPolicyArr(1) = "AirPolicyID"
            '//Get ClientID 
            If ClientName <> "" Then
                ClientID = GetClientIDByName(ClientName)
            End If

            With Me.MySQLParser
                .TableName = "Temp_tblAirClass c inner join " + CWTMasterDB.Util.StandardDB("tblClassCode") + " co on c.AirClass = co.ClassID"
                With .Columns
                    .Clear()
                    If ClientName <> "" Then
                        If ClientID <> "" Then
                            .Add("c.ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        Else
                            .Add("c.ClientID", "-1", SqlBuilder.SQLParserDataType.spNum, True)
                        End If
                    End If
                    If dateFrom = dateTo Then
                        If dateFrom <> "" And dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:990"
                            .Add("c.DateModification", "convert(varchar,cast('" + dateFrom + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, ">")
                            .Add("c.DateModification", "convert(varchar,cast('" + dateTo + " 23:59:59:990" + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, "<")
                        End If
                    Else
                        If dateFrom <> "" Then
                            .Add("c.DateModification", dateFrom, SqlBuilder.SQLParserDataType.spDate, True, ">")
                        End If
                        If dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:990"
                            .Add("c.DateModification", dateTo + " 23:59:59:990", SqlBuilder.SQLParserDataType.spDate, True, "<=")
                        End If
                    End If
                    .Add("c.AirClassID,c.ClientID,co.ClassDescription,c.FlyingTimeType,c.FlyingEndTime,c.TravelerType,c.Remarks,c.DateModification,c.UserName,c.ValueTypeChanged")
                End With
                TempAirClassDT = .ExecuteDataTable(.SQLSelect + " order by DateModification Desc")

                .TableName = "tblAirClass c inner join " + CWTMasterDB.Util.StandardDB("tblClassCode") + " co on c.AirClass = co.ClassID"
                With .Columns
                    .Clear()
                    If ClientName <> "" Then
                        If ClientID <> "" Then
                            .Add("c.ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        Else
                            .Add("c.ClientID", "-1", SqlBuilder.SQLParserDataType.spNum, True)
                        End If
                    End If
                    .Add("c.AirClassID,c.ClientID,co.ClassDescription,c.FlyingTimeType,c.FlyingEndTime,c.TravelerType,c.Remarks")
                End With
                AirClassDT = .ExecuteDataTable()

                TempTable = TempAirClassDT.DefaultView.ToTable(True, AirClassArr)
                AirClassMasterDT = TempAirClassDT.Clone()
                For count = 0 To TempTable.Rows.Count - 1
                    foundRow = AirClassDT.Select("ClientID='" + TempTable.Rows(count).Item("ClientID").ToString() + "' and AirClassID ='" + TempTable.Rows(count).Item("AirClassID").ToString() + "'")
                    If foundRow.Length > 0 Then
                        AirClassMasterDT.ImportRow(foundRow(0))
                    End If
                Next
                AirClassMasterDT.AcceptChanges()
                AirClassMasterDT.Merge(TempAirClassDT)
                AirClassMasterDT.TableName = "AirClass"
                ds.Tables.Add(AirClassMasterDT)


                .TableName = "Temp_tblAirPolicy"
                With .Columns
                    .Clear()
                    If ClientName <> "" Then
                        If ClientID <> "" Then
                            .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        Else
                            .Add("ClientID", "-1", SqlBuilder.SQLParserDataType.spNum, True)
                        End If
                    End If
                    If dateFrom = dateTo Then
                        If dateFrom <> "" And dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:990"
                            .Add("DateModification", "convert(varchar,cast('" + dateFrom + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, ">")
                            .Add("DateModification", "convert(varchar,cast('" + dateTo + " 23:59:59:990" + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, "<")
                        End If
                    Else
                        If dateFrom <> "" Then
                            .Add("DateModification", dateFrom, SqlBuilder.SQLParserDataType.spDate, True, ">")
                        End If
                        If dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:990"
                            .Add("DateModification", dateTo + " 23:59:59:990", SqlBuilder.SQLParserDataType.spText, True, "<=")
                        End If
                    End If
                    .Add("AirPolicyID,ClientID,PolicyLine,DateModification,UserName,ValueTypeChanged")
                End With
                TempAirPolicyDT = .ExecuteDataTable(.SQLSelect + " order by DateModification Desc")

                .TableName = "tblAirPolicy"
                With .Columns
                    .Clear()
                    If ClientName <> "" Then
                        If ClientID <> "" Then
                            .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        Else
                            .Add("ClientID", "-1", SqlBuilder.SQLParserDataType.spNum, True)
                        End If
                    End If
                    .Add("AirPolicyID,ClientID,PolicyLine")
                End With
                AirPolicyDT = .ExecuteDataTable()

                TempTable = TempAirPolicyDT.DefaultView.ToTable(True, AirPolicyArr)
                AirPolicyMasterDT = TempAirPolicyDT.Clone()
                For count = 0 To TempTable.Rows.Count - 1
                    foundRow = AirPolicyDT.Select("ClientID='" + TempTable.Rows(count).Item("ClientID").ToString() + "' and AirPolicyID='" + TempTable.Rows(count).Item("AirPolicyID").ToString() + "'")
                    If foundRow.Length > 0 Then
                        AirPolicyMasterDT.ImportRow(foundRow(0))
                    End If
                Next
                AirPolicyMasterDT.AcceptChanges()
                AirPolicyMasterDT.Merge(TempAirPolicyDT)
                AirPolicyMasterDT.TableName = "AirPolicy"
                ds.Tables.Add(AirPolicyMasterDT)
            End With
            Return ds
        End Function

#End Region

#Region "Hotel"
        Public Function GetHotelClassList() As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .TableName = CWTMasterDB.Util.StandardDB("tblRoomType")
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("*")
                End With
                dt = .ExecuteDataTable(.SQLSelect() + " order by RoomTypeDescription")
            End With
            Return dt
        End Function

        Public Function GetHotelPolicyData(ByVal ClientID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .TableName = "tblHotelGenPolicy"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("*")
                End With
                dt = .ExecuteDataTable(.SQLSelect() + " order by HotelPolicyID")
            End With
            Return dt
        End Function

        Public Function GetHotelClassData(ByVal ClientID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .TableName = "tblHotelClientRoom"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("*")
                End With
                dt = .ExecuteDataTable(.SQLSelect() + " order by HotelClassID")
            End With
            Return dt
        End Function

        Public Function UpdateHotelPolicy(ByVal info As DataInfo.CompanyPolicyInfo) As Integer
            Dim EffectRow As Integer = 1
            Dim HotelClassDT As DataTable
            Dim HotelGenPolicyDT As DataTable

            Try
                HotelClassDT = GetHotelClassData(info.ClientID)
                HotelGenPolicyDT = GetHotelPolicyData(info.ClientID)
                With Me.MySQLParser
                    '//
                    If info.CurrentWebMode = DataInfo.CompanyPolicyInfo.WebMode.ClassPolicy Then
                        .TableName = "tblHotelClientRoom"
                        With .Columns
                            .Clear()
                            .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        End With
                        .ExecuteDelete()
                        '// 
                        .TableName = "tblHotelClientRoom"
                        For i As Integer = 0 To info.HotelClassList.Count - 1
                            With .Columns
                                .Clear()
                                .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum)
                                .Add("HotelClassID", i + 1, SqlBuilder.SQLParserDataType.spNum)
                                .Add("TravelerType", info.HotelClassList(i).TravellerType)
                                .Add("RoomTypeCode", info.HotelClassList(i).PreferredClass)
                                .Add("Remarks", info.HotelClassList(i).Remark)
                            End With
                            EffectRow = .ExecuteInsert()
                            If EffectRow <= 0 Then
                                Exit For
                            End If
                        Next

                    Else
                        .TableName = "tblHotelGenPolicy"
                        With .Columns
                            .Clear()
                            .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        End With
                        .ExecuteDelete()
                        '//
                        .TableName = "tblHotelGenPolicy"
                        For i As Integer = 0 To info.PolicyLines.Count - 1
                            With .Columns
                                .Clear()
                                .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum)
                                .Add("HotelPolicyID", i + 1, SqlBuilder.SQLParserDataType.spNum)
                                .Add("PolicyLine", info.PolicyLines(i))
                            End With
                            EffectRow = .ExecuteInsert()
                            If EffectRow <= 0 Then
                                Exit For
                            End If
                        Next

                    End If
                End With
                If info.CurrentWebMode = DataInfo.CompanyPolicyInfo.WebMode.ClassPolicy Then
                    MatchRecordHotel(HotelClassDT, info, "HotelRoom")
                Else
                    MatchRecordHotel(HotelGenPolicyDT, info, "GenPolicy")
                End If
                If EffectRow > 0 Then
                    Me.MySQLParser.CommitTran()
                Else
                    Me.MySQLParser.RollbackTran()
                End If
            Catch ex As Exception
                EffectRow = -1
                Me.MySQLParser.RollbackTran()
            Finally
                Me.MySQLParser.CloseConnection()
            End Try
            Return EffectRow
        End Function

        Private Function CheckHotelExist(ByVal row As DataRow, ByRef info As DataInfo.CompanyPolicyInfo, ByVal Type As String)
            Dim countInfo As Integer
            Dim check As Boolean
            If Type = "GenPolicy" Then
                For countInfo = 0 To info.PolicyLines.Count - 1
                    If row.Item("PolicyLine").ToString() = info.PolicyLines(countInfo) And row.Item("ClientID").ToString() = info.ClientID Then
                        check = True
                        Exit For
                    End If
                Next
            ElseIf Type = "HotelRoom" Then
                For countInfo = 0 To info.HotelClassList.Count - 1
                    If row.Item("ClientID").ToString() = info.ClientID And row.Item("RoomTypeCode").ToString() = info.HotelClassList(countInfo).PreferredClass And row.Item("TravelerType").ToString() = info.HotelClassList(countInfo).TravellerType And row.Item("Remarks").ToString() = info.HotelClassList(countInfo).Remark Then
                        check = True
                        Exit For
                    End If
                Next
            End If

            Return check
        End Function

        Private Sub MatchRecordHotel(ByRef HotelDT As DataTable, ByRef info As DataInfo.CompanyPolicyInfo, ByVal Type As String)
            Dim countInfo As Integer
            Dim countDT As Integer
            Dim effectRow As Integer
            Dim checkMatch As Boolean
            If HotelDT.Rows.Count > 0 Then
                For countDT = 0 To HotelDT.Rows.Count - 1
                    If Type = "HotelRoom" Then
                        checkMatch = CheckHotelExist(HotelDT.Rows(countDT), info, "HotelRoom")
                        If checkMatch = False Then
                            For countInfo = 0 To info.HotelClassList.Count - 1
                                If HotelDT.Rows(countDT).Item("HotelClassID").ToString() = countInfo + 1 And HotelDT.Rows(countDT).Item("ClientID").ToString() = info.ClientID Then
                                    With Me.MySQLParser
                                        .TableName = "Temp_tblHotelClientRoom"
                                        With .Columns
                                            .Clear()
                                            .Add("HotelClassID", HotelDT.Rows(countDT).Item("HotelClassID").ToString())
                                            .Add("ClientID", HotelDT.Rows(countDT).Item("ClientID").ToString())
                                            .Add("RoomTypeCode", HotelDT.Rows(countDT).Item("RoomTypeCode").ToString())
                                            .Add("TravelerType", HotelDT.Rows(countDT).Item("TravelerType").ToString())
                                            .Add("Remarks", HotelDT.Rows(countDT).Item("Remarks").ToString())
                                            .Add("DateModification", DateTime.Now)
                                            .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                            .Add("ValueTypeChanged", "Update")
                                        End With
                                        effectRow = .ExecuteInsert()
                                        Exit For
                                    End With
                                Else
                                    If HotelDT.Rows.Count > info.HotelClassList.Count Then
                                        With Me.MySQLParser
                                            .TableName = "Temp_tblHotelClientRoom"
                                            With .Columns
                                                .Clear()
                                                .Add("HotelClassID", HotelDT.Rows(countDT).Item("HotelClassID").ToString())
                                                .Add("ClientID", HotelDT.Rows(countDT).Item("ClientID").ToString())
                                                .Add("RoomTypeCode", HotelDT.Rows(countDT).Item("RoomTypeCode").ToString())
                                                .Add("TravelerType", HotelDT.Rows(countDT).Item("TravelerType").ToString())
                                                .Add("Remarks", HotelDT.Rows(countDT).Item("Remarks").ToString())
                                                .Add("DateModification", DateTime.Now)
                                                .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                                .Add("ValueTypeChanged", "Delete")
                                            End With
                                            effectRow = .ExecuteInsert()
                                            Exit For
                                        End With
                                    End If
                                End If
                            Next countInfo
                        End If

                        
                    Else
                        checkMatch = CheckHotelExist(HotelDT.Rows(countDT), info, "GenPolicy")
                        If checkMatch = False Then
                            For countInfo = 0 To info.PolicyLines.Count - 1
                                If HotelDT.Rows(countDT).Item("HotelPolicyID").ToString() = countInfo + 1 And HotelDT.Rows(countDT).Item("ClientID").ToString() = info.ClientID Then
                                    With Me.MySQLParser
                                        .TableName = "Temp_tblHotelGenPolicy"
                                        With .Columns
                                            .Clear()
                                            .Add("HotelPolicyID", countDT + 1, SqlBuilder.SQLParserDataType.spNum)
                                            .Add("ClientID", HotelDT.Rows(countDT).Item("ClientID").ToString())
                                            .Add("PolicyLine", HotelDT.Rows(countDT).Item("PolicyLine").ToString())
                                            .Add("DateModification", DateTime.Now)
                                            .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                            .Add("ValueTypeChanged", "Update")
                                        End With
                                        effectRow = .ExecuteInsert()
                                        Exit For
                                    End With
                                Else
                                    If HotelDT.Rows.Count > info.PolicyLines.Count Then
                                        With Me.MySQLParser
                                            .TableName = "Temp_tblHotelGenPolicy"
                                            With .Columns
                                                .Clear()
                                                .Add("HotelPolicyID", HotelDT.Rows(countDT).Item("HotelPolicyID").ToString(), SqlBuilder.SQLParserDataType.spNum)
                                                .Add("ClientID", HotelDT.Rows(countDT).Item("ClientID").ToString())
                                                .Add("PolicyLine", HotelDT.Rows(countDT).Item("PolicyLine").ToString())
                                                .Add("DateModification", DateTime.Now)
                                                .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                                .Add("ValueTypeChanged", "Delete")
                                            End With
                                            effectRow = .ExecuteInsert()
                                            Exit For
                                        End With
                                    End If
                                End If
                            Next countInfo
                        End If
                    End If
                Next countDT
            End If

            If Type = "HotelRoom" Then
                If info.HotelClassList.Count > HotelDT.Rows.Count Then
                    For countInfo = countDT To info.HotelClassList.Count - 1
                        With Me.MySQLParser
                            .TableName = "Temp_tblHotelClientRoom"
                            With .Columns
                                .Clear()
                                .Add("HotelClassID", countInfo + 1)
                                .Add("ClientID", info.ClientID)
                                .Add("RoomTypeCode", info.HotelClassList(countInfo).PreferredClass)
                                .Add("TravelerType", info.HotelClassList(countInfo).TravellerType)
                                .Add("Remarks", info.HotelClassList(countInfo).Remark)
                                .Add("DateModification", DateTime.Now)
                                .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                .Add("ValueTypeChanged", "Insert")
                            End With
                            effectRow = .ExecuteInsert()
                        End With
                    Next
                End If

            Else
                If info.PolicyLines.Count > HotelDT.Rows.Count Then
                    For countInfo = countDT To info.PolicyLines.Count - 1
                        With Me.MySQLParser
                            .TableName = "Temp_tblHotelGenPolicy"
                            With .Columns
                                .Clear()
                                .Add("HotelPolicyID", countInfo + 1, SqlBuilder.SQLParserDataType.spNum)
                                .Add("ClientID", info.ClientID)
                                .Add("PolicyLine", info.PolicyLines(countInfo))
                                .Add("DateModification", DateTime.Now)
                                .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                .Add("ValueTypeChanged", "Insert")
                            End With
                            effectRow = .ExecuteInsert()
                        End With
                    Next countInfo
                End If
            End If
        End Sub

        Public Function GetTempHotelInfo(Optional ByVal ClientName As String = "", Optional ByVal dateFrom As String = "", Optional ByVal dateTo As String = "") As DataSet
            '//Hotel Client Room
            Dim RoomDT As DataTable
            Dim TempRoomDT As DataTable
            Dim RoomMasterDT As DataTable

            '//Hotel Policy
            Dim HotelPolicyDT As DataTable
            Dim TempHotelPolicyDT As DataTable
            Dim HotelPolicyMasterDT As DataTable

            Dim ClientID As String = ""
            Dim TempTable As DataTable
            Dim HotelClientArr(1) As String
            Dim HotelPolicyArr(1) As String
            Dim count As Integer
            Dim count2 As Integer
            Dim ds As New DataSet
            Dim foundRow() As DataRow

            HotelClientArr(0) = "ClientID"
            HotelClientArr(1) = "HotelClassID"
            HotelPolicyArr(0) = "ClientID"
            HotelPolicyArr(1) = "HotelPolicyID"

            '//Get ClientID 
            If ClientName <> "" Then
                ClientID = GetClientIDByName(ClientName)
            End If
            With Me.MySQLParser
                .TableName = "Temp_tblHotelClientRoom r inner join " + CWTMasterDB.Util.StandardDB("tblRoomType") + " t on r.RoomTypeCode=t.RoomTypeCode"
                With .Columns
                    .Clear()
                    If ClientName <> "" Then
                        If ClientID <> "" Then
                            .Add("r.ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        Else
                            .Add("r.ClientID", "-1", SqlBuilder.SQLParserDataType.spNum, True)
                        End If
                    End If
                    If dateFrom = dateTo Then
                        If dateFrom <> "" And dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:990"
                            .Add("r.DateModification", "convert(varchar,cast('" + dateFrom + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, ">")
                            .Add("r.DateModification", "convert(varchar,cast('" + dateTo + " 23:59:59:990" + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, "<")
                        End If
                    Else
                        If dateFrom <> "" Then
                            .Add("r.DateModification", dateFrom, SqlBuilder.SQLParserDataType.spDate, True, ">")
                        End If
                        If dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:990"
                            .Add("r.DateModification", dateTo + " 23:59:59:990", SqlBuilder.SQLParserDataType.spText, True, "<=")
                        End If
                    End If
                    .Add("r.HotelClassID,r.ClientID,t.RoomTypeDescription,r.TravelerType,r.Remarks,r.DateModification,r.UserName,r.ValueTypeChanged")
                End With
                TempRoomDT = .ExecuteDataTable(.SQLSelect + " order by DateModification Desc")

                .TableName = "tblHotelClientRoom  r inner join " + CWTMasterDB.Util.StandardDB("tblRoomType") + " t on r.RoomTypeCode=t.RoomTypeCode"
                With .Columns
                    .Clear()
                    If ClientName <> "" Then
                        If ClientID <> "" Then
                            .Add("r.ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        Else
                            .Add("r.ClientID", "-1", SqlBuilder.SQLParserDataType.spNum, True)
                        End If
                    End If
                    .Add("r.HotelClassID,r.ClientID,t.RoomTypeDescription,r.TravelerType,r.Remarks")
                End With
                RoomDT = .ExecuteDataTable()

                TempTable = TempRoomDT.DefaultView.ToTable(True, HotelClientArr)
                RoomMasterDT = TempRoomDT.Clone()
                For count = 0 To TempTable.Rows.Count - 1
                    foundRow = RoomDT.Select("ClientID='" + TempTable.Rows(count).Item("ClientID").ToString() + "' and HotelClassID='" + TempTable.Rows(count).Item("HotelClassID").ToString() + "'")
                    If foundRow.Length > 0 Then
                        For count2 = 0 To foundRow.Length - 1
                            RoomMasterDT.ImportRow(foundRow(count2))
                        Next count2
                    End If
                Next
                RoomMasterDT.AcceptChanges()
                RoomMasterDT.Merge(TempRoomDT)
                RoomMasterDT.TableName = "Room"
                ds.Tables.Add(RoomMasterDT)

                .TableName = "Temp_tblHotelGenPolicy"
                With .Columns
                    .Clear()
                    If ClientName <> "" Then
                        If ClientID <> "" Then
                            .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        Else
                            .Add("ClientID", "-1", SqlBuilder.SQLParserDataType.spNum, True)
                        End If
                    End If
                    If dateFrom = dateTo Then
                        If dateFrom <> "" And dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:990"
                            .Add("DateModification", "convert(varchar,cast('" + dateFrom + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, ">")
                            .Add("DateModification", "convert(varchar,cast('" + dateTo + " 23:59:59:990" + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, "<")
                        End If
                    Else
                        If dateFrom <> "" Then
                            .Add("DateModification", dateTo, SqlBuilder.SQLParserDataType.spDate, True, ">")
                        End If
                        If dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:990"
                            .Add("DateModification", dateTo + " 23:59:59:990", SqlBuilder.SQLParserDataType.spText, True, "<=")
                        End If
                    End If
                    .Add("*")
                End With
                TempHotelPolicyDT = .ExecuteDataTable(.SQLSelect + " order by DateModification Desc")

                .TableName = "tblHotelGenPolicy"
                With .Columns
                    .Clear()
                    If ClientName <> "" Then
                        If ClientID <> "" Then
                            .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        Else
                            .Add("ClientID", "-1", SqlBuilder.SQLParserDataType.spNum, True)
                        End If
                    End If
                    .Add("*")
                End With
                HotelPolicyDT = .ExecuteDataTable()

                TempTable = TempHotelPolicyDT.DefaultView.ToTable(True, HotelPolicyArr)
                HotelPolicyMasterDT = TempHotelPolicyDT.Clone()
                For count = 0 To TempTable.Rows.Count - 1
                    foundRow = HotelPolicyDT.Select("ClientID='" + TempTable.Rows(count).Item("ClientID").ToString() + "' and HotelPolicyID='" + TempTable.Rows(count).Item("HotelPolicyID").ToString() + "'")
                    If foundRow.Length > 0 Then
                        For count2 = 0 To foundRow.Length - 1
                            HotelPolicyMasterDT.ImportRow(foundRow(count2))
                        Next count2
                    End If
                Next
                HotelPolicyMasterDT.AcceptChanges()
                HotelPolicyMasterDT.Merge(TempHotelPolicyDT)
                HotelPolicyMasterDT.TableName = "Policy"
                ds.Tables.Add(HotelPolicyMasterDT)
            End With
            Return ds
        End Function


#End Region

#Region "Car"
        Public Function GetCarClassList() As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .TableName = CWTMasterDB.Util.StandardDB("tblCarType")
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("*")
                End With
                dt = .ExecuteDataTable(.SQLSelect() + " order by CarTypeDescription")
            End With
            Return dt
        End Function

        Public Function GetCarPolicyData(ByVal ClientID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .TableName = "tblCarGenPolicy"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("*")
                End With
                dt = .ExecuteDataTable(.SQLSelect() + " order by CarPolicyID")
            End With
            Return dt
        End Function

        Public Function GetCarClassData(ByVal ClientID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .TableName = "tblCarTypeClient"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("*")
                End With
                dt = .ExecuteDataTable(.SQLSelect() + " order by ClientCarID")
            End With
            Return dt
        End Function

        Public Function UpdateCarPolicy(ByVal info As DataInfo.CompanyPolicyInfo) As Integer
            Dim EffectRow As Integer = 1
            Dim CarPolicyDT As New DataTable
            Dim CarClassDT As New DataTable
            Try

                With Me.MySQLParser
                    '//
                    If info.CurrentWebMode = DataInfo.CompanyPolicyInfo.WebMode.ClassPolicy Then
                        CarClassDT = GetCarClassData(info.ClientID)
                        .TableName = "tblCarTypeClient"
                        With .Columns
                            .Clear()
                            .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        End With
                        .ExecuteDelete()
                        '// 
                        .TableName = "tblCarTypeClient"
                        For i As Integer = 0 To info.CarClassList.Count - 1
                            With .Columns
                                .Clear()
                                .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum)
                                .Add("ClientCarID", i + 1, SqlBuilder.SQLParserDataType.spNum)
                                .Add("TravelerType", info.CarClassList(i).TravellerType)
                                .Add("CarTypeCode", info.CarClassList(i).PreferredClass)
                                .Add("Remarks", info.CarClassList(i).Remark)
                            End With
                            EffectRow = .ExecuteInsert()
                            If EffectRow <= 0 Then
                                Exit For
                            End If
                        Next
                    Else
                        CarPolicyDT = GetCarPolicyData(info.ClientID)
                        .TableName = "tblCarGenPolicy"
                        With .Columns
                            .Clear()
                            .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        End With
                        .ExecuteDelete()
                        '//
                        .TableName = "tblCarGenPolicy"
                        For i As Integer = 0 To info.PolicyLines.Count - 1
                            With .Columns
                                .Clear()
                                .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum)
                                .Add("CarPolicyID", i + 1, SqlBuilder.SQLParserDataType.spNum)
                                .Add("PolicyLine", info.PolicyLines(i))
                            End With
                            EffectRow = .ExecuteInsert()
                            If EffectRow <= 0 Then
                                Exit For
                            End If
                        Next

                    End If
                End With
                If info.CurrentWebMode = DataInfo.CompanyPolicyInfo.WebMode.ClassPolicy Then
                    MatchRecordCar(CarClassDT, info, "CarType")
                Else
                    MatchRecordCar(CarPolicyDT, info, "CarPolicy")
                End If
               

                If EffectRow > 0 Then
                    Me.MySQLParser.CommitTran()
                Else
                    Me.MySQLParser.RollbackTran()
                End If
            Catch ex As Exception
                EffectRow = -1
                Me.MySQLParser.RollbackTran()
            Finally
                Me.MySQLParser.CloseConnection()
            End Try
            Return EffectRow
        End Function

        Private Sub MatchRecordCar(ByRef CarDT As DataTable, ByRef info As DataInfo.CompanyPolicyInfo, ByVal Type As String)
            Dim countInfo As Integer
            Dim countDT As Integer
            Dim effectRow As Integer
            Dim checkMatch As Boolean
            If CarDT.Rows.Count > 0 Then
                For countDT = 0 To CarDT.Rows.Count - 1
                    If Type = "CarType" Then
                        checkMatch = CheckCarExist(CarDT.Rows(countDT), info, "CarType")
                        If checkMatch = False Then
                            For countInfo = 0 To info.CarClassList.Count - 1
                                If CarDT.Rows(countDT).Item("ClientCarID").ToString() = countInfo + 1 And CarDT.Rows(countDT).Item("ClientID").ToString() = info.ClientID Then
                                    With Me.MySQLParser
                                        .TableName = "Temp_tblCarTypeClient"
                                        With .Columns
                                            .Clear()
                                            .Add("ClientCarID", CarDT.Rows(countDT).Item("ClientCarID").ToString())
                                            .Add("ClientID", CarDT.Rows(countDT).Item("ClientID").ToString())
                                            .Add("TravelerType", CarDT.Rows(countDT).Item("TravelerType").ToString())
                                            .Add("CarTypeCode", CarDT.Rows(countDT).Item("CarTypeCode").ToString())
                                            .Add("Remarks", CarDT.Rows(countDT).Item("Remarks").ToString())
                                            .Add("DateModification", DateTime.Now)
                                            .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                            .Add("ValueTypeChanged", "Update")
                                        End With
                                        effectRow = .ExecuteInsert()
                                        Exit For
                                    End With
                                Else
                                    If CarDT.Rows.Count > info.CarClassList.Count Then
                                        With Me.MySQLParser
                                            .TableName = "Temp_tblCarTypeClient"
                                            With .Columns
                                                .Clear()
                                                .Add("ClientCarID", CarDT.Rows(countDT).Item("ClientCarID").ToString())
                                                .Add("ClientID", CarDT.Rows(countDT).Item("ClientID").ToString())
                                                .Add("TravelerType", CarDT.Rows(countDT).Item("TravelerType").ToString())
                                                .Add("CarTypeCode", CarDT.Rows(countDT).Item("CarTypeCode").ToString())
                                                .Add("Remarks", CarDT.Rows(countDT).Item("Remarks").ToString())
                                                .Add("DateModification", DateTime.Now)
                                                .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                                .Add("ValueTypeChanged", "Delete")
                                            End With
                                            effectRow = .ExecuteInsert()
                                            Exit For
                                        End With
                                    End If
                                End If
                            Next countInfo
                        End If

                      
                    Else
                        checkMatch = CheckCarExist(CarDT.Rows(countDT), info, "CarPolicy")
                        If checkMatch = False Then
                            For countInfo = 0 To info.PolicyLines.Count - 1
                                If CarDT.Rows(countDT).Item("CarPolicyID").ToString() = countInfo + 1 And CarDT.Rows(countDT).Item("ClientID").ToString() = info.ClientID Then
                                    With Me.MySQLParser
                                        .TableName = "Temp_tblCarGenPolicy"
                                        With .Columns
                                            .Clear()
                                            .Add("CarPolicyID", countDT + 1, SqlBuilder.SQLParserDataType.spNum)
                                            .Add("ClientID", CarDT.Rows(countDT).Item("ClientID").ToString())
                                            .Add("PolicyLine", CarDT.Rows(countDT).Item("PolicyLine").ToString())
                                            .Add("DateModification", DateTime.Now)
                                            .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                            .Add("ValueTypeChanged", "Update")
                                        End With
                                        effectRow = .ExecuteInsert()
                                        Exit For
                                    End With
                                Else
                                    If CarDT.Rows.Count > info.PolicyLines.Count Then
                                        With Me.MySQLParser
                                            .TableName = "Temp_tblCarGenPolicy"
                                            With .Columns
                                                .Clear()
                                                .Add("CarPolicyID", countDT + 1, SqlBuilder.SQLParserDataType.spNum)
                                                .Add("ClientID", CarDT.Rows(countDT).Item("ClientID").ToString())
                                                .Add("PolicyLine", CarDT.Rows(countDT).Item("PolicyLine").ToString())
                                                .Add("DateModification", DateTime.Now)
                                                .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                                .Add("ValueTypeChanged", "Delete")
                                            End With
                                            effectRow = .ExecuteInsert()
                                            Exit For
                                        End With
                                    End If
                                End If
                            Next countInfo
                        End If
                    End If
                Next countDT
            End If

            If Type = "CarType" Then
                If info.CarClassList.Count > CarDT.Rows.Count Then
                    For countInfo = countDT To info.CarClassList.Count - 1
                        With Me.MySQLParser
                            .TableName = "Temp_tblCarTypeClient"
                            With .Columns
                                .Clear()
                                .Add("ClientCarID", countInfo + 1, SqlBuilder.SQLParserDataType.spNum)
                                .Add("ClientID", info.ClientID)
                                .Add("TravelerType", info.CarClassList(countInfo).TravellerType)
                                .Add("CarTypeCode", info.CarClassList(countInfo).PreferredClass)
                                .Add("Remarks", info.CarClassList(countInfo).Remark)
                                .Add("DateModification", DateTime.Now)
                                .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                .Add("ValueTypeChanged", "Insert")
                            End With
                            effectRow = .ExecuteInsert()
                        End With
                    Next
                End If

            Else
                If info.PolicyLines.Count > CarDT.Rows.Count Then
                    For countInfo = countDT To info.PolicyLines.Count - 1
                        With Me.MySQLParser
                            .TableName = "Temp_tblCarGenPolicy"
                            With .Columns
                                .Clear()
                                .Add("CarPolicyID", countInfo + 1, SqlBuilder.SQLParserDataType.spNum)
                                .Add("ClientID", info.ClientID)
                                .Add("PolicyLine", info.PolicyLines(countInfo))
                                .Add("DateModification", DateTime.Now)
                                .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                .Add("ValueTypeChanged", "Insert")
                            End With
                            effectRow = .ExecuteInsert()
                        End With
                    Next countInfo
                End If
            End If
        End Sub

        Private Function CheckCarExist(ByVal row As DataRow, ByRef info As DataInfo.CompanyPolicyInfo, ByVal Type As String)
            Dim countInfo As Integer
            Dim check As Boolean
            If Type = "CarPolicy" Then
                For countInfo = 0 To info.PolicyLines.Count - 1
                    If row.Item("PolicyLine").ToString() = info.PolicyLines(countInfo) And row.Item("ClientID").ToString() = info.ClientID Then
                        check = True
                        Exit For
                    End If
                Next
            ElseIf Type = "CarType" Then
                For countInfo = 0 To info.CarClassList.Count - 1
                    If row.Item("ClientID").ToString() = info.ClientID And row.Item("CarTypeCode").ToString() = info.CarClassList(countInfo).PreferredClass And row.Item("TravelerType").ToString() = info.CarClassList(countInfo).TravellerType And row.Item("Remarks").ToString() = info.CarClassList(countInfo).Remark Then
                        check = True
                        Exit For
                    End If
                Next
            End If

            Return check
        End Function

        Public Function GetTempCarInfo(Optional ByVal ClientName As String = "", Optional ByVal dateFrom As String = "", Optional ByVal dateTo As String = "") As DataSet
            '//Car Type Client
            Dim CarTypeDT As DataTable
            Dim TempCarTypeDT As DataTable
            Dim CarTypeMasterDT As DataTable

            '//Car Gen Policy
            Dim CarPolicyDT As DataTable
            Dim TempCarPolicyDT As DataTable
            Dim CarPolicyMasterDT As DataTable

            Dim ClientID As String = ""
            Dim TempTable As DataTable
            Dim CarTypeArr(1) As String
            Dim CarPolicyArr(1) As String
            Dim count As Integer
            Dim count2 As Integer
            Dim ds As New DataSet
            Dim foundRow() As DataRow

            CarTypeArr(0) = "ClientID"
            CarTypeArr(1) = "ClientCarID"
            CarPolicyArr(0) = "ClientID"
            CarPolicyArr(1) = "CarPolicyID"

            '//Get ClientID 
            If ClientName <> "" Then
                ClientID = GetClientIDByName(ClientName)
            End If

            With Me.MySQLParser
                .TableName = "Temp_tblCarTypeClient c inner join " + CWTMasterDB.Util.StandardDB("tblCarType") + " t on c.CarTypeCode=t.CarTypeCode"
                With .Columns
                    .Clear()
                    If ClientName <> "" Then
                        If ClientID <> "" Then
                            .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        Else
                            .Add("ClientID", "-1", SqlBuilder.SQLParserDataType.spNum, True)
                        End If
                    End If
                    If dateFrom = dateTo Then
                        If dateFrom <> "" And dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:990"
                            .Add("DateModification", "convert(varchar,cast('" + dateFrom + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, ">")
                            .Add("DateModification", "convert(varchar,cast('" + dateTo + " 23:59:59:990" + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, "<")
                        End If
                    Else
                        If dateFrom <> "" Then
                            .Add("DateModification", dateFrom, SqlBuilder.SQLParserDataType.spDate, True, ">")
                        End If
                        If dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:990"
                            .Add("DateModification", dateTo + " 23:59:59:990", SqlBuilder.SQLParserDataType.spDate, True, "<=")
                        End If
                    End If
                    .Add("c.ClientCarID,c.ClientID,c.TravelerType,t.CarTypeDescription,c.Remarks,c.DateModification,c.UserName,c.ValueTypeChanged")
                End With
                TempCarTypeDT = .ExecuteDataTable(.SQLSelect + " order by DateModification Desc")

                .TableName = "tblCarTypeClient c inner join " + CWTMasterDB.Util.StandardDB("tblCarType") + " t on c.CarTypeCode=t.CarTypeCode"
                With .Columns
                    .Clear()
                    If ClientName <> "" Then
                        If ClientID <> "" Then
                            .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        Else
                            .Add("ClientID", "-1", SqlBuilder.SQLParserDataType.spNum, True)
                        End If
                    End If
                    .Add("c.ClientCarID,c.ClientID,c.TravelerType,t.CarTypeDescription,c.Remarks")
                End With
                CarTypeDT = .ExecuteDataTable()

                TempTable = TempCarTypeDT.DefaultView.ToTable(True, CarTypeArr)
                CarTypeMasterDT = TempCarTypeDT.Clone()
                For count = 0 To TempTable.Rows.Count - 1
                    foundRow = CarTypeDT.Select("ClientID='" + TempTable.Rows(count).Item("ClientID").ToString() + "' and ClientCarID='" + TempTable.Rows(count).Item("ClientCarID").ToString() + "'")
                    If foundRow.Length > 0 Then
                        For count2 = 0 To foundRow.Length - 1
                            CarTypeMasterDT.ImportRow(foundRow(count2))
                        Next count2
                    End If
                Next
                CarTypeMasterDT.AcceptChanges()
                CarTypeMasterDT.Merge(TempCarTypeDT)
                CarTypeMasterDT.TableName = "CarType"
                ds.Tables.Add(CarTypeMasterDT)


                .TableName = "Temp_tblCarGenPolicy"
                With .Columns
                    .Clear()
                    If ClientName <> "" Then
                        If ClientID <> "" Then
                            .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        Else
                            .Add("ClientID", "-1", SqlBuilder.SQLParserDataType.spNum, True)
                        End If
                    End If
                    If dateFrom = dateTo Then
                        If dateFrom <> "" And dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:990"
                            .Add("DateModification", "convert(varchar,cast('" + dateFrom + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, ">")
                            .Add("DateModification", "convert(varchar,cast('" + dateTo + " 23:59:59:990" + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, "<")
                        End If
                    Else
                        If dateFrom <> "" Then
                            .Add("DateModification", dateFrom, SqlBuilder.SQLParserDataType.spDate, True, ">")
                        End If
                        If dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:990"
                            .Add("DateModification", dateTo + " 23:59:59:990", SqlBuilder.SQLParserDataType.spText, True, "<=")
                        End If
                    End If
                    .Add("*")
                End With
                TempCarPolicyDT = .ExecuteDataTable(.SQLSelect + " order by DateModification Desc")

                .TableName = "tblCarGenPolicy"
                With .Columns
                    .Clear()
                    If ClientName <> "" Then
                        If ClientID <> "" Then
                            .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        Else
                            .Add("ClientID", "-1", SqlBuilder.SQLParserDataType.spNum, True)
                        End If
                    End If
                    .Add("*")
                End With
                CarPolicyDT = .ExecuteDataTable()
            End With

            TempTable = TempCarPolicyDT.DefaultView.ToTable(True, CarPolicyArr)
            CarPolicyMasterDT = TempCarPolicyDT.Clone()
            For count = 0 To TempTable.Rows.Count - 1
                foundRow = CarPolicyDT.Select("ClientID='" + TempTable.Rows(count).Item("ClientID").ToString() + "' and CarPolicyID='" + TempTable.Rows(count).Item("CarPolicyID").ToString() + "'") 'and CarPolicyID='" + TempTable.Rows(count).Item("CarPolicyID").ToString() + "'
                If foundRow.Length > 0 Then
                    For count2 = 0 To foundRow.Length - 1
                        CarPolicyMasterDT.ImportRow(foundRow(count2))
                    Next count2
                End If
            Next
            CarPolicyMasterDT.AcceptChanges()
            CarPolicyMasterDT.Merge(TempCarPolicyDT)
            CarPolicyMasterDT.TableName = "Policy"
            ds.Tables.Add(CarPolicyMasterDT)
            Return ds
        End Function


#End Region

#Region "Auxiliary"
        Public Function GetAuxPolicyData(ByVal ClientID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .TableName = "tblAuxClientPolicy"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("*")
                End With
                dt = .ExecuteDataTable(.SQLSelect() + " order by AuxClientPolicyID")
            End With
            Return dt
        End Function

        Public Function UpdateAuxPolicy(ByVal info As DataInfo.CompanyPolicyInfo) As Integer
            Dim EffectRow As Integer = 1
            Dim AuxPolicyDT As DataTable
            Try
                AuxPolicyDT = GetAuxPolicyData(info.ClientID)
                With Me.MySQLParser
                    .OpenConnection()
                    .BeginTran()
                    .TableName = "tblAuxClientPolicy"
                    With .Columns
                        .Clear()
                        .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    End With
                    .ExecuteDelete()
                    '//
                    .TableName = "tblAuxClientPolicy"
                    For i As Integer = 0 To info.PolicyLines.Count - 1
                        'If info.PolicyLines(i) = "" Then
                        '    Continue For
                        'End If
                        With .Columns
                            .Clear()
                            .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum)
                            .Add("AuxClientPolicyID", i + 1, SqlBuilder.SQLParserDataType.spNum)
                            .Add("PolicyLine", info.PolicyLines(i))
                        End With
                        EffectRow = .ExecuteInsert()
                        If EffectRow <= 0 Then
                            Exit For
                        End If
                    Next
                    MatchAuxRecord(AuxPolicyDT, info)
                End With
                If EffectRow > 0 Then
                    Me.MySQLParser.CommitTran()
                Else
                    Me.MySQLParser.RollbackTran()
                End If
            Catch ex As Exception
                EffectRow = -1
                Me.MySQLParser.RollbackTran()
            Finally
                Me.MySQLParser.CloseConnection()
            End Try
            Return EffectRow
        End Function

        Private Sub MatchAuxRecord(ByRef AuxDT As DataTable, ByRef info As DataInfo.CompanyPolicyInfo)
            Dim countDT As Integer
            Dim countInfo As Integer
            Dim checkMatch As Boolean
            Dim effectRow As Integer

            If AuxDT.Rows.Count > 0 Then
                For countDT = 0 To AuxDT.Rows.Count - 1
                    checkMatch = checkAuxExists(AuxDT.Rows(countDT), info)
                    If checkMatch = False Then
                        For countInfo = 0 To info.PolicyLines.Count - 1
                            If AuxDT.Rows(countDT).Item("AuxClientPolicyID").ToString() = countInfo + 1 And AuxDT.Rows(countDT).Item("ClientID").ToString() = info.ClientID Then
                                With Me.MySQLParser
                                    .TableName = "Temp_tblAuxClientPolicy"
                                    With .Columns
                                        .Clear()
                                        .Add("AuxClientPolicyID", countInfo + 1, SqlBuilder.SQLParserDataType.spNum)
                                        .Add("ClientID", AuxDT.Rows(countDT).Item("ClientID").ToString())
                                        .Add("DateModification", DateTime.Now)
                                        .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)

                                        If AuxDT.Rows(countDT).Item("PolicyLine").ToString() <> "" And info.PolicyLines(countInfo) = "" Then
                                            .Add("PolicyLine", AuxDT.Rows(countDT).Item("PolicyLine").ToString())
                                            .Add("ValueTypeChanged", "Delete")
                                        ElseIf AuxDT.Rows(countDT).Item("PolicyLine").ToString() <> "" And info.PolicyLines(countInfo) <> "" Then
                                            .Add("PolicyLine", AuxDT.Rows(countDT).Item("PolicyLine").ToString())
                                            .Add("ValueTypeChanged", "Update")
                                        ElseIf AuxDT.Rows(countDT).Item("PolicyLine").ToString() = "" And info.PolicyLines(countInfo) <> "" And AuxDT.Rows(countDT).Item("PolicyLine").ToString() <> info.PolicyLines(countInfo) Then
                                            .Add("PolicyLine", info.PolicyLines(countInfo))
                                            .Add("ValueTypeChanged", "Insert")
                                        End If
                                    End With
                                    effectRow = .ExecuteInsert()
                                    Exit For
                                End With
                            End If
                        Next countInfo
                    End If
                Next countDT
            End If

            'If info.PolicyLines.Count > AuxDT.Rows.Count Then
            '    For countInfo = countDT To info.PolicyLines.Count - 1
            '        If info.PolicyLines(countInfo) <> "" Then
            '            With Me.MySQLParser
            '                .TableName = "Temp_tblAuxClientPolicy"
            '                With .Columns
            '                    .Clear()
            '                    .Add("AuxClientPolicyID", countInfo, SqlBuilder.SQLParserDataType.spNum)
            '                    .Add("ClientID", info.ClientID)
            '                    .Add("PolicyLine", info.PolicyLines(countInfo))
            '                    .Add("DateModification", DateTime.Now)
            '                    .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
            '                    .Add("ValueTypeChanged", "Insert")
            '                End With
            '                effectRow = .ExecuteInsert()
            '            End With
            '        End If
            '    Next countInfo
            'End If
        End Sub

        Private Function checkAuxExists(ByVal row As DataRow, ByVal info As DataInfo.CompanyPolicyInfo) As Boolean
            Dim check As Boolean
            Dim countInfo As Integer

            For countInfo = 0 To info.PolicyLines.Count - 1
                If row.Item("AuxClientPolicyID").ToString() = countInfo + 1 And row.Item("ClientID").ToString() = info.ClientID And row.Item("PolicyLine").ToString() = info.PolicyLines(countInfo) Then
                    check = True
                    Exit For
                End If
            Next countInfo
            Return check
        End Function

        Public Function GetTempAuxInfo(Optional ByVal ClientName As String = "", Optional ByVal dateFrom As String = "", Optional ByVal dateTo As String = "") As DataSet
            '//Aux 
            Dim AuxDT As DataTable
            Dim TempAuxDT As DataTable
            Dim AuxMasterDT As DataTable

            Dim ClientID As String = ""
            Dim TempTable As DataTable
            Dim AuxClientArr(1) As String
            Dim count As Integer
            Dim count2 As Integer
            Dim ds As New DataSet
            Dim foundRow() As DataRow

            AuxClientArr(0) = "ClientID"
            AuxClientArr(1) = "AuxClientPolicyID"

            '//Get ClientID 
            If ClientName <> "" Then
                ClientID = GetClientIDByName(ClientName)
            End If
            With Me.MySQLParser
                .TableName = "Temp_tblAuxClientPolicy"
                With .Columns
                    .Clear()
                    If ClientName <> "" Then
                        If ClientID <> "" Then
                            .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        Else
                            .Add("ClientID", "-1", SqlBuilder.SQLParserDataType.spNum, True)
                        End If
                    End If
                    If dateFrom = dateTo Then
                        If dateFrom <> "" And dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:990"
                            .Add("DateModification", "convert(varchar,cast('" + dateFrom + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, ">")
                            .Add("DateModification", "convert(varchar,cast('" + dateTo + " 23:59:59:990" + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, "<")
                        End If
                    Else
                        If dateFrom <> "" Then
                            .Add("DateModification", dateFrom, SqlBuilder.SQLParserDataType.spDate, True, ">")
                        End If
                        If dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:990"
                            .Add("DateModification", dateTo + " 23:59:59:990", SqlBuilder.SQLParserDataType.spText, True, "<=")
                        End If
                    End If
                    .Add("*")
                End With
                TempAuxDT = .ExecuteDataTable(.SQLSelect + " order by DateModification Desc")

                .TableName = "tblAuxClientPolicy"
                With .Columns
                    .Clear()
                    If ClientName <> "" Then
                        If ClientID <> "" Then
                            .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        Else
                            .Add("ClientID", "-1", SqlBuilder.SQLParserDataType.spNum, True)
                        End If
                    End If
                    .Add("PolicyLine", "", SqlBuilder.SQLParserDataType.spText, True, "is not")
                    .Add("*")
                End With
                AuxDT = .ExecuteDataTable()

                TempTable = TempAuxDT.DefaultView.ToTable(True, AuxClientArr)
                AuxMasterDT = TempAuxDT.Clone()
                For count = 0 To TempTable.Rows.Count - 1
                    foundRow = AuxDT.Select("ClientID='" + TempTable.Rows(count).Item("ClientID").ToString() + "' and AuxClientPolicyID='" + TempTable.Rows(count).Item("AuxClientPolicyID").ToString() + "'")
                    If foundRow.Length > 0 Then
                        For count2 = 0 To foundRow.Length - 1
                            AuxMasterDT.ImportRow(foundRow(count2))
                        Next count2
                    End If
                Next
                AuxMasterDT.AcceptChanges()
                AuxMasterDT.Merge(TempAuxDT)
                AuxMasterDT.TableName = "Aux"
                ds.Tables.Add(AuxMasterDT)
            End With
            Return ds
        End Function

#End Region

#Region "TA"
        Public Function GetTAClassData(ByVal ClientID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .TableName = "tblTA"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("*")
                End With
                dt = .ExecuteDataTable(.SQLSelect() + " order by TAID")
            End With
            Return dt
        End Function

        Public Function UpdateTAPolicy(ByVal info As DataInfo.CompanyPolicyInfo) As Integer
            Dim EffectRow As Integer = 1
            Dim TADT As DataTable
            Try
                TADT = GetTAClassData(info.ClientID)
                With Me.MySQLParser
                    '.OpenConnection()
                    '.BeginTran()
                    .TableName = "tblTA"
                    With .Columns
                        .Clear()
                        .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    End With
                    .ExecuteDelete()
                    '//
                    If EffectRow > 0 Then
                        '// 
                        .TableName = "tblTA"
                        For i As Integer = 0 To info.TAList.Count - 1
                            With .Columns
                                .Clear()
                                .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum)
                                .Add("TAID", i + 1, SqlBuilder.SQLParserDataType.spNum)
                                .Add("TravelerType", info.TAList(i).TravellerType)
                                .Add("RequiredTA", info.TAList(i).RequiredTA, SqlBuilder.SQLParserDataType.spBoolean)
                                .Add("Remarks", info.TAList(i).Remark)
                            End With
                            EffectRow = .ExecuteInsert()
                            If EffectRow <= 0 Then
                                Exit For
                            End If
                        Next
                    End If
                End With
                MatchTARecords(TADT, info)
                If EffectRow > 0 Then
                    Me.MySQLParser.CommitTran()
                Else
                    Me.MySQLParser.RollbackTran()
                End If
            Catch ex As Exception
                EffectRow = -1
                Me.MySQLParser.RollbackTran()
            Finally
                Me.MySQLParser.CloseConnection()
            End Try
            Return EffectRow
        End Function

        Private Sub MatchTARecords(ByVal TADT As DataTable, ByVal info As DataInfo.CompanyPolicyInfo)
            Dim countDT As Integer
            Dim countInfo As Integer
            Dim checkMatch As Boolean
            Dim effectRow As Integer

            If TADT.Rows.Count > 0 Then
                For countDT = 0 To TADT.Rows.Count - 1
                    checkMatch = CheckRecordExists(TADT.Rows(countDT), info)
                    If checkMatch = False Then

                        For countInfo = 0 To info.TAList.Count - 1
                            With Me.MySQLParser
                                .TableName = "Temp_tblTA"
                                With .Columns
                                    .Clear()
                                    .Add("ClientID", TADT.Rows(countDT).Item("ClientID").ToString())
                                    .Add("TAID", TADT.Rows(countDT).Item("TAID").ToString())
                                    .Add("TravelerType", TADT.Rows(countDT).Item("TravelerType").ToString())
                                    .Add("Remarks", TADT.Rows(countDT).Item("Remarks").ToString())
                                    .Add("RequiredTA", TADT.Rows(countDT).Item("RequiredTA").ToString())
                                    .Add("DateModification", DateTime.Now)
                                    .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                    If TADT.Rows(countDT).Item("ClientID").ToString() = info.ClientID And TADT.Rows(countDT).Item("TAID").ToString() = countInfo + 1 Then
                                        .Add("ValueTypeChanged", "Update")
                                    Else
                                        .Add("ValueTypeChanged", "Delete")
                                    End If
                                End With
                                effectRow = .ExecuteInsert()
                                Exit For
                            End With
                        Next countInfo
                    End If
                Next countDT
            End If

            If info.TAList.Count > countDT Then
                For countInfo = countDT To info.TAList.Count - 1
                    With Me.MySQLParser
                        .TableName = "Temp_tblTA"
                        With .Columns
                            .Clear()
                            .Add("ClientID", info.ClientID)
                            .Add("TAID", countInfo + 1)
                            .Add("TravelerType", info.TAList(countInfo).TravellerType)
                            .Add("Remarks", info.TAList(countInfo).Remark)
                            .Add("RequiredTA", info.TAList(countInfo).RequiredTA)
                            .Add("DateModification", DateTime.Now)
                            .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)          
                            .Add("ValueTypeChanged", "Insert")
                        End With
                        effectRow = .ExecuteInsert()
                    End With
                Next countInfo
            End If

        End Sub

        Private Function CheckRecordExists(ByVal row As DataRow, ByVal info As DataInfo.CompanyPolicyInfo)
            Dim countInfo As Integer
            Dim check As Boolean
            For countInfo = 0 To info.TAList.Count - 1
                If row.Item("ClientID").ToString() = info.ClientID And row.Item("TravelerType").ToString() = info.TAList(countInfo).TravellerType And row.Item("Remarks").ToString() = info.TAList(countInfo).Remark And row.Item("RequiredTA").ToString() = info.TAList(countInfo).RequiredTA Then
                    check = True
                    Exit For
                End If
            Next countInfo
            Return check
        End Function
        Public Function GetTempTAInfo(Optional ByVal ClientName As String = "", Optional ByVal dateFrom As String = "", Optional ByVal dateTo As String = "") As DataSet
            '//TA DT 
            Dim TADT As DataTable
            Dim TempTADT As DataTable
            Dim TAMasterDT As DataTable

            Dim ClientID As String = ""
            Dim TempTable As DataTable
            Dim ClientIDArr(1) As String
            Dim count As Integer
            Dim count2 As Integer
            Dim ds As New DataSet
            Dim foundRow() As DataRow

            ClientIDArr(0) = "ClientID"
            ClientIDArr(1) = "TAID"
            '//Get ClientID 
            If ClientName <> "" Then
                ClientID = GetClientIDByName(ClientName)
            End If

            With Me.MySQLParser
                .TableName = "Temp_tblTA"
                With .Columns
                    .Clear()
                    If ClientName <> "" Then
                        If ClientID <> "" Then
                            .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        Else
                            .Add("ClientID", "-1", SqlBuilder.SQLParserDataType.spNum, True)
                        End If
                    End If
                    If dateFrom = dateTo Then
                        If dateFrom <> "" And dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:990"
                            .Add("DateModification", "convert(varchar,cast('" + dateFrom + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, ">")
                            .Add("DateModification", "convert(varchar,cast('" + dateTo + " 23:59:59:990" + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, "<")
                        End If
                    Else
                        If dateFrom <> "" Then
                            .Add("DateModification", dateFrom, SqlBuilder.SQLParserDataType.spDate, True, ">")
                        End If
                        If dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:990"
                            .Add("DateModification", dateTo + " 23:59:59:990", SqlBuilder.SQLParserDataType.spText, True, "<=")
                        End If
                    End If
                    .Add("*")
                End With
                TempTADT = .ExecuteDataTable(.SQLSelect + " order by DateModification Desc")

                .TableName = "tblTA"
                With .Columns
                    .Clear()
                    If ClientName <> "" Then
                        If ClientID <> "" Then
                            .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        Else
                            .Add("ClientID", "-1", SqlBuilder.SQLParserDataType.spNum, True)
                        End If
                    End If
                    .Add("*")
                End With
                TADT = .ExecuteDataTable()

                TempTable = TempTADT.DefaultView.ToTable(True, ClientIDArr)
                TAMasterDT = TempTADT.Clone()
                For count = 0 To TempTable.Rows.Count - 1
                    foundRow = TADT.Select("ClientID='" + TempTable.Rows(count).Item("ClientID").ToString() + "' and TAID='" + TempTable.Rows(count).Item("TAID").ToString() + "'")
                    If foundRow.Length > 0 Then
                        For count2 = 0 To foundRow.Length - 1
                            TAMasterDT.ImportRow(foundRow(count2))
                        Next count2
                    End If
                Next
                TAMasterDT.AcceptChanges()
                TAMasterDT.Merge(TempTADT)
                TAMasterDT.TableName = "TA"
                ds.Tables.Add(TAMasterDT)
            End With
            Return ds
        End Function
#End Region

        Public Function GetClientIDByName(ByVal ClientName As String) As String
            Dim retVal As String
            Dim retObj As Object
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblClientMaster"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("Name", ClientName, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("ClientID")
                End With
                retObj = .ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar, CommandType.Text)
                retVal = Util.DBNullToText(retObj)
            End With
            Return retVal
        End Function

    End Class
End Namespace


@


1.1.1.1
log
@no message
@
text
@@
