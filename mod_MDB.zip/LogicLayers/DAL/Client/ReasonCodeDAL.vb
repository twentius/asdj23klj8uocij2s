head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.22;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.22;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic
Imports System.Collections.Generic

Namespace DataAccessLayer
    Public Class ReasonCodeDAL
        Inherits BaseDA

        Public Function GetReasonCodeList(ByVal ClientID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .TableName = "tblStandardReasonCode r"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("distinct r.ProductType,r.[Type]")
                    .Add("(case r.[Type] when 'R' then 'Realized saving' else 'Missed saving' end) as TypeName")
                    .Add("isnull((select ApplyStd from tblReasonCodeSettings where ProductType=r.ProductType and [Type]=r.[Type] and ClientID=" + CWTMasterDB.Util.LimitTheString(ClientID) + "),0) as ApplyStd")
                End With
                dt = .ExecuteDataTable(.SQLSelect() + " order by r.ProductType")
            End With
            Return dt
        End Function

        Public Function GetReasonCodeByID(ByVal ClientID As String, ByVal ProductType As String, ByVal Type As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .TableName = "tblStandardReasonCode r"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("r.ProductType", ProductType, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("r.[Type]", Type, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("r.CRCodeID", "(select CRCodeID from tblClientReasonCode where ClientID=" + ClientID + ")", SqlBuilder.SQLParserDataType.spFunction, True, "not in")
                    .Add("r.*")
                    .Add("(case r.[Type] when 'R' then 'Realized saving' else 'Missed saving' end) as TypeName")
                End With
                dt = .ExecuteDataTable(.SQLSelect() + " order by r.ProductType")
            End With
            Return dt
        End Function

        Public Function GetReasonCodeByID(ByVal ProductType As String, ByVal Type As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .TableName = "tblStandardReasonCode r"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("r.ProductType", ProductType, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("r.[Type]", Type, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("r.*")
                    .Add("(case r.[Type] when 'R' then 'Realized saving' else 'Missed saving' end) as TypeName")
                End With
                dt = .ExecuteDataTable(.SQLSelect() + " order by r.ProductType")
            End With
            Return dt
        End Function

        Public Function GetClientReasonCode(ByVal ClientID As String, ByVal ProductType As String, ByVal Type As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .TableName = "tblClientReasonCode c inner join tblStandardReasonCode s on c.CRCodeID=s.CRCodeID"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("c.ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("c.ProductType", ProductType, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("s.ProductType", ProductType, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("s.[Type]", Type, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("c.*")
                    .Add("s.ReasonCode")
                    .Add("s.ProductType")
                    .Add("s.[Type]")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function IsApplyStd(ByVal ClientID As String, ByVal ProductType As String, ByVal Type As String) As Boolean
            Dim retVal As Boolean
            Dim retObject As Object
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblReasonCodeSettings"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("ProductType", ProductType, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("[Type]", Type, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("ApplyStd")
                End With
                retObject = .ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar)
            End With
            retVal = CBool(CWTMasterDB.Util.DBNullToZero(retObject))
            Return retVal
        End Function

        Public Function GetReasonDescByCode(ByVal CRCodeID As String) As String
            Dim retVal As String
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblStandardReasonCode"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("CRCodeID", CRCodeID, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("Description")
                End With
                retVal = .ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar)
            End With
            Return retVal
        End Function

        Private Function GetReasonCodeKeyID(ByVal ClientID As String, ByVal CRCodeID As String) As String
            Dim retVal As String = ""
            Dim retObj As Object
            With Me.MySQLParser
                .TableName = "tblClientReasonCode"
                With .Columns
                    .Clear()
                    .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("CRCodeID", CRCodeID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("ClientRCodeID")
                End With
                retObj = .ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar)
                If retObj IsNot Nothing Then
                    retVal = CWTMasterDB.Util.DBNullToText(retObj.ToString)
                End If
            End With
            Return retVal
        End Function

        Public Function UpdateReasonCode(ByVal info As DataInfo.CompanyReasonInfo) As Integer
            Dim EffectRow As Integer = 1
            Dim ReasonDT As DataTable
            Dim ClientReasonDT As DataTable
            Dim sqlTemp As String
            'Dim IsUpdate As Boolean
            'Dim KeyID As String = ""
            Try
                ReasonDT = GetReasonCodeByIDType(info.ClientID, info.ProductType, info.ReasonType)
                ClientReasonDT = GetClientReasonCode(info.ClientID, info.ProductType)
                With Me.MySQLParser

                    .TableName = "tblReasonCodeSettings"
                    With .Columns
                        .Clear()
                        .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        .Add("ProductType", info.ProductType, SqlBuilder.SQLParserDataType.spText, True)
                        .Add("[Type]", info.ReasonType, SqlBuilder.SQLParserDataType.spText, True)
                    End With
                    .ExecuteDelete()
                    With .Columns
                        .Clear()
                        .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum)
                        .Add("ProductType", info.ProductType)
                        .Add("[Type]", info.ReasonType, SqlBuilder.SQLParserDataType.spText)
                        .Add("ApplyStd", info.ApplyStd, SqlBuilder.SQLParserDataType.spBoolean)
                    End With
                    EffectRow = .ExecuteInsert()

                    '.TableName = "tblClientReasonCode c inner join tblStandardReasonCode s on c.CRCodeID=s.CRCodeID"
                    'With .Columns
                    '    .Clear()
                    '    .Add("c.ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    '    .Add("c.ProductType", info.ProductType, SqlBuilder.SQLParserDataType.spText, True)
                    '    .Add("s.Type", info.ReasonType, SqlBuilder.SQLParserDataType.spText, True)
                    'End With
                    '.ExecuteDelete()
                    sqlTemp = "Delete c FROM tblClientReasonCode c inner join tblStandardReasonCode s on c.CRCodeID=s.CRCodeID WHERE  c.ClientID = '" + info.ClientID + "' and c.ProductType = '" + info.ProductType + "' and s.[Type] ='" + info.ReasonType + "'"
                    .ExecuteCommand(sqlTemp)

                    For i As Integer = 0 To info.ReasonList.Count - 1
                        'KeyID = Me.GetReasonCodeKeyID(info.ClientID, info.ReasonList(i).CRCodeID)
                        .TableName = "tblClientReasonCode"
                        'IsUpdate = (KeyID <> "")
                        With .Columns
                            .Clear()
                            .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum)
                            .Add("CRCodeID", info.ReasonList(i).CRCodeID, SqlBuilder.SQLParserDataType.spNum)
                            .Add("ProductType", info.ProductType, SqlBuilder.SQLParserDataType.spText)
                            .Add("Description", info.ReasonList(i).Description)
                        End With
                        EffectRow = .ExecuteInsert()
                        If EffectRow <= 0 Then
                            Exit For
                        End If
                    Next
                End With
                MatchRecord(ReasonDT, info, "ReasonCodeSettings")
                MatchRecord(ClientReasonDT, info, "ClientReasonCode")

            Catch ex As Exception
                EffectRow = -1
            End Try
            Return EffectRow
        End Function

        Private Sub MatchRecord(ByRef ReasonTable As DataTable, ByRef info As DataInfo.CompanyReasonInfo, ByVal Type As String)
            Dim countDT As Integer
            Dim countInfo As Integer
            Dim checkMatch As Boolean
            Dim EffectedRow As Integer

            If Type = "ReasonCodeSettings" Then
                If ReasonTable.Rows.Count > 0 Then
                    For countDT = 0 To ReasonTable.Rows.Count - 1
                        checkMatch = CheckExist(ReasonTable.Rows(countDT), info, "ReasonCodeSettings")
                        If checkMatch = False Then
                            With Me.MySQLParser
                                .TableName = "Temp_tblReasonCodeSettings"
                                With .Columns
                                    .Clear()
                                    .Add("ClientID", ReasonTable.Rows(countDT).Item("ClientID").ToString(), SqlBuilder.SQLParserDataType.spNum)
                                    .Add("ProductType", ReasonTable.Rows(countDT).Item("ProductType").ToString())
                                    .Add("[Type]", ReasonTable.Rows(countDT).Item("Type").ToString())
                                    .Add("ApplyStd", ReasonTable.Rows(countDT).Item("ApplyStd"))
                                    .Add("DateModification", DateTime.Now)
                                    .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                    .Add("ValueTypeChanged", "Update")
                                End With
                                EffectedRow = .ExecuteInsert()
                            End With
                        End If
                    Next countDT
            Else
                With Me.MySQLParser
                    .TableName = "Temp_tblReasonCodeSettings"
                    With .Columns
                        .Clear()
                        .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum)
                        .Add("ProductType", info.ProductType)
                        .Add("[Type]", info.ReasonType)
                        .Add("ApplyStd", info.ApplyStd)
                        .Add("DateModification", DateTime.Now)
                        .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                        .Add("ValueTypeChanged", "Insert")
                    End With
                    EffectedRow = .ExecuteInsert()
                End With
                End If

            ElseIf Type = "ClientReasonCode" Then
                If ReasonTable.Rows.Count > 0 Then
                    For countDT = 0 To ReasonTable.Rows.Count - 1
                        If info.ReasonList.Count > 0 Then
                            checkMatch = CheckExist(ReasonTable.Rows(countDT), info, "ClientReasonCode")
                            If checkMatch = False Then
                                For countInfo = 0 To info.ReasonList.Count - 1
                                    If ReasonTable.Rows(countDT).Item("ClientID").ToString() = info.ClientID And ReasonTable.Rows(countDT).Item("CRCodeID") = info.ReasonList(countInfo).CRCodeID Then
                                        With Me.MySQLParser
                                            .TableName = "Temp_tblClientReasonCode"
                                            With .Columns
                                                .Clear()
                                                .Add("ClientID", ReasonTable.Rows(countDT).Item("ClientID").ToString(), SqlBuilder.SQLParserDataType.spNum)
                                                .Add("CRCodeID", ReasonTable.Rows(countDT).Item("CRCodeID"), SqlBuilder.SQLParserDataType.spNum)
                                                .Add("ProductType", ReasonTable.Rows(countDT).Item("ProductType"), SqlBuilder.SQLParserDataType.spText)
                                                .Add("Description", ReasonTable.Rows(countDT).Item("Description"))
                                                .Add("DateModification", DateTime.Now)
                                                .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                                .Add("ValueTypeChanged", "Update")
                                            End With
                                            EffectedRow = .ExecuteInsert()
                                            Exit For
                                        End With
                                    End If

                                    If CheckExistInDT(ReasonTable, info.ClientID, info.ReasonList(countInfo).CRCodeID, info.ProductType, info.ReasonList(countInfo).Description) = False Then
                                        With Me.MySQLParser
                                            .TableName = "Temp_tblClientReasonCode"
                                            With .Columns
                                                .Clear()
                                                .Add("ClientID", ReasonTable.Rows(countDT).Item("ClientID").ToString(), SqlBuilder.SQLParserDataType.spNum)
                                                .Add("CRCodeID", ReasonTable.Rows(countDT).Item("CRCodeID"), SqlBuilder.SQLParserDataType.spNum)
                                                .Add("ProductType", ReasonTable.Rows(countDT).Item("ProductType"), SqlBuilder.SQLParserDataType.spText)
                                                .Add("Description", ReasonTable.Rows(countDT).Item("Description"))
                                                .Add("DateModification", DateTime.Now)
                                                .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                                .Add("ValueTypeChanged", "Delete")
                                            End With
                                            EffectedRow = .ExecuteInsert()
                                            Exit For
                                        End With
                                    End If
                                Next countInfo
                            End If
                        Else 'delete when user selected type is ApplyStd = true
                            With Me.MySQLParser
                                .TableName = "Temp_tblClientReasonCode"
                                With .Columns
                                    .Clear()
                                    .Add("ClientID", ReasonTable.Rows(countDT).Item("ClientID").ToString(), SqlBuilder.SQLParserDataType.spNum)
                                    .Add("CRCodeID", ReasonTable.Rows(countDT).Item("CRCodeID"), SqlBuilder.SQLParserDataType.spNum)
                                    .Add("ProductType", ReasonTable.Rows(countDT).Item("ProductType"), SqlBuilder.SQLParserDataType.spText)
                                    .Add("Description", ReasonTable.Rows(countDT).Item("Description"))
                                    .Add("DateModification", DateTime.Now)
                                    .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                    .Add("ValueTypeChanged", "Delete")
                                End With
                                EffectedRow = .ExecuteInsert()
                            End With
                        End If
                    Next countDT
                End If

                If info.ReasonList.Count > ReasonTable.Rows.Count Then
                    For countInfo = countDT To info.ReasonList.Count - 1
                        With Me.MySQLParser
                            .TableName = "Temp_tblClientReasonCode"
                            With .Columns
                                .Clear()
                                .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum)
                                .Add("CRCodeID", info.ReasonList(countInfo).CRCodeID, SqlBuilder.SQLParserDataType.spNum)
                                .Add("ProductType", info.ProductType, SqlBuilder.SQLParserDataType.spText)
                                .Add("Description", info.ReasonList(countInfo).Description)
                                .Add("DateModification", DateTime.Now)
                                .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                .Add("ValueTypeChanged", "Insert")
                            End With
                            EffectedRow = .ExecuteInsert()
                        End With
                    Next countInfo
                End If
            End If
        End Sub

        Private Function CheckExist(ByVal row As DataRow, ByRef info As DataInfo.CompanyReasonInfo, ByVal Type As String) As Boolean
            Dim Boolcheck As Boolean
            Dim countInfo As Integer

            If Type = "ReasonCodeSettings" Then
                If row.Item("ProductType").ToString() = info.ProductType And row.Item("Type").ToString() = info.ReasonType And row.Item("ApplyStd") = info.ApplyStd Then
                    Boolcheck = True
                End If
            ElseIf Type = "ClientReasonCode" Then
                For countInfo = 0 To info.ReasonList.Count - 1
                    If row.Item("CRCodeID").ToString() = info.ReasonList(countInfo).CRCodeID And row.Item("ProductType").ToString() = info.ProductType And row.Item("Description").ToString() = info.ReasonList(countInfo).Description Then
                        Boolcheck = True
                        Exit For
                    End If
                Next
            End If
            Return Boolcheck
        End Function

        Private Function CheckExistInDT(ByVal ReasonDT As DataTable, ByVal ClientID As String, ByVal CRCodeID As String, ByVal ProductType As String, ByVal Description As String) As Boolean
            Dim bool As Boolean
            Dim countDT As Integer

            For countDT = 0 To ReasonDT.Rows.Count - 1
                If ReasonDT.Rows(countDT).Item("ClientID").ToString() = ClientID And ReasonDT.Rows(countDT).Item("CRCodeID").ToString() = CRCodeID Then
                    bool = True
                End If
            Next
            Return bool
        End Function

        Private Function GetReasonCodeByIDType(ByVal ClientID As String, ByVal ProductType As String, ByVal Type As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .TableName = "tblReasonCodeSettings"
                With .Columns
                    .Clear()
                    .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("ProductType", ProductType, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("Type", Type, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Private Function GetClientReasonCode(ByVal ClientID As String, ByVal ProductType As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .TableName = "tblClientReasonCode"
                With .Columns
                    .Clear()
                    .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("ProductType", ProductType, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function DeleteReasonCode(ByVal CID As String, ByVal PType As String, ByVal Type As String, ByVal CRCodeID As String) As Integer
            Dim effect As Boolean
            Try
                With Me.MySQLParser
                    .TableName = "tblClientReasonCode"
                    With .Columns
                        .Clear()
                        .Add("ClientID", CID, SqlBuilder.SQLParserDataType.spNum, True)
                        .Add("ProductType", PType, SqlBuilder.SQLParserDataType.spText, True)
                        .Add("CRCodeID", CRCodeID, SqlBuilder.SQLParserDataType.spFunction, True)
                    End With
                    CallProcedure(CID, PType, CRCodeID, "Delete", "sp_ClientReasonCode")
                    .ExecuteDelete()
                    .TableName = "tblReasonCodeSettings"
                    With .Columns
                        .Clear()
                        .Add("ClientID", CID, SqlBuilder.SQLParserDataType.spNum, True)
                        .Add("ProductType", PType, SqlBuilder.SQLParserDataType.spText, True)
                        .Add("[Type]", Type, SqlBuilder.SQLParserDataType.spText, True)
                    End With
                    CallProcedure(CID, PType, Type, "Delete", "sp_ReasonCodeSettings")
                    .ExecuteDelete()

                    effect = True
                End With
            Catch ex As Exception
                effect = False
            End Try
            Return effect
        End Function

        Private Sub CallProcedure(ByVal ClientID As String, ByVal ProductType As String, ByVal ReasonType As String, ByVal Type As String, ByVal StoreProdType As String)
            With Me.MySQLParser
                .ExecuteStoreProcedure("exec " + StoreProdType + " '" + ClientID + "','" + ProductType + "','" + ReasonType + "','" + ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName + "','" + Type + "'")
            End With
        End Sub

        Public Function GetTempReasonCode(Optional ByVal ClientName As String = "", Optional ByVal dateFrom As String = "", Optional ByVal dateTo As String = "") As DataSet
            '//ReasonCode Settings
            Dim SettingDT As DataTable
            Dim TempSettingDT As DataTable
            Dim SettingMasterDT As DataTable

            '//Client Reason Code
            Dim ClientDT As DataTable
            Dim TempClientDT As DataTable
            Dim ClientMasterDT As DataTable

            Dim ClientID As String = ""
            Dim TempTable As DataTable
            'Dim ClientIDArr(0) As String
            Dim ReasonCodeArr(2) As String
            Dim ClientReasonCodeArr(1) As String
            Dim count As Integer
            Dim count2 As Integer
            Dim ds As New DataSet
            Dim foundRow() As DataRow

            ReasonCodeArr(0) = "ClientID"
            ReasonCodeArr(1) = "ProductType"
            ReasonCodeArr(2) = "Type"
            ClientReasonCodeArr(0) = "ClientID"
            ClientReasonCodeArr(1) = "Type"
            '//Get ClientID 
            If ClientName <> "" Then
                ClientID = GetClientIDByName(ClientName)
            End If

            With Me.MySQLParser
                .TableName = "Temp_tblReasonCodeSettings"
                With .Columns
                    .Clear()
                    If ClientID <> "" Then
                        .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    End If
                    If dateFrom = dateTo Then
                        If dateFrom <> "" And dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:990"
                            .Add("DateModification", "convert(varchar,cast('" + dateFrom + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, ">")
                            .Add("DateModification", "convert(varchar,cast('" + dateTo + " 23:59:59:990" + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, "<")
                        End If
                    Else
                        If dateFrom <> "" Then
                            .Add("DateModification", dateFrom, SqlBuilder.SQLParserDataType.spDate, True, ">")
                        End If
                        If dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:990"
                            .Add("DateModification", dateTo + " 23:59:59:990", SqlBuilder.SQLParserDataType.spText, True, "<=")
                        End If
                    End If
                    .Add("ClientID,ProductType,case Type when 'R' then 'Realized Saving' when 'M' then 'Missing Saving'End As Type, ApplyStd,DateModification,UserName,ValueTypeChanged")
                End With
                TempSettingDT = .ExecuteDataTable(.SQLSelect + " order by DateModification Desc")

                .TableName = "tblReasonCodeSettings"
                With .Columns
                    .Clear()
                    If ClientID <> "" Then
                        .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    End If
                    .Add("ClientID,ProductType,case Type when 'R' then 'Realized Saving' when 'M' then 'Missing Saving' End As Type,ApplyStd")
                End With
                SettingDT = .ExecuteDataTable()

                TempTable = TempSettingDT.DefaultView.ToTable(True, ReasonCodeArr)
                SettingMasterDT = TempSettingDT.Clone()
                For count = 0 To TempTable.Rows.Count - 1
                    foundRow = SettingDT.Select("ClientID='" + TempTable.Rows(count).Item("ClientID").ToString() + "' and ProductType='" + TempTable.Rows(count).Item("ProductType").ToString() + "' and Type='" + TempTable.Rows(count).Item("Type").ToString() + "'")
                    If foundRow.Length > 0 Then
                        For count2 = 0 To foundRow.Length - 1
                            SettingMasterDT.ImportRow(foundRow(count2))
                        Next count2
                    End If
                Next
                SettingMasterDT.AcceptChanges()
                SettingMasterDT.Merge(TempSettingDT)
                SettingMasterDT.TableName = "Setting"
                ds.Tables.Add(SettingMasterDT)

                .TableName = "Temp_tblClientReasonCode cr left join tblStandardReasonCode s on cr.CRCodeID=s.CRCodeID"
                With .Columns
                    .Clear()
                    If ClientID <> "" Then
                        .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    End If
                    If dateFrom = dateTo Then
                        If dateFrom <> "" And dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:990"
                            .Add("DateModification", "convert(varchar,cast('" + dateFrom + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, ">")
                            .Add("DateModification", "convert(varchar,cast('" + dateTo + " 23:59:59:990" + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, "<")
                        End If
                    Else
                        If dateFrom <> "" Then
                            .Add("DateModification", dateFrom, SqlBuilder.SQLParserDataType.spDate, True, ">")
                        End If
                        If dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:999"
                            .Add("DateModification", dateTo + " 23:59:59:990", SqlBuilder.SQLParserDataType.spText, True, "<=")
                        End If
                    End If
                    .Add("cr.ClientID,case when s.Type ='R' then 'Realized Saving' else 'Missing Saving' end as Type,cr.ProductType,cr.Description,cr.DateModification,cr.UserName,cr.ValueTypeChanged")
                End With
                TempClientDT = .ExecuteDataTable(.SQLSelect + " order by DateModification Desc")

                .TableName = "tblClientReasonCode cr left join tblStandardReasonCode s on cr.CRCodeID=s.CRCodeID"
                With .Columns
                    .Clear()
                    If ClientID <> "" Then
                        .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    End If
                    .Add("cr.ClientID,case when s.Type ='R' then 'Realized Saving' else 'Missing Saving' end as Type,cr.ProductType,cr.Description")
                End With
                ClientDT = .ExecuteDataTable()

                TempTable = TempClientDT.DefaultView.ToTable(True, ClientReasonCodeArr)
                ClientMasterDT = TempClientDT.Clone()
                For count = 0 To TempTable.Rows.Count - 1
                    foundRow = ClientDT.Select("ClientID='" + TempTable.Rows(count).Item("ClientID").ToString() + "' and Type='" + TempTable.Rows(count).Item("Type").ToString() + "'")
                    If foundRow.Length > 0 Then
                        For count2 = 0 To foundRow.Length - 1
                            ClientMasterDT.ImportRow(foundRow(count2))
                        Next count2
                    End If
                Next
                ClientMasterDT.AcceptChanges()
                ClientMasterDT.Merge(TempClientDT)
                ClientMasterDT.TableName = "ClientCode"
                ds.Tables.Add(ClientMasterDT)
            End With
            Return ds
        End Function

        Public Function GetClientIDByName(ByVal ClientName As String) As String
            Dim retVal As String
            Dim retObj As Object
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblClientMaster"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("Name", ClientName, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("ClientID")
                End With
                retObj = .ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar, CommandType.Text)
                retVal = Util.DBNullToText(retObj)
            End With
            Return retVal
        End Function

    End Class
End Namespace

@


1.1.1.1
log
@no message
@
text
@@
