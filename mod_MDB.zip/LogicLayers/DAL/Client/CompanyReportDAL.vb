head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.22;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.22;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic
Imports System.Collections.Generic

Namespace DataAccessLayer
    Public Class CompanyReportDAL
        Inherits BaseDA

        Public Function GetReportingFieldType() As DataTable
            Dim oDataTable As DataTable
            With Me.MySQLParser
                .TableName = Util.StandardDB("tblReportingFieldType")
                With .Columns
                    .Clear()
                    .IncludeKey = False
                    .Add("ShowInMDB", True, SqlBuilder.SQLParserDataType.spBoolean, True)
                    .Add("*")
                End With
                oDataTable = .ExecuteDataTable()
            End With
            Return oDataTable
        End Function

        Public Function GetReportConfig(ByVal ClientID As String) As DataTable
            Dim oDataTable As DataTable
            With Me.MySQLParser
                .TableName = "tblClientMaster"
                With .Columns
                    .Clear()
                    .IncludeKey = False
                    .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("StandardReport")
                    .Add("ClientDefineReport")
                    .Add("CFACode")
                    .Add("GDSCode")
                End With
                oDataTable = .ExecuteDataTable()
            End With
            Return oDataTable
        End Function

        Public Function GetStandardReport(ByVal ClientID As String) As Boolean
            Dim retVal As Boolean
            With Me.MySQLParser
                .TableName = "tblClientMaster"
                With .Columns
                    .Clear()
                    .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("StandardReport")
                End With
                retVal = Util.DBNullToFalse(.ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar))
            End With
            Return retVal
        End Function

        Public Function GetClientDefineReport(ByVal ClientID As String) As Boolean
            Dim retVal As Boolean
            With Me.MySQLParser
                .TableName = "tblClientMaster"
                With .Columns
                    .Clear()
                    .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("ClientDefineReport")
                End With
                retVal = Util.DBNullToFalse(.ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar))
            End With
            Return retVal
        End Function

        Public Function UpdateReportConfig(ByVal info As DataInfo.CompanyInfo) As Integer
            Dim EffectRow As Integer
            Try
                With Me.MySQLParser
                    .TableName = "tblClientMaster"
                    With .Columns
                        .Clear()
                        .Add("ClientID", info.ID, SqlBuilder.SQLParserDataType.spNum, True)
                        .Add("StandardReport", info.StandardReport, SqlBuilder.SQLParserDataType.spBoolean)
                        .Add("ClientDefineReport", info.ClientDefineReport, SqlBuilder.SQLParserDataType.spBoolean)
                        .Add("CFACode", info.CFACode)
                        .Add("GDSCode", info.GDSCode)
                    End With
                    Me.CallProcedure("", info.ID, "Update", "sp_ClientMaster")
                    EffectRow = .ExecuteUpdate()
                End With
            Catch ex As Exception
                EffectRow = -1
            End Try
            Return EffectRow
        End Function

        Private Sub CallProcedure(ByVal ReportingListID As String, ByVal ClientID As String, ByVal Type As String, ByVal StoreProdType As String)
            If StoreProdType = "sp_ClientMaster" Then
                With Me.MySQLParser
                    .ExecuteStoreProcedure("exec " + StoreProdType + " '" + ClientID + "','" + ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName + "','" + Type + "'")
                End With
            ElseIf StoreProdType = "sp_ReportingList" Then
                With Me.MySQLParser
                    .ExecuteStoreProcedure("exec " + StoreProdType + " '" + ClientID + "','" + ReportingListID + "','" + ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName + "','" + Type + "'")
                End With
            Else
                With Me.MySQLParser
                    .ExecuteStoreProcedure("exec " + StoreProdType + " '" + ReportingListID + "','" + ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName + "','" + Type + "'")
                End With
            End If

        End Sub

        Public Function GetUDFReportList(ByVal ClientID As String, ByVal ReportingListID As String) As DataTable
            Dim oDataTable As DataTable
            With Me.MySQLParser
                .TableName = "tblReportingList r"
                With .Columns
                    .Clear()
                    .IncludeKey = False
                    .Add("r.ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    If ReportingListID <> "" Then
                        .Add("r.ReportingListID", ReportingListID, SqlBuilder.SQLParserDataType.spNum, True)
                    Else
                        .Add("(select count(*) from tblReportingDropList where ReportingListID=r.ReportingListID) as dropcount")
                    End If
                    .Add("r.*")
                End With
                oDataTable = .ExecuteDataTable()
            End With
            Return oDataTable
        End Function

        Public Function GetDroplistCount(ByVal ReportingListID As String) As Integer
            Dim retVal As Integer
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblReportingDropList"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("ReportingListID", ReportingListID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("count(*) as RecordCount")
                End With
                retVal = CWTMasterDB.Util.DBNullToZero(.ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar))
            End With
            Return retVal
        End Function

        Public Function GetUDFReportGDS(ByVal ReportingListID As String) As DataTable
            Dim oDataTable As DataTable
            With Me.MySQLParser
                .TableName = "tblGDSMapping"
                With .Columns
                    .Clear()
                    .IncludeKey = False
                    .Add("ReportingListID", ReportingListID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("*")
                End With
                oDataTable = .ExecuteDataTable(.SQLSelect + " order by GDSMappingID")
            End With
            Return oDataTable
        End Function

        Public Function GetUDFReportDropList(ByVal ReportingListID As String) As DataTable
            Dim oDataTable As DataTable
            With Me.MySQLParser
                .TableName = "tblReportingDropList"
                With .Columns
                    .Clear()
                    .IncludeKey = False
                    .Add("ReportingListID", ReportingListID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("*")
                End With
                oDataTable = .ExecuteDataTable(.SQLSelect + " order by ReportingValueID")
            End With
            Return oDataTable
        End Function

        Public Function GetUDFGDSMapping(ByVal ReportingListID As String) As DataTable
            Dim oDataTable As DataTable
            With Me.MySQLParser
                .TableName = "tblGDSMapping"
                With .Columns
                    .Clear()
                    .IncludeKey = False
                    .Add("ReportingListID", ReportingListID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("*")
                End With
                oDataTable = .ExecuteDataTable(.SQLSelect + " order by GDSMappingID")
            End With
            Return oDataTable
        End Function

        Public Function IsExistName(ByVal FieldName As String, ByVal ID As String, ByVal ClientID As String) As Boolean
            Dim retVal As Boolean
            Dim rCount As Integer
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblReportingList"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("Description", FieldName, SqlBuilder.SQLParserDataType.spText, True)
                    If ID <> "" Then .Add("ReportingListID", ID, SqlBuilder.SQLParserDataType.spText, True, "<>")
                    .Add("count(*) as RecordCount")
                End With
                rCount = CWTMasterDB.Util.DBNullToZero(.ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar))
                retVal = (rCount > 0)
            End With
            Return retVal
        End Function

        Public Function GetMinDropValue(ByVal ReportingListID As String) As Integer
            Dim retVal As Integer
            Dim retObj As Object
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblReportingDropList"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("ReportingListID", ReportingListID, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("Len(Min(Value))")
                End With
                retObj = .ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar)
                retVal = CWTMasterDB.Util.DBNullToZero(retObj)
            End With
            Return retVal
        End Function

        Public Function GetMaxDropValue(ByVal ReportingListID As String) As Integer
            Dim retVal As Integer
            Dim retObj As Object
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblReportingDropList"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("ReportingListID", ReportingListID, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("Len(Max(Value))")
                End With
                retObj = .ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar)
                retVal = CWTMasterDB.Util.DBNullToZero(retObj)
            End With
            Return retVal
        End Function

        Public Function GetMinValue(ByVal ReportingListID As String) As Integer
            Dim retVal As Integer
            Dim retObj As Object
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblReportingList"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("ReportingListID", ReportingListID, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("[Min]")
                End With
                retObj = .ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar)
                retVal = CWTMasterDB.Util.DBNullToZero(retObj)
            End With
            Return retVal
        End Function

        Public Function GetMaxValue(ByVal ReportingListID As String) As Integer
            Dim retVal As Integer
            Dim retObj As Object
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblReportingList"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("ReportingListID", ReportingListID, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("[Max]")
                End With
                retObj = .ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar)
                retVal = CWTMasterDB.Util.DBNullToZero(retObj)
            End With
            Return retVal
        End Function

        Public Function GetLastInsertReportingIDByClientID(ByVal ClientID As String) As String
            Dim retVal As Integer
            Dim retObj As Object
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblReportingList"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("max(ReportingListID) As ReportingListID")
                End With
                retObj = .ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar)
                retVal = CWTMasterDB.Util.DBNullToZero(retObj)
            End With
            Return retVal
        End Function

        Public Function UpdateUDFReport(ByVal info As DataInfo.UDFReportInfo) As Integer
            Dim EffectRow As Integer = -1
            Dim GDSMapDT As DataTable
            Dim ReportingDT As DataTable
            Try
                ReportingDT = GetReportingListDT(info.ID, info.ClientID)
                GDSMapDT = GetGDSMapping(info.ID)
                With Me.MySQLParser
                    .TableName = "tblReportingList"
                    With .Columns
                        .Clear()
                        If info.PageMode = CWTMasterDB.TransactionMode.UpdateMode Then
                            .Add("ReportingListID", info.ID, SqlBuilder.SQLParserDataType.spNum, True)
                        End If
                        .Add("ClientID", info.ClientID)
                        .Add("Description", info.Description)
                        .Add("FieldType", info.FieldType, SqlBuilder.SQLParserDataType.spNum)
                        .Add("Mandatory", info.Mandatory)
                        .Add("DataType", info.DataType)
                        .Add("Min", info.Min, SqlBuilder.SQLParserDataType.spNum)
                        .Add("Max", info.Max, SqlBuilder.SQLParserDataType.spNum)
                        If info.FieldType = 2 Then
                            .Add("ActualValue", info.SampleValue)
                        Else
                            .Add("SampleValue", info.SampleValue)
                        End If
                    End With

                    Select Case info.PageMode
                        Case CWTMasterDB.TransactionMode.AddNewMode
                            EffectRow = .ExecuteInsert()
                            info.ID = GetLastInsertReportingIDByClientID(info.ClientID)
                            CallProcedure(info.ID, info.ClientID, "Insert", "sp_ReportingList")
                            'info.ID = .GetLastIdentity
                        Case CWTMasterDB.TransactionMode.UpdateMode
                            If MatchReportingList(ReportingDT, info) = False Then
                                CallProcedure(info.ID, info.ClientID, "Update", "sp_ReportingList")
                            End If
                            EffectRow = .ExecuteUpdate()

                            '// CWT Contact
                            .TableName = "tblGDSMapping"
                            With .Columns
                                .Clear()
                                .Add("ReportingListID", info.ID, SqlBuilder.SQLParserDataType.spNum, True)
                            End With
                            .ExecuteDelete()
                    End Select
                    If EffectRow > 0 Then
                        '// GDS Mapping
                        .TableName = "tblGDSMapping"
                        For i As Integer = 0 To info.GDSFormat.Count - 1
                            With .Columns
                                .Clear()
                                .Add("ReportingListID", info.ID, SqlBuilder.SQLParserDataType.spNum)
                                .Add("GDSMappingID", i + 1, SqlBuilder.SQLParserDataType.spNum)
                                .Add("GDSFormat", info.GDSFormat(i))
                            End With
                            EffectRow = .ExecuteInsert()
                            If EffectRow <= 0 Then
                                Exit For
                            End If
                        Next
                        MatchGDSRecord(GDSMapDT, info)
                    End If
                End With
                If EffectRow > 0 Then
                    Me.MySQLParser.CommitTran()
                Else
                    Me.MySQLParser.RollbackTran()
                End If
            Catch ex As Exception
                EffectRow = -1
                Me.MySQLParser.RollbackTran()
            Finally
                Me.MySQLParser.CloseConnection()
            End Try
            Return EffectRow
        End Function

        Public Function UpdateUDFDropList(ByVal info As DataInfo.UDFReportInfo) As Integer
            Dim EffectRow As Integer = 1
            Dim ReportingDropListDT As DataTable
            ReportingDropListDT = GetUDFReportDropList(info.ID)
            Try
                With Me.MySQLParser
                    .TableName = "tblReportingDropList"
                    With .Columns
                        .Clear()
                        .Add("ReportingListID", info.ID, SqlBuilder.SQLParserDataType.spNum, True)
                    End With
                    .ExecuteDelete()
                    For i As Integer = 0 To info.Droplist.Count - 1
                        With .Columns
                            .Clear()
                            .Add("ReportingListID", info.ID, SqlBuilder.SQLParserDataType.spNum)
                            .Add("ReportingValueID", i + 1, SqlBuilder.SQLParserDataType.spNum)
                            .Add("Value", info.Droplist(i).Value)
                            .Add("Description", info.Droplist(i).Description)
                        End With
                        EffectRow = .ExecuteInsert()
                        If EffectRow <= 0 Then
                            Exit For
                        End If
                    Next
                End With
                MatchReportingDropList(ReportingDropListDT, info)
            Catch ex As Exception
                EffectRow = -1
            End Try
            Return EffectRow
        End Function

        Public Function DeleteUDFReport(ByVal ClientID As String, ByVal ReportingListID As String) As Integer
            Dim EffectRow As Integer = -1
            Dim ReportingDropListDT As DataTable
            Dim GDSMappingDT As DataTable
            Try
                ReportingDropListDT = GetUDFReportDropList(ReportingListID)
                GDSMappingDT = GetUDFGDSMapping(ReportingListID)
                With Me.MySQLParser
                    '.OpenConnection()
                    '.BeginTran()
                    '//
                    .TableName = "tblReportingDropList"
                    With .Columns
                        .Clear()
                        .Add("ReportingListID", ReportingListID, SqlBuilder.SQLParserDataType.spNum, True)
                    End With
                    .ExecuteDelete()
                    '//
                    .TableName = "tblGDSMapping"
                    With .Columns
                        .Clear()
                        .Add("ReportingListID", ReportingListID, SqlBuilder.SQLParserDataType.spNum, True)
                    End With
                    .ExecuteDelete()
                    '//
                    .TableName = "tblReportingList"
                    With .Columns
                        .Clear()
                        .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        .Add("ReportingListID", ReportingListID, SqlBuilder.SQLParserDataType.spNum, True)
                    End With
                    CallProcedure(ReportingListID, ClientID, "Delete", "sp_ReportingList")
                    .ExecuteDelete()
                End With
                Me.MySQLParser.CommitTran()
                EffectRow = 1

                InsertTempDeleteRecord(ReportingDropListDT, "ReportingDropList")
                InsertTempDeleteRecord(GDSMappingDT, "GDS")
            Catch ex As Exception
                EffectRow = -1
                Me.MySQLParser.RollbackTran()
            Finally
                Me.MySQLParser.CloseConnection()
            End Try
            Return EffectRow
        End Function

        Private Sub InsertTempDeleteRecord(ByVal DeleteDT As DataTable, ByVal Type As String)
            Dim countDT As Integer
            Dim effectRow As Integer

            For countDT = 0 To DeleteDT.Rows.Count - 1
                If Type = "ReportingDropList" Then
                    With Me.MySQLParser
                        .TableName = "Temp_tblReportingDropList"
                        With .Columns
                            .Clear()
                            .Add("ReportingValueID", DeleteDT.Rows(countDT).Item("ReportingValueID").ToString())
                            .Add("ReportingListID", DeleteDT.Rows(countDT).Item("ReportingListID").ToString())
                            .Add("Value", DeleteDT.Rows(countDT).Item("Value").ToString())
                            .Add("Description", DeleteDT.Rows(countDT).Item("Description").ToString())
                            .Add("DateModification", DateTime.Now)
                            .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                            .Add("ValueTypeChanged", "Delete")
                        End With
                        effectRow = .ExecuteInsert()
                    End With
                Else
                    With Me.MySQLParser
                        .TableName = "Temp_tblGDSMapping"
                        With .Columns
                            .Clear()
                            .IncludeKey = False
                            .Add("GDSMappingID", DeleteDT.Rows(countDT).Item("GDSMappingID").ToString(), SqlBuilder.SQLParserDataType.spNum)
                            .Add("ReportingListID", DeleteDT.Rows(countDT).Item("ReportingListID").ToString())
                            .Add("GDSFormat", DeleteDT.Rows(countDT).Item("GDSFormat").ToString())
                            .Add("DateModification", DateTime.Now)
                            .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                            .Add("ValueTypeChanged", "Delete")
                        End With
                        effectRow = .ExecuteInsert()
                    End With
                End If
                
            Next
        End Sub

        Private Function GetGDSMapping(ByVal ReportingListID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .TableName = "tblGDSMapping"
                With .Columns
                    .Clear()
                    .Add("ReportingListID", ReportingListID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Private Sub MatchReportingDropList(ByVal ReportingListDT As DataTable, ByVal info As DataInfo.UDFReportInfo)
            Dim countDT As Integer
            Dim countInfo As Integer
            Dim checkMatch As Boolean
            Dim effectRow As Integer

            If ReportingListDT.Rows.Count > 0 Then
                For countDT = 0 To ReportingListDT.Rows.Count - 1
                    checkMatch = CheckReportingDropListExists(ReportingListDT.Rows(countDT), info)

                    If checkMatch = False Then

                        For countInfo = 0 To info.Droplist.Count - 1
                            If ReportingListDT.Rows(countDT).Item("ReportingValueID").ToString() = countInfo + 1 And ReportingListDT.Rows(countDT).Item("ReportingListID").ToString() = info.ID Then
                                With Me.MySQLParser
                                    .TableName = "Temp_tblReportingDropList"
                                    With .Columns
                                        .Clear()
                                        .Add("ReportingValueID", ReportingListDT.Rows(countDT).Item("ReportingValueID").ToString())
                                        .Add("ReportingListID", ReportingListDT.Rows(countDT).Item("ReportingListID").ToString())
                                        .Add("Value", ReportingListDT.Rows(countDT).Item("Value").ToString())
                                        .Add("Description", ReportingListDT.Rows(countDT).Item("Description").ToString())
                                        .Add("DateModification", DateTime.Now)
                                        .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                        .Add("ValueTypeChanged", "Update")
                                    End With
                                    effectRow = .ExecuteInsert()
                                End With
                                Exit For
                                checkMatch = True
                            End If
                        Next countInfo

                        If checkMatch = False And ReportingListDT.Rows.Count > info.Droplist.Count Then
                            With Me.MySQLParser
                                .TableName = "Temp_tblReportingDropList"
                                With .Columns
                                    .Clear()
                                    .Add("ReportingValueID", ReportingListDT.Rows(countDT).Item("ReportingValueID").ToString())
                                    .Add("ReportingListID", ReportingListDT.Rows(countDT).Item("ReportingListID").ToString())
                                    .Add("Value", ReportingListDT.Rows(countDT).Item("Value").ToString())
                                    .Add("Description", ReportingListDT.Rows(countDT).Item("Description").ToString())
                                    .Add("DateModification", DateTime.Now)
                                    .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                    .Add("ValueTypeChanged", "Delete")
                                End With
                                effectRow = .ExecuteInsert()
                            End With
                        End If
                    End If
                Next countDT
            End If

            If info.Droplist.Count > countDT Then
                For countInfo = countDT To info.Droplist.Count - 1
                    With Me.MySQLParser
                        .TableName = "Temp_tblReportingDropList"
                        With .Columns
                            .Clear()
                            .Add("ReportingListID", info.ID, SqlBuilder.SQLParserDataType.spNum)
                            .Add("ReportingValueID", countInfo + 1, SqlBuilder.SQLParserDataType.spNum)
                            .Add("Value", info.Droplist(countInfo).Value)
                            .Add("Description", info.Droplist(countInfo).Description)
                            .Add("DateModification", DateTime.Now)
                            .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                            .Add("ValueTypeChanged", "Insert")
                        End With
                        effectRow = .ExecuteInsert()
                    End With
                Next countInfo
            End If

        End Sub

        Private Function CheckReportingDropListExists(ByVal row As DataRow, ByVal info As DataInfo.UDFReportInfo) As Boolean
            Dim check As Boolean
            Dim countInfo As Integer

            For countInfo = 0 To info.Droplist.Count - 1
                If row.Item("ReportingListID").ToString() = info.ID And row.Item("Value").ToString() = info.Droplist(countInfo).Value AndAlso row.Item("Description").ToString() = info.Droplist(countInfo).Description Then
                    check = True
                    Exit For
                End If
            Next countInfo
            Return check
        End Function

        Private Sub MatchGDSRecord(ByRef GDSDT As DataTable, ByRef info As DataInfo.UDFReportInfo)
            Dim countDT As Integer
            Dim countInfo As Integer
            Dim checkMatch As Boolean
            Dim effectRow As Integer

            If GDSDT.Rows.Count > 0 Then
                For countDT = 0 To GDSDT.Rows.Count - 1
                    checkMatch = CheckExists(GDSDT.Rows(countDT), info)
                    If checkMatch = False Then

                        For countInfo = 0 To info.GDSFormat.Count - 1
                            If GDSDT.Rows(countDT).Item("GDSMappingID").ToString() = countInfo + 1 And GDSDT.Rows(countDT).Item("ReportingListID").ToString() = info.ID Then
                                With Me.MySQLParser
                                    .TableName = "Temp_tblGDSMapping"
                                    With .Columns
                                        .Clear()
                                        .IncludeKey = False
                                        .Add("GDSMappingID", countInfo + 1, SqlBuilder.SQLParserDataType.spNum)
                                        .Add("ReportingListID", GDSDT.Rows(countDT).Item("ReportingListID").ToString())
                                        .Add("GDSFormat", GDSDT.Rows(countDT).Item("GDSFormat").ToString())
                                        .Add("DateModification", DateTime.Now)
                                        .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                        .Add("ValueTypeChanged", "Update")
                                    End With
                                    effectRow = .ExecuteInsert()
                                End With
                                Exit For
                            Else
                                If GDSDT.Rows.Count > info.GDSFormat.Count Then
                                    With Me.MySQLParser
                                        .TableName = "Temp_tblGDSMapping"
                                        With .Columns
                                            .Clear()
                                            .IncludeKey = False
                                            .Add("GDSMappingID", GDSDT.Rows(countDT).Item("GDSMappingID").ToString(), SqlBuilder.SQLParserDataType.spNum)
                                            .Add("ReportingListID", GDSDT.Rows(countDT).Item("ReportingListID").ToString())
                                            .Add("GDSFormat", GDSDT.Rows(countDT).Item("GDSFormat").ToString())
                                            .Add("DateModification", DateTime.Now)
                                            .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                            .Add("ValueTypeChanged", "Delete")
                                        End With
                                        effectRow = .ExecuteInsert()
                                    End With
                                    Exit For
                                End If
                            End If
                        Next countInfo


                    End If
                Next countDT
            End If
            If info.GDSFormat.Count > countDT Then
                For countInfo = countDT To info.GDSFormat.Count - 1
                    With Me.MySQLParser
                        .TableName = "Temp_tblGDSMapping"
                        With .Columns
                            .Clear()
                            .IncludeKey = False
                            .Add("GDSMappingID", countInfo + 1, SqlBuilder.SQLParserDataType.spNum)
                            .Add("ReportingListID", info.ID)
                            .Add("GDSFormat", info.GDSFormat(countInfo))
                            .Add("DateModification", DateTime.Now)
                            .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                            .Add("ValueTypeChanged", "Insert")
                        End With
                        effectRow = .ExecuteInsert()
                    End With
                Next
            End If
        End Sub

        Private Function MatchReportingList(ByVal dt As DataTable, ByRef info As DataInfo.UDFReportInfo) As Boolean
            Dim check As Boolean
            If dt.Rows.Count > 0 Then
                For i As Integer = 0 To dt.Rows.Count - 1
                    If info.FieldType = 2 Then
                        If dt.Rows(i).Item("ReportingListID").ToString() = info.ID AndAlso dt.Rows(i).Item("ClientID").ToString() = info.ClientID AndAlso dt.Rows(i).Item("Description").ToString() = info.Description AndAlso dt.Rows(i).Item("FieldType").ToString() = info.FieldType AndAlso dt.Rows(i).Item("Mandatory") = info.Mandatory AndAlso dt.Rows(i).Item("DataType").ToString() = info.DataType AndAlso dt.Rows(i).Item("Min").ToString() = info.Min AndAlso dt.Rows(i).Item("Max").ToString() = info.Max AndAlso dt.Rows(i).Item("ActualValue").ToString() = info.SampleValue Then
                            check = True
                            Exit For
                        End If
                    Else

                        If dt.Rows(i).Item("ReportingListID").ToString() = info.ID AndAlso dt.Rows(i).Item("ClientID").ToString() = info.ClientID AndAlso dt.Rows(i).Item("Description").ToString() = info.Description AndAlso dt.Rows(i).Item("FieldType").ToString() = info.FieldType AndAlso dt.Rows(i).Item("Mandatory") = info.Mandatory AndAlso dt.Rows(i).Item("DataType").ToString() = info.DataType AndAlso dt.Rows(i).Item("Min").ToString() = info.Min AndAlso dt.Rows(i).Item("Max").ToString() = info.Max AndAlso dt.Rows(i).Item("SampleValue").ToString() = info.SampleValue Then
                            check = True
                            Exit For
                        End If
                    End If
                Next
            End If

            Return check
        End Function

        Private Function GetReportingListDT(ByVal ReportingID As String, ByVal ClientID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .TableName = "tblReportingList"
                With .Columns
                    .Clear()
                    .Add("ReportingListID", ReportingID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Private Function CheckExists(ByVal row As DataRow, ByVal info As DataInfo.UDFReportInfo) As Boolean
            Dim check As Boolean
            Dim countInfo As Integer

            For countInfo = 0 To info.GDSFormat.Count - 1
                If row.Item("ReportingListID").ToString() = info.ID AndAlso row.Item("GDSFormat").ToString() = info.GDSFormat(countInfo) Then
                    check = True
                End If
            Next countInfo
            Return check
        End Function

        Public Function GetTempReportInfo(Optional ByVal ClientName As String = "", Optional ByVal dateFrom As String = "", Optional ByVal dateTo As String = "") As DataSet
            '//Report
            Dim TempConfigDT As DataTable
            Dim ConfigDT As DataTable
            Dim ConfigMasterDT As DataTable

            Dim TempTable As DataTable
            Dim ClientIDArr(0) As String
            Dim count As Integer
            Dim count2 As Integer
            Dim ds As New DataSet
            Dim foundRow() As DataRow

            ClientIDArr(0) = "ClientID"


            With Me.MySQLParser
                .TableName = "Temp_tblClientMaster"
                With .Columns
                    .Clear()
                    If ClientName <> "" Then
                        .Add("Name", ClientName, SqlBuilder.SQLParserDataType.spText, True)
                    End If
                    If dateFrom = dateTo Then
                        If dateFrom <> "" And dateTo <> "" Then
                            dateTo = dateTo + " 23:59:59:990"
                            .Add("DateModification", "convert(varchar,cast('" + dateFrom + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, ">")
                            .Add("DateModification", "convert(varchar,cast('" + dateTo + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, "<")
                        End If
                    Else
                        If dateFrom <> "" Then
                            .Add("DateModification", dateFrom, SqlBuilder.SQLParserDataType.spDate, True, ">")
                        End If
                        If dateTo <> "" Then
                            .Add("DateModification", dateTo, SqlBuilder.SQLParserDataType.spDate, True, "<")
                        End If
                    End If
                    .Add("ClientID,GroupName,Name,StandardReport,ClientDefineReport,CFACode,GDSCode,DateModification,UserName,ValueTypeChanged")
                End With
                TempConfigDT = .ExecuteDataTable(.SQLSelect + " order by DateModification DESC")

                .TableName = "tblClientMaster"
                With .Columns
                    .Clear()
                    If ClientName <> "" Then
                        .Add("Name", ClientName, SqlBuilder.SQLParserDataType.spText, True)
                    End If
                    If dateFrom = dateTo Then
                        If dateFrom <> "" And dateTo <> "" Then
                            dateTo = dateTo + " 23:59:59:990"
                            .Add("DateModification", "convert(varchar,cast('" + dateFrom + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, ">")
                            .Add("DateModification", "convert(varchar,cast('" + dateTo + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, "<")
                        End If
                    Else
                        If dateFrom <> "" Then
                            .Add("DateModification", dateFrom, SqlBuilder.SQLParserDataType.spDate, True, ">")
                        End If
                        If dateTo <> "" Then
                            .Add("DateModification", dateTo, SqlBuilder.SQLParserDataType.spDate, True, "<")
                        End If
                    End If
                    .Add("ClientID,GroupName,Name,StandardReport,ClientDefineReport,CFACode,GDSCode")
                End With
                ConfigDT = .ExecuteDataTable()

                Dim count3 As Integer
                Dim TempDeleteRecordDT As New DataTable
                Dim TempTableConfig As New DataTable
                Dim TempMasterConfigDT As New DataTable

                TempDeleteRecordDT = TempConfigDT.Clone()
                TempMasterConfigDT = TempConfigDT.Clone()
                TempTable = TempConfigDT.DefaultView.ToTable(True, ClientIDArr)
                ConfigMasterDT = TempConfigDT.Clone()
                For count = 0 To TempTable.Rows.Count - 1
                    foundRow = ConfigDT.Select("ClientID='" + TempTable.Rows(count).Item("ClientID").ToString() + "'")
                    If foundRow.Length > 0 Then
                        For count2 = 0 To foundRow.Length - 1

                            If count2 = foundRow.Length - 1 Then
                                ConfigMasterDT.ImportRow(foundRow(count2))

                                'Fliter those same record in Temp_Client Master table .. 
                                For count3 = 0 To TempConfigDT.Rows.Count - 1
                                    If foundRow(count2).Item("ClientID").ToString() = TempConfigDT.Rows(count3).Item("ClientID").ToString() Then
                                        If TempConfigDT.Rows(count3).Item("ValueTypeChanged").ToString() <> "Insert" Then
                                            If foundRow(count2).Item("StandardReport").ToString() <> TempConfigDT.Rows(count3).Item("StandardReport").ToString() Or foundRow(count2).Item("ClientDefineReport").ToString() <> TempConfigDT.Rows(count3).Item("ClientDefineReport").ToString() Or foundRow(count2).Item("CFACode").ToString() <> TempConfigDT.Rows(count3).Item("CFACode").ToString() Or foundRow(count2).Item("GDSCode").ToString() <> TempConfigDT.Rows(count3).Item("GDSCode").ToString() Then
                                                If CheckTempRecordExist(TempDeleteRecordDT, TempConfigDT.Rows(count3)) = False Then
                                                    TempDeleteRecordDT.ImportRow(TempConfigDT.Rows(count3))
                                                End If
                                            End If
                                        Else
                                            TempDeleteRecordDT.ImportRow(TempConfigDT.Rows(count3))
                                        End If
                                    End If
                                Next count3


                            End If
                        Next count2
                    End If
                Next

                Dim drs() As DataRow = TempDeleteRecordDT.Select("UserName<>''", "DateModification desc")
                For Each dr As DataRow In drs
                    TempMasterConfigDT.ImportRow(dr)
                Next

                ConfigMasterDT.AcceptChanges()
                ConfigMasterDT.Merge(TempMasterConfigDT)
                ConfigMasterDT.TableName = "Config"
                ds.Tables.Add(ConfigMasterDT)
            End With
            Return ds
        End Function

        Private Function CheckTempRecordExist(ByVal TempDeleteRecordDT As DataTable, ByVal TempConfigDT As DataRow)
            Dim check As Boolean
            Dim count2 As Integer

            For count2 = 0 To TempDeleteRecordDT.Rows.Count - 1
                If TempDeleteRecordDT.Rows(count2).Item("Name").ToString() = TempConfigDT.Item("Name").ToString() Then
                    If TempDeleteRecordDT.Rows(count2).Item("StandardReport").ToString() = TempConfigDT.Item("StandardReport").ToString() And TempDeleteRecordDT.Rows(count2).Item("ClientDefineReport").ToString() = TempConfigDT.Item("ClientDefineReport").ToString() And TempDeleteRecordDT.Rows(count2).Item("CFACode").ToString() = TempConfigDT.Item("CFACode").ToString() And TempDeleteRecordDT.Rows(count2).Item("GDSCode").ToString() = TempConfigDT.Item("GDSCode").ToString() Then
                        check = True
                        Exit For
                    End If
                End If
            Next count2
            Return check
        End Function

        Private Function CheckTempClientIDExists(ByVal TempRecordRow As DataRow, ByVal TempConfigDT As DataTable)
            Dim check As Boolean
            Dim count As Integer

            For count = 0 To TempConfigDT.Rows.Count - 1
                If TempRecordRow.Item("ClientID").ToString() = TempConfigDT.Rows(count).Item("ClientID").ToString() Then
                    check = True
                    Exit For
                End If
            Next count
            Return check
        End Function

        Public Function GetClientIDByName(ByVal ClientName As String) As String
            Dim retVal As String
            Dim retObj As Object
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblClientMaster"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("Name", ClientName, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("ClientID")
                End With
                retObj = .ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar, CommandType.Text)
                retVal = Util.DBNullToText(retObj)
            End With
            Return retVal
        End Function

        Public Function GetTempClientReportingInfo(Optional ByVal ClientName As String = "", Optional ByVal dateFrom As String = "", Optional ByVal dateTo As String = "") As DataSet
            '//Reporting List
            Dim ReportDT As DataTable
            Dim TempReportDT As DataTable
            Dim ReportMasterDT As DataTable

            '// GDS Mapping
            Dim GDSDT As DataTable
            Dim TempGDSDT As DataTable
            Dim GDSMasterDT As DataTable

            '//ReportingDropDownList
            Dim ReportDropDownDT As DataTable
            Dim TempReportDropDownDT As DataTable
            Dim ReportDropDownMasterDT As DataTable

            Dim ClientID As String = ""
            Dim TempTable As DataTable
            Dim ClientIDArr(0) As String
            Dim GDSArr(1) As String
            Dim ReportingDropDownArr(1) As String
            Dim count As Integer
            Dim count2 As Integer
            Dim ds As New DataSet
            Dim foundRow() As DataRow
            Dim ReportingListIDDT As New DataTable
            Dim stringBuilderID As String = ""

            ClientIDArr(0) = "ClientID"
            GDSArr(0) = "GDSMappingID"
            GDSArr(1) = "ReportingListID"

            ReportingDropDownArr(0) = "ReportingValueID"
            ReportingDropDownArr(1) = "ReportingListID"
            '//Get ClientID 
            If ClientName <> "" Then
                ClientID = GetClientIDByName(ClientName)
                'If ClientID <> "" Then
                '    ReportingListIDDT = GetReportingListIDByClientID(ClientID)
                '    For count = 0 To ReportingListIDDT.Rows.Count - 1
                '        If stringBuilderID = "" Then
                '            stringBuilderID = stringBuilderID + ReportingListIDDT.Rows(count).Item("ReportingListID").ToString()
                '        Else
                '            stringBuilderID = stringBuilderID + "," + ReportingListIDDT.Rows(count).Item("ReportingListID").ToString()
                '        End If
                '    Next count
                'End If
            End If

            With Me.MySQLParser
                .TableName = "Temp_tblReportingList r inner join tblReportingFieldType t on r.FieldType =t.ReportingFieldTypeID "
                With .Columns
                    .Clear()
                    If ClientName <> "" Then
                        If ClientID <> "" Then    
                            .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        Else
                            .Add("ClientID", "-1", SqlBuilder.SQLParserDataType.spNum, True)
                        End If
                    End If
                    If dateFrom = dateTo Then
                        If dateFrom <> "" And dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:990"
                            .Add("DateModification", "convert(varchar,cast('" + dateFrom + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, ">")
                            .Add("DateModification", "convert(varchar,cast('" + dateTo + " 23:59:59:990" + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, "<")
                        End If
                    Else
                        If dateFrom <> "" Then
                            .Add("DateModification", dateFrom, SqlBuilder.SQLParserDataType.spDate, True, ">")
                        End If
                        If dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:990"
                            .Add("DateModification", dateTo + " 23:59:59:990", SqlBuilder.SQLParserDataType.spText, True, "<=")
                        End If
                    End If
                    .Add("r.ReportingListID,r.ClientID,r.Description,t.ReportingFieldType As FieldTypeDescription,r.Mandatory,r.DataType,r.Min,r.Max,r.SampleValue,r.ActualValue,r.DateModification,r.UserName,r.ValueTypeChanged")
                End With
                TempReportDT = .ExecuteDataTable(.SQLSelect + " order by DateModification Desc")

                .TableName = "tblReportingList r inner join tblReportingFieldType t on r.FieldType =t.ReportingFieldTypeID "
                With .Columns
                    .Clear()
                    If ClientName <> "" Then
                        If ClientID <> "" Then
                            .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        Else
                            .Add("ClientID", "-1", SqlBuilder.SQLParserDataType.spNum, True)
                        End If
                    End If
                    .Add("r.ReportingListID,r.ClientID,r.Description,t.ReportingFieldType As FieldTypeDescription,r.Mandatory,r.DataType,r.Min,r.Max,r.SampleValue,r.ActualValue")
                End With
                ReportDT = .ExecuteDataTable()

                TempTable = TempReportDT.DefaultView.ToTable(True, ClientIDArr)
                ReportMasterDT = TempReportDT.Clone()
                For count = 0 To TempTable.Rows.Count - 1
                    foundRow = ReportDT.Select("ClientID='" + TempTable.Rows(count).Item("ClientID").ToString() + "'")
                    If foundRow.Length > 0 Then
                        For count2 = 0 To foundRow.Length - 1
                            ReportMasterDT.ImportRow(foundRow(count2))
                        Next count2
                    End If
                Next
                ReportMasterDT.AcceptChanges()
                ReportMasterDT.Merge(TempReportDT)
                ReportMasterDT.TableName = "Reporting"
                ds.Tables.Add(ReportMasterDT)

                .TableName = "Temp_tblGDSMapping m inner join tblReportingList r on m.ReportingListID = r.ReportingListID"
                With .Columns
                    .Clear()
                    If ClientName <> "" Then
                        If ClientID <> "" And stringBuilderID <> "" Then
                            .Add("r.ClientID", ClientID, SqlBuilder.SQLParserDataType.spText, True)
                        End If
                    End If
                    If dateFrom = dateTo Then
                        If dateFrom <> "" And dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:990"
                            .Add("m.DateModification", "convert(varchar,cast('" + dateFrom + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, ">")
                            .Add("m.DateModification", "convert(varchar,cast('" + dateTo + " 23:59:59:990" + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, "<")
                        End If
                    Else
                        If dateFrom <> "" Then
                            .Add("m.DateModification", dateFrom, SqlBuilder.SQLParserDataType.spDate, True, ">")
                        End If
                        If dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:990"
                            .Add("DateModification", dateTo + " 23:59:59:990", SqlBuilder.SQLParserDataType.spText, True, "<=")
                        End If
                    End If
                    .Add("m.*")
                End With
                TempGDSDT = .ExecuteDataTable(.SQLSelect + " order by m.DateModification Desc")

                .TableName = "tblGDSMapping m inner join tblReportingList r on m.ReportingListID = r.ReportingListID"
                With .Columns
                    .Clear()
                    If ClientName <> "" Then
                        If ClientID <> "" And stringBuilderID <> "" Then
                            .Add("r.ClientID", ClientID, SqlBuilder.SQLParserDataType.spText, True)
                        End If
                    End If
                    .Add("m.*")
                End With
                GDSDT = .ExecuteDataTable()

                TempTable = TempGDSDT.DefaultView.ToTable(True, GDSArr)
                GDSMasterDT = TempGDSDT.Clone()
                For count = 0 To TempTable.Rows.Count - 1
                    foundRow = GDSDT.Select("GDSMappingID='" + TempTable.Rows(count).Item("GDSMappingID").ToString() + "' and ReportingListID='" + TempTable.Rows(count).Item("ReportingListID").ToString() + "'")
                    If foundRow.Length > 0 Then
                        For count2 = 0 To foundRow.Length - 1
                            GDSMasterDT.ImportRow(foundRow(count2))
                        Next count2
                    End If
                Next
                GDSMasterDT.AcceptChanges()
                GDSMasterDT.Merge(TempGDSDT)
                GDSMasterDT.TableName = "GDS"
                ds.Tables.Add(GDSMasterDT)


                .TableName = "Temp_tblReportingDropList d left join tblReportingList r on d.ReportingListID = r.ReportingListID"
                With .Columns
                    .Clear()
                    If ClientName <> "" Then
                        If ClientID <> "" And stringBuilderID <> "" Then
                            .Add("r.ClientID", ClientID, SqlBuilder.SQLParserDataType.spText, True)
                        End If
                    End If
                    If dateFrom = dateTo Then
                        If dateFrom <> "" And dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:990"
                            .Add("d.DateModification", "convert(varchar,cast('" + dateFrom + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, ">")
                            .Add("d.DateModification", "convert(varchar,cast('" + dateTo + " 23:59:59:990" + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, "<")
                        End If
                    Else
                        If dateFrom <> "" Then
                            .Add("d.DateModification", dateFrom, SqlBuilder.SQLParserDataType.spDate, True, ">")
                        End If
                        If dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:990"
                            .Add("d.DateModification", dateTo + " 23:59:59:990", SqlBuilder.SQLParserDataType.spText, True, "<=")
                        End If
                    End If
                    .Add("d.*")
                End With
                TempReportDropDownDT = .ExecuteDataTable(.SQLSelect + " order by d.DateModification Desc")

                .TableName = "tblReportingDropList d left join tblReportingList r on d.ReportingListID = r.ReportingListID"
                With .Columns
                    .Clear()
                    If ClientName <> "" Then
                        If ClientID <> "" And stringBuilderID <> "" Then
                            .Add("r.ClientID", ClientID, SqlBuilder.SQLParserDataType.spText, True)
                        End If
                    End If
                    .Add("d.*")
                End With
                ReportDropDownDT = .ExecuteDataTable()
            End With


            TempTable = TempReportDropDownDT.DefaultView.ToTable(True, ReportingDropDownArr)
            ReportDropDownMasterDT = TempReportDropDownDT.Clone()
            For count = 0 To TempTable.Rows.Count - 1
                foundRow = ReportDropDownDT.Select("ReportingValueID='" + TempTable.Rows(count).Item("ReportingValueID").ToString() + "' and ReportingListID='" + TempTable.Rows(count).Item("ReportingListID").ToString() + "'")
                If foundRow.Length > 0 Then
                    For count2 = 0 To foundRow.Length - 1
                        ReportDropDownMasterDT.ImportRow(foundRow(count2))
                    Next count2
                End If
            Next
            ReportDropDownMasterDT.AcceptChanges()
            ReportDropDownMasterDT.Merge(TempReportDropDownDT)
            ReportDropDownMasterDT.TableName = "ReportDropDown"
            ds.Tables.Add(ReportDropDownMasterDT)
            Return ds
        End Function

        Private Function GetReportingListIDByClientID(ByVal ClientID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .TableName = "Temp_tblReportingList"
                With .Columns
                    .Clear()
                    .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("ReportingListID")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

    End Class
End Namespace

@


1.1.1.1
log
@no message
@
text
@@
