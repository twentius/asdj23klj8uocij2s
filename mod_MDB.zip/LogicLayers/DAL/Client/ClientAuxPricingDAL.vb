head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.20;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.20;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic
Imports System.Collections.Generic

Namespace DataAccessLayer
    Public Class ClientAuxPricingDAL
        Inherits BaseDA

        Public Function GetProductList() As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblProducts"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("[Number]", "(select ApplytoProduct from tblAuxFee)", SqlBuilder.SQLParserDataType.spFunction, True, "IN")
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetAuxPricingList(ByVal ProductID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblAuxFee"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("ApplytoProduct", ProductID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetAuxPricingByID(ByVal AuxFeeID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblAuxFee"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("AuxFeeID", AuxFeeID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("FeeAmount")
                    .Add("(select top 1 p.[Name] from tblProducts p where p.[Number]=FeeProduct) as FeeProductName")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetAuxClientFee(ByVal ClientID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .TableName = "tblAuxClientFee c inner join tblAuxFee f on c.AuxFeeID=f.AuxFeeID"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("f.*")
                    .Add("(select top 1 p.[Name] from tblProducts p where p.[Number]=f.FeeProduct) as FeeProductName")
                    .Add("(select top 1 p.[Name] from tblProducts p where p.[Number]=f.ApplytoProduct) as ProductName ")
                End With
                dt = .ExecuteDataTable(.SQLSelect() + " order by AuxClientFeeID")
            End With
            Return dt
        End Function

        Public Function UpdateAuxClientFee(ByVal info As DataInfo.ClientAuxPricingInfo) As Integer
            Dim EffectRow As Integer = 1
            Try
                With Me.MySQLParser
                    .OpenConnection()
                    .BeginTran()
                    .TableName = "tblAuxClientFee"
                    With .Columns
                        .Clear()
                        .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    End With
                    .ExecuteDelete()
                    '//
                    If EffectRow > 0 Then
                        '// 
                        .TableName = "tblAuxClientFee"
                        For i As Integer = 0 To info.AuxFeeList.Count - 1
                            With .Columns
                                .Clear()
                                .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum)
                                .Add("AuxClientFeeID", i + 1, SqlBuilder.SQLParserDataType.spNum)
                                .Add("AuxFeeID", info.AuxFeeList(i))
                            End With
                            EffectRow = .ExecuteInsert()
                            If EffectRow <= 0 Then
                                Exit For
                            End If
                        Next
                    End If
                End With
                If EffectRow > 0 Then
                    Me.MySQLParser.CommitTran()
                Else
                    Me.MySQLParser.RollbackTran()
                End If
            Catch ex As Exception
                EffectRow = -1
                Me.MySQLParser.RollbackTran()
            Finally
                Me.MySQLParser.CloseConnection()
            End Try
            Return EffectRow
        End Function

    End Class

End Namespace

@


1.1.1.1
log
@no message
@
text
@@
