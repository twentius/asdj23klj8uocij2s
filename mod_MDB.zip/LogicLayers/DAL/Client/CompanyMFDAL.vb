head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.21;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.21;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic
Imports System.Collections.Generic

Namespace DataAccessLayer
    Public Class CompanyMFDAL
        Inherits BaseDA

        Public Function IsApplyStdMFCC(ByVal ClientID As String) As Boolean
            'ApplyMFCC
            Dim retVal As Boolean = False
            Dim retObj As Object = 0
            With Me.MySQLParser
                .TableName = "tblClientMaster"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("ApplyMFCC")
                End With
                retObj = .ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar)
            End With
            If Not IsDBNull(retObj) Then
                retVal = CBool(retObj)
            End If
            Return retVal
        End Function

        Public Function IsApplyStdMFBank(ByVal ClientID As String) As Boolean
            'ApplyMFCC
            Dim retVal As Boolean = False
            Dim retObj As Object = 0
            With Me.MySQLParser
                .TableName = "tblClientMaster"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("ApplyMFBank")
                End With
                retObj = .ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar)
            End With
            If Not IsDBNull(retObj) Then
                retVal = CBool(retObj)
            End If
            Return retVal
        End Function

        Public Function IsApplyStdMFProduct(ByVal ClientID As String) As Boolean
            'ApplyMFCC
            Dim retVal As Boolean = False
            Dim retObj As Object = 0
            With Me.MySQLParser
                .TableName = "tblClientMaster"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("StandardMFProduct")
                End With
                retObj = .ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar)
            End With
            If Not IsDBNull(retObj) Then
                retVal = CBool(retObj)
            End If
            Return retVal
        End Function

        Public Function GetClientMFCC(ByVal ClientID As String) As DataTable
            Dim dt As DataTable
            Dim sql As New StringBuilder()
            sql.AppendLine("declare @@db_name nvarchar(100);")
            sql.AppendLine("set @@db_name=db_name();")
            sql.AppendLine("exec " + CWTMasterDB.Util.StandardDB("sp_CWT_GetMFCCSettings") + "  @@db_name,'dbo'," + CWTMasterDB.Util.LimitTheString(ClientID) + "")
            dt = Me.MySQLParser.ExecuteDataTable(sql.ToString())
            Return dt
        End Function

        Public Function GetClientMFBank(ByVal ClientID As String) As DataTable
            'Dim dt As DataTable
            'Dim sql As New StringBuilder()
            'sql.AppendLine("declare @@db_name nvarchar(100);")
            'sql.AppendLine("set @@db_name=db_name();")
            'sql.AppendLine("exec " + CWTMasterDB.Util.StandardDB("sp_CWT_GetMFBankSettings") + "  @@db_name,'dbo'," + CWTMasterDB.Util.LimitTheString(ClientID) + "")
            'dt = Me.MySQLParser.ExecuteDataTable(sql.ToString())
            'Return dt
            Dim dt As DataTable
            With Me.MySQLParser
                .TableName = "tblMFByBank"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("MFBankID")
                    .Add("CCNumber")
                    .Add("Percentage")
                End With
                dt = .ExecuteDataTable(.SQLSelect() + " order by CCNumber")
            End With
            Return dt
        End Function

        Public Function GetClientMFProduct(ByVal ClientID As String) As DataTable
            Dim dt As DataTable
            Dim sql As New StringBuilder()
            sql.AppendLine("declare @@db_name nvarchar(100);")
            sql.AppendLine("set @@db_name=db_name();")
            sql.AppendLine("exec " + CWTMasterDB.Util.StandardDB("sp_CWT_GetMFProductSettings") + "  @@db_name,'dbo'," + CWTMasterDB.Util.LimitTheString(ClientID) + "")
            dt = Me.MySQLParser.ExecuteDataTable(sql.ToString())
            Return dt
        End Function


        'Public Function GetProduct() As DataTable
        '    Dim dt As DataTable
        '    With Me.MySQLParser
        '        .TableName = "tblProducts"
        '        With .Columns
        '            .IncludeKey = False
        '            .Clear()
        '            .Add("Number as ProductCode")
        '            .Add("Name")
        '        End With
        '        dt = .ExecuteDataTable(.SQLSelect() + " order by Number")
        '    End With

        '    Return dt
        'End Function

        Public Function GetStandardMF(ByVal ClientID As String) As Double
            Dim retVal As Double = 0
            Dim retObj As Object = 0
            With Me.MySQLParser
                .TableName = "tblClientMaster"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("MerchantFee")
                End With
                retObj = .ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar)
            End With
            retVal = CWTMasterDB.Util.DBNullToZero(retObj)
            Return retVal
        End Function

        '// Default
        Public Function GetMFCCList() As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .TableName = "tblMFByCC"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("Standard", True, SqlBuilder.SQLParserDataType.spBoolean, True)
                    .Add("*")
                    .Add("(select top 1 CCDescription from " + CWTMasterDB.Util.StandardDB("tblPaymentType") + " where CCCode=Vendor) as VendorText")
                End With
                dt = .ExecuteDataTable(.SQLSelect() + " order by VendorText")
            End With
            Return dt
        End Function

        Public Function GetMFBankList() As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .TableName = "tblMFByBank"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("Standard", True, SqlBuilder.SQLParserDataType.spBoolean, True)
                    .Add("MFBankID")
                    .Add("CCNumber")
                    .Add("Percentage")
                End With
                dt = .ExecuteDataTable(.SQLSelect() + " order by CCNumber")
            End With
            Return dt
        End Function

        Public Function GetMFProductList() As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .TableName = "tblMFByProduct m inner join tblProducts p on m.ProductCode=p.Number"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("Standard", True, SqlBuilder.SQLParserDataType.spBoolean, True)
                    .Add("p.Name,m.*")
                End With
                dt = .ExecuteDataTable(.SQLSelect() + " order by m.ProductCode")
            End With
            Return dt
        End Function

        Public Function SaveStandardMF(ByVal ClientID As String, ByVal MF As Double) As Integer
            Dim EffectRow As Integer
            Dim MFPen As Double
            MFPen = GetStandardMF(ClientID)
            Try
                With Me.MySQLParser
                    .TableName = "tblClientMaster"
                    With .Columns
                        .Clear()
                        .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        .Add("MerchantFee", MF, SqlBuilder.SQLParserDataType.spNum)
                    End With
                    EffectRow = .ExecuteUpdate()
                    InsertTempCCBankStandard("Standard", ClientID, MF, MFPen)
                End With
            Catch ex As Exception
                EffectRow = -1
            End Try
            Return EffectRow
        End Function

        Private Sub CallProcedure(ByVal ClientID As String, ByVal Type As String, ByVal StoreProdType As String)
            With Me.MySQLParser
                .ExecuteStoreProcedure("exec " + StoreProdType + " '" + ClientID + "','" + ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName + "','" + Type + "'")
            End With
        End Sub

        Public Function SaveMFCC(ByVal info As DataInfo.CompanyMFInfo) As Integer
            Dim dt As DataTable
            Dim EffectRow As Integer
            Dim ApplyCC As Boolean
            ApplyCC = IsApplyStdMFCC(info.ClientID)
            Try
                dt = GetMFByCCDetails(info.ClientID)
                With Me.MySQLParser
                    .TableName = "tblClientMaster"
                    With .Columns
                        .Clear()
                        .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        .Add("ApplyMFCC", info.ApplyStdCC, SqlBuilder.SQLParserDataType.spBoolean)
                    End With
                    .ExecuteUpdate()

                    InsertTempCCBankStandard("CC", info.ClientID, info.ApplyStdCC, ApplyCC)

                    .TableName = "tblMFByCC"
                    With .Columns
                        .Clear()
                        .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        .Add("ClientID", "NULL", SqlBuilder.SQLParserDataType.spFunction, True, "is not")
                    End With
                    .ExecuteDelete()
                    If Not info.ApplyStdCC Then
                        For i As Integer = 0 To info.CreditCards.Count - 1
                            With .Columns
                                .Clear()
                                .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum)
                                .Add("Vendor", info.CreditCards(i).Vendor)
                                .Add("Percentage", info.CreditCards(i).MFFee, SqlBuilder.SQLParserDataType.spNum)
                                .Add("Standard", False, SqlBuilder.SQLParserDataType.spBoolean)
                            End With
                            EffectRow = .ExecuteInsert()
                            If EffectRow <= 0 Then
                                Exit For
                            End If
                        Next
                        MatchMFByRecords(info, dt, "CreditCard")
                    End If
                End With
            Catch ex As Exception
                EffectRow = -1
            End Try
            Return EffectRow
        End Function

        Private Function GetMFByCCDetails(ByVal ClientID As String) As DataTable
            Dim dt As DataTable = New DataTable
            If ClientID <> "" Then
                With Me.MySQLParser
                    .AutoParameter = False
                    .TableName = "tblMFByCC"
                    With .Columns
                        .Clear()
                        .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        .Add("*")
                    End With
                    dt = .ExecuteDataTable()
                End With
            End If
            Return dt
        End Function

        Private Function CheckMFByCCRecordsExist(ByRef info As DataInfo.CompanyMFInfo, ByVal Row As DataRow, ByVal Type As String) As Boolean
            Dim checkExist As Boolean
            Dim countInfo As Integer

            If Type = "CreditCard" Then
                For countInfo = 0 To info.CreditCards.Count - 1
                    If Row.Item("Vendor").ToString() = info.CreditCards(countInfo).Vendor AndAlso Convert.ToDouble(Row.Item("Percentage")) = info.CreditCards(countInfo).MFFee Then
                        checkExist = True
                        Exit For
                    End If
                Next
            ElseIf Type = "Bank" Then
                For countInfo = 0 To info.BankCards.Count - 1
                    If Row.Item("MFBankID").ToString() = countInfo + 1 AndAlso Row.Item("CCNumber") = info.BankCards(countInfo).CCnumber AndAlso Convert.ToDouble(Row.Item("Percentage")) = info.BankCards(countInfo).MFFee Then
                        checkExist = True
                        Exit For
                    End If
                Next
            ElseIf Type = "Product" Then
                For countInfo = 0 To info.ProductMF.Count - 1
                    If Row.Item("ProductCode").ToString() = info.ProductMF(countInfo).ProductCode AndAlso Row.Item("SubjectToMF").ToString() = info.ProductMF(countInfo).SubjectToMF Then
                        checkExist = True
                        Exit For
                    End If
                Next
            End If
            Return checkExist
        End Function

        Private Sub MatchMFByRecords(ByRef info As DataInfo.CompanyMFInfo, ByRef MFByCC As DataTable, ByVal Type As String)
            Dim countInfo As Integer
            Dim countDT As Integer
            Dim checkExist As Boolean
            Dim EffectRow As Integer

            If Type = "CreditCard" Then
                If MFByCC.Rows.Count > 0 Then
                    For countDT = 0 To MFByCC.Rows.Count - 1
                        If Not info.ApplyStdCC Then
                            checkExist = CheckMFByCCRecordsExist(info, MFByCC.Rows(countDT), "CreditCard")
                            If checkExist = False Then
                                For countInfo = 0 To info.CreditCards.Count - 1
                                    If MFByCC.Rows(countDT).Item("Vendor").ToString() = info.CreditCards(countInfo).Vendor Then
                                        With Me.MySQLParser
                                            .TableName = "Temp_tblMFByCC"
                                            With .Columns
                                                .Clear()
                                                .Add("ClientID", MFByCC.Rows(countDT).Item("ClientID").ToString(), SqlBuilder.SQLParserDataType.spNum)
                                                .Add("Vendor", MFByCC.Rows(countDT).Item("Vendor").ToString())
                                                .Add("Percentage", MFByCC.Rows(countDT).Item("Percentage").ToString(), SqlBuilder.SQLParserDataType.spNum)
                                                .Add("Standard", MFByCC.Rows(countDT).Item("Standard").ToString(), SqlBuilder.SQLParserDataType.spBoolean)
                                                .Add("DateModification", DateTime.Now)
                                                .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                                .Add("ValueTypeChanged", "Update")
                                            End With
                                            EffectRow = .ExecuteInsert()
                                            Exit For
                                        End With
                                    End If
                                Next countInfo
                            End If
                        Else
                            With Me.MySQLParser
                                .TableName = "Temp_tblMFByCC"
                                With .Columns
                                    .Clear()
                                    .Add("ClientID", MFByCC.Rows(countDT).Item("ClientID").ToString(), SqlBuilder.SQLParserDataType.spNum)
                                    .Add("Vendor", MFByCC.Rows(countDT).Item("Vendor").ToString())
                                    .Add("Percentage", MFByCC.Rows(countDT).Item("Percentage").ToString(), SqlBuilder.SQLParserDataType.spNum)
                                    .Add("Standard", MFByCC.Rows(countDT).Item("Standard").ToString(), SqlBuilder.SQLParserDataType.spBoolean)
                                    .Add("DateModification", DateTime.Now)
                                    .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                    .Add("ValueTypeChanged", "Delete")
                                End With
                                EffectRow = .ExecuteInsert()
                            End With
                        End If
                    Next countDT
                End If

                If info.CreditCards.Count > MFByCC.Rows.Count Then
                    For countInfo = countDT To info.CreditCards.Count - 1
                        With Me.MySQLParser
                            .TableName = "Temp_tblMFByCC"
                            With .Columns
                                .Clear()
                                .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum)
                                .Add("Vendor", info.CreditCards(countInfo).Vendor)
                                .Add("Percentage", info.CreditCards(countInfo).MFFee, SqlBuilder.SQLParserDataType.spNum)
                                .Add("Standard", False, SqlBuilder.SQLParserDataType.spBoolean)
                                .Add("DateModification", DateTime.Now)
                                .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                .Add("ValueTypeChanged", "Insert")
                            End With
                            EffectRow = .ExecuteInsert()
                        End With
                    Next countInfo
                End If

            ElseIf Type = "Bank" Then

                If MFByCC.Rows.Count > 0 Then
                    For countDT = 0 To MFByCC.Rows.Count - 1
                        checkExist = CheckMFByCCRecordsExist(info, MFByCC.Rows(countDT), "Bank")
                        If checkExist = False Then
                            For countInfo = 0 To info.BankCards.Count - 1
                                If MFByCC.Rows(countDT).Item("MFBankID").ToString() = countInfo + 1 Then
                                    With Me.MySQLParser
                                        .TableName = "Temp_tblMFByBank"
                                        With .Columns
                                            .Clear()
                                            .Add("ClientID", MFByCC.Rows(countDT).Item("ClientID").ToString(), SqlBuilder.SQLParserDataType.spNum)
                                            .Add("MFBankID", MFByCC.Rows(countDT).Item("MFBankID").ToString())
                                            .Add("CCNumber", MFByCC.Rows(countDT).Item("CCNumber").ToString())
                                            .Add("Percentage", MFByCC.Rows(countDT).Item("Percentage").ToString(), SqlBuilder.SQLParserDataType.spNum)
                                            .Add("Standard", MFByCC.Rows(countDT).Item("Standard").ToString(), SqlBuilder.SQLParserDataType.spBoolean)
                                            .Add("DateModification", DateTime.Now)
                                            .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                            .Add("ValueTypeChanged", "Update")
                                        End With
                                        EffectRow = .ExecuteInsert()
                                        Exit For
                                    End With
                                End If
                            Next countInfo

                            If countDT > info.BankCards.Count - 1 Then
                                With Me.MySQLParser
                                    .TableName = "Temp_tblMFByBank"
                                    With .Columns
                                        .Clear()
                                        .Add("ClientID", MFByCC.Rows(countDT).Item("ClientID").ToString(), SqlBuilder.SQLParserDataType.spNum)
                                        .Add("MFBankID", MFByCC.Rows(countDT).Item("MFBankID").ToString())
                                        .Add("CCNumber", MFByCC.Rows(countDT).Item("CCNumber").ToString())
                                        .Add("Percentage", MFByCC.Rows(countDT).Item("Percentage").ToString(), SqlBuilder.SQLParserDataType.spNum)
                                        .Add("Standard", MFByCC.Rows(countDT).Item("Standard").ToString(), SqlBuilder.SQLParserDataType.spBoolean)
                                        .Add("DateModification", DateTime.Now)
                                        .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                        .Add("ValueTypeChanged", "Delete")
                                    End With
                                    EffectRow = .ExecuteInsert()
                                End With
                            End If
                        End If
                    Next countDT
            End If

                If info.BankCards.Count > MFByCC.Rows.Count Then
                    For countInfo = countDT To info.BankCards.Count - 1
                        With Me.MySQLParser
                            .TableName = "Temp_tblMFByBank"
                            With .Columns
                                .Clear()
                                .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum)
                                .Add("MFBankID", countInfo + 1)
                                .Add("CCNumber", info.BankCards(countInfo).CCnumber)
                                .Add("Percentage", info.BankCards(countInfo).MFFee, SqlBuilder.SQLParserDataType.spNum)
                                .Add("Standard", False, SqlBuilder.SQLParserDataType.spBoolean)
                                .Add("DateModification", DateTime.Now)
                                .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                .Add("ValueTypeChanged", "Insert")
                            End With
                            EffectRow = .ExecuteInsert()
                        End With
                    Next countInfo
                End If

            ElseIf Type = "Product" Then
                If MFByCC.Rows.Count > 0 Then
                    For countDT = 0 To MFByCC.Rows.Count - 1
                        checkExist = CheckMFByCCRecordsExist(info, MFByCC.Rows(countDT), "Product")
                        If checkExist = False Then
                            For countInfo = 0 To info.ProductMF.Count - 1
                                If info.ProductMF(countInfo).ProductCode = MFByCC.Rows(countDT).Item("ProductCode").ToString() Then
                                    With Me.MySQLParser
                                        .TableName = "Temp_tblMFByProduct"
                                        With .Columns
                                            .Clear()
                                            .Add("ClientID", MFByCC.Rows(countDT).Item("ClientID").ToString(), SqlBuilder.SQLParserDataType.spNum)
                                            .Add("ProductCode", MFByCC.Rows(countDT).Item("ProductCode").ToString())
                                            .Add("SubjectToMF", MFByCC.Rows(countDT).Item("SubjectToMF").ToString(), SqlBuilder.SQLParserDataType.spBoolean)
                                            .Add("Standard", MFByCC.Rows(countDT).Item("Standard").ToString(), SqlBuilder.SQLParserDataType.spBoolean)
                                            .Add("DateModification", DateTime.Now)
                                            .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                            .Add("ValueTypeChanged", "Update")
                                        End With
                                        EffectRow = .ExecuteInsert()
                                        Exit For
                                    End With
                                End If
                            Next countInfo
                        End If
                    Next countDT
                End If

                If info.ProductMF.Count > MFByCC.Rows.Count - 1 Then
                    For countInfo = countDT To info.ProductMF.Count - 1
                        With Me.MySQLParser
                            .TableName = "Temp_tblMFByProduct"
                            With .Columns
                                .Clear()
                                .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum)
                                .Add("ProductCode", info.ProductMF(countInfo).ProductCode)
                                .Add("SubjectToMF", info.ProductMF(countInfo).SubjectToMF, SqlBuilder.SQLParserDataType.spBoolean)
                                .Add("Standard", False, SqlBuilder.SQLParserDataType.spBoolean)
                                .Add("DateModification", DateTime.Now)
                                .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                .Add("ValueTypeChanged", "Insert")
                            End With
                            EffectRow = .ExecuteInsert()
                        End With
                    Next countInfo
                End If
            End If

        End Sub

        Public Function SaveMFBank(ByVal info As DataInfo.CompanyMFInfo) As Integer
            Dim EffectRow As Integer = 1
            Dim dt As DataTable
            Dim ApplyBank As Boolean
            ApplyBank = IsApplyStdMFBank(info.ClientID)
            Try
                dt = GetMFBankDetails(info.ClientID)
                With Me.MySQLParser
                    .TableName = "tblClientMaster"
                    With .Columns
                        .Clear()
                        .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        .Add("ApplyMFBank", info.ApplyStdBank, SqlBuilder.SQLParserDataType.spBoolean)
                    End With
                    .ExecuteUpdate()
                    InsertTempCCBankStandard("Bank", info.ClientID, info.ApplyStdBank, ApplyBank)


                    .TableName = "tblMFByBank"
                    With .Columns
                        .Clear()
                        .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        .Add("ClientID", "NULL", SqlBuilder.SQLParserDataType.spFunction, True, "is not")
                    End With
                    .ExecuteDelete()
                    If Not info.ApplyStdBank Then
                        For i As Integer = 0 To info.BankCards.Count - 1
                            With .Columns
                                .Clear()
                                .Add("MFBankID", i + 1, SqlBuilder.SQLParserDataType.spNum)
                                .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum)
                                .Add("CCNumber", info.BankCards(i).CCnumber)
                                .Add("Percentage", info.BankCards(i).MFFee, SqlBuilder.SQLParserDataType.spNum)
                                .Add("Standard", False, SqlBuilder.SQLParserDataType.spBoolean)
                            End With
                            EffectRow = .ExecuteInsert()
                            If EffectRow <= 0 Then
                                Exit For
                            End If
                        Next
                        MatchMFByRecords(info, dt, "Bank")
                    End If
                End With
            Catch ex As Exception
                EffectRow = -1
            End Try
            Return EffectRow
        End Function

        Private Sub InsertTempCCBankStandard(ByVal Type As String, ByVal ClientID As String, ByVal Value As String, ByVal OldValue As String)
            Dim effectRow As Integer
            Dim MFPen As Double
            Dim ApplyBank As Boolean
            Dim ApplyCC As Boolean
            MFPen = GetStandardMF(ClientID)
            ApplyCC = IsApplyStdMFCC(ClientID)
            ApplyBank = IsApplyStdMFBank(ClientID)

            If Type = "Standard" Then
                If Convert.ToDouble(OldValue) <> Convert.ToDouble(Value) Then
                    With Me.MySQLParser
                        .TableName = "Temp_tblMFCCBankStandard"
                        With .Columns
                            .Clear()
                            .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum)
                            .Add("StandardMerchantFee", OldValue, SqlBuilder.SQLParserDataType.spNum)
                            .Add("ApplyMFCC", ApplyCC, SqlBuilder.SQLParserDataType.spBoolean)
                            .Add("ApplyMFBank", ApplyBank, SqlBuilder.SQLParserDataType.spBoolean)
                            .Add("DateModification", DateTime.Now)
                            .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                            .Add("ValueTypeChanged", "Update")
                        End With
                        effectRow = .ExecuteInsert()
                    End With
                End If
            ElseIf Type = "CC" Then
                If Convert.ToBoolean(OldValue) <> Convert.ToBoolean(Value) Then
                    With Me.MySQLParser
                        .TableName = "Temp_tblMFCCBankStandard"
                        With .Columns
                            .Clear()
                            .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum)
                            .Add("StandardMerchantFee", MFPen, SqlBuilder.SQLParserDataType.spNum)
                            .Add("ApplyMFCC", OldValue, SqlBuilder.SQLParserDataType.spBoolean)
                            .Add("ApplyMFBank", ApplyBank, SqlBuilder.SQLParserDataType.spBoolean)
                            .Add("DateModification", DateTime.Now)
                            .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                            .Add("ValueTypeChanged", "Update")
                        End With
                        effectRow = .ExecuteInsert()
                    End With
                End If
            ElseIf Type = "Bank" Then
                If Convert.ToBoolean(OldValue) <> Convert.ToBoolean(Value) Then
                    With Me.MySQLParser
                        .TableName = "Temp_tblMFCCBankStandard"
                        With .Columns
                            .Clear()
                            .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum)
                            .Add("StandardMerchantFee", MFPen, SqlBuilder.SQLParserDataType.spNum)
                            .Add("ApplyMFCC", ApplyCC, SqlBuilder.SQLParserDataType.spBoolean)
                            .Add("ApplyMFBank", OldValue, SqlBuilder.SQLParserDataType.spBoolean)
                            .Add("DateModification", DateTime.Now)
                            .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                            .Add("ValueTypeChanged", "Update")
                        End With
                        effectRow = .ExecuteInsert()
                    End With
                End If
            End If
        End Sub
        Private Function GetMFBankDetails(ByVal ClientID As String) As DataTable
            Dim dt As DataTable
            If ClientID <> "" Then
                With Me.MySQLParser
                    .AutoParameter = False
                    .TableName = "tblMFByBank"
                    With .Columns
                        .Clear()
                        .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        .Add("*")
                    End With
                    dt = .ExecuteDataTable()
                End With
            End If
            Return dt
        End Function

        Public Function SaveMFProduct(ByVal info As DataInfo.CompanyMFInfo) As Integer
            Dim EffectRow As Integer = 1
            Dim dt As DataTable
            Try
                dt = GetMFProductDetails(info.ClientID)
                With Me.MySQLParser
                    .TableName = "tblClientMaster"
                    With .Columns
                        .Clear()
                        .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        .Add("StandardMFProduct", info.ApplyStdProduct, SqlBuilder.SQLParserDataType.spBoolean)
                    End With
                    Me.CallProcedure(info.ClientID, "Update", "sp_ClientMaster")
                    .ExecuteUpdate()
                    .TableName = "tblMFByProduct"
                    With .Columns
                        .Clear()
                        .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        .Add("ClientID", "NULL", SqlBuilder.SQLParserDataType.spFunction, True, "is not")
                    End With
                    .ExecuteDelete()
                    If Not info.ApplyStdProduct Then
                        For i As Integer = 0 To info.ProductMF.Count - 1
                            With .Columns
                                .Clear()
                                .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum)
                                .Add("ProductCode", info.ProductMF(i).ProductCode, SqlBuilder.SQLParserDataType.spNum)
                                .Add("SubjectToMF", info.ProductMF(i).SubjectToMF, SqlBuilder.SQLParserDataType.spBoolean)
                                .Add("Standard", False, SqlBuilder.SQLParserDataType.spBoolean)
                            End With
                            EffectRow = .ExecuteInsert()
                            If EffectRow <= 0 Then
                                Exit For
                            End If
                        Next
                        MatchMFByRecords(info, dt, "Product")

                        If dt.Rows.Count = 0 Then
                            .TableName = "Temp_tblMFProductApplyStandard"
                            With .Columns
                                .Clear()
                                .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum)
                                .Add("ApplyStandard", True, SqlBuilder.SQLParserDataType.spBoolean)
                                .Add("DateModification", DateTime.Now)
                                .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                .Add("ValueTypeChanged", "Update")
                            End With
                            EffectRow = .ExecuteInsert()
                        End If
                    Else
                        If dt.Rows.Count > 0 Then
                            .TableName = "Temp_tblMFProductApplyStandard"
                            With .Columns
                                .Clear()
                                .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum)
                                .Add("ApplyStandard", False, SqlBuilder.SQLParserDataType.spBoolean)
                                .Add("DateModification", DateTime.Now)
                                .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                .Add("ValueTypeChanged", "Update")
                            End With
                            EffectRow = .ExecuteInsert()
                        End If

                    End If

               
                End With
            Catch ex As Exception
                EffectRow = -1
            End Try
            Return EffectRow
        End Function

        Private Function GetMFProductDetails(ByVal ClientID As String)
            Dim dt As DataTable
            If ClientID <> "" Then
                With Me.MySQLParser
                    .AutoParameter = False
                    .TableName = "tblMFByProduct"
                    With .Columns
                        .Clear()
                        .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        .Add("*")
                    End With
                    dt = .ExecuteDataTable()
                End With
            End If
            Return dt
        End Function

        Public Function GetTempMFInfo(Optional ByVal ClientName As String = "", Optional ByVal dateFrom As String = "", Optional ByVal dateTo As String = "") As DataSet
            '//MFBank 
            Dim MFBankDT As DataTable
            Dim TempMFBankDT As DataTable
            Dim MFBankMasterDT As DataTable

            '//MFCC
            Dim MFCCDT As DataTable
            Dim TempMFCCDT As DataTable
            Dim MFCCMasterDT As DataTable

            '//Merchant Fee Bank & CC 
            Dim MFFeeDT As DataTable
            Dim TempMFFeeDT As DataTable
            Dim MFFeeMasterDT As DataTable

            Dim TempTable As DataTable
            Dim ClientIDArr(1) As String
            Dim CCArr(1) As String
            Dim FeeArr(0) As String
            Dim ClientID As String = ""
            Dim count As Integer
            Dim count2 As Integer
            Dim ds As New DataSet
            Dim foundRow() As DataRow

            ClientIDArr(0) = "ClientID"
            ClientIDArr(1) = "MFBankID"
            CCArr(0) = "ClientID"
            CCArr(1) = "Vendor"
            FeeArr(0) = "ClientID"
            '//Get ClientID 
            If ClientName <> "" Then
                ClientID = GetClientIDByName(ClientName)
            End If

            With Me.MySQLParser
                .TableName = "Temp_tblMFByBank"
                With .Columns
                    .Clear()
                    If ClientName <> "" Then
                        If ClientID <> "" Then
                            .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        Else
                            .Add("ClientID", "0", SqlBuilder.SQLParserDataType.spNum, True)
                        End If
                    End If
                    If dateFrom = dateTo Then
                        If dateFrom <> "" And dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:990"
                            .Add("DateModification", "convert(varchar,cast('" + dateFrom + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, ">")
                            .Add("DateModification", "convert(varchar,cast('" + dateTo + " 23:59:59:990" + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, "<")
                        End If
                    Else
                        If dateFrom <> "" Then
                            .Add("DateModification", dateFrom, SqlBuilder.SQLParserDataType.spDate, True, ">")
                        End If
                        If dateTo <> "" Then
                            ' dateTo = dateTo + " 23:59:59:990"
                            .Add("DateModification", dateTo + " 23:59:59:990", SqlBuilder.SQLParserDataType.spText, True, "<=")
                        End If
                    End If
                    .Add("*")
                End With
                TempMFBankDT = .ExecuteDataTable(.SQLSelect + " order by DateModification Desc")

                .TableName = "tblMFByBank"
                With .Columns
                    .Clear()
                    If ClientName <> "" Then
                        If ClientID <> "" Then
                            .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        Else
                            .Add("ClientID", "0", SqlBuilder.SQLParserDataType.spNum, True)
                        End If
                    End If
                    .Add("*")
                End With
                MFBankDT = .ExecuteDataTable()

                TempTable = TempMFBankDT.DefaultView.ToTable(True, ClientIDArr)
                MFBankMasterDT = TempMFBankDT.Clone()
                For count = 0 To TempTable.Rows.Count - 1
                    foundRow = MFBankDT.Select("ClientID='" + TempTable.Rows(count).Item("ClientID").ToString() + "' and MFBankID='" + TempTable.Rows(count).Item("MFBankID").ToString() + "'")
                    If foundRow.Length > 0 Then
                        For count2 = 0 To foundRow.Length - 1
                            MFBankMasterDT.ImportRow(foundRow(count2))
                        Next count2
                    End If
                Next
                MFBankMasterDT.AcceptChanges()
                MFBankMasterDT.Merge(TempMFBankDT)
                MFBankMasterDT.TableName = "Bank"
                ds.Tables.Add(MFBankMasterDT)


                '//MFByCC
                .TableName = "Temp_tblMFByCC"
                With .Columns
                    .Clear()
                    If ClientName <> "" Then
                        If ClientID <> "" Then
                            .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        Else
                            .Add("ClientID", "0", SqlBuilder.SQLParserDataType.spNum, True)
                        End If
                    End If
                    If dateFrom = dateTo Then
                        If dateFrom <> "" And dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:990"
                            .Add("DateModification", "convert(varchar,cast('" + dateFrom + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, ">")
                            .Add("DateModification", "convert(varchar,cast('" + dateTo + " 23:59:59:990" + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, "<")
                        End If
                    Else
                        If dateFrom <> "" Then
                            .Add("DateModification", dateFrom, SqlBuilder.SQLParserDataType.spDate, True, ">")
                        End If
                        If dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:990"
                            .Add("DateModification", dateTo + " 23:59:59:990", SqlBuilder.SQLParserDataType.spText, True, "<=")
                        End If
                    End If
                    .Add("*")
                End With
                TempMFCCDT = .ExecuteDataTable(.SQLSelect + " order by DateModification Desc")

                .TableName = "tblMFByCC"
                With .Columns
                    .Clear()
                    If ClientName <> "" Then
                        If ClientID <> "" Then
                            .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        Else
                            .Add("ClientID", "0", SqlBuilder.SQLParserDataType.spNum, True)
                        End If
                    End If
                    .Add("*")
                End With
                MFCCDT = .ExecuteDataTable()


                TempTable = TempMFCCDT.DefaultView.ToTable(True, CCArr)
                MFCCMasterDT = TempMFCCDT.Clone()
                For count = 0 To TempTable.Rows.Count - 1
                    foundRow = MFCCDT.Select("ClientID='" + TempTable.Rows(count).Item("ClientID").ToString() + "' and Vendor='" + TempTable.Rows(count).Item("Vendor").ToString() + "'")
                    If foundRow.Length > 0 Then
                        For count2 = 0 To foundRow.Length - 1
                            MFCCMasterDT.ImportRow(foundRow(count2))
                        Next count2
                    End If
                Next
                MFCCMasterDT.AcceptChanges()
                MFCCMasterDT.Merge(TempMFCCDT)
                MFCCMasterDT.TableName = "CC"
                ds.Tables.Add(MFCCMasterDT)

                .TableName = "Temp_tblMFCCBankStandard"
                With .Columns
                    .Clear()
                    If ClientName <> "" Then
                        If ClientID <> "" Then
                            .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        Else
                            .Add("ClientID", "0", SqlBuilder.SQLParserDataType.spNum, True)
                        End If
                    End If
                    If dateFrom = dateTo Then
                        If dateFrom <> "" And dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:990"
                            .Add("DateModification", "convert(varchar,cast('" + dateFrom + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, ">")
                            .Add("DateModification", "convert(varchar,cast('" + dateTo + " 23:59:59:990" + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, "<")
                        End If
                    Else
                        If dateFrom <> "" Then
                            .Add("DateModification", dateFrom, SqlBuilder.SQLParserDataType.spDate, True, ">")
                        End If
                        If dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:990"
                            .Add("DateModification", dateTo + " 23:59:59:990", SqlBuilder.SQLParserDataType.spText, True, "<=")
                        End If
                    End If
                    .Add("*")
                End With
                TempMFFeeDT = .ExecuteDataTable(.SQLSelect + " order by DateModification Desc")

                .TableName = "tblClientMaster"
                With .Columns
                    .Clear()
                    If ClientName <> "" Then
                        If ClientID <> "" Then
                            .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        Else
                            .Add("ClientID", "0", SqlBuilder.SQLParserDataType.spNum, True)
                        End If
                    End If
                    .Add("ClientID,MerchantFee As StandardMerchantFee,ApplyMFCC,ApplyMFBank")
                End With
                MFFeeDT = .ExecuteDataTable()

                TempTable = TempMFFeeDT.DefaultView.ToTable(True, FeeArr)
                MFFeeMasterDT = TempMFFeeDT.Clone()
                For count = 0 To TempTable.Rows.Count - 1
                    foundRow = MFFeeDT.Select("ClientID='" + TempTable.Rows(count).Item("ClientID").ToString() + "'")
                    If foundRow.Length > 0 Then
                        For count2 = 0 To foundRow.Length - 1
                            MFFeeMasterDT.ImportRow(foundRow(count2))
                        Next count2
                    End If
                Next
                MFFeeMasterDT.AcceptChanges()
                MFFeeMasterDT.Merge(TempMFFeeDT)
                MFFeeMasterDT.TableName = "Fee"
                ds.Tables.Add(MFFeeMasterDT)
            End With
            Return ds
        End Function

        Public Function GetTempMFProducInfo(Optional ByVal ClientName As String = "", Optional ByVal dateFrom As String = "", Optional ByVal dateTo As String = "") As DataSet
            '//MF Product

            Dim MFProductDT As DataTable
            Dim TempMFProductDT As DataTable
            Dim MFProductMasterDT As DataTable

            Dim MFProductApplyDT As DataTable
            Dim ClientMasterProductApplyDT As DataTable
            Dim ProductApplyMasterDT As DataTable

            Dim TempTable As DataTable
            Dim ClientIDArr(1) As String
            Dim ClientIDArr2(0) As String
            Dim ClientID As String = ""
            Dim count As Integer
            Dim count2 As Integer
            Dim ds As New DataSet
            Dim foundRow() As DataRow

            ClientIDArr(0) = "ClientID"
            ClientIDArr(1) = "ProductCode"
            ClientIDArr2(0) = "ClientID"
            '//Get ClientID 
            If ClientName <> "" Then
                ClientID = GetClientIDByName(ClientName)
            End If

            With Me.MySQLParser
                .TableName = "Temp_tblMFByProduct"
                With .Columns
                    .Clear()
                    If ClientName <> "" Then
                        If ClientID <> "" Then
                            .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        Else
                            .Add("ClientID", "-1", SqlBuilder.SQLParserDataType.spNum, True)
                        End If
                    End If
                    If dateFrom = dateTo Then
                        If dateFrom <> "" And dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:990"
                            .Add("DateModification", "convert(varchar,cast('" + dateFrom + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, ">")
                            .Add("DateModification", "convert(varchar,cast('" + dateTo + " 23:59:59:990" + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, "<")
                        End If
                    Else
                        If dateFrom <> "" Then
                            .Add("DateModification", dateFrom, SqlBuilder.SQLParserDataType.spDate, True, ">")
                        End If
                        If dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:990"
                            .Add("DateModification", dateTo + " 23:59:59:990", SqlBuilder.SQLParserDataType.spText, True, "<=")
                        End If
                    End If
                    .Add("*")
                End With
                TempMFProductDT = .ExecuteDataTable(.SQLSelect + " order by DateModification Desc")

                .TableName = "tblMFByProduct"
                With .Columns
                    .Clear()
                    If ClientName <> "" Then
                        If ClientID <> "" Then
                            .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        Else
                            .Add("ClientID", "-1", SqlBuilder.SQLParserDataType.spNum, True)
                        End If
                    End If
                    .Add("*")
                End With
                MFProductDT = .ExecuteDataTable()

                TempTable = TempMFProductDT.DefaultView.ToTable(True, ClientIDArr)
                MFProductMasterDT = TempMFProductDT.Clone()
                For count = 0 To TempTable.Rows.Count - 1
                    foundRow = MFProductDT.Select("ClientID='" + TempTable.Rows(count).Item("ClientID").ToString() + "' and ProductCode='" + TempTable.Rows(count).Item("ProductCode").ToString() + "'")
                    If foundRow.Length > 0 Then
                        For count2 = 0 To foundRow.Length - 1
                            MFProductMasterDT.ImportRow(foundRow(count2))
                        Next count2
                    End If
                Next
                MFProductMasterDT.AcceptChanges()
                MFProductMasterDT.Merge(TempMFProductDT)
                MFProductMasterDT.TableName = "Product"
                ds.Tables.Add(MFProductMasterDT)



                .TableName = "Temp_tblMFProductApplyStandard p inner join tblClientMaster cm on p.ClientID=cm.ClientID"
                With .Columns
                    .Clear()
                    If ClientName <> "" Then
                        .Add("cm.Name", ClientName, SqlBuilder.SQLParserDataType.spText, True)
                    End If
                    If dateFrom = dateTo Then
                        If dateFrom <> "" And dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:990"
                            .Add("p.DateModification", "convert(varchar,cast('" + dateFrom + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, ">")
                            .Add("p.DateModification", "convert(varchar,cast('" + dateTo + " 23:59:59:990" + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, "<")
                        End If
                    Else
                        If dateFrom <> "" Then
                            .Add("p.DateModification", dateFrom, SqlBuilder.SQLParserDataType.spDate, True, ">")
                        End If
                        If dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:990"
                            .Add("p.DateModification", dateTo + " 23:59:59:990", SqlBuilder.SQLParserDataType.spText, True, "<=")
                        End If
                    End If
                    .Add("p.*")
                End With
                MFProductApplyDT = .ExecuteDataTable(.SQLSelect + " order by DateModification Desc")

                .TableName = "tblClientMaster"
                With .Columns
                    .Clear()
                    If ClientName <> "" Then
                        .Add("Name", ClientName, SqlBuilder.SQLParserDataType.spText, True)
                    End If
                    .Add("ClientID,StandardMFProduct As ApplyStandard")
                End With
                ClientMasterProductApplyDT = .ExecuteDataTable()


                TempTable = MFProductApplyDT.DefaultView.ToTable(True, ClientIDArr2)
                ProductApplyMasterDT = MFProductApplyDT.Clone()
                For count = 0 To TempTable.Rows.Count - 1
                    foundRow = ClientMasterProductApplyDT.Select("ClientID='" + TempTable.Rows(count).Item("ClientID").ToString() + "'")
                    If foundRow.Length > 0 Then
                        For count2 = 0 To foundRow.Length - 1
                            ProductApplyMasterDT.ImportRow(foundRow(count2))
                        Next count2
                    End If
                Next
                ProductApplyMasterDT.AcceptChanges()
                ProductApplyMasterDT.Merge(MFProductApplyDT)
                ProductApplyMasterDT.TableName = "ProductApply"
                ds.Tables.Add(ProductApplyMasterDT)
            End With
            Return ds
        End Function

        Public Function GetClientIDByName(ByVal ClientName As String) As String
            Dim retVal As String
            Dim retObj As Object
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblClientMaster"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("Name", ClientName, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("ClientID")
                End With
                retObj = .ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar, CommandType.Text)
                retVal = Util.DBNullToText(retObj)
            End With
            Return retVal
        End Function

    End Class
End Namespace

@


1.1.1.1
log
@no message
@
text
@@
