head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.20;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.20;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic
Imports System.Collections.Generic

Namespace DataAccessLayer
    Public Class CompanyAccountingDAL
        Inherits BaseDA

        Public Function GetCompanyAccountingData(ByVal ClientID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .TableName = "tblClientMaster"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function UpdateCompanyAccounting(ByVal info As DataInfo.CompanyAccountingInfo) As Integer
            Dim EffectRow As Integer
            Try
                With Me.MySQLParser
                    .TableName = "tblClientMaster"
                    With .Columns
                        .Clear()
                        .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        Select Case info.PreferedAccType
                            Case DataInfo.CompanyAccountingInfo.AccountType.Business
                                .Add("PreferredAccountingNo", "B")
                            Case DataInfo.CompanyAccountingInfo.AccountType.Leisure
                                .Add("PreferredAccountingNo", "L")
                            Case DataInfo.CompanyAccountingInfo.AccountType.MICE
                                .Add("PreferredAccountingNo", "M")
                        End Select
                        .Add("ClientNumber", info.AccNoBiz)
                        .Add("LeisureClientNo", info.AccNoLeisure)
                        .Add("MICEClientNo", info.AccNoMice)
                        .Add("DivisionNo", info.DivNo)
                        .Add("AccountingField1", info.FieldName1)
                        .Add("AccountingField2", info.FieldName2)
                        .Add("AccountingField3", info.FieldName3)
                        .Add("AccountingField4", info.FieldName4)
                        .Add("AccountingField5", info.FieldName5)
                        .Add("AccountingValue1", info.FieldValue1)
                        .Add("AccountingValue2", info.FieldValue2)
                        .Add("AccountingValue3", info.FieldValue3)
                        .Add("AccountingValue4", info.FieldValue4)
                        .Add("AccountingValue5", info.FieldValue5)
                    End With
                    Me.CallProcedure(info.ClientID, "Update", "sp_ClientMaster")
                    EffectRow = .ExecuteUpdate()
                End With
            Catch ex As Exception
                EffectRow = -1
            End Try
            Return EffectRow
        End Function

        Private Sub CallProcedure(ByVal ClientID As String, ByVal Type As String, ByVal StoreProdType As String)
            With Me.MySQLParser
                .ExecuteStoreProcedure("exec " + StoreProdType + " '" + ClientID + "','" + ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName + "','" + Type + "'")
            End With
        End Sub

        Public Function GetTempCompanyAccountingData(Optional ByVal ClientName As String = "", Optional ByVal dateFrom As String = "", Optional ByVal dateTo As String = "") As DataSet
            '//Config DT 
            Dim PCCDT As DataTable
            Dim TempPCCDT As DataTable
            Dim PCCMasterDT As DataTable

            Dim TempTable As DataTable
            Dim ClientIDArr(0) As String
            Dim count As Integer
            Dim count2 As Integer
            Dim ds As New DataSet
            Dim foundRow() As DataRow

            ClientIDArr(0) = "ClientID"


            With Me.MySQLParser
                .TableName = "Temp_tblClientMaster"
                With .Columns
                    .Clear()
                    If ClientName <> "" Then
                        .Add("Name", ClientName, SqlBuilder.SQLParserDataType.spText, True)
                    End If
                    If dateFrom = dateTo Then
                        If dateFrom <> "" And dateTo <> "" Then
                            dateTo = dateTo + " 23:59:59:990"
                            .Add("DateModification", "convert(varchar,cast('" + dateFrom + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, ">")
                            .Add("DateModification", "convert(varchar,cast('" + dateTo + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, "<")
                        End If
                    Else
                        If dateFrom <> "" Then
                            .Add("DateModification", dateFrom, SqlBuilder.SQLParserDataType.spDate, True, ">")
                        End If
                        If dateTo <> "" Then
                            dateTo = dateTo + " 23:59:59:990"
                            .Add("DateModification", dateTo, SqlBuilder.SQLParserDataType.spText, True, "<=")
                        End If
                    End If
                    .Add("ClientID,Name,ClientNumber,LeisureClientNo,MICEClientNo,DivisionNo,AccountingField1,AccountingField2,AccountingField3,AccountingField4,AccountingField5,AccountingValue1,AccountingValue2,AccountingValue3,AccountingValue4,AccountingValue5,DateModification,UserName,ValueTypeChanged")

                End With
                TempPCCDT = .ExecuteDataTable(.SQLSelect + " order by DateModification Desc")

                .TableName = "tblClientMaster"
                With .Columns
                    .Clear()
                    If ClientName <> "" Then
                        .Add("Name", ClientName, SqlBuilder.SQLParserDataType.spText, True)
                    End If
                    .Add("ClientID,Name,ClientNumber,LeisureClientNo,MICEClientNo,DivisionNo,AccountingField1,AccountingField2,AccountingField3,AccountingField4,AccountingField5,AccountingValue1,AccountingValue2,AccountingValue3,AccountingValue4,AccountingValue5")
                End With
                PCCDT = .ExecuteDataTable()

                Dim count3 As Integer
                Dim TempACCMasterDT As DataTable
                Dim TempMasterPCCDT As DataTable
                TempACCMasterDT = TempPCCDT.Clone()
                TempMasterPCCDT = TempPCCDT.Clone()
                TempTable = TempPCCDT.DefaultView.ToTable(True, ClientIDArr)
                PCCMasterDT = TempPCCDT.Clone()
                For count = 0 To TempTable.Rows.Count - 1
                    foundRow = PCCDT.Select("ClientID='" + TempTable.Rows(count).Item("ClientID").ToString() + "'")
                    If foundRow.Length > 0 Then
                        For count2 = 0 To foundRow.Length - 1
                            PCCMasterDT.ImportRow(foundRow(count2))

                            For count3 = 0 To TempPCCDT.Rows.Count - 1
                                If TempPCCDT.Rows(count3).Item("ClientID").ToString() = foundRow(count2).Item("ClientID").ToString() Then
                                    If TempPCCDT.Rows(count3).Item("ValueTypeChanged").ToString() <> "Insert" Then
                                        If TempPCCDT.Rows(count3).Item("LeisureClientNo").ToString() <> foundRow(count2).Item("LeisureClientNo").ToString() Or TempPCCDT.Rows(count3).Item("MICEClientNo").ToString() <> foundRow(count2).Item("MICEClientNo").ToString() Or TempPCCDT.Rows(count3).Item("DivisionNo").ToString() <> foundRow(count2).Item("DivisionNo").ToString() Or TempPCCDT.Rows(count3).Item("AccountingField1").ToString() <> foundRow(count2).Item("AccountingField1").ToString() Or TempPCCDT.Rows(count3).Item("AccountingField2").ToString() <> foundRow(count2).Item("AccountingField2").ToString() Or TempPCCDT.Rows(count3).Item("AccountingField3").ToString() <> foundRow(count2).Item("AccountingField3").ToString() Or TempPCCDT.Rows(count3).Item("AccountingField4").ToString() <> foundRow(count2).Item("AccountingField4").ToString() Or TempPCCDT.Rows(count3).Item("AccountingField5").ToString() <> foundRow(count2).Item("AccountingField5").ToString() Or TempPCCDT.Rows(count3).Item("AccountingValue1").ToString() <> foundRow(count2).Item("AccountingValue1").ToString() Or TempPCCDT.Rows(count3).Item("AccountingValue2").ToString() <> foundRow(count2).Item("AccountingValue2").ToString() Or TempPCCDT.Rows(count3).Item("AccountingValue3").ToString() <> foundRow(count2).Item("AccountingValue3").ToString() Or TempPCCDT.Rows(count3).Item("AccountingValue4").ToString() <> foundRow(count2).Item("AccountingValue4").ToString() Or TempPCCDT.Rows(count3).Item("AccountingValue5").ToString() <> foundRow(count2).Item("AccountingValue5").ToString() Then
                                            If CheckMasterMatch(TempACCMasterDT, TempPCCDT.Rows(count3)) = False Then
                                                TempACCMasterDT.ImportRow(TempPCCDT.Rows(count3))
                                            End If
                                        End If
                                    Else
                                        TempACCMasterDT.ImportRow(TempPCCDT.Rows(count3))
                                    End If
                                End If
                            Next count3

                        Next count2
                    End If
                Next

                Dim drs() As DataRow = TempACCMasterDT.Select("UserName<>''", "DateModification desc")
                For Each dr As DataRow In drs
                    TempMasterPCCDT.ImportRow(dr)
                Next

                PCCMasterDT.AcceptChanges()
                PCCMasterDT.Merge(TempMasterPCCDT)
                PCCMasterDT.TableName = "AccountingData"
                ds.Tables.Add(PCCMasterDT)
            End With
            Return ds
        End Function

        Public Function CheckMasterMatch(ByVal ACCDT As DataTable, ByVal Row As DataRow)
            Dim countDT As Integer
            Dim check As Boolean
            For countDT = 0 To ACCDT.Rows.Count - 1
                If ACCDT.Rows(countDT).Item("LeisureClientNo").ToString() = Row.Item("LeisureClientNo").ToString() And ACCDT.Rows(countDT).Item("MICEClientNo").ToString() = Row.Item("MICEClientNo").ToString() And ACCDT.Rows(countDT).Item("DivisionNo").ToString() = Row.Item("DivisionNo").ToString() And ACCDT.Rows(countDT).Item("AccountingField1").ToString() = Row.Item("AccountingField1").ToString() And ACCDT.Rows(countDT).Item("AccountingField2").ToString() = Row.Item("AccountingField2").ToString() And ACCDT.Rows(countDT).Item("AccountingField3").ToString() = Row.Item("AccountingField3").ToString() And ACCDT.Rows(countDT).Item("AccountingField4").ToString() = Row.Item("AccountingField4").ToString() And ACCDT.Rows(countDT).Item("AccountingField5").ToString() = Row.Item("AccountingField5").ToString() And ACCDT.Rows(countDT).Item("AccountingValue1").ToString() = Row.Item("AccountingValue1").ToString() And ACCDT.Rows(countDT).Item("AccountingValue2").ToString() = Row.Item("AccountingValue2").ToString() And ACCDT.Rows(countDT).Item("AccountingValue3").ToString() = Row.Item("AccountingValue3").ToString() And ACCDT.Rows(countDT).Item("AccountingValue4").ToString() = Row.Item("AccountingValue4").ToString() And ACCDT.Rows(countDT).Item("AccountingValue5").ToString() = Row.Item("AccountingValue5").ToString() Then
                    check = True
                    Exit For
                End If
            Next
            Return check
        End Function

    End Class
End Namespace


@


1.1.1.1
log
@no message
@
text
@@
