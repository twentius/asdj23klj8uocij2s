head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.20;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.20;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic
Imports System.Collections.Generic

Namespace DataAccessLayer
    Public Class CompanyIncidentDAL
        Inherits BaseDA

        Public Function GetIncidentProgramList() As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .TableName = CWTMasterDB.Util.StandardDB("tblIncident")
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("*")
                End With
                dt = .ExecuteDataTable(.SQLSelect() + " order by IncidentProgram")
            End With
            Return dt
        End Function

        Public Function GetIncidentData(ByVal ClientID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .TableName = "tblIncidentManagement"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("*")
                End With
                dt = .ExecuteDataTable(.SQLSelect() + " order by IncidentMgmtID")
            End With
            Return dt
        End Function

        Public Function UpdateIncident(ByVal info As DataInfo.CompanyIncidentInfo) As Integer
            Dim EffectRow As Integer = 1
            Dim IncidentDT = GetIncidentData(info.ClientID)
            Try
                With Me.MySQLParser
                    .OpenConnection()
                    .BeginTran()
                    .TableName = "tblIncidentManagement"
                    With .Columns
                        .Clear()
                        .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    End With
                    .ExecuteDelete()
                    '//
                    If EffectRow > 0 Then
                        '// 
                        .TableName = "tblIncidentManagement"
                        For i As Integer = 0 To info.ProgramList.Count - 1
                            With .Columns
                                .Clear()
                                .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum)
                                .Add("IncidentMgmtID", i + 1, SqlBuilder.SQLParserDataType.spNum)
                                .Add("PCC", info.ProgramList(i).PCC)
                                .Add("Queue", info.ProgramList(i).Queue)
                                .Add("IncidentID", info.ProgramList(i).IncidentID)
                                .Add("Remarks", info.ProgramList(i).Remark)
                            End With
                            EffectRow = .ExecuteInsert()
                            If EffectRow <= 0 Then
                                Exit For
                            End If
                        Next
                    End If
                End With
                MatchIncidentRecord(IncidentDT,info)
                If EffectRow > 0 Then
                    Me.MySQLParser.CommitTran()
                Else
                    Me.MySQLParser.RollbackTran()
                End If
            Catch ex As Exception
                EffectRow = -1
                Me.MySQLParser.RollbackTran()
            Finally
                Me.MySQLParser.CloseConnection()
            End Try
            Return EffectRow
        End Function

        Private Sub MatchIncidentRecord(ByVal IncidentDT As DataTable, ByVal info As DataInfo.CompanyIncidentInfo)
            Dim countDT As Integer
            Dim countInfo As Integer
            Dim effectRow As Integer
            Dim checkMatch As Boolean

            If IncidentDT.Rows.Count > 0 Then
                For countDT = 0 To IncidentDT.Rows.Count - 1
                    checkMatch = CheckIncidentExists(IncidentDT.Rows(countDT), info)
                    If checkMatch = False Then
                        For countInfo = 0 To info.ProgramList.Count - 1
                            If IncidentDT.Rows(countDT).Item("IncidentMgmtID").ToString() = countInfo + 1 And IncidentDT.Rows(countDT).Item("ClientID").ToString() = info.ClientID And IncidentDT.Rows.Count = info.ProgramList.Count Then
                                With Me.MySQLParser
                                    .TableName = "Temp_tblIncidentManagement"
                                    With .Columns
                                        .Clear()
                                        .Add("IncidentMgmtID", IncidentDT.Rows(countDT).Item("IncidentMgmtID").ToString(), SqlBuilder.SQLParserDataType.spNum)
                                        .Add("ClientID", IncidentDT.Rows(countDT).Item("ClientID").ToString(), SqlBuilder.SQLParserDataType.spNum)
                                        .Add("IncidentID", IncidentDT.Rows(countDT).Item("IncidentID").ToString())
                                        .Add("PCC", IncidentDT.Rows(countDT).Item("PCC").ToString())
                                        .Add("Queue", IncidentDT.Rows(countDT).Item("Queue").ToString())
                                        .Add("Remarks", IncidentDT.Rows(countDT).Item("Remarks").ToString())
                                        .Add("DateModification", DateTime.Now)
                                        .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                        .Add("ValueTypeChanged", "Update")
                                    End With
                                    effectRow = .ExecuteInsert()
                                    Exit For
                                    checkMatch = True
                                End With
                            End If
                        Next countInfo

                        If checkMatch = False And IncidentDT.Rows.Count > info.ProgramList.Count Then
                            With Me.MySQLParser
                                .TableName = "Temp_tblIncidentManagement"
                                With .Columns
                                    .Clear()
                                    .Add("IncidentMgmtID", IncidentDT.Rows(countDT).Item("IncidentMgmtID").ToString(), SqlBuilder.SQLParserDataType.spNum)
                                    .Add("ClientID", IncidentDT.Rows(countDT).Item("ClientID").ToString(), SqlBuilder.SQLParserDataType.spNum)
                                    .Add("IncidentID", IncidentDT.Rows(countDT).Item("IncidentID").ToString())
                                    .Add("PCC", IncidentDT.Rows(countDT).Item("PCC").ToString())
                                    .Add("Queue", IncidentDT.Rows(countDT).Item("Queue").ToString())
                                    .Add("Remarks", IncidentDT.Rows(countDT).Item("Remarks").ToString())
                                    .Add("DateModification", DateTime.Now)
                                    .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                    .Add("ValueTypeChanged", "Delete")
                                End With
                                effectRow = .ExecuteInsert()
                                Exit For
                            End With
                        End If
                    End If
                Next countDT
            End If

            If info.ProgramList.Count > countDT Then
                For countInfo = countDT To info.ProgramList.Count - 1
                    With Me.MySQLParser
                        .TableName = "Temp_tblIncidentManagement"
                        With .Columns
                            .Clear()
                            .Add("IncidentMgmtID", countInfo + 1, SqlBuilder.SQLParserDataType.spNum)
                            .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum)
                            .Add("IncidentID", info.ProgramList(countInfo).IncidentID)
                            .Add("PCC", info.ProgramList(countInfo).PCC)
                            .Add("Queue", info.ProgramList(countInfo).Queue)
                            .Add("Remarks", info.ProgramList(countInfo).Remark)
                            .Add("DateModification", DateTime.Now)
                            .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                            .Add("ValueTypeChanged", "Insert")
                        End With
                        effectRow = .ExecuteInsert()
                    End With
                Next countInfo
            End If


        End Sub

        Private Function CheckIncidentExists(ByVal row As DataRow, ByVal info As DataInfo.CompanyIncidentInfo) As Boolean
            Dim countInfo As Integer
            Dim check As Boolean

            For countInfo = 0 To info.ProgramList.Count - 1
                If row.Item("ClientID").ToString() = info.ClientID AndAlso row.Item("IncidentID").ToString() = info.ProgramList(countInfo).IncidentID AndAlso row.Item("PCC").ToString() = info.ProgramList(countInfo).PCC AndAlso row.Item("Queue").ToString() = info.ProgramList(countInfo).Queue AndAlso row.Item("Remarks").ToString() = info.ProgramList(countInfo).Remark Then
                    check = True
                    Exit For
                End If
            Next
            Return check
        End Function

        Public Function GetClientIDByName(ByVal ClientName As String) As String
            Dim retVal As String
            Dim retObj As Object
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblClientMaster"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("Name", ClientName, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("ClientID")
                End With
                retObj = .ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar, CommandType.Text)
                retVal = Util.DBNullToText(retObj)
            End With
            Return retVal
        End Function

        Public Function GetTempIncidentInfo(Optional ByVal ClientName As String = "", Optional ByVal dateFrom As String = "", Optional ByVal dateTo As String = "") As DataSet
            '//Incident Management DT
            Dim IncidentDT As DataTable
            Dim TempIncidentDT As DataTable
            Dim IncidentMasterDT As DataTable

            Dim ClientID As String = ""
            Dim TempTable As DataTable
            Dim ClientIDArr(1) As String
            Dim count As Integer
            Dim count2 As Integer
            Dim ds As New DataSet
            Dim foundRow() As DataRow

            ClientIDArr(0) = "ClientID"
            ClientIDArr(1) = "IncidentMgmtID"
            '//Get ClientID 
            If ClientName <> "" Then
                ClientID = GetClientIDByName(ClientName)
            End If

            With Me.MySQLParser
                .TableName = "Temp_tblIncidentManagement m inner join " + CWTMasterDB.Util.StandardDB("tblIncident") + " i on m.IncidentID=i.IncidentID"
                With .Columns
                    .Clear()
                    If ClientName <> "" Then
                        If ClientID <> "" Then
                            .Add("m.ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        Else
                            .Add("m.ClientID", "-1", SqlBuilder.SQLParserDataType.spNum, True)
                        End If
                    End If
                    If dateFrom = dateTo Then
                        If dateFrom <> "" And dateTo <> "" Then
                            dateTo = dateTo + " 23:59:59:990"
                            .Add("m.DateModification", "convert(varchar,cast('" + dateFrom + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, ">")
                            .Add("m.DateModification", "convert(varchar,cast('" + dateTo + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, "<")
                        End If
                    Else
                        If dateFrom <> "" Then
                            .Add("m.DateModification", dateFrom, SqlBuilder.SQLParserDataType.spDate, True, ">")
                        End If
                        If dateTo <> "" Then
                            dateTo = dateTo + " 23:59:59:990"
                            .Add("m.DateModification", dateTo, SqlBuilder.SQLParserDataType.spText, True, "<=")
                        End If
                    End If
                    .Add("m.IncidentMgmtID,m.ClientID,i.IncidentProgram As IncidentName,m.PCC,m.Queue,m.Remarks,m.DateModification,m.UserName,m.ValueTypeChanged")
                End With
                TempIncidentDT = .ExecuteDataTable(.SQLSelect + " order by DateModification Desc")

                .TableName = "tblIncidentManagement m inner join " + CWTMasterDB.Util.StandardDB("tblIncident") + " i on m.IncidentID=i.IncidentID"
                With .Columns
                    .Clear()
                    If ClientName <> "" Then
                        If ClientID <> "" Then
                            .Add("m.ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        Else
                            .Add("m.ClientID", "-1", SqlBuilder.SQLParserDataType.spNum, True)
                        End If
                    End If
                    .Add("m.IncidentMgmtID,m.ClientID,i.IncidentProgram As IncidentName,m.PCC,m.Queue,m.Remarks")
                End With
                IncidentDT = .ExecuteDataTable()

                TempTable = TempIncidentDT.DefaultView.ToTable(True, ClientIDArr)
                IncidentMasterDT = TempIncidentDT.Clone()
                For count = 0 To TempTable.Rows.Count - 1
                    foundRow = IncidentDT.Select("ClientID='" + TempTable.Rows(count).Item("ClientID").ToString() + "' and IncidentMgmtID='" + TempTable.Rows(count).Item("IncidentMgmtID").ToString() + "'")
                    If foundRow.Length > 0 Then
                        For count2 = 0 To foundRow.Length - 1
                            IncidentMasterDT.ImportRow(foundRow(count2))
                        Next count2
                    End If
                Next
                IncidentMasterDT.AcceptChanges()
                IncidentMasterDT.Merge(TempIncidentDT)
                IncidentMasterDT.TableName = "Incident"
                ds.Tables.Add(IncidentMasterDT)
            End With
            Return ds
        End Function
    End Class

End Namespace
@


1.1.1.1
log
@no message
@
text
@@
