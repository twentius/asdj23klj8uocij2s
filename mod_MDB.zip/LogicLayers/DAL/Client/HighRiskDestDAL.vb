head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.22;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.22;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic
Imports System.Collections.Generic

Namespace DataAccessLayer
    Public Class HighRiskDestDAL
        Inherits BaseDA

        Public Function GetCityList() As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .TableName = CWTMasterDB.Util.StandardDB("tblCity")
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("*")
                    .Add("CountryCode+' > '+City as CityCaption")
                    .Add("0 as IsRisk")
                End With
                dt = .ExecuteDataTable(.SQLSelect() + " order by City")
            End With
            Return dt
        End Function

        Public Function GetAirlineList() As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .TableName = CWTMasterDB.Util.StandardDB("tblAirlines")
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("*")
                    .Add("0 as IsRisk")
                End With
                dt = .ExecuteDataTable(.SQLSelect() + " order by AirlineDescription")
            End With
            Return dt
        End Function

        Public Function GetHighRiskDestination(ByVal ClientID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .TableName = "tblHighRisk h"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("h.ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("h.CountryCode")
                    .Add("h.CityCode")
                    .Add("(select Top 1 City from " + CWTMasterDB.Util.StandardDB("tblCity") + " where CityCode=h.CityCode) as City")
                    .Add("(select Top 1 CountryName from " + CWTMasterDB.Util.StandardDB("tblCountry") + " where CountryCode=h.CountryCode) as CountryName")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetHighRiskAirline(ByVal ClientID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .TableName = "tblHighRiskAirline"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("AirlineCode")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function UpdateHighRiskDest(ByVal info As DataInfo.HighRiskInfo) As Integer
            Dim EffectRow As Integer = 1
            Dim RiskDT As DataTable
            Try
                RiskDT = GetHighRiskDestDT(info.ClientID)
                With Me.MySQLParser
                    .TableName = "tblHighRisk"
                    With .Columns
                        .Clear()
                        .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    End With
                    .ExecuteDelete()
                    For i As Integer = 0 To info.HighRiskDest.Count - 1
                        With .Columns
                            .Clear()
                            .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum)
                            .Add("CityCode", info.HighRiskDest(i).CityCode)
                            .Add("CountryCode", info.HighRiskDest(i).CountryCode)
                        End With
                        EffectRow = .ExecuteInsert()
                        If EffectRow <= 0 Then
                            Exit For
                        End If
                    Next
                    MatchRecord(RiskDT, info, "RiskDest")
                End With
            Catch ex As Exception
                EffectRow = -1
            End Try
            Return EffectRow
        End Function

        Public Function UpdateHighRiskAir(ByVal info As DataInfo.HighRiskInfo) As Integer
            Dim EffectRow As Integer = 1
            Dim HighRiskDT As DataTable

            Try
                HighRiskDT = GetHighRiskDT(info.ClientID)
                With Me.MySQLParser
                    .TableName = "tblHighRiskAirline"
                    With .Columns
                        .Clear()
                        .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    End With
                    .ExecuteDelete()
                    For i As Integer = 0 To info.HighRiskAirList.Count - 1
                        With .Columns
                            .Clear()
                            .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum)
                            .Add("AirlineCode", info.HighRiskAirList(i).ToString)
                        End With
                        EffectRow = .ExecuteInsert()
                        If EffectRow <= 0 Then
                            Exit For
                        End If
                    Next
                    MatchRecord(HighRiskDT, info, "Airline")
                End With
            Catch ex As Exception
                EffectRow = -1
            End Try
            Return EffectRow
        End Function

        Private Function GetHighRiskDT(ByVal ClientID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .TableName = "tblHighRiskAirline"
                With .Columns
                    .Clear()
                    .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Private Function GetHighRiskDestDT(ByVal ClientID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .TableName = "tblHighRisk"
                With .Columns
                    .Clear()
                    .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Private Sub MatchRecord(ByRef RiskDT As DataTable, ByRef info As DataInfo.HighRiskInfo, ByVal Type As String)
            Dim effectRow As Integer
            Dim countInfo As Integer
            Dim countDT As Integer
            Dim checkMatch As Boolean
            Dim checkInfoMatch As Boolean

            If RiskDT.Rows.Count > 0 Then
                For countDT = 0 To RiskDT.Rows.Count - 1
                    If Type = "Airline" Then
                        checkMatch = CheckExists(RiskDT.Rows(countDT), info, "Airline")
                        If checkMatch = False Then
                            With Me.MySQLParser
                                .TableName = "Temp_tblHighRiskAirline"
                                With .Columns
                                    .Clear()
                                    .Add("ClientID", RiskDT.Rows(countDT).Item("ClientID"), SqlBuilder.SQLParserDataType.spNum)
                                    .Add("AirlineCode", RiskDT.Rows(countDT).Item("AirlineCode"))
                                    .Add("DateModification", DateTime.Now)
                                    .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                    .Add("ValueTypeChanged", "Delete")
                                End With
                                effectRow = .ExecuteInsert()
                                Exit For
                            End With
                        End If
                    ElseIf Type = "RiskDest" Then

                        checkMatch = CheckExists(RiskDT.Rows(countDT), info, "RiskDest")
                        If checkMatch = False Then
                            With Me.MySQLParser
                                .TableName = "Temp_tblHighRisk"
                                With .Columns
                                    .Clear()
                                    .Add("ClientID", RiskDT.Rows(countDT).Item("ClientID").ToString(), SqlBuilder.SQLParserDataType.spNum)
                                    .Add("CountryCode", RiskDT.Rows(countDT).Item("CountryCode").ToString())
                                    .Add("CityCode", RiskDT.Rows(countDT).Item("CityCode").ToString())
                                    .Add("DateModification", DateTime.Now)
                                    .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                    .Add("ValueTypeChanged", "Delete")
                                End With
                                effectRow = .ExecuteInsert()
                                Exit For
                            End With
                        End If
                    End If
                Next
            End If

            If Type = "Airline" Then
                For countInfo = 0 To info.HighRiskAirList.Count - 1
                    If RiskDT.Rows.Count > 0 Then
                        checkInfoMatch = CheckDTExistsByInfo(RiskDT, info.ClientID, info.HighRiskAirList(countInfo), "", "Airline")
                        If checkInfoMatch = False Then
                            With Me.MySQLParser
                                .TableName = "Temp_tblHighRiskAirline"
                                With .Columns
                                    .Clear()
                                    .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum)
                                    .Add("AirlineCode", info.HighRiskAirList(countInfo))
                                    .Add("DateModification", DateTime.Now)
                                    .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                    .Add("ValueTypeChanged", "Insert")
                                End With
                                effectRow = .ExecuteInsert()
                                Exit For
                            End With
                        End If
                    Else
                        With Me.MySQLParser
                            .TableName = "Temp_tblHighRiskAirline"
                            With .Columns
                                .Clear()
                                .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum)
                                .Add("AirlineCode", info.HighRiskAirList(countInfo))
                                .Add("DateModification", DateTime.Now)
                                .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                .Add("ValueTypeChanged", "Insert")
                            End With
                            effectRow = .ExecuteInsert()
                            Exit For
                        End With
                    End If
                Next countInfo

            ElseIf Type = "RiskDest" Then
                For countInfo = 0 To info.HighRiskDest.Count - 1
                    If RiskDT.Rows.Count > 0 Then
                        checkInfoMatch = CheckDTExistsByInfo(RiskDT, info.ClientID, info.HighRiskDest(countInfo).CountryCode, info.HighRiskDest(countInfo).CityCode, "RiskDest")
                        If checkInfoMatch = False Then
                            With Me.MySQLParser
                                .TableName = "Temp_tblHighRisk"
                                With .Columns
                                    .Clear()
                                    .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum)
                                    .Add("CountryCode", info.HighRiskDest(countInfo).CountryCode)
                                    .Add("CityCode", info.HighRiskDest(countInfo).CityCode)
                                    .Add("DateModification", DateTime.Now)
                                    .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                    .Add("ValueTypeChanged", "Insert")
                                End With
                                effectRow = .ExecuteInsert()
                                Exit For
                            End With
                        End If
                    Else
                        With Me.MySQLParser
                            .TableName = "Temp_tblHighRisk"
                            With .Columns
                                .Clear()
                                .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum)
                                .Add("CountryCode", info.HighRiskDest(countInfo).CountryCode)
                                .Add("CityCode", info.HighRiskDest(countInfo).CityCode)
                                .Add("DateModification", DateTime.Now)
                                .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                .Add("ValueTypeChanged", "Insert")
                            End With
                            effectRow = .ExecuteInsert()
                            Exit For
                        End With
                    End If
                Next countInfo
            End If
        End Sub

        Private Function CheckExists(ByVal row As DataRow, ByVal info As DataInfo.HighRiskInfo, ByVal Type As String) As Boolean
            Dim check As Boolean
            Dim countInfo As Integer

            If Type = "Airline" Then
                For countInfo = 0 To info.HighRiskAirList.Count - 1
                    If row.Item("AirlineCode").ToString() = info.HighRiskAirList(countInfo) And row.Item("ClientID").ToString() = info.ClientID Then
                        check = True
                        Exit For
                    End If
                Next countInfo
            ElseIf Type = "RiskDest" Then
                For countInfo = 0 To info.HighRiskDest.Count - 1
                    If row.Item("CountryCode").ToString() = info.HighRiskDest(countInfo).CountryCode And row.Item("CityCode").ToString() = info.HighRiskDest(countInfo).CityCode And row.Item("ClientID").ToString() = info.ClientID Then
                        check = True
                        Exit For
                    End If
                Next countInfo
            End If

            Return check
        End Function

        Private Function CheckDTExistsByInfo(ByVal RiskDT As DataTable, ByVal ClientID As String, ByVal Parameter1 As String, ByVal Parameter2 As String, ByVal Type As String) As Boolean
            Dim check As Boolean
            Dim countDT As Integer

            If Type = "Airline" Then
                For countDT = 0 To RiskDT.Rows.Count - 1
                    If RiskDT.Rows(countDT).Item("ClientID").ToString() = ClientID And RiskDT.Rows(countDT).Item("AirlineCode").ToString() = Parameter1 Then
                        check = True
                        Exit For
                    End If
                Next countDT
            ElseIf Type = "RiskDest" Then
                For countDT = 0 To RiskDT.Rows.Count - 1
                    If RiskDT.Rows(countDT).Item("ClientID").ToString() = ClientID And RiskDT.Rows(countDT).Item("CountryCode").ToString() = Parameter1 And RiskDT.Rows(countDT).Item("CityCode").ToString() = Parameter2 Then
                        check = True
                        Exit For
                    End If
                Next countDT
            End If

            Return check
        End Function

        Public Function GetClientIDByName(ByVal ClientName As String) As String
            Dim retVal As String
            Dim retObj As Object
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblClientMaster"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("Name", ClientName, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("ClientID")
                End With
                retObj = .ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar, CommandType.Text)
                retVal = Util.DBNullToText(retObj)
            End With
            Return retVal
        End Function

        Public Function GetTempHighRisk(Optional ByVal ClientName As String = "", Optional ByVal dateFrom As String = "", Optional ByVal dateTo As String = "") As DataSet
            '//High Risk Airline
            Dim RiskAirlineDT As DataTable
            Dim TempRiskAirlineDT As DataTable
            Dim RiskAirlineMasterDT As DataTable

            '//High Risk Cities
            Dim RiskDesDT As DataTable
            Dim TempRiskDesDT As DataTable
            Dim RiskDesMasterDT As DataTable

            Dim ClientID As String = ""
            Dim TempTable As DataTable
            Dim count As Integer
            Dim count2 As Integer
            Dim ds As New DataSet
            Dim foundRow() As DataRow
            Dim RiskAirline(1) As String
            Dim RiskDest(2) As String

            RiskAirline(0) = "ClientID"
            RiskAirline(1) = "AirlineDescription"
            RiskDest(0) = "ClientID"
            RiskDest(1) = "CountryName"
            RiskDest(2) = "City"

            '//Get ClientID 
            If ClientName <> "" Then
                ClientID = GetClientIDByName(ClientName)
            End If
            With Me.MySQLParser
                .TableName = "Temp_tblHighRiskAirline a inner join " + Util.StandardDB("tblAirlines") + " c on a.AirlineCode = c.AirlineCode "
                With .Columns
                    .Clear()
                    If ClientName <> "" Then
                        If ClientID <> "" Then
                            .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        Else
                            .Add("ClientID", "-1", SqlBuilder.SQLParserDataType.spNum, True)
                        End If
                    End If
                    If dateFrom = dateTo Then
                        If dateFrom <> "" And dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:990"
                            .Add("DateModification", "convert(varchar,cast('" + dateFrom + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, ">")
                            .Add("DateModification", "convert(varchar,cast('" + dateTo + " 23:59:59:990" + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, "<")
                        End If
                    Else
                        If dateFrom <> "" Then
                            .Add("DateModification", dateFrom, SqlBuilder.SQLParserDataType.spDate, True, ">")
                        End If
                        If dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:990"
                            .Add("DateModification", dateTo + " 23:59:59:990", SqlBuilder.SQLParserDataType.spText, True, "<=")
                        End If
                    End If
                    .Add("a.ClientID,c.AirlineDescription,a.DateModification,a.UserName,a.ValueTypeChanged")
                End With
                TempRiskAirlineDT = .ExecuteDataTable(.SQLSelect + " order by DateModification Desc")

                .TableName = "tblHighRiskAirline a inner join " + Util.StandardDB("tblAirlines") + " c on a.AirlineCode COLLATE Latin1_General_CI_AS= c.AirlineCode "
                With .Columns
                    .Clear()
                    If ClientName <> "" Then
                        If ClientID <> "" Then
                            .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        Else
                            .Add("ClientID", "-1", SqlBuilder.SQLParserDataType.spNum, True)
                        End If
                    End If
                    .Add("a.ClientID,c.AirlineDescription")
                End With
                RiskAirlineDT = .ExecuteDataTable()

                TempTable = TempRiskAirlineDT.DefaultView.ToTable(True, RiskAirline)
                RiskAirlineMasterDT = TempRiskAirlineDT.Clone()
                For count = 0 To TempTable.Rows.Count - 1
                    foundRow = RiskAirlineDT.Select("ClientID='" + TempTable.Rows(count).Item("ClientID").ToString() + "' and AirlineDescription = '" + TempTable.Rows(count).Item("AirlineDescription").ToString() + "'")
                    If foundRow.Length > 0 Then
                        For count2 = 0 To foundRow.Length - 1
                            RiskAirlineMasterDT.ImportRow(foundRow(count2))
                        Next count2
                    End If
                Next
                RiskAirlineMasterDT.AcceptChanges()
                RiskAirlineMasterDT.Merge(TempRiskAirlineDT)
                RiskAirlineMasterDT.TableName = "RiskAirline"
                ds.Tables.Add(RiskAirlineMasterDT)



                .TableName = "Temp_tblHighRisk r left join " + Util.StandardDB("tblCountry") + " co on r.CountryCode = co.CountryCode inner join " + Util.StandardDB("tblCity") + " ci on r.CityCode = ci.CityCode and co.CountryCode=ci.CountryCode"
                With .Columns
                    .Clear()
                    If ClientName <> "" Then
                        If ClientID <> "" Then
                            .Add("r.ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        Else
                            .Add("r.ClientID", "-1", SqlBuilder.SQLParserDataType.spNum, True)
                        End If
                    End If
                    If dateFrom = dateTo Then
                        If dateFrom <> "" And dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:990"
                            .Add("r.DateModification", "convert(varchar,cast('" + dateFrom + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, ">")
                            .Add("r.DateModification", "convert(varchar,cast('" + dateTo + " 23:59:59:990" + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, "<")
                        End If
                    Else
                        If dateFrom <> "" Then
                            .Add("r.DateModification", dateFrom, SqlBuilder.SQLParserDataType.spDate, True, ">")
                        End If
                        If dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:990"
                            .Add("r.DateModification", dateTo + " 23:59:59:990", SqlBuilder.SQLParserDataType.spText, True, "<=")
                        End If
                    End If
                    .Add("distinct r.ClientID,co.CountryName,ci.City,r.DateModification,r.UserName,r.ValueTypeChanged")
                End With
                TempRiskDesDT = .ExecuteDataTable(.SQLSelect + " order by DateModification Desc")

                .TableName = "tblHighRisk r left join " + Util.StandardDB("tblCountry") + " co on r.CountryCode = co.CountryCode inner join " + Util.StandardDB("tblCity") + " ci on r.CityCode = ci.CityCode and co.CountryCode=ci.CountryCode"
                With .Columns
                    .Clear()
                    If ClientName <> "" Then
                        If ClientID <> "" Then
                            .Add("r.ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        Else
                            .Add("r.ClientID", "-1", SqlBuilder.SQLParserDataType.spNum, True)
                        End If
                    End If
                    .Add("distinct r.ClientID,co.CountryName,ci.City")
                End With
                RiskDesDT = .ExecuteDataTable()

                TempTable = TempRiskDesDT.DefaultView.ToTable(True, RiskDest)
                RiskDesMasterDT = TempRiskDesDT.Clone()
                For count = 0 To TempTable.Rows.Count - 1
                    foundRow = RiskDesDT.Select("ClientID='" + TempTable.Rows(count).Item("ClientID").ToString() + "' and CountryName='" + TempTable.Rows(count).Item("CountryName").ToString() + "' and City='" + TempTable.Rows(count).Item("City").ToString() + "'")
                    If foundRow.Length > 0 Then
                        For count2 = 0 To foundRow.Length - 1
                            RiskDesMasterDT.ImportRow(foundRow(count2))
                        Next count2
                    End If
                Next
                RiskDesMasterDT.AcceptChanges()
                RiskDesMasterDT.Merge(TempRiskDesDT)
                RiskDesMasterDT.TableName = "RiskDes"
                ds.Tables.Add(RiskDesMasterDT)
            End With
            Return ds
        End Function
    End Class
End Namespace








@


1.1.1.1
log
@no message
@
text
@@
