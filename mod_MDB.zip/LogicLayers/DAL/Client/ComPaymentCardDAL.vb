head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.22;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.22;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic
Imports System.Collections.Generic

Namespace DataAccessLayer
    Public Class ComPaymentCardDAL
        Inherits BaseDA

        Public Function GetCardList() As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = CWTMasterDB.Util.StandardDB("tblPaymentType")
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("CCCode", "IN", SqlBuilder.SQLParserDataType.spText, True, "<>")
                    .Add("*")
                End With
                dt = .ExecuteDataTable(.SQLSelect + " order by CCDescription")
            End With
            Return dt
        End Function

        Public Function GetCardValidateFormat(ByVal CCCode As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = CWTMasterDB.Util.StandardDB("tblCardValidFormat")
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("CCCode", CCCode, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetPaymentMode(ByVal ClientID As String, ByVal type As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .TableName = "tblPaymentCard"
                With .Columns
                    .Clear()
                    .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("Type", type, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("PayMode")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetReferToProfile(ByVal ClientID As String) As Boolean
            Dim retVal As Boolean = False
            With Me.MySQLParser
                .TableName = "tblClientMaster"
                With .Columns
                    .Clear()
                    .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("ReferToPax")
                End With
                retVal = CWTMasterDB.Util.DBNullToFalse(.ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar))
            End With
            Return retVal
        End Function

        Public Function GetClientCard(ByVal ClientID As String, ByVal type As String, ByVal payMode As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblPaymentCard"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("Type", type, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("PayMode", payMode, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function UpdatePaymentCard(ByVal info As DataInfo.CompanyPayCardInfo) As Integer
            Dim EffectRow As Integer
            Dim PaymentDT As DataTable = New DataTable()
            'Dim checkInsert As Boolean
            Try
                PaymentDT = GetPaymentRecord(info.ClientID)
                With Me.MySQLParser
                    .TableName = "tblClientMaster"
                    With .Columns
                        .Clear()
                        .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        .Add("PaymentMode", info.PayMode)
                        .Add("ReferToPax", info.ReferToProfile, SqlBuilder.SQLParserDataType.spBoolean)
                    End With
                    CallProcedureClientMaster(info.ClientID, "Update")
                    EffectRow = .ExecuteUpdate()
                    '//
                    .TableName = "tblPaymentCard"
                    With .Columns
                        .Clear()
                        .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        .Add("ClientID", "NULL", SqlBuilder.SQLParserDataType.spFunction, True, "is not")
                    End With
                    .ExecuteDelete()
                    'Dim x As Integer = 0
                    If info.AirIntPayMode.Equals("CORPCC") Then
                        '.TableName = "tblPaymentCard"
                        For i As Integer = 0 To info.AirIntList.Count - 1
                            .TableName = "tblPaymentCard"
                            With .Columns
                                .Clear()
                                .Add("PaymentID", i + 1, SqlBuilder.SQLParserDataType.spNum)
                                .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum)
                                .Add("Type", "AirInt")
                                .Add("PayMode", info.AirIntPayMode, SqlBuilder.SQLParserDataType.spText)
                                .Add("Name", info.AirIntList(i).Name)
                                .Add("CCVendor", info.AirIntList(i).CCVendor)
                                .Add("CCNumber", info.AirIntList(i).CCNum)
                                .Add("ExpDate", info.AirIntList(i).ExpiryDate)
                                'x = i + 1
                            End With
                            EffectRow = .ExecuteInsert()
                            If EffectRow <= 0 Then
                                Exit For
                            End If
                        Next
                        UpdateTempPaymentRecord(PaymentDT, info, "AirInt")
                    Else
                        .TableName = "tblPaymentCard"
                        With .Columns
                            .Clear()
                            .Add("PaymentID", 1, SqlBuilder.SQLParserDataType.spNum)
                            .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum)
                            .Add("Type", "AirInt")
                            .Add("PayMode", info.AirIntPayMode, SqlBuilder.SQLParserDataType.spText)
                        End With
                        EffectRow = .ExecuteInsert()
                        UpdateTempPaymentRecord(PaymentDT, info, "AirInt")
                    End If


                    If info.AirDomPayMode.Equals("CORPCC") Then
                        '.TableName = "tblPaymentCard"
                        'x = x + 1
                        For i As Integer = 0 To info.AirDomList.Count - 1
                            .TableName = "tblPaymentCard"
                            With .Columns
                                .Clear()
                                .Add("PaymentID", i + 1, SqlBuilder.SQLParserDataType.spNum)
                                .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum)
                                .Add("Type", "AirDom")
                                .Add("PayMode", info.AirDomPayMode, SqlBuilder.SQLParserDataType.spText)
                                .Add("Name", info.AirDomList(i).Name)
                                .Add("CCVendor", info.AirDomList(i).CCVendor)
                                .Add("CCNumber", info.AirDomList(i).CCNum)
                                .Add("ExpDate", info.AirDomList(i).ExpiryDate)
                            End With
                            EffectRow = .ExecuteInsert()
                            If EffectRow <= 0 Then
                                Exit For
                            End If
                        Next
                        UpdateTempPaymentRecord(PaymentDT, info, "AirDom")
                    Else
                        .TableName = "tblPaymentCard"
                        With .Columns
                            .Clear()
                            .Add("PaymentID", 1, SqlBuilder.SQLParserDataType.spNum)
                            .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum)
                            .Add("Type", "AirDom")
                            .Add("PayMode", info.AirDomPayMode, SqlBuilder.SQLParserDataType.spText)
                        End With
                        EffectRow = .ExecuteInsert()
                        UpdateTempPaymentRecord(PaymentDT, info, "AirDom")
                    End If

                    If info.AirLccPayMode.Equals("CORPCC") Then
                        '.TableName = "tblPaymentCard"
                        'x = x + 1
                        For i As Integer = 0 To info.AirLccList.Count - 1
                            .TableName = "tblPaymentCard"
                            With .Columns
                                .Clear()
                                .Add("PaymentID", i + 1, SqlBuilder.SQLParserDataType.spNum)
                                .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum)
                                .Add("Type", "AirLCC")
                                .Add("PayMode", info.AirLccPayMode, SqlBuilder.SQLParserDataType.spText)
                                .Add("Name", info.AirLccList(i).Name)
                                .Add("CCVendor", info.AirLccList(i).CCVendor)
                                .Add("CCNumber", info.AirLccList(i).CCNum)
                                .Add("ExpDate", info.AirLccList(i).ExpiryDate)
                            End With
                            EffectRow = .ExecuteInsert()
                            If EffectRow <= 0 Then
                                Exit For
                            End If
                        Next
                        UpdateTempPaymentRecord(PaymentDT, info, "AirLCC")
                    Else
                        .TableName = "tblPaymentCard"
                        With .Columns
                            .Clear()
                            .Add("PaymentID", 1, SqlBuilder.SQLParserDataType.spNum)
                            .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum)
                            .Add("Type", "AirLCC")
                            .Add("PayMode", info.AirLccPayMode, SqlBuilder.SQLParserDataType.spText)
                        End With
                        EffectRow = .ExecuteInsert()
                        UpdateTempPaymentRecord(PaymentDT, info, "AirLCC")
                        'CheckDeleteOrInsert(PaymentDT, info, "AirLCC")
                    End If


                    If info.HotelPayMode.Equals("CORPCC") Then
                        '.TableName = "tblPaymentCard"
                        'x = x + 1
                        For i As Integer = 0 To info.HotelList.Count - 1
                            .TableName = "tblPaymentCard"
                            With .Columns
                                .Clear()
                                .Add("PaymentID", i + 1, SqlBuilder.SQLParserDataType.spNum)
                                .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum)
                                .Add("Type", "Hotel")
                                .Add("PayMode", info.HotelPayMode, SqlBuilder.SQLParserDataType.spText)
                                .Add("Name", info.HotelList(i).Name)
                                .Add("CCVendor", info.HotelList(i).CCVendor)
                                .Add("CCNumber", info.HotelList(i).CCNum)
                                .Add("ExpDate", info.HotelList(i).ExpiryDate)
                            End With
                            EffectRow = .ExecuteInsert()
                            If EffectRow <= 0 Then
                                Exit For
                            End If
                        Next
                        UpdateTempPaymentRecord(PaymentDT, info, "Hotel")
                    Else
                        .TableName = "tblPaymentCard"
                        With .Columns
                            .Clear()
                            .Add("PaymentID", 1, SqlBuilder.SQLParserDataType.spNum)
                            .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum)
                            .Add("Type", "Hotel")
                            .Add("PayMode", info.HotelPayMode, SqlBuilder.SQLParserDataType.spText)
                        End With
                        EffectRow = .ExecuteInsert()
                        UpdateTempPaymentRecord(PaymentDT, info, "Hotel")
                    End If


                    If info.CarPayMode.Equals("CORPCC") Then
                        '.TableName = "tblPaymentCard"
                        'x = x + 1
                        For i As Integer = 0 To info.CarList.Count - 1
                            .TableName = "tblPaymentCard"
                            With .Columns
                                .Clear()
                                .Add("PaymentID", i + 1, SqlBuilder.SQLParserDataType.spNum)
                                .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum)
                                .Add("Type", "Car")
                                .Add("PayMode", info.CarPayMode, SqlBuilder.SQLParserDataType.spText)
                                .Add("Name", info.CarList(i).Name)
                                .Add("CCVendor", info.CarList(i).CCVendor)
                                .Add("CCNumber", info.CarList(i).CCNum)
                                .Add("ExpDate", info.CarList(i).ExpiryDate)
                            End With
                            EffectRow = .ExecuteInsert()
                            If EffectRow <= 0 Then
                                Exit For
                            End If
                        Next
                        UpdateTempPaymentRecord(PaymentDT, info, "Car")
                    Else
                        .TableName = "tblPaymentCard"
                        With .Columns
                            .Clear()
                            .Add("PaymentID", 1, SqlBuilder.SQLParserDataType.spNum)
                            .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum)
                            .Add("Type", "Car")
                            .Add("PayMode", info.CarPayMode, SqlBuilder.SQLParserDataType.spText)
                        End With
                        EffectRow = .ExecuteInsert()
                        UpdateTempPaymentRecord(PaymentDT, info, "Car")
                    End If


                    If info.AuxPayMode.Equals("CORPCC") Then
                        '.TableName = "tblPaymentCard"
                        'x = x + 1
                        For i As Integer = 0 To info.AuxList.Count - 1
                            .TableName = "tblPaymentCard"
                            With .Columns
                                .Clear()
                                .Add("PaymentID", i + 1, SqlBuilder.SQLParserDataType.spNum)
                                .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum)
                                .Add("Type", "Aux")
                                .Add("PayMode", info.AuxPayMode, SqlBuilder.SQLParserDataType.spText)
                                .Add("Name", info.AuxList(i).Name)
                                .Add("CCVendor", info.AuxList(i).CCVendor)
                                .Add("CCNumber", info.AuxList(i).CCNum)
                                .Add("ExpDate", info.AuxList(i).ExpiryDate)
                            End With
                            EffectRow = .ExecuteInsert()
                            If EffectRow <= 0 Then
                                Exit For
                            End If
                        Next
                        UpdateTempPaymentRecord(PaymentDT, info, "Aux")
                    Else
                        .TableName = "tblPaymentCard"
                        With .Columns
                            .Clear()
                            .Add("PaymentID", 1, SqlBuilder.SQLParserDataType.spNum)
                            .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum)
                            .Add("Type", "Aux")
                            .Add("PayMode", info.AuxPayMode, SqlBuilder.SQLParserDataType.spText)
                        End With
                        EffectRow = .ExecuteInsert()
                        UpdateTempPaymentRecord(PaymentDT, info, "Aux")
                    End If
                    'If info.PayMode = DataInfo.CompanyPayCardInfo.PaymentMode.CreditCard AndAlso Not info.ReferToProfile Then
                    '    For i As Integer = 0 To info.CardList.Count - 1
                    '        With .Columns
                    '            .Clear()
                    '            .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum)
                    '            .Add("PaymentID", i + 1, SqlBuilder.SQLParserDataType.spNum)
                    '            .Add("CCVendor", info.CardList(i).Vendor)
                    '            .Add("CCNumber", info.CardList(i).Number)
                    '            .Add("ExpDate", info.CardList(i).ExpiryDate, SqlBuilder.SQLParserDataType.spDate)
                    '            .Add("Air", info.CardList(i).PrefAir, SqlBuilder.SQLParserDataType.spBoolean)
                    '            .Add("Hotel", info.CardList(i).PrefHotel, SqlBuilder.SQLParserDataType.spBoolean)
                    '            .Add("Car", info.CardList(i).PrefCar, SqlBuilder.SQLParserDataType.spBoolean)
                    '        End With
                    '        EffectRow = .ExecuteInsert()
                    '        If EffectRow <= 0 Then
                    '            Exit For
                    '        End If
                    '    Next
                    'End If
                End With
            Catch ex As Exception
                EffectRow = -1
            End Try
            Return EffectRow
        End Function

        Private Sub CallProcedurePayment(ByVal ID As Integer, ByVal Type As String, ByVal PaymentID As Integer, ByVal PaymentType As String)
            With Me.MySQLParser
                .ExecuteStoreProcedure("exec sp_PaymentType '" + Convert.ToString(PaymentID) + "','" + Convert.ToString(ID) + "','" + PaymentType + "','" + ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName + "','" + Type + "'")
            End With
        End Sub

        Private Sub CallProcedureClientMaster(ByVal ID As Integer, ByVal Type As String)
            With Me.MySQLParser
                .ExecuteStoreProcedure("exec sp_ClientMaster '" + Convert.ToString(ID) + "', '" + ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName + "','" + Type + "'")
            End With
        End Sub

        Private Function CheckMatchRecord(ByVal PaymentRow As DataRow, ByVal info As DataInfo.CompanyPayCardInfo, ByVal Mode As String)
            Dim countInfo As Integer
            Dim checkMatch As Boolean = False
            Select Case Mode
                'AirDom
                Case "AirDom"
                    If PaymentRow.Item("PayMode") = info.AirDomPayMode Then
                        If info.AirDomPayMode = "CORPCC" Then
                            For countInfo = 0 To info.AirDomList.Count - 1
                                If info.AirDomList(countInfo).Name = PaymentRow.Item("Name") And info.AirDomList(countInfo).CCVendor = PaymentRow.Item("CCVendor") And info.AirDomList(countInfo).CCNum = PaymentRow.Item("CCNumber") And info.AirDomList(countInfo).ExpiryDate = PaymentRow.Item("ExpDate") Then
                                    checkMatch = True
                                    Exit For
                                End If
                            Next
                        Else
                            checkMatch = True
                        End If
                    End If
                    'AirLcc
                Case "AirLCC"
                    If PaymentRow.Item("PayMode") = info.AirLccPayMode Then
                        If info.AirLccPayMode = "CORPCC" Then
                            For countInfo = 0 To info.AirLccList.Count - 1
                                If info.AirLccList(countInfo).Name = PaymentRow.Item("Name") And info.AirLccList(countInfo).CCVendor = PaymentRow.Item("CCVendor") And info.AirLccList(countInfo).CCNum = PaymentRow.Item("CCNumber") And info.AirLccList(countInfo).ExpiryDate = PaymentRow.Item("ExpDate") Then
                                    checkMatch = True
                                    Exit For
                                End If
                            Next
                        Else
                            checkMatch = True
                        End If
                    End If
                    'AirInt
                Case "AirInt"
                    If PaymentRow.Item("PayMode") = info.AirIntPayMode Then
                        If info.AirIntPayMode = "CORPCC" Then
                            For countInfo = 0 To info.AirIntList.Count - 1
                                If info.AirIntList(countInfo).Name = PaymentRow.Item("Name") And info.AirIntList(countInfo).CCVendor = PaymentRow.Item("CCVendor") And info.AirIntList(countInfo).CCNum = PaymentRow.Item("CCNumber") And info.AirIntList(countInfo).ExpiryDate = PaymentRow.Item("ExpDate") Then
                                    checkMatch = True
                                    Exit For
                                End If
                            Next
                        Else
                            checkMatch = True
                        End If
                    End If
                    'Car
                Case "Car"
                    If PaymentRow.Item("PayMode") = info.CarPayMode Then
                        If info.CarPayMode = "CORPCC" Then
                            For countInfo = 0 To info.CarList.Count - 1
                                If info.CarList(countInfo).Name = PaymentRow.Item("Name") And info.CarList(countInfo).CCVendor = PaymentRow.Item("CCVendor") And info.CarList(countInfo).CCNum = PaymentRow.Item("CCNumber") And info.CarList(countInfo).ExpiryDate = PaymentRow.Item("ExpDate") Then
                                    checkMatch = True
                                    Exit For
                                End If
                            Next
                        Else
                            checkMatch = True
                        End If
                    End If
                    'Hotel
                Case "Hotel"
                    If PaymentRow.Item("PayMode") = info.HotelPayMode Then
                        If info.HotelPayMode = "CORPCC" Then
                            For countInfo = 0 To info.HotelList.Count - 1
                                If info.HotelList(countInfo).Name = PaymentRow.Item("Name") And info.HotelList(countInfo).CCVendor = PaymentRow.Item("CCVendor") And info.HotelList(countInfo).CCNum = PaymentRow.Item("CCNumber") And info.HotelList(countInfo).ExpiryDate = PaymentRow.Item("ExpDate") Then
                                    checkMatch = True
                                    Exit For
                                End If
                            Next
                        Else
                            checkMatch = True
                        End If
                    End If
                    'Aux
                Case "Aux"
                    If PaymentRow.Item("PayMode") = info.AuxPayMode Then
                        If info.AuxPayMode = "CORPCC" Then
                            For countInfo = 0 To info.AuxList.Count - 1
                                If info.AuxList(countInfo).Name = PaymentRow.Item("Name") And info.AuxList(countInfo).CCVendor = PaymentRow.Item("CCVendor") And info.AuxList(countInfo).CCNum = PaymentRow.Item("CCNumber") And info.AuxList(countInfo).ExpiryDate = PaymentRow.Item("ExpDate") Then
                                    checkMatch = True
                                    Exit For
                                End If
                            Next
                        Else
                            checkMatch = True
                        End If
                    End If
            End Select
            Return checkMatch
        End Function

        Private Sub InsertTempPaymentRecord(ByVal PaymentRow As DataRow, ByVal ModeInsert As String)
            Dim EffectRow As Integer
            With Me.MySQLParser
                .TableName = "Temp_tblPaymentCard"
                With .Columns
                    .Clear()
                    If ModeInsert = "CORPCC" Then
                        .Add("PaymentID", PaymentRow.Item("PaymentID").ToString(), SqlBuilder.SQLParserDataType.spNum)
                        .Add("ClientID", PaymentRow.Item("ClientID").ToString(), SqlBuilder.SQLParserDataType.spNum)
                        .Add("Type", PaymentRow.Item("Type").ToString())
                        .Add("PayMode", PaymentRow.Item("PayMode").ToString(), SqlBuilder.SQLParserDataType.spText)
                        .Add("Name", PaymentRow.Item("Name").ToString())
                        .Add("CCVendor", PaymentRow.Item("CCVendor").ToString())
                        .Add("CCNumber", PaymentRow.Item("CCNumber").ToString())
                        .Add("ExpDate", PaymentRow.Item("ExpDate").ToString())
                        .Add("DateModification", DateTime.Now)
                        .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                        .Add("ValueTypeChanged", "Update")
                    Else
                        .Add("PaymentID", 1, SqlBuilder.SQLParserDataType.spNum)
                        .Add("ClientID", PaymentRow.Item("ClientID").ToString(), SqlBuilder.SQLParserDataType.spNum)
                        .Add("Type", PaymentRow.Item("Type").ToString())
                        .Add("PayMode", PaymentRow.Item("PayMode").ToString(), SqlBuilder.SQLParserDataType.spText)
                        .Add("DateModification", DateTime.Now)
                        .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                        .Add("ValueTypeChanged", "Update")
                    End If
                End With
                EffectRow = .ExecuteInsert()
            End With
        End Sub

        Private Sub UpdateTempPaymentRecord(ByVal PaymentDT As DataTable, ByVal info As DataInfo.CompanyPayCardInfo, ByVal Type As String)
            Dim countDT As Integer
            Dim checkMatch As Boolean

            For countDT = 0 To PaymentDT.Rows.Count - 1
                If Type = PaymentDT.Rows(countDT).Item("Type") Then
                    checkMatch = CheckMatchRecord(PaymentDT.Rows(countDT), info, PaymentDT.Rows(countDT).Item("Type"))
                    If checkMatch = False Then
                        InsertTempPaymentRecord(PaymentDT.Rows(countDT), PaymentDT.Rows(countDT).Item("PayMode"))
                        Exit For
                    End If
                End If
            Next
        End Sub

        Private Function GetPaymentRecord(ByVal ClientID) As DataTable
            Dim PaymentDT As DataTable
            With Me.MySQLParser
                .TableName = "tblPaymentCard"
                With .Columns
                    .Clear()
                    .IncludeKey = False
                    .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("*")
                End With
                PaymentDT = .ExecuteDataTable()
            End With
            Return PaymentDT
        End Function

        Private Function CheckDeleteOrInsert(ByRef PaymentRecordDT As DataTable, ByVal info As DataInfo.CompanyPayCardInfo, ByVal PayType As String) As Boolean
            Dim status As String = ""
            Dim countInfo As Integer = 0
            Dim EffectRow As Integer

            Select Case PayType
                Case "AirLCC"
                    If PaymentRecordDT.Rows.Count > 0 Then
                        For countInfo = 0 To PaymentRecordDT.Rows.Count - 1
                            If PaymentRecordDT.Rows(countInfo).Item("Type") = "AirLCC" Then
                                With Me.MySQLParser
                                    .TableName = "Temp_tblPaymentCard"
                                    With .Columns
                                        .Clear()
                                        .Add("PaymentID", countInfo + 1, SqlBuilder.SQLParserDataType.spNum)
                                        .Add("ClientID", PaymentRecordDT.Rows(countInfo).Item("ClientID"), SqlBuilder.SQLParserDataType.spNum)
                                        .Add("Type", "AirLCC")
                                        .Add("PayMode", PaymentRecordDT.Rows(countInfo).Item("PayMode"), SqlBuilder.SQLParserDataType.spText)
                                        If PaymentRecordDT.Rows(countInfo).Item("PayMode") = "CORPCC" Then
                                            .Add("Name", PaymentRecordDT.Rows(countInfo).Item("Name"))
                                            .Add("CCVendor", PaymentRecordDT.Rows(countInfo).Item("CCVendor"))
                                            .Add("CCNumber", PaymentRecordDT.Rows(countInfo).Item("CCNumber"))
                                            .Add("ExpDate", PaymentRecordDT.Rows(countInfo).Item("ExpDate"))
                                        End If
                                        .Add("DateModification", DateTime.Now)
                                        .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                        .Add("ValueTypeChanged", "Delete")
                                    End With
                                    EffectRow = .ExecuteInsert()
                                End With
                            End If
                        Next
                    End If



                Case "AirInt"
                    If PaymentRecordDT.Rows.Count > 0 Then
                        For countInfo = 0 To PaymentRecordDT.Rows.Count - 1
                            If PaymentRecordDT.Rows(countInfo).Item("Type") = "AirInt" Then
                                With Me.MySQLParser
                                    .TableName = "Temp_tblPaymentCard"
                                    With .Columns
                                        .Clear()
                                        .Add("PaymentID", countInfo + 1, SqlBuilder.SQLParserDataType.spNum)
                                        .Add("ClientID", PaymentRecordDT.Rows(countInfo).Item("ClientID"), SqlBuilder.SQLParserDataType.spNum)
                                        .Add("Type", "AirInt")
                                        .Add("PayMode", PaymentRecordDT.Rows(countInfo).Item("PayMode"), SqlBuilder.SQLParserDataType.spText)
                                        If PaymentRecordDT.Rows(countInfo).Item("PayMode") = "CORPCC" Then
                                            .Add("Name", PaymentRecordDT.Rows(countInfo).Item("Name"))
                                            .Add("CCVendor", PaymentRecordDT.Rows(countInfo).Item("CCVendor"))
                                            .Add("CCNumber", PaymentRecordDT.Rows(countInfo).Item("CCNumber"))
                                            .Add("ExpDate", PaymentRecordDT.Rows(countInfo).Item("ExpDate"))
                                        End If
                                        .Add("DateModification", DateTime.Now)
                                        .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                        .Add("ValueTypeChanged", "Delete")
                                    End With
                                    EffectRow = .ExecuteInsert()
                                End With
                            End If
                        Next
                    End If



                Case "AirDom"
                    If PaymentRecordDT.Rows.Count > 0 Then
                        For countInfo = 0 To PaymentRecordDT.Rows.Count - 1
                            If PaymentRecordDT.Rows(countInfo).Item("Type") = "AirDom" Then
                                With Me.MySQLParser
                                    .TableName = "Temp_tblPaymentCard"
                                    With .Columns
                                        .Clear()
                                        .Add("PaymentID", countInfo + 1, SqlBuilder.SQLParserDataType.spNum)
                                        .Add("ClientID", PaymentRecordDT.Rows(countInfo).Item("ClientID"), SqlBuilder.SQLParserDataType.spNum)
                                        .Add("Type", "AirDom")
                                        .Add("PayMode", PaymentRecordDT.Rows(countInfo).Item("PayMode"), SqlBuilder.SQLParserDataType.spText)
                                        If PaymentRecordDT.Rows(countInfo).Item("PayMode") = "CORPCC" Then
                                            .Add("Name", PaymentRecordDT.Rows(countInfo).Item("Name"))
                                            .Add("CCVendor", PaymentRecordDT.Rows(countInfo).Item("CCVendor"))
                                            .Add("CCNumber", PaymentRecordDT.Rows(countInfo).Item("CCNumber"))
                                            .Add("ExpDate", PaymentRecordDT.Rows(countInfo).Item("ExpDate"))
                                        End If
                                        .Add("DateModification", DateTime.Now)
                                        .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                        .Add("ValueTypeChanged", "Delete")
                                    End With
                                    EffectRow = .ExecuteInsert()
                                End With
                            End If
                        Next
                    End If



                Case "Car"
                    If PaymentRecordDT.Rows.Count > 0 Then
                        For countInfo = 0 To PaymentRecordDT.Rows.Count - 1
                            If PaymentRecordDT.Rows(countInfo).Item("Type") = "Car" Then
                                With Me.MySQLParser
                                    .TableName = "Temp_tblPaymentCard"
                                    With .Columns
                                        .Clear()
                                        .Add("PaymentID", countInfo + 1, SqlBuilder.SQLParserDataType.spNum)
                                        .Add("ClientID", PaymentRecordDT.Rows(countInfo).Item("ClientID"), SqlBuilder.SQLParserDataType.spNum)
                                        .Add("Type", "Car")
                                        .Add("PayMode", PaymentRecordDT.Rows(countInfo).Item("PayMode"), SqlBuilder.SQLParserDataType.spText)
                                        If PaymentRecordDT.Rows(countInfo).Item("PayMode") = "CORPCC" Then
                                            .Add("Name", PaymentRecordDT.Rows(countInfo).Item("Name"))
                                            .Add("CCVendor", PaymentRecordDT.Rows(countInfo).Item("CCVendor"))
                                            .Add("CCNumber", PaymentRecordDT.Rows(countInfo).Item("CCNumber"))
                                            .Add("ExpDate", PaymentRecordDT.Rows(countInfo).Item("ExpDate"))
                                        End If
                                        .Add("DateModification", DateTime.Now)
                                        .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                        .Add("ValueTypeChanged", "Delete")
                                    End With
                                    EffectRow = .ExecuteInsert()
                                End With
                            End If
                        Next
                    End If


                Case "Hotel"
                    If PaymentRecordDT.Rows.Count > 0 Then
                        For countInfo = 0 To PaymentRecordDT.Rows.Count - 1
                            If PaymentRecordDT.Rows(countInfo).Item("Type") = "Hotel" Then
                                With Me.MySQLParser
                                    .TableName = "Temp_tblPaymentCard"
                                    With .Columns
                                        .Clear()
                                        .Add("PaymentID", countInfo + 1, SqlBuilder.SQLParserDataType.spNum)
                                        .Add("ClientID", PaymentRecordDT.Rows(countInfo).Item("ClientID"), SqlBuilder.SQLParserDataType.spNum)
                                        .Add("Type", "Hotel")
                                        .Add("PayMode", PaymentRecordDT.Rows(countInfo).Item("PayMode"), SqlBuilder.SQLParserDataType.spText)
                                        If PaymentRecordDT.Rows(countInfo).Item("PayMode") = "CORPCC" Then
                                            .Add("Name", PaymentRecordDT.Rows(countInfo).Item("Name"))
                                            .Add("CCVendor", PaymentRecordDT.Rows(countInfo).Item("CCVendor"))
                                            .Add("CCNumber", PaymentRecordDT.Rows(countInfo).Item("CCNumber"))
                                            .Add("ExpDate", PaymentRecordDT.Rows(countInfo).Item("ExpDate"))
                                        End If
                                        .Add("DateModification", DateTime.Now)
                                        .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                        .Add("ValueTypeChanged", "Delete")
                                    End With
                                    EffectRow = .ExecuteInsert()
                                End With
                            End If
                        Next
                    End If

                Case "Aux"
                    If PaymentRecordDT.Rows.Count > 0 Then
                        For countInfo = 0 To PaymentRecordDT.Rows.Count - 1
                            If PaymentRecordDT.Rows(countInfo).Item("Type") = "Aux" Then
                                With Me.MySQLParser
                                    .TableName = "Temp_tblPaymentCard"
                                    With .Columns
                                        .Clear()
                                        .Add("PaymentID", countInfo + 1, SqlBuilder.SQLParserDataType.spNum)
                                        .Add("ClientID", PaymentRecordDT.Rows(countInfo).Item("ClientID"), SqlBuilder.SQLParserDataType.spNum)
                                        .Add("Type", "Aux")
                                        .Add("PayMode", PaymentRecordDT.Rows(countInfo).Item("PayMode"), SqlBuilder.SQLParserDataType.spText)
                                        If PaymentRecordDT.Rows(countInfo).Item("PayMode") = "CORPCC" Then
                                            .Add("Name", PaymentRecordDT.Rows(countInfo).Item("Name"))
                                            .Add("CCVendor", PaymentRecordDT.Rows(countInfo).Item("CCVendor"))
                                            .Add("CCNumber", PaymentRecordDT.Rows(countInfo).Item("CCNumber"))
                                            .Add("ExpDate", PaymentRecordDT.Rows(countInfo).Item("ExpDate"))
                                        End If
                                        .Add("DateModification", DateTime.Now)
                                        .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                        .Add("ValueTypeChanged", "Delete")
                                    End With
                                    EffectRow = .ExecuteInsert()
                                End With
                            End If
                        Next
                    End If

            End Select
        End Function

        Public Function GetTempPaymentCard(Optional ByVal ClientName As String = "", Optional ByVal dateFrom As String = "", Optional ByVal dateTo As String = "") As DataSet
            '//Payment
            Dim PayDT As DataTable
            Dim TempPayDT As DataTable
            Dim PayMasterDT As DataTable
            '//Client
            'Dim ClientDT As DataTable
            'Dim TempClientDT As DataTable
            'Dim ClientMasterDT As DataTable

            Dim TempTable As DataTable
            Dim ds As New DataSet
            Dim ClientID As String = ""
            Dim count As Integer
            Dim count2 As Integer
            Dim foundRow() As DataRow
            Dim ClientIDArr(2) As String
            ClientIDArr(0) = "ClientID"
            ClientIDArr(1) = "PaymentID"
            ClientIDArr(2) = "Type"
            Dim ClientNameArr(0) As String
            ClientNameArr(0) = "ClientID"

            If ClientName <> "" Then
                ClientID = GetClientIDByName(ClientName)
            End If

            With Me.MySQLParser
                '//Payment Card
                .TableName = "Temp_tblPaymentCard"
                With .Columns
                    .Clear()
                    If ClientName <> "" Then
                        If ClientID <> "" Then
                            .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        Else
                            .Add("ClientID", "-1", SqlBuilder.SQLParserDataType.spNum, True)
                        End If
                    End If
                    If dateFrom = dateTo Then
                        If dateFrom <> "" And dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:990"
                            .Add("DateModification", "convert(varchar,cast('" + dateFrom + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, ">")
                            .Add("DateModification", "convert(varchar,cast('" + dateTo + " 23:59:59:990" + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, "<")
                        End If
                    Else
                        If dateFrom <> "" Then
                            .Add("DateModification", dateFrom, SqlBuilder.SQLParserDataType.spDate, True, ">")
                        End If
                        If dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:990"
                            .Add("DateModification", dateTo + " 23:59:59:990", SqlBuilder.SQLParserDataType.spText, True, "<=")
                        End If
                    End If
                    .Add("*")
                End With
                TempPayDT = .ExecuteDataTable(.SQLSelect + " order by DateModification Desc")

                .TableName = "tblPaymentCard"
                With .Columns
                    .Clear()
                    If ClientName <> "" Then
                        If ClientID <> "" Then
                            .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        Else
                            .Add("ClientID", "-1", SqlBuilder.SQLParserDataType.spNum, True)
                        End If
                    End If
                    .Add("*")
                End With
                PayDT = .ExecuteDataTable()

                TempTable = TempPayDT.DefaultView.ToTable(True, ClientIDArr)
                PayMasterDT = TempPayDT.Clone()
                For count = 0 To TempTable.Rows.Count - 1
                    foundRow = PayDT.Select("ClientID='" + TempTable.Rows(count).Item("ClientID").ToString() + "' and PaymentID='" + TempTable.Rows(count).Item("PaymentID").ToString() + "' and Type='" + TempTable.Rows(count).Item("Type").ToString() + "'")
                    If foundRow.Length > 0 Then
                        For count2 = 0 To foundRow.Length - 1
                            PayMasterDT.ImportRow(foundRow(count2))
                        Next count2
                    End If
                Next
                PayMasterDT.AcceptChanges()
                PayMasterDT.Merge(TempPayDT)
                PayMasterDT.TableName = "Payment"
                ds.Tables.Add(PayMasterDT)

                ''//Client Master
                '.TableName = "Temp_tblClientMaster"
                'With .Columns
                '    .Clear()
                '    If ClientName <> "" Then
                '        .Add("Name", ClientName, SqlBuilder.SQLParserDataType.spText, True)
                '    End If
                '    If dateFrom = dateTo Then
                '        If dateFrom <> "" And dateTo <> "" Then
                '            'dateTo = dateTo + " 23:59:59:990"
                '            .Add("DateModification", "convert(varchar,cast('" + dateFrom + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, ">")
                '            .Add("DateModification", "convert(varchar,cast('" + dateTo + " 23:59:59:990" + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, "<")
                '        End If
                '    Else
                '        If dateFrom <> "" Then
                '            .Add("DateModification", dateFrom, SqlBuilder.SQLParserDataType.spDate, True, ">")
                '        End If
                '        If dateTo <> "" Then
                '            'dateTo = dateTo + " 23:59:59:990"
                '            .Add("DateModification", dateTo + " 23:59:59:990", SqlBuilder.SQLParserDataType.spText, True, "<=")
                '        End If
                '    End If
                '    .Add("ClientID,PaymentMode,ReferToPax,DateModification,UserName,ValueTypeChanged")
                'End With
                'TempClientDT = .ExecuteDataTable(.SQLSelect + " order by DateModification ASC")

                '.TableName = "tblClientMaster"
                'With .Columns
                '    .Clear()
                '    If ClientName <> "" Then
                '        .Add("Name", ClientName, SqlBuilder.SQLParserDataType.spText, True)
                '    End If
                '    .Add("ClientID,PaymentMode,ReferToPax")
                'End With
                'ClientDT = .ExecuteDataTable()

                'Dim count3 As Integer
                'Dim TempClientMasterDT As DataTable
                'TempClientMasterDT = TempClientDT.Clone()
                'TempTable = TempClientDT.DefaultView.ToTable(True, ClientNameArr)
                'ClientMasterDT = TempClientDT.Clone()
                'For count = 0 To TempTable.Rows.Count - 1
                '    foundRow = ClientDT.Select("ClientID='" + TempTable.Rows(count).Item("ClientID").ToString() + "'")
                '    If foundRow.Length > 0 Then
                '        For count2 = 0 To foundRow.Length - 1
                '            ClientMasterDT.ImportRow(foundRow(count2))
                '            For count3 = 0 To TempClientDT.Rows.Count - 1
                '                If TempClientDT.Rows(count3).Item("ClientID").ToString() = foundRow(count2).Item("ClientID").ToString() Then
                '                    If TempClientDT.Rows(count3).Item("ValueTypeChanged").ToString() <> "Insert" Then
                '                        If TempClientDT.Rows(count3).Item("PaymentMode").ToString() <> foundRow(count2).Item("PaymentMode").ToString() Or TempClientDT.Rows(count3).Item("ReferToPax").ToString() <> foundRow(count2).Item("ReferToPax").ToString() Then
                '                            If CheckTempClientMasterExist(TempClientMasterDT, TempClientDT.Rows(count3)) = False Then
                '                                TempClientMasterDT.ImportRow(TempClientDT.Rows(count3))
                '                            End If
                '                        End If
                '                    Else
                '                        TempClientMasterDT.ImportRow(TempClientDT.Rows(count3))
                '                    End If
                '                End If
                '            Next count3
                '        Next count2
                '    End If
                'Next
                'ClientMasterDT.AcceptChanges()
                'ClientMasterDT.Merge(TempClientMasterDT)
                'ClientMasterDT.TableName = "Client"
                'ds.Tables.Add(ClientMasterDT)
            End With
            Return ds
        End Function

        Public Function GetClientIDByName(ByVal ClientName As String) As String
            Dim retVal As String
            Dim retObj As Object
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblClientMaster"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("Name", ClientName, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("ClientID")
                End With
                retObj = .ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar, CommandType.Text)
                retVal = Util.DBNullToText(retObj)
            End With
            Return retVal
        End Function

        Public Function CheckTempClientMasterExist(ByVal ClientDT As DataTable, ByVal ClientRow As DataRow)
            Dim check As Boolean
            Dim count As Integer

            For count = 0 To ClientDT.Rows.Count - 1
                If ClientDT.Rows(count).Item("ClientID").ToString() = ClientRow.Item("ClientID").ToString() And ClientDT.Rows(count).Item("PaymentMode").ToString() = ClientRow.Item("PaymentMode").ToString() And ClientDT.Rows(count).Item("ReferToPax").ToString() = ClientRow.Item("ReferToPax").ToString() Then
                    check = True
                    Exit For
                End If
            Next count
            Return check
        End Function

    End Class
End Namespace


@


1.1.1.1
log
@no message
@
text
@@
