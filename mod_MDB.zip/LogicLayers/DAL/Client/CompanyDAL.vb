head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.20;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.20;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic
Imports System.Collections.Generic

Namespace DataAccessLayer
    Public Class CompanyDAL
        Inherits BaseDA

        Public Function GetCompanyList(ByVal ClientName As String, ByVal AffGroup As String, ByVal IncInActive As Boolean, ByVal ProfileName As String, ByVal ClientNum As String, ByVal ConfigKey As String) As DataTable
            Dim dt As DataTable
            Dim oSql As String



            oSql = "Select * from tblClientMaster "
            oSql = oSql & "WHERE  GroupName LIKE " + "'%" + ClientName + "%'" + " and SubUnit LIKE " + "'%" + AffGroup + "%'" + " "
            If Not IncInActive Then
                oSql = oSql & " and Status =1 "
            End If

            'If ProfileName <> "" Then
            '    oSql = oSql & " and ClientID = (Select Distinct ClientID from CWTStandardData.dbo.tblCSP_LineDefClientMapping " & _
            '                  " where ProfileName = " + "'" + ProfileName + "'" + " and ConfigInstanceKeyID= " + ConfigKey + ") "
            'End If

            'If ProfileName = "" And ClientNum <> "" Then
            '    'oSql = oSql & " and ClientID = (Select Distinct ClientID from tblBillingAddress where ClientID= " + "'" + ClientNum + "'" + ")  "
            '    oSql = oSql & "and ClientNumber = '" + ClientNum + "'"
            'End If

            If ProfileName <> "" And ClientNum <> "" Then
                'oSql = oSql & " or ClientID = (Select Distinct ClientID from tblBillingAddress where ClientID= " + "'" + ClientNum + "'" + ")  "
                oSql = oSql & "and ClientNumber = '" + ClientNum + "'"
            ElseIf ProfileName = "" And ClientNum <> "" Then
                oSql = oSql & "and ClientNumber = '" + ClientNum + "'"
            ElseIf ProfileName <> "" Then
                oSql = oSql & " and ClientID = (Select Distinct ClientID from CWTStandardData.dbo.tblCSP_LineDefClientMapping " & _
                              " where ProfileName = " + "'" + ProfileName + "'" + " and ConfigInstanceKeyID= " + ConfigKey + ") "
            End If

            dt = Me.MySQLParser.ExecuteDataTable(oSql)

            'With Me.MySQLParser
            '    .AutoParameter = False
            '    .TableName = "tblClientMaster"
            '    With .Columns
            '        .IncludeKey = False
            '        .Clear()
            '        .Add("GroupName", "%" + ClientName + "%", SqlBuilder.SQLParserDataType.spText, True, "LIKE")
            '        .Add("SubUnit", "%" + AffGroup + "%", SqlBuilder.SQLParserDataType.spText, True, "LIKE")
            '        If Not IncInActive Then .Add("Status", True, SqlBuilder.SQLParserDataType.spBoolean, True)

            '        .Add("*")
            '    End With
            '    dt = .ExecuteDataTable()
            'End With
            Return dt
        End Function

        Public Function GetCompanyPrefAirList(ByVal ClientName As String, ByVal AffGroup As String, ByVal IncInActive As Boolean) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblClientMaster"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("GroupName", "%" + ClientName + "%", SqlBuilder.SQLParserDataType.spText, True, "LIKE")
                    .Add("SubUnit", "%" + AffGroup + "%", SqlBuilder.SQLParserDataType.spText, True, "LIKE")
                    If Not IncInActive Then .Add("Status", True, SqlBuilder.SQLParserDataType.spBoolean, True)
                    .Add("*")
                    .Add("(select count(*) from tblAirlinePrefer p where p.ClientID=tblClientMaster.ClientID) as PrefAirCount")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetCompanyAirContList(ByVal ClientName As String, ByVal AffGroup As String, ByVal IncInActive As Boolean) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblClientMaster"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("GroupName", "%" + ClientName + "%", SqlBuilder.SQLParserDataType.spText, True, "LIKE")
                    .Add("SubUnit", "%" + AffGroup + "%", SqlBuilder.SQLParserDataType.spText, True, "LIKE")
                    If Not IncInActive Then .Add("Status", True, SqlBuilder.SQLParserDataType.spBoolean, True)
                    .Add("*")
                    .Add("(select count(*) from tblClientAirContracts c where c.ClientID=tblClientMaster.ClientID) as ContAirCount")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetClientName(ByVal ClientName As String) As String()
            Dim dt As DataTable
            Dim retVal As New List(Of String)
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblClientMaster"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("GroupName", ClientName + "%", SqlBuilder.SQLParserDataType.spText, True, "LIKE")
                    .Add("Distinct ClientName")
                End With
                dt = .ExecuteDataTable()
            End With
            If dt IsNot Nothing AndAlso dt.Rows.Count > 0 Then
                For i As Integer = 0 To dt.Rows.Count - 1
                    retVal.Add(dt.Rows(i).Item("GroupName").ToString)
                Next
            End If
            Return retVal.ToArray
        End Function

        Public Function GetBillingModeByClientID(ByVal ClientID As String) As String
            Dim retVal As String
            Dim retObj As Object
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblClientMaster"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("BillingMode")
                End With
                retObj = .ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar, CommandType.Text)
                retVal = Util.DBNullToText(retObj)
            End With
            Return retVal
        End Function

        Public Function GetClientNameByID(ByVal ClientID As String) As String
            Dim retVal As String
            Dim retObj As Object
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblClientMaster"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("GroupName")
                End With
                retObj = .ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar, CommandType.Text)
                retVal = Util.DBNullToText(retObj)
            End With
            Return retVal
        End Function

        Public Function IsExistName(ByVal ClientName As String, ByVal ID As String) As Boolean
            Dim retVal As Boolean
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblClientMaster"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("GroupName", ClientName, SqlBuilder.SQLParserDataType.spText, True)
                    If ID <> "" Then .Add("ClientID", ID, SqlBuilder.SQLParserDataType.spText, True, "<>")
                    .Add("count(*) as RecordCount")
                End With
                retVal = (CWTMasterDB.Util.DBNullToZero(.ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar)) > 0)
            End With
            Return retVal
        End Function

        Public Function GetAffiliateName(ByVal AffiliateName As String) As String()
            Dim dt As DataTable
            Dim retVal As New List(Of String)
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblClientMaster"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("SubUnit", AffiliateName + "%", SqlBuilder.SQLParserDataType.spText, True, "LIKE")
                    .Add("Distinct AffiliateName")
                End With
                dt = .ExecuteDataTable()
            End With
            If dt IsNot Nothing AndAlso dt.Rows.Count > 0 Then
                For i As Integer = 0 To dt.Rows.Count - 1
                    retVal.Add(dt.Rows(i).Item("SubUnit").ToString)
                Next
            End If
            Return retVal.ToArray
        End Function

        Public Function GetCompayInfo(ByVal ClientID As String) As DataSet
            Dim ds As New DataSet()
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblClientMaster"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
                dt.TableName = "Company"
                ds.Tables.Add(dt)
                '// CWT Contact
                .TableName = "tblCWTContact"
                dt = .ExecuteDataTable(.SQLSelect + " order by ContactID")
                dt.TableName = "CWT"
                ds.Tables.Add(dt)
                '// Client Contact
                .TableName = "tblTM"
                dt = .ExecuteDataTable(.SQLSelect + " order by TMSequenceNo")
                dt.TableName = "Client"
                ds.Tables.Add(dt)
            End With
            Return ds
        End Function

        Public Function UpdateCompany(ByRef info As DataInfo.CompanyInfo) As Integer
            Dim EffectRow As Integer = -1
            'Dim checkClientMasterMatch As Boolean
            Dim ds As New DataSet()
            Try
                ds = GetCWTTMDetails(info.ID)
                With Me.MySQLParser
                    .OpenConnection()
                    .BeginTran()
                    .TableName = "tblClientMaster"
                    With .Columns
                        .Clear()
                        If info.PageMode = CWTMasterDB.TransactionMode.UpdateMode Then
                            .Add("ClientID", info.ID, SqlBuilder.SQLParserDataType.spNum, True)
                        End If
                        If info.CurrentWebMode = DataInfo.CompanyInfo.WebMode.GeneralInfo Then
                            .Add("GroupName", info.Name)
                            '.Add("ClientType", info.Type)
                            .Add("Name", info.EntityName)
                            .Add("SubUnit", info.AffName)
                            .Add("BizPhoneLocalCode", info.BizPhoneCode)
                            .Add("BizPhoneNumber", info.BizPhoneNo)
                            .Add("BizFaxLocalCode", info.FaxPhoneCode)
                            .Add("BizFaxNumber", info.FaxPhoneNo)
                            .Add("Email", info.Email)
                            .Add("Address1", info.Address1)
                            .Add("Address2", info.Address2)
                            .Add("Address3", info.Address3)
                            .Add("Address4", info.Address4)
                            .Add("Address5", info.Address5)
                            .Add("TeamEmail", info.TeamEmail)
                            .Add("VendorReplyEmail", info.VendorReplyEmail)
                            .Add("ActivateDate", info.ActivateDate, SqlBuilder.SQLParserDataType.spDate)
                            .Add("Status", info.Status, SqlBuilder.SQLParserDataType.spBoolean)
                        End If
                    End With

                    Select Case info.PageMode
                        Case CWTMasterDB.TransactionMode.AddNewMode
                            EffectRow = .ExecuteInsert()
                            info.ID = .GetLastIdentity
                            CallProcedure(info.ID, "Insert", "sp_ClientInfo")
                        Case CWTMasterDB.TransactionMode.UpdateMode
                            If info.CurrentWebMode = DataInfo.CompanyInfo.WebMode.GeneralInfo Then
                                CallProcedure(info.ID, "Update", "sp_ClientInfo")
                                EffectRow = .ExecuteUpdate()
                            Else
                                EffectRow = 1
                            End If

                            '// CWT Contact
                            If info.CurrentWebMode = DataInfo.CompanyInfo.WebMode.CWTContact Then
                                .TableName = "tblCWTContact"
                                With .Columns
                                    .Clear()
                                    .Add("ClientID", info.ID, SqlBuilder.SQLParserDataType.spNum, True)
                                End With
                                .ExecuteDelete()
                            End If
                            '// Client Contact
                            If info.CurrentWebMode = DataInfo.CompanyInfo.WebMode.ClientContact Then
                                .TableName = "tblTM"
                                With .Columns
                                    .Clear()
                                    .Add("ClientID", info.ID, SqlBuilder.SQLParserDataType.spNum, True)
                                End With
                                .ExecuteDelete()
                            End If
                    End Select
                    If info.CurrentWebMode = DataInfo.CompanyInfo.WebMode.CWTContact AndAlso EffectRow > 0 Then
                        '// CWT Contacts
                        .TableName = "tblCWTContact"
                        For i As Integer = 0 To info.CWTContact.Count - 1
                            With .Columns
                                .Clear()
                                .Add("ClientID", info.ID, SqlBuilder.SQLParserDataType.spNum)
                                .Add("ContactID", i + 1, SqlBuilder.SQLParserDataType.spNum)
                                .Add("UserID", info.CWTContact.Item(i).UserName)
                                .Add("Title", info.CWTContact.Item(i).Title)
                                .Add("FirstName", info.CWTContact.Item(i).FirstName)
                                .Add("LastName", info.CWTContact.Item(i).LastName)
                                .Add("LocalCode", info.CWTContact.Item(i).PhoneCode)
                                .Add("LocalCodeMobile", info.CWTContact.Item(i).MobileCode)

                                .Add("Phone", info.CWTContact.Item(i).Phone)
                                .Add("Mobile", info.CWTContact.Item(i).Mobile)

                                .Add("Email", info.CWTContact.Item(i).Email)
                                .Add("JobTitle", info.CWTContact.Item(i).JobTitle)
                            End With
                            EffectRow = .ExecuteInsert()
                            If EffectRow <= 0 Then
                                Exit For
                            End If
                        Next
                    End If
                    If info.CurrentWebMode = DataInfo.CompanyInfo.WebMode.ClientContact AndAlso EffectRow > 0 Then
                        '// Client Contacts
                        .TableName = "tblTM"
                        For i As Integer = 0 To info.ClientContact.Count - 1
                            With .Columns
                                .Clear()
                                .Add("ClientID", info.ID, SqlBuilder.SQLParserDataType.spNum)
                                .Add("TMID", i + 1, SqlBuilder.SQLParserDataType.spNum)
                                .Add("TMSequenceNo", i + 1, SqlBuilder.SQLParserDataType.spNum)
                                .Add("Title", info.ClientContact.Item(i).Title)
                                .Add("FirstName", info.ClientContact.Item(i).FirstName)
                                .Add("LastName", info.ClientContact.Item(i).LastName)
                                .Add("LocalCode", info.ClientContact.Item(i).PhoneCode)
                                .Add("LocalCodeMobile", info.ClientContact.Item(i).MobileCode)
                                .Add("LocalCodeFax", info.ClientContact.Item(i).FaxCode)
                                .Add("Phone", info.ClientContact.Item(i).Phone)
                                .Add("Mobile", info.ClientContact.Item(i).Mobile)
                                .Add("Fax", info.ClientContact.Item(i).Fax)
                                .Add("Email", info.ClientContact.Item(i).Email)
                                .Add("JobTitle", info.ClientContact.Item(i).JobTitle)
                            End With
                            EffectRow = .ExecuteInsert()
                            If EffectRow <= 0 Then
                                Exit For
                            End If
                        Next
                    End If
                End With
                If EffectRow > 0 Then
                    MatchRecords(info, ds)
                    Me.MySQLParser.CommitTran()
                Else
                    Me.MySQLParser.RollbackTran()
                End If
            Catch ex As Exception
                EffectRow = -1
                Me.MySQLParser.RollbackTran()
            Finally
                Me.MySQLParser.CloseConnection()
            End Try
            Return EffectRow
        End Function

        Private Sub CallProcedure(ByVal ClientID As String, ByVal Type As String, ByVal StoreProdType As String)
            With Me.MySQLParser
                .ExecuteStoreProcedure("exec " + StoreProdType + " '" + ClientID + "','" + ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName + "','" + Type + "'")
            End With
        End Sub

        Private Function GetCWTTMDetails(ByVal ClientID As String) As DataSet
            Dim ds As New DataSet()
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblClientMaster"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
                dt.TableName = "ClientMaster"
                ds.Tables.Add(dt)

                'Contact
                .TableName = "tblCWTContact"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
                dt.TableName = "CWTContact"
                ds.Tables.Add(dt)

                'TM
                .TableName = "tblTM"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
                dt.TableName = "TM"
                ds.Tables.Add(dt)
            End With
            Return ds
        End Function

        Private Sub MatchRecords(ByRef info As DataInfo.CompanyInfo, ByRef ds As DataSet)
            Dim EffectRow As Integer
            Dim countInfo As Integer
            Dim countDT As Integer
            Dim CWTDT As DataTable
            Dim TMDT As DataTable
            Dim checkExist As Boolean

            If info.CurrentWebMode = DataInfo.CompanyInfo.WebMode.CWTContact Then
                CWTDT = ds.Tables("CWTContact")
                If CWTDT.Rows.Count > 0 Then
                    For countDT = 0 To CWTDT.Rows.Count - 1
                        checkExist = CheckRecordExists(CWTDT.Rows(countDT), info, "CWT")
                        If checkExist = False Then
                            For countInfo = 0 To info.CWTContact.Count - 1
                                If CWTDT.Rows(countDT).Item("ContactID").ToString() = countInfo + 1 Then
                                    With Me.MySQLParser
                                        .TableName = "Temp_tblCWTContact"
                                        With .Columns
                                            .Clear()
                                            .Add("ClientID", CWTDT.Rows(countDT).Item("ClientID").ToString(), SqlBuilder.SQLParserDataType.spNum)
                                            .Add("ContactID", CWTDT.Rows(countDT).Item("ContactID").ToString(), SqlBuilder.SQLParserDataType.spNum)
                                            .Add("UserID", CWTDT.Rows(countDT).Item("UserID").ToString())
                                            .Add("Title", CWTDT.Rows(countDT).Item("Title").ToString())
                                            .Add("FirstName", CWTDT.Rows(countDT).Item("FirstName").ToString())
                                            .Add("LastName", CWTDT.Rows(countDT).Item("LastName").ToString())
                                            .Add("LocalCode", CWTDT.Rows(countDT).Item("LocalCode").ToString())
                                            .Add("LocalCodeMobile", CWTDT.Rows(countDT).Item("LocalCodeMobile").ToString())
                                            .Add("Phone", CWTDT.Rows(countDT).Item("Phone").ToString())
                                            .Add("Mobile", CWTDT.Rows(countDT).Item("Mobile").ToString())
                                            .Add("Email", CWTDT.Rows(countDT).Item("Email").ToString())
                                            .Add("JobTitle", CWTDT.Rows(countDT).Item("JobTitle").ToString())
                                            .Add("DateModification", DateTime.Now)
                                            .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                            .Add("ValueTypeChanged", "Update")
                                        End With
                                        EffectRow = .ExecuteInsert()
                                        Exit For
                                    End With
                                End If

                                If countDT > info.CWTContact.Count Then
                                    With Me.MySQLParser
                                        .TableName = "Temp_tblCWTContact"
                                        With .Columns
                                            .Clear()
                                            .Add("ClientID", CWTDT.Rows(countDT).Item("ClientID").ToString(), SqlBuilder.SQLParserDataType.spNum)
                                            .Add("ContactID", CWTDT.Rows(countDT).Item("ContactID").ToString(), SqlBuilder.SQLParserDataType.spNum)
                                            .Add("UserID", CWTDT.Rows(countDT).Item("UserID").ToString())
                                            .Add("Title", CWTDT.Rows(countDT).Item("Title").ToString())
                                            .Add("FirstName", CWTDT.Rows(countDT).Item("FirstName").ToString())
                                            .Add("LastName", CWTDT.Rows(countDT).Item("LastName").ToString())
                                            .Add("LocalCode", CWTDT.Rows(countDT).Item("LocalCode").ToString())
                                            .Add("LocalCodeMobile", CWTDT.Rows(countDT).Item("LocalCodeMobile").ToString())
                                            .Add("Phone", CWTDT.Rows(countDT).Item("Phone").ToString())
                                            .Add("Mobile", CWTDT.Rows(countDT).Item("Mobile").ToString())
                                            .Add("Email", CWTDT.Rows(countDT).Item("Email").ToString())
                                            .Add("JobTitle", CWTDT.Rows(countDT).Item("JobTitle").ToString())
                                            .Add("DateModification", DateTime.Now)
                                            .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                            .Add("ValueTypeChanged", "Delete")
                                        End With
                                        EffectRow = .ExecuteInsert()
                                    End With
                                End If
                            Next countInfo
                        End If
                    Next countDT
                End If

                If info.CWTContact.Count > CWTDT.Rows.Count Then
                    For countInfo = countDT To info.CWTContact.Count - 1
                        With Me.MySQLParser
                            .TableName = "Temp_tblCWTContact"
                            With .Columns
                                .Clear()
                                .Add("ClientID", info.ID, SqlBuilder.SQLParserDataType.spNum)
                                .Add("ContactID", countInfo + 1, SqlBuilder.SQLParserDataType.spNum)
                                .Add("UserID", info.CWTContact.Item(countInfo).UserName)
                                .Add("Title", info.CWTContact.Item(countInfo).Title)
                                .Add("FirstName", info.CWTContact.Item(countInfo).FirstName)
                                .Add("LastName", info.CWTContact.Item(countInfo).LastName)
                                .Add("LocalCode", info.CWTContact.Item(countInfo).PhoneCode)
                                .Add("LocalCodeMobile", info.CWTContact.Item(countInfo).MobileCode)
                                .Add("Phone", info.CWTContact.Item(countInfo).Phone)
                                .Add("Mobile", info.CWTContact.Item(countInfo).Mobile)
                                .Add("Email", info.CWTContact.Item(countInfo).Email)
                                .Add("JobTitle", info.CWTContact.Item(countInfo).JobTitle)
                                .Add("DateModification", DateTime.Now)
                                .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                .Add("ValueTypeChanged", "Insert")
                            End With
                            EffectRow = .ExecuteInsert()
                        End With
                    Next countInfo
                End If

            ElseIf info.CurrentWebMode = DataInfo.CompanyInfo.WebMode.ClientContact Then
                TMDT = ds.Tables("TM")
                If TMDT.Rows.Count > 0 Then
                    For countDT = 0 To TMDT.Rows.Count - 1
                        checkExist = CheckRecordExists(TMDT.Rows(countDT), info, "TM")
                        If checkExist = False Then

                            For countInfo = 0 To info.ClientContact.Count - 1
                                If TMDT.Rows(countDT).Item("ClientID").ToString() = info.ID And TMDT.Rows(countDT).Item("TMID").ToString() = countInfo + 1 Then
                                    With Me.MySQLParser
                                        .TableName = "Temp_tblTM"
                                        With .Columns
                                            .Clear()
                                            .Add("ClientID", TMDT.Rows(countDT).Item("ClientID").ToString(), SqlBuilder.SQLParserDataType.spNum)
                                            .Add("TMID", TMDT.Rows(countDT).Item("TMID").ToString(), SqlBuilder.SQLParserDataType.spNum)
                                            .Add("TMSequenceNo", TMDT.Rows(countDT).Item("TMSequenceNo").ToString(), SqlBuilder.SQLParserDataType.spNum)
                                            .Add("Title", TMDT.Rows(countDT).Item("Title").ToString())
                                            .Add("FirstName", TMDT.Rows(countDT).Item("FirstName").ToString())
                                            .Add("LastName", TMDT.Rows(countDT).Item("LastName").ToString())
                                            .Add("LocalCode", TMDT.Rows(countDT).Item("LocalCode").ToString())
                                            .Add("LocalCodeMobile", TMDT.Rows(countDT).Item("LocalCodeMobile").ToString())
                                            .Add("Phone", TMDT.Rows(countDT).Item("Phone").ToString())
                                            .Add("Mobile", TMDT.Rows(countDT).Item("Mobile").ToString())
                                            .Add("LocalCodeFax", TMDT.Rows(countDT).Item("LocalCodeFax").ToString())
                                            .Add("Fax", TMDT.Rows(countDT).Item("Fax").ToString())
                                            .Add("Email", TMDT.Rows(countDT).Item("Email").ToString())
                                            .Add("JobTitle", TMDT.Rows(countDT).Item("JobTitle").ToString())
                                            .Add("DateModification", DateTime.Now)
                                            .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                            .Add("ValueTypeChanged", "Update")
                                        End With
                                        EffectRow = .ExecuteInsert()
                                        Exit For
                                    End With
                                End If
                            Next countInfo
                            If countDT > info.ClientContact.Count Then
                                With Me.MySQLParser
                                    .TableName = "Temp_tblTM"
                                    With .Columns
                                        .Clear()
                                        .Add("ClientID", TMDT.Rows(countDT).Item("ClientID").ToString(), SqlBuilder.SQLParserDataType.spNum)
                                        .Add("TMID", TMDT.Rows(countDT).Item("TMID").ToString(), SqlBuilder.SQLParserDataType.spNum)
                                        .Add("TMSequenceNo", TMDT.Rows(countDT).Item("TMSequenceNo").ToString(), SqlBuilder.SQLParserDataType.spNum)
                                        .Add("Title", TMDT.Rows(countDT).Item("Title").ToString())
                                        .Add("FirstName", TMDT.Rows(countDT).Item("FirstName").ToString())
                                        .Add("LastName", TMDT.Rows(countDT).Item("LastName").ToString())
                                        .Add("LocalCode", TMDT.Rows(countDT).Item("LocalCode").ToString())
                                        .Add("LocalCodeMobile", TMDT.Rows(countDT).Item("LocalCodeMobile").ToString())
                                        .Add("Phone", TMDT.Rows(countDT).Item("Phone").ToString())
                                        .Add("Mobile", TMDT.Rows(countDT).Item("Mobile").ToString())
                                        .Add("LocalCodeFax", TMDT.Rows(countDT).Item("LocalCodeFax").ToString())
                                        .Add("Fax", TMDT.Rows(countDT).Item("Fax").ToString())
                                        .Add("Email", TMDT.Rows(countDT).Item("Email").ToString())
                                        .Add("JobTitle", TMDT.Rows(countDT).Item("JobTitle").ToString())
                                        .Add("DateModification", DateTime.Now)
                                        .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                        .Add("ValueTypeChanged", "Delete")
                                    End With
                                    EffectRow = .ExecuteInsert()
                                    Exit For
                                End With
                            End If

                        End If
                    Next countDT
                End If

                If info.ClientContact.Count > TMDT.Rows.Count Then
                    For countInfo = countDT To info.ClientContact.Count - 1
                        With Me.MySQLParser
                            .TableName = "Temp_tblTM"
                            With .Columns
                                .Clear()
                                .Add("ClientID", info.ID, SqlBuilder.SQLParserDataType.spNum)
                                .Add("TMID", countInfo + 1, SqlBuilder.SQLParserDataType.spNum)
                                .Add("TMSequenceNo", countInfo + 1, SqlBuilder.SQLParserDataType.spNum)
                                .Add("Title", info.ClientContact.Item(countInfo).Title)
                                .Add("FirstName", info.ClientContact.Item(countInfo).FirstName)
                                .Add("LastName", info.ClientContact.Item(countInfo).LastName)
                                .Add("LocalCode", info.ClientContact.Item(countInfo).PhoneCode)
                                .Add("LocalCodeMobile", info.ClientContact.Item(countInfo).MobileCode)
                                .Add("Phone", info.ClientContact.Item(countInfo).Phone)
                                .Add("Mobile", info.ClientContact.Item(countInfo).Mobile)
                                .Add("LocalCodeFax", info.ClientContact.Item(countInfo).FaxCode)
                                .Add("Fax", info.ClientContact.Item(countInfo).Fax)
                                .Add("Email", info.ClientContact.Item(countInfo).Email)
                                .Add("JobTitle", info.ClientContact.Item(countInfo).JobTitle)
                                .Add("DateModification", DateTime.Now)
                                .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                .Add("ValueTypeChanged", "Insert")
                            End With
                            EffectRow = .ExecuteInsert()
                        End With
                    Next countInfo
                End If

            End If

        End Sub

        Private Function MatchClientMasterDetails(ByRef info As DataInfo.CompanyInfo, ByVal ClientMasterDT As DataTable) As Boolean
            Dim countDT As Integer
            Dim checkMatch As Boolean
            For countDT = 0 To ClientMasterDT.Rows.Count - 1
                If info.Name = ClientMasterDT.Rows(countDT).Item("GroupName").ToString() AndAlso info.EntityName = ClientMasterDT.Rows(countDT).Item("Name").ToString() AndAlso info.AffName = ClientMasterDT.Rows(countDT).Item("SubUnit").ToString() AndAlso info.BizPhoneCode = ClientMasterDT.Rows(countDT).Item("BizPhoneLocalCode").ToString() AndAlso info.BizPhoneNo = ClientMasterDT.Rows(countDT).Item("BizPhoneNumber").ToString() AndAlso info.FaxPhoneCode = ClientMasterDT.Rows(countDT).Item("BizFaxLocalCode").ToString() AndAlso info.FaxPhoneNo = ClientMasterDT.Rows(countDT).Item("BizFaxNumber").ToString() AndAlso info.Email = ClientMasterDT.Rows(countDT).Item("Email").ToString() AndAlso info.Address1 = ClientMasterDT.Rows(countDT).Item("Address1").ToString() AndAlso info.Address2 = ClientMasterDT.Rows(countDT).Item("Address2").ToString() AndAlso info.Address3 = ClientMasterDT.Rows(countDT).Item("Address3").ToString() AndAlso info.Address4 = ClientMasterDT.Rows(countDT).Item("Address4").ToString() AndAlso info.Address5 = ClientMasterDT.Rows(countDT).Item("Address5").ToString() AndAlso info.TeamEmail = ClientMasterDT.Rows(countDT).Item("TeamEmail").ToString() AndAlso info.VendorReplyEmail = ClientMasterDT.Rows(countDT).Item("VendorReplyEmail").ToString() AndAlso info.ActivateDate = ClientMasterDT.Rows(countDT).Item("ActivateDate").ToString() AndAlso info.Status = ClientMasterDT.Rows(countDT).Item("Status").ToString() Then
                    checkMatch = True
                    Exit For
                End If
            Next
            Return checkMatch
        End Function

        Public Function CheckRecordExists(ByVal Row As DataRow, ByRef info As DataInfo.CompanyInfo, ByVal Type As String) As Boolean
            Dim check As Boolean
            Dim countInfo As Integer
            If Type = "CWT" Then
                For countInfo = 0 To info.CWTContact.Count - 1
                    If Row.Item("UserID").ToString() = info.CWTContact(countInfo).UserName AndAlso Row.Item("Title").ToString() = info.CWTContact(countInfo).Title AndAlso Row.Item("FirstName").ToString() = info.CWTContact(countInfo).FirstName AndAlso Row.Item("LastName").ToString() = info.CWTContact(countInfo).LastName AndAlso Row.Item("LocalCode").ToString() = info.CWTContact(countInfo).PhoneCode AndAlso Row.Item("LocalCodeMobile").ToString() = info.CWTContact(countInfo).MobileCode AndAlso Row.Item("Phone").ToString() = info.CWTContact(countInfo).Phone AndAlso Row.Item("Mobile").ToString() = info.CWTContact(countInfo).Mobile AndAlso Row.Item("Email").ToString() = info.CWTContact(countInfo).Email AndAlso Row.Item("JobTitle").ToString() = info.CWTContact(countInfo).JobTitle Then
                        check = True
                        Exit For
                    End If
                Next
            Else
                For countInfo = 0 To info.ClientContact.Count - 1
                    If Row.Item("Title").ToString() = info.ClientContact(countInfo).Title AndAlso Row.Item("FirstName").ToString() = info.ClientContact(countInfo).FirstName AndAlso Row.Item("LastName").ToString() = info.ClientContact(countInfo).LastName AndAlso Row.Item("LocalCode").ToString() = info.ClientContact(countInfo).PhoneCode AndAlso Row.Item("LocalCodeMobile").ToString() = info.ClientContact(countInfo).MobileCode AndAlso Row.Item("Phone").ToString() = info.ClientContact(countInfo).Phone AndAlso Row.Item("Mobile").ToString() = info.ClientContact(countInfo).Mobile AndAlso Row.Item("Email").ToString() = info.ClientContact(countInfo).Email AndAlso Row.Item("JobTitle").ToString() = info.ClientContact(countInfo).JobTitle AndAlso Row.Item("Fax").ToString() = info.ClientContact(countInfo).Fax AndAlso Row.Item("LocalCodeFax").ToString() = info.ClientContact(countInfo).FaxCode Then
                        check = True
                        Exit For
                    End If
                Next
            End If
        End Function

        Public Function GetBillingData(ByVal ClientID As String) As DataSet
            Dim ds As New DataSet()
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblClientMaster"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
                dt.TableName = "Company"
                ds.Tables.Add(dt)
                '// Email
                .TableName = "tblBillingEmail"
                'With .Columns
                '    .IncludeKey = False
                '    .Clear()
                '    .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spText, True)
                '    .Add("*")
                'End With
                dt = .ExecuteDataTable()
                dt.TableName = "Email"
                ds.Tables.Add(dt)
                '// Billing
                .TableName = "tblBillingAddress"
                'With .Columns
                '    .IncludeKey = False
                '    .Clear()
                '    .Add("ClientNumber", "(Select ClientNumber from tblClientMaster Where ClientID='" + ClientID + "')", SqlBuilder.SQLParserDataType.spFunction, True)
                '    .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spText, True)
                '    .Add("*")
                'End With
                dt = .ExecuteDataTable()
                dt.TableName = "Billing"
                ds.Tables.Add(dt)
                '// Delivery
                .TableName = "tblDelivery"
                'With .Columns
                '    .IncludeKey = False
                '    .Clear()
                '    .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spText, True)
                '    .Add("*")
                'End With
                dt = .ExecuteDataTable()
                dt.TableName = "Delivery"
                ds.Tables.Add(dt)
            End With
            Return ds
        End Function

        Public Function GetBillingDataFromTemp(ByVal ClientID As String) As DataSet
            Dim ds As New DataSet()
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblClientMaster"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
                dt.TableName = "Company"
                ds.Tables.Add(dt)
                '// Email
                .TableName = "tblBillingEmail "
                'With .Columns
                '    .IncludeKey = False
                '    .Clear()
                '    .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spText, True)
                '    .Add("*")
                'End With
                dt = .ExecuteDataTable()
                dt.TableName = "Email"
                ds.Tables.Add(dt)
                '// Billing
                .TableName = "tblBillingAddress"
                'With .Columns
                '    .IncludeKey = False
                '    .Clear()
                '    .Add("ClientNumber", "(Select ClientNumber from tblClientMaster Where ClientID='" + ClientID + "')", SqlBuilder.SQLParserDataType.spFunction, True)
                '    .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spText, True)
                '    .Add("*")
                'End With
                dt = .ExecuteDataTable()
                dt.TableName = "Billing"
                ds.Tables.Add(dt)
                '// Delivery
                .TableName = "tblDelivery"
                'With .Columns
                '    .IncludeKey = False
                '    .Clear()
                '    .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spText, True)
                '    .Add("*")
                'End With
                dt = .ExecuteDataTable()
                dt.TableName = "Delivery"
                ds.Tables.Add(dt)
            End With
            Return ds
        End Function

        Public Function UpdateBillingAddress(ByVal info As DataInfo.BillingAddressDataInfo) As Integer
            Dim EffectRow As Integer = 1
            Try
                With Me.MySQLParser
                    .OpenConnection()
                    .BeginTran()
                    .TableName = "tblClientMaster"
                    With .Columns
                        .Clear()
                        .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        .Add("BillingMode", info.BillMode, SqlBuilder.SQLParserDataType.spNum)
                        Select Case info.BillMode
                            Case DataInfo.BillingAddressDataInfo.BillingMode.eInvoice
                                .Add("InvEmailToTraveler", info.EmailReferToProfile, SqlBuilder.SQLParserDataType.spBoolean)
                        End Select
                        .Add("InvDelAddrToTraveler", info.DelAddrReferToProfile, SqlBuilder.SQLParserDataType.spBoolean)
                        If Not info.DelAddrReferToProfile Then
                            .Add("SameasBilling", info.SameAsBillAddress, SqlBuilder.SQLParserDataType.spBoolean)
                        End If
                    End With
                    .ExecuteUpdate()
                    '//
                    .TableName = "tblBillingEmail"
                    With .Columns
                        .Clear()
                        .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    End With
                    .ExecuteDelete()
                    '//
                    .TableName = "tblBillingAddress"
                    .ExecuteDelete()
                    '//
                    .TableName = "tblDelivery"
                    .ExecuteDelete()
                    '// CWT Contacts
                    .TableName = "tblBillingEmail"
                    For i As Integer = 0 To info.EmailList.Count - 1
                        With .Columns
                            .Clear()
                            .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum)
                            .Add("BillingID", i + 1, SqlBuilder.SQLParserDataType.spNum)
                            .Add("BillingEmail", info.EmailList.Item(i).Email)
                            '.Add("Preferred", info.EmailList.Item(i).Prefered, SqlBuilder.SQLParserDataType.spBoolean)
                        End With
                        EffectRow = .ExecuteInsert()
                        If EffectRow <= 0 Then
                            Exit For
                        End If
                    Next
                    If EffectRow > 0 Then
                        '// Client Contacts
                        .TableName = "tblBillingAddress"
                        For i As Integer = 0 To info.BillingAddrList.Count - 1
                            With .Columns
                                .Clear()
                                .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum)
                                .Add("BillingID", i + 1, SqlBuilder.SQLParserDataType.spNum)
                                .Add("Title", info.BillingAddrList.Item(i).Address1)
                                .Add("BillingAddr1", info.BillingAddrList.Item(i).Address2)
                                .Add("BillingAddr2", info.BillingAddrList.Item(i).Address3)
                                .Add("BillingAddr3", info.BillingAddrList.Item(i).Address4)
                                .Add("BillingAddr4", info.BillingAddrList.Item(i).Address5)
                                .Add("BillingAddr5", info.BillingAddrList.Item(i).Address6)
                                .Add("ClientNumber", info.BillingAddrList.Item(i).ClientNumber)
                                '.Add("Preferred", info.BillingAddrList.Item(i).Prefered, SqlBuilder.SQLParserDataType.spBoolean)
                            End With
                            EffectRow = .ExecuteInsert()
                            If EffectRow <= 0 Then
                                Exit For
                            End If
                        Next
                    End If
                    If Not info.SameAsBillAddress AndAlso Not info.DelAddrReferToProfile AndAlso EffectRow > 0 Then
                        '// Client Contacts
                        .TableName = "tblDelivery"
                        For i As Integer = 0 To info.DelAddrList.Count - 1
                            With .Columns
                                .Clear()
                                .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum)
                                .Add("DeliveryID", i + 1, SqlBuilder.SQLParserDataType.spNum)
                                .Add("DeliveryAddr1", info.DelAddrList.Item(i).Address1)
                                .Add("DeliveryAddr2", info.DelAddrList.Item(i).Address2)
                                .Add("DeliveryAddr3", info.DelAddrList.Item(i).Address3)
                                .Add("DeliveryAddr4", info.DelAddrList.Item(i).Address4)
                                .Add("DeliveryAddr5", info.DelAddrList.Item(i).Address5)
                                .Add("DeliveryAddr6", info.DelAddrList.Item(i).Address6)
                                .Add("ClientNumber", info.DelAddrList.Item(i).ClientNumber)
                                '.Add("Preferred", info.DelAddrList.Item(i).Prefered, SqlBuilder.SQLParserDataType.spBoolean)
                            End With
                            EffectRow = .ExecuteInsert()
                            If EffectRow <= 0 Then
                                Exit For
                            End If
                        Next
                    End If
                End With
                If EffectRow > 0 Then
                    Me.MySQLParser.CommitTran()
                Else
                    Me.MySQLParser.RollbackTran()
                End If
            Catch ex As Exception
                EffectRow = -1
                Me.MySQLParser.RollbackTran()
            Finally
                Me.MySQLParser.CloseConnection()
            End Try
            Return EffectRow
        End Function

        Public Function InsertTempBillingRecords(ByVal Email As DataTable, ByVal Address As DataTable, ByVal Delivery As DataTable, ByVal Client As DataTable) As Integer
            Dim EffectRow As Integer
            Try
                With Me.MySQLParser
                    .TableName = "Temp_tblBillingEmail"
                    For i As Integer = 0 To Email.Rows.Count - 1
                        If Email.Rows(i).Item("Status") <> "Completed" And Email.Rows(i).Item("Status") <> "" Then
                            With .Columns
                                .Clear()
                                .Add("ClientID", Email.Rows(i).Item("ClientID").ToString(), SqlBuilder.SQLParserDataType.spNum)
                                .Add("BillingID", i + 1, SqlBuilder.SQLParserDataType.spNum)
                                .Add("BillingEmail", Email.Rows(i).Item("BillingEmail").ToString())
                                '.Add("BillingMode", Email.Rows(i).Item("BillingMode").ToString())
                                '.Add("ReferToTravelerProfile", Email.Rows(i).Item("ReferToTravelerProfile").ToString(), SqlBuilder.SQLParserDataType.spBoolean)
                                .Add("DateModification", DateTime.Now)
                                .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                .Add("ValueTypeChanged", Email.Rows(i).Item("Status").ToString())
                                '.Add("Preferred", info.EmailList.Item(i).Prefered, SqlBuilder.SQLParserDataType.spBoolean)
                            End With
                            EffectRow = .ExecuteInsert()
                            If EffectRow <= 0 Then
                                Exit For
                            End If
                        End If
                    Next
                    '// Client Contacts
                    .TableName = "Temp_tblBillingAddress"
                    For i As Integer = 0 To Address.Rows.Count - 1
                        If Address.Rows(i).Item("Status") <> "Completed" And Address.Rows(i).Item("Status") <> "" Then
                            With .Columns
                                .Clear()
                                .Add("ClientID", Address.Rows(i).Item("ClientID").ToString(), SqlBuilder.SQLParserDataType.spNum)
                                .Add("BillingID", i + 1, SqlBuilder.SQLParserDataType.spNum)
                                .Add("Title", Address.Rows(i).Item("Title").ToString())
                                '.Add("BillingMode", Address.Rows(i).Item("BillingMode").ToString())
                                .Add("BillingAddr1", Address.Rows(i).Item("BillingAddr1").ToString())
                                .Add("BillingAddr2", Address.Rows(i).Item("BillingAddr2").ToString())
                                .Add("BillingAddr3", Address.Rows(i).Item("BillingAddr3").ToString())
                                .Add("BillingAddr4", Address.Rows(i).Item("BillingAddr4").ToString())
                                .Add("BillingAddr5", Address.Rows(i).Item("BillingAddr5").ToString())
                                .Add("ClientNumber", Address.Rows(i).Item("ClientNumber").ToString())
                                .Add("DateModification", DateTime.Now)
                                .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                .Add("ValueTypeChanged", Address.Rows(i).Item("Status").ToString())
                                '.Add("Preferred", info.BillingAddrList.Item(i).Prefered, SqlBuilder.SQLParserDataType.spBoolean)
                            End With
                            EffectRow = .ExecuteInsert()
                            If EffectRow <= 0 Then
                                Exit For
                            End If
                        End If
                    Next

                    '// Client Contacts
                    .TableName = "Temp_tblDelivery"
                    For i As Integer = 0 To Delivery.Rows.Count - 1
                        If Delivery.Rows(i).Item("Status") <> "Completed" And Delivery.Rows(i).Item("Status") <> "" Then
                            With .Columns
                                .Clear()
                                .Add("ClientID", Delivery.Rows(i).Item("ClientID").ToString(), SqlBuilder.SQLParserDataType.spNum)
                                .Add("DeliveryID", i + 1, SqlBuilder.SQLParserDataType.spNum)
                                '.Add("BillingMode", Delivery.Rows(i).Item("BillingMode").ToString())
                                '.Add("ReferToTravelerProfile", Delivery.Rows(i).Item("ReferToTravelerProfile").ToString(), SqlBuilder.SQLParserDataType.spBoolean)
                                '.Add("SameAsBilling", Delivery.Rows(i).Item("SameAsBilling").ToString(), SqlBuilder.SQLParserDataType.spBoolean)
                                .Add("DeliveryAddr1", Delivery.Rows(i).Item("DeliveryAddr1").ToString())
                                .Add("DeliveryAddr2", Delivery.Rows(i).Item("DeliveryAddr2").ToString())
                                .Add("DeliveryAddr3", Delivery.Rows(i).Item("DeliveryAddr3").ToString())
                                .Add("DeliveryAddr4", Delivery.Rows(i).Item("DeliveryAddr4").ToString())
                                .Add("DeliveryAddr5", Delivery.Rows(i).Item("DeliveryAddr5").ToString())
                                .Add("DeliveryAddr6", Delivery.Rows(i).Item("DeliveryAddr6").ToString())
                                .Add("ClientNumber", Delivery.Rows(i).Item("ClientNumber").ToString())
                                .Add("DateModification", DateTime.Now)
                                .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                .Add("ValueTypeChanged", Delivery.Rows(i).Item("Status"))
                                '.Add("Preferred", info.DelAddrList.Item(i).Prefered, SqlBuilder.SQLParserDataType.spBoolean)
                            End With
                            EffectRow = .ExecuteInsert()
                            If EffectRow <= 0 Then
                                Exit For
                            End If
                        End If
                    Next


                    '//ClientBilling
                    .TableName = "Temp_tblClientBilling"
                    For i As Integer = 0 To Client.Rows.Count - 1
                        If Client.Rows(i).Item("StatusClient").ToString() <> "Completed" And Client.Rows(i).Item("StatusClient").ToString() <> "" Then
                            With .Columns
                                .Clear()
                                .Add("ClientID", Client.Rows(i).Item("ClientID").ToString(), SqlBuilder.SQLParserDataType.spNum)
                                .Add("InvEmailToTraveler", Client.Rows(i).Item("InvEmailToTraveler").ToString(), SqlBuilder.SQLParserDataType.spBoolean)
                                .Add("InvDelAddrToTraveler", Client.Rows(i).Item("InvDelAddrToTraveler").ToString(), SqlBuilder.SQLParserDataType.spBoolean)
                                .Add("BillingMode", Client.Rows(i).Item("BillingMode").ToString())
                                .Add("SameasBilling", Client.Rows(i).Item("SameasBilling").ToString(), SqlBuilder.SQLParserDataType.spBoolean)
                                .Add("DateModification", DateTime.Now)
                                .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                .Add("ValueTypeChanged", Client.Rows(i).Item("StatusClient"))
                            End With
                            EffectRow = .ExecuteInsert()
                            If EffectRow <= 0 Then
                                Exit For
                            End If
                        End If
                    Next

                End With
            Catch ex As Exception
                EffectRow = -1
                Me.MySQLParser.RollbackTran()
            End Try
        End Function

        Public Function GetConfigList() As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblConfiguration"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetConfigData(ByVal ClientID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblClientMaster"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function UpdateConfig(ByVal info As DataInfo.CompanyInfo) As Integer
            Dim EffectRow As Integer
            Try
                With Me.MySQLParser
                    .TableName = "tblClientMaster"
                    With .Columns
                        .Clear()
                        .Add("ClientID", info.ID, SqlBuilder.SQLParserDataType.spNum, True)
                        .Add("ConfigurationID", info.ConfigurationID)
                    End With
                    CallProcedure(info.ID, "Update", "sp_ClientConfig")
                    EffectRow = .ExecuteUpdate()
                End With
            Catch ex As Exception
                EffectRow = -1
            End Try
            Return EffectRow
        End Function

        Public Function GetGDSNumberList(ByVal ClientID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = Util.StandardDB("tblCSP_LineDefClientMapping") + " c INNER JOIN " + Util.StandardDB("tblCSP_LineDefMaster") + " m ON c.LineDefMasterID = m.LineDefMasterID "
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("c.ConfigInstanceKeyID", ServiceLogicLayer.DACSLL.CurrentKeyID, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("c.*")
                    .Add("m.GDSNumber")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function UpdateGDS(ByVal info As DataInfo.CompanyUpdateGDSInfo) As Integer
            Dim EffectRow As Integer
            Try
                With Me.MySQLParser
                    .OpenConnection()
                    .BeginTran()
                    .TableName = Util.StandardDB("tblCSP_ClientGDSSync")
                    With .Columns
                        .Clear()
                        .Add("UpdateGDSFlag", 1, SqlBuilder.SQLParserDataType.spNum, True)
                        .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        .Add("ConfigInstanceKeyID", info.ConfigInstanceKeyID, SqlBuilder.SQLParserDataType.spNum, True)
                    End With
                    .ExecuteDelete()


                    .TableName = Util.StandardDB("tblCSP_ClientGDSSync")
                    For i As Integer = 0 To info.GDSNumber.Count - 1
                        With .Columns
                            .Clear()
                            .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                            .Add("Requestor", info.Requestor)
                            .Add("ConfigInstanceKeyID", info.ConfigInstanceKeyID)
                            .Add("ClientID", info.ClientID)
                            .Add("RequestTime", "getdate()", SqlBuilder.SQLParserDataType.spFunction)
                            .Add("UpdateGDSFlag", info.UpdateGDSFlag)
                            .Add("UpdatedByIP", info.UpdateIP)
                            .Add("GDSNumber", info.GDSNumber(i))
                            .Add("LineDefMasterID", info.LineDefMasterID(i))
                            .Add("ProfilePCC", info.ProfilPCC(i))
                            .Add("ProfileName", info.ProfileName(i))
                        End With
                        EffectRow = .ExecuteInsert()
                        If EffectRow <= 0 Then
                            Exit For
                        End If
                    Next
                End With
                If EffectRow > 0 Then
                    Me.MySQLParser.CommitTran()
                Else
                    Me.MySQLParser.RollbackTran()
                End If
            Catch ex As Exception
                EffectRow = -1
                Me.MySQLParser.RollbackTran()
            Finally
                Me.MySQLParser.CloseConnection()
            End Try
            Return EffectRow
        End Function

        Public Function GetTempClientInfo(Optional ByVal ClientName As String = "", Optional ByVal dateFrom As String = "", Optional ByVal dateTo As String = "") As DataSet
            Dim count As Integer
            Dim dt As DataTable
            Dim dt2 As DataTable
            Dim CWTDT As DataTable
            Dim TempCWTDT As DataTable
            Dim CWTMaster As DataTable
            Dim TMDT As DataTable
            Dim TempTMDT As DataTable
            Dim TMMaster As DataTable = New DataTable()
            Dim ClientMaster As DataTable
            Dim TempTable As DataTable
            Dim foundRow() As DataRow
            'Dim countRow As Integer
            'Dim count2 As Integer
            Dim TempDeleteRecordDT As New DataTable

            Dim CWTString(0) As String
            Dim CWTContact(1) As String
            Dim TMString(1) As String
            'ArrString(0) = "Name"
            CWTString(0) = "ClientID"
            CWTContact(0) = "ClientID"
            CWTContact(1) = "ContactID"
            TMString(0) = "ClientID"
            TMString(1) = "TMID"
            Dim ds As New DataSet
            Dim dv As DataView

            With Me.MySQLParser
                .TableName = "tblClientMaster"
                With .Columns
                    .Clear()
                    If ClientName <> "" Then
                        .Add("Name", ClientName, SqlBuilder.SQLParserDataType.spText, True)
                    End If
                    .Add("ClientID,ActivateDate,GroupName,Name,SubUnit,BizPhoneLocalCode,BizPhoneNumber,BizFaxLocalCode,BizFaxNumber,Email,Address,Address1,Address2,Address3,Address4,Address5,TeamEmail,VendorReplyEmail,Status")
                End With
                dt2 = .ExecuteDataTable()

                If dt2.Rows.Count > 0 Then
                    .TableName = "Temp_tblClientInfo"
                    With .Columns
                        .Clear()
                        If ClientName <> "" Then
                            .Add("ClientID", dt2.Rows(0).Item("ClientID").ToString(), SqlBuilder.SQLParserDataType.spNum, True)
                        End If
                        If dateFrom = dateTo Then
                            If dateFrom <> "" And dateTo <> "" Then
                                'dateTo = dateTo + " 23:59:59:990"
                                .Add("DateModification", "convert(varchar,cast('" + dateFrom + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, ">")
                                .Add("DateModification", "convert(varchar,cast('" + dateTo + " 23:59:59:990" + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, "<")
                            End If
                        Else
                            If dateFrom <> "" Then
                                .Add("DateModification", dateFrom, SqlBuilder.SQLParserDataType.spDate, True, ">")
                            End If
                            If dateTo <> "" Then
                                'dateTo = dateTo + " 23:59:59:990"
                                .Add("DateModification", dateTo + " 23:59:59:990", SqlBuilder.SQLParserDataType.spText, True, "<=")
                            End If
                        End If
                        '.Add("ClientID,ActivateDate,GroupName,SubUnit,BizPhoneLocalCode,BizPhoneNumber,BizFaxLocalCode,BizFaxNumber,Email,Address1,Address2,Address3,Address4,Address5,DateModification,UserName,ValueTypeChanged")
                        .Add("*")
                    End With
                    dt = .ExecuteDataTable(.SQLSelect + " order by DateModification DESC")

                    TempDeleteRecordDT = dt.Clone()
                    TempTable = dt.DefaultView.ToTable(True, CWTString)
                    ClientMaster = dt.Clone()
                    For count = 0 To TempTable.Rows.Count - 1
                        foundRow = dt2.Select("ClientID='" + TempTable.Rows(count).Item("ClientID").ToString() + "'")
                        If foundRow.Length > 0 Then
                            ClientMaster.ImportRow(foundRow(0))

                            'For countRow = 0 To foundRow.Length - 1
                            '    For count2 = 0 To dt.Rows.Count - 1
                            '        If dt.Rows(count2).Item("ClientID").ToString() = foundRow(countRow).Item("ClientID") Then

                            '            'If dt.Rows(count2).Item("ValueTypeChanged").ToString() <> "Insert" Then
                            '            'If dt.Rows(count2).Item("ActivateDate").ToString() <> foundRow(countRow).Item("ActivateDate").ToString() Or dt.Rows(count2).Item("GroupName").ToString() <> foundRow(countRow).Item("GroupName").ToString() Or dt.Rows(count2).Item("SubUnit").ToString() <> foundRow(countRow).Item("SubUnit").ToString() Or dt.Rows(count2).Item("BizPhoneLocalCode").ToString() <> foundRow(countRow).Item("BizPhoneLocalCode").ToString() Or dt.Rows(count2).Item("BizPhoneNumber").ToString() <> foundRow(countRow).Item("BizPhoneNumber").ToString() Or dt.Rows(count2).Item("BizFaxLocalCode").ToString() <> foundRow(countRow).Item("BizFaxLocalCode").ToString() Or dt.Rows(count2).Item("BizFaxNumber").ToString() <> foundRow(countRow).Item("BizFaxNumber").ToString() Or dt.Rows(count2).Item("Email").ToString() <> foundRow(countRow).Item("Email").ToString() Or dt.Rows(count2).Item("Address1").ToString() <> foundRow(countRow).Item("Address1").ToString() Or dt.Rows(count2).Item("Address2").ToString() <> foundRow(countRow).Item("Address2").ToString() Or dt.Rows(count2).Item("Address3").ToString() <> foundRow(countRow).Item("Address3").ToString() Or dt.Rows(count2).Item("Address4").ToString() <> foundRow(countRow).Item("Address4").ToString() Or dt.Rows(count2).Item("Address5").ToString() <> foundRow(countRow).Item("Address5").ToString() Then
                            '            If CheckTempClientMasterExist(TempDeleteRecordDT, foundRow(countRow), dt.Rows(count2)) = False Then
                            '                TempDeleteRecordDT.ImportRow(dt.Rows(count2))
                            '            End If
                            '            'End If
                            '            'End If
                            '        End If
                            '    Next
                            'Next

                        End If
                    Next


                    ClientMaster.AcceptChanges()
                    ClientMaster.Merge(dt)
                    ClientMaster.TableName = "ClientMaster"
                    ds.Tables.Add(ClientMaster)
                End If
               


                'CWT Contact
                If dt2.Rows.Count > 0 Then
                    .TableName = "Temp_tblCWTContact"
                    With .Columns
                        .Clear()
                        If ClientName <> "" Then
                            .Add("ClientID", dt2.Rows(0).Item("ClientID").ToString(), SqlBuilder.SQLParserDataType.spNum, True)
                        End If
                        If dateFrom = dateTo Then
                            If dateFrom <> "" And dateTo <> "" Then
                                'dateTo = dateTo + " 23:59:59:990"
                                .Add("DateModification", "convert(varchar,cast('" + dateFrom + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, ">")
                                .Add("DateModification", "convert(varchar,cast('" + dateTo + " 23:59:59:990" + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, "<")
                            End If
                        Else
                            If dateFrom <> "" Then
                                .Add("DateModification", dateFrom, SqlBuilder.SQLParserDataType.spDate, True, ">")
                            End If
                            If dateTo <> "" Then
                                'dateTo = dateTo + " 23:59:59:990"
                                .Add("DateModification", dateTo + " 23:59:59:990", SqlBuilder.SQLParserDataType.spText, True, "<=")
                            End If
                        End If
                        .Add("ClientID,ContactID,UserID,FirstName,LastName,Title,JobTitle,LocalCode,Phone,LocalCodeMobile,Mobile,Email,DateModification,UserName,ValueTypeChanged")
                    End With
                    TempCWTDT = .ExecuteDataTable(.SQLSelect + " order by DateModification Desc")

                    .TableName = "tblCWTContact"
                    With .Columns
                        .Clear()
                        If ClientName <> "" Then
                            .Add("ClientID", dt2.Rows(0).Item("ClientID").ToString(), SqlBuilder.SQLParserDataType.spNum, True)
                        End If
                        .Add("ClientID,ContactID,UserID,FirstName,LastName,Title,JobTitle,LocalCode,Phone,LocalCodeMobile,Mobile,Email")
                    End With
                    CWTDT = .ExecuteDataTable()

                    TempTable = TempCWTDT.DefaultView.ToTable(True, CWTContact)
                    CWTMaster = TempCWTDT.Clone()
                    For count = 0 To TempTable.Rows.Count - 1
                        foundRow = CWTDT.Select("ClientID='" + TempTable.Rows(count).Item("ClientID").ToString() + "' and ContactID='" + TempTable.Rows(count).Item("ContactID").ToString() + "'")
                        If foundRow.Length > 0 Then
                            CWTMaster.ImportRow(foundRow(0))
                        End If
                    Next
                    CWTMaster.AcceptChanges()
                    CWTMaster.Merge(TempCWTDT)
                    CWTMaster.TableName = "CWTContact"
                    ds.Tables.Add(CWTMaster)


                    'TM
                    .TableName = "Temp_tblTM"
                    With .Columns
                        .Clear()
                        If ClientName <> "" Then
                            .Add("ClientID", dt2.Rows(0).Item("ClientID").ToString(), SqlBuilder.SQLParserDataType.spNum, True)
                        End If
                        If dateFrom = dateTo Then
                            If dateFrom <> "" And dateTo <> "" Then
                                'dateTo = dateTo + " 23:59:59:990"
                                .Add("DateModification", "convert(varchar,cast('" + dateFrom + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, ">")
                                .Add("DateModification", "convert(varchar,cast('" + dateTo + " 23:59:59:990" + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, "<")
                            End If
                        Else
                            If dateFrom <> "" Then
                                .Add("DateModification", dateFrom, SqlBuilder.SQLParserDataType.spDate, True, ">")
                            End If
                            If dateTo <> "" Then
                                'dateTo = dateTo + " 23:59:59:990"
                                .Add("DateModification", dateTo + " 23:59:59:990", SqlBuilder.SQLParserDataType.spText, True, "<=")
                            End If
                        End If
                        .Add("*")
                    End With
                    TempTMDT = .ExecuteDataTable(.SQLSelect + " order by DateModification Desc")

                    .TableName = "tblTM"
                    With .Columns
                        .Clear()
                        If ClientName <> "" Then
                            .Add("ClientID", dt2.Rows(0).Item("ClientID").ToString(), SqlBuilder.SQLParserDataType.spNum, True)
                        End If
                        .Add("*")
                    End With
                    TMDT = .ExecuteDataTable()


                    TempTable = TempTMDT.DefaultView.ToTable(True, TMString)
                    TMMaster = TempTMDT.Clone()
                    For count = 0 To TempTable.Rows.Count - 1
                        foundRow = TMDT.Select("ClientID='" + TempTable.Rows(count).Item("ClientID").ToString() + "' and TMID='" + TempTable.Rows(count).Item("TMID").ToString() + "'")
                        If foundRow.Length > 0 Then
                            TMMaster.ImportRow(foundRow(0))
                        End If
                    Next
                    TMMaster.AcceptChanges()
                    TMMaster.Merge(TempTMDT)
                    TMMaster.TableName = "TM"
                    ds.Tables.Add(TMMaster)
                End If
            End With

            Return ds
        End Function

        Public Function GetTempBillingInfo(Optional ByVal ClientName As String = "", Optional ByVal dateFrom As String = "", Optional ByVal dateTo As String = "") As DataSet
            '// Address 
            Dim AddDT As DataTable
            Dim TempAddDT As DataTable
            Dim AddMasterDT As DataTable
            '// Email
            Dim EmailDT As DataTable
            Dim TempEmailDT As DataTable
            Dim EmailMasterDT As DataTable
            '//Delivery
            Dim DelDT As DataTable
            Dim TempDelDT As DataTable
            Dim DelMasterDT As DataTable

            '//Client
            Dim ClientDT As DataTable
            Dim TempClientDT As DataTable
            Dim ClientMasterDT As DataTable

            Dim TempTable As DataTable
            Dim ClientIDArr(1) As String
            Dim DeliveryArr(1) As String
            Dim ClientBillingArr(0) As String
            Dim ClientID As String = ""
            Dim count As Integer
            Dim count2 As Integer
            Dim ds As New DataSet
            Dim foundRow() As DataRow

            ClientBillingArr(0) = "ClientID"
            ClientIDArr(0) = "ClientID"
            ClientIDArr(1) = "BillingID"
            DeliveryArr(0) = "ClientID"
            DeliveryArr(1) = "DeliveryID"

            If ClientName <> "" Then
                ClientID = GetClientIDByName(ClientName)
            End If

            With Me.MySQLParser
                .TableName = "Temp_tblBillingAddress"
                With .Columns
                    .Clear()
                    If ClientName <> "" Then
                        If ClientID <> "" Then
                            .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        Else
                            .Add("ClientID", "-1", SqlBuilder.SQLParserDataType.spNum, True)
                        End If
                    End If

                    If dateFrom = dateTo Then
                        If dateFrom <> "" And dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:990"
                            .Add("DateModification", "convert(varchar,cast('" + dateFrom + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, ">")
                            .Add("DateModification", "convert(varchar,cast('" + dateTo + " 23:59:59:990" + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, "<")
                        End If
                    Else
                        If dateFrom <> "" Then
                            .Add("DateModification", dateFrom, SqlBuilder.SQLParserDataType.spDate, True, ">")
                        End If
                        If dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:990"
                            .Add("DateModification", dateTo + " 23:59:59:990", SqlBuilder.SQLParserDataType.spText, True, "<=")
                        End If
                    End If
                    .Add("BillingID,ClientID,Title,BillingAddr1,BillingAddr2,BillingAddr3,BillingAddr4,BillingAddr5,ClientNumber,DateModification,UserName,ValueTypeChanged")
                End With
                TempAddDT = .ExecuteDataTable(.SQLSelect + " order by DateModification Desc")

                .TableName = "tblBillingAddress"
                With .Columns
                    .Clear()
                    If ClientName <> "" Then
                        If ClientID <> "" Then
                            .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        Else
                            .Add("ClientID", "-1", SqlBuilder.SQLParserDataType.spNum, True)
                        End If
                    End If
                    .Add("BillingID,ClientID,Title,BillingAddr1,BillingAddr2,BillingAddr3,BillingAddr4,BillingAddr5,ClientNumber")
                End With
                AddDT = .ExecuteDataTable()

                TempTable = TempAddDT.DefaultView.ToTable(True, ClientIDArr)
                AddMasterDT = TempAddDT.Clone()
                For count = 0 To TempTable.Rows.Count - 1
                    foundRow = AddDT.Select("ClientID='" + TempTable.Rows(count).Item("ClientID").ToString() + "' and BillingID='" + TempTable.Rows(count).Item("BillingID").ToString() + "'")
                    If foundRow.Length > 0 Then
                        For count2 = 0 To foundRow.Length - 1
                            AddMasterDT.ImportRow(foundRow(count2))
                        Next count2
                    End If
                Next
                AddMasterDT.AcceptChanges()
                AddMasterDT.Merge(TempAddDT)
                AddMasterDT.TableName = "Address"
                ds.Tables.Add(AddMasterDT)

                'Email
                .TableName = "Temp_tblBillingEmail"
                With .Columns
                    .Clear()
                    If ClientName <> "" Then
                        If ClientID <> "" Then
                            .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        Else
                            .Add("ClientID", "-1", SqlBuilder.SQLParserDataType.spNum, True)
                        End If
                    End If
                    If dateFrom = dateTo Then
                        If dateFrom <> "" And dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:990"
                            .Add("DateModification", "convert(varchar,cast('" + dateFrom + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, ">")
                            .Add("DateModification", "convert(varchar,cast('" + dateTo + " 23:59:59:990" + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, "<")
                        End If
                    Else
                        If dateFrom <> "" Then
                            .Add("DateModification", dateFrom, SqlBuilder.SQLParserDataType.spDate, True, ">")
                        End If
                        If dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:990"
                            .Add("DateModification", dateTo + " 23:59:59:990", SqlBuilder.SQLParserDataType.spText, True, "<=")
                        End If
                    End If
                    .Add("*")
                End With
                TempEmailDT = .ExecuteDataTable(.SQLSelect + " order by DateModification Desc")

                .TableName = "tblBillingEmail"
                With .Columns
                    .Clear()
                    If ClientName <> "" Then
                        If ClientID <> "" Then
                            .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        Else
                            .Add("ClientID", "-1", SqlBuilder.SQLParserDataType.spNum, True)
                        End If
                    End If
                    .Add("*")
                End With
                EmailDT = .ExecuteDataTable()

                TempTable = TempEmailDT.DefaultView.ToTable(True, ClientIDArr)
                EmailMasterDT = TempEmailDT.Clone()
                For count = 0 To TempTable.Rows.Count - 1
                    foundRow = EmailDT.Select("ClientID='" + TempTable.Rows(count).Item("ClientID").ToString() + "' and BillingID='" + TempTable.Rows(count).Item("BillingID").ToString() + "'")
                    If foundRow.Length > 0 Then
                        For count2 = 0 To foundRow.Length - 1
                            EmailMasterDT.ImportRow(foundRow(count2))
                        Next count2
                    End If
                Next
                EmailMasterDT.AcceptChanges()
                EmailMasterDT.Merge(TempEmailDT)
                EmailMasterDT.TableName = "Email"
                ds.Tables.Add(EmailMasterDT)

                'Delivery 
                .TableName = "Temp_tblDelivery"
                With .Columns
                    .Clear()
                    If ClientName <> "" Then
                        If ClientID <> "" Then
                            .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        Else
                            .Add("ClientID", "-1", SqlBuilder.SQLParserDataType.spNum, True)
                        End If
                    End If
                    If dateFrom = dateTo Then
                        If dateFrom <> "" And dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:990"
                            .Add("DateModification", "convert(varchar,cast('" + dateFrom + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, ">")
                            .Add("DateModification", "convert(varchar,cast('" + dateTo + " 23:59:59:990" + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, "<")
                        End If
                    Else
                        If dateFrom <> "" Then
                            .Add("DateModification", dateFrom, SqlBuilder.SQLParserDataType.spDate, True, ">")
                        End If
                        If dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:990"
                            .Add("DateModification", dateTo + " 23:59:59:990", SqlBuilder.SQLParserDataType.spText, True, "<=")
                        End If
                    End If
                    .Add("*")
                End With
                TempDelDT = .ExecuteDataTable(.SQLSelect + " order by DateModification Desc")

                .TableName = "tblDelivery"
                With .Columns
                    .Clear()
                    If ClientName <> "" Then
                        If ClientID <> "" Then
                            .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        Else
                            .Add("ClientID", "-1", SqlBuilder.SQLParserDataType.spNum, True)
                        End If
                    End If
                    .Add("*")
                End With
                DelDT = .ExecuteDataTable()

                TempTable = TempDelDT.DefaultView.ToTable(True, DeliveryArr)
                DelMasterDT = TempDelDT.Clone()
                For count = 0 To TempTable.Rows.Count - 1
                    foundRow = DelDT.Select("ClientID='" + TempTable.Rows(count).Item("ClientID").ToString() + "' and DeliveryID='" + TempTable.Rows(count).Item("DeliveryID").ToString() + "'")
                    If foundRow.Length > 0 Then
                        For count2 = 0 To foundRow.Length - 1
                            DelMasterDT.ImportRow(foundRow(count2))
                        Next count2
                    End If
                Next
                DelMasterDT.AcceptChanges()
                DelMasterDT.Merge(TempDelDT)
                DelMasterDT.TableName = "Delivery"
                ds.Tables.Add(DelMasterDT)


                .TableName = "Temp_tblClientBilling"
                With .Columns
                    .Clear()
                    If ClientName <> "" Then
                        If ClientID <> "" Then
                            .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        Else
                            .Add("ClientID", "-1", SqlBuilder.SQLParserDataType.spNum, True)
                        End If
                    End If

                    If dateFrom = dateTo Then
                        If dateFrom <> "" And dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:990"
                            .Add("DateModification", "convert(varchar,cast('" + dateFrom + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, ">")
                            .Add("DateModification", "convert(varchar,cast('" + dateTo + " 23:59:59:990" + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, "<")
                        End If
                    Else
                        If dateFrom <> "" Then
                            .Add("DateModification", dateFrom, SqlBuilder.SQLParserDataType.spDate, True, ">")
                        End If
                        If dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:990"
                            .Add("DateModification", dateTo + " 23:59:59:990", SqlBuilder.SQLParserDataType.spText, True, "<=")
                        End If
                    End If
                    .Add("*")
                End With
                TempClientDT = .ExecuteDataTable(.SQLSelect + " order by DateModification Desc")

                .TableName = "tblClientMaster"
                With .Columns
                    .Clear()
                    If ClientName <> "" Then
                        .Add("Name", ClientName, SqlBuilder.SQLParserDataType.spText, True)
                    End If
                    .Add("ClientID,InvEmailToTraveler,InvDelAddrToTraveler,case BillingMode when '0' then 'eInvoice' when '1' then 'pInvoice' else 'noInvoice' End As BillingMode,SameasBilling")
                End With
                ClientDT = .ExecuteDataTable()

                TempTable = TempClientDT.DefaultView.ToTable(True, ClientBillingArr)
                ClientMasterDT = TempClientDT.Clone()
                For count = 0 To TempTable.Rows.Count - 1
                    foundRow = ClientDT.Select("ClientID='" + TempTable.Rows(count).Item("ClientID").ToString() + "'")
                    If foundRow.Length > 0 Then
                        For count2 = 0 To foundRow.Length - 1
                            ClientMasterDT.ImportRow(foundRow(count2))
                        Next count2
                    End If
                Next
                ClientMasterDT.AcceptChanges()
                ClientMasterDT.Merge(TempClientDT)
                ClientMasterDT.TableName = "Client"
                ds.Tables.Add(ClientMasterDT)


            End With
            Return ds
        End Function

        Public Function GetClientIDByName(ByVal ClientName As String) As String
            Dim retVal As String
            Dim retObj As Object
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblClientMaster"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("Name", ClientName, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("ClientID")
                End With
                retObj = .ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar, CommandType.Text)
                retVal = Util.DBNullToText(retObj)
            End With
            Return retVal
        End Function

        Public Function GetTempConfigInfo(Optional ByVal ClientName As String = "", Optional ByVal dateFrom As String = "", Optional ByVal dateTo As String = "") As DataSet
            '//Config DT 
            Dim PCCDT As DataTable
            Dim TempPCCDT As DataTable
            Dim PCCMasterDT As DataTable
            Dim AddPCCDT As DataTable

            Dim TempTable As DataTable
            Dim TempClientIDArr(0) As String
            Dim ClientIDArr(1) As String
            Dim count As Integer
            Dim count2 As Integer
            Dim ds As New DataSet
            Dim foundRow() As DataRow
            Dim ClientID As String = ""

            TempClientIDArr(0) = "ClientID"
            ClientIDArr(0) = "ClientID"
            ClientIDArr(1) = "ConfigurationDesc"


            If ClientName <> "" Then
                ClientID = GetClientIDByName(ClientName)
            End If

            With Me.MySQLParser
                .TableName = "Temp_tblClientPCCConfiguration cm inner join tblConfiguration c on cm.ConfigurationID=c.ConfigurationID"
                With .Columns
                    .Clear()
                    If ClientName <> "" Then
                        If ClientID <> "" Then
                            .Add("cm.ClientID", ClientID, SqlBuilder.SQLParserDataType.spText, True)
                        End If
                    End If
                    If dateFrom = dateTo Then
                        If dateFrom <> "" And dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:990"
                            .Add("cm.DateModification", "convert(varchar,cast('" + dateFrom + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, ">")
                            .Add("cm.DateModification", "convert(varchar,cast('" + dateTo + " 23:59:59:990" + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, "<")
                        End If
                    Else
                        If dateFrom <> "" Then
                            .Add("cm.DateModification", dateFrom, SqlBuilder.SQLParserDataType.spDate, True, ">")
                        End If
                        If dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:990"
                            .Add("cm.DateModification", dateTo + " 23:59:59:990", SqlBuilder.SQLParserDataType.spText, True, "<=")
                        End If
                    End If
                    .Add("cm.ClientID,c.ConfigurationDesc,cm.DateModification,cm.UserName,cm.ValueTypeChanged")
                End With
                TempPCCDT = .ExecuteDataTable(.SQLSelect + " order by DateModification Desc")

                .TableName = "tblClientMaster cm inner join tblConfiguration c on cm.ConfigurationID=c.ConfigurationID"
                With .Columns
                    .Clear()
                    If ClientName <> "" Then
                        .Add("Name", ClientName, SqlBuilder.SQLParserDataType.spText, True)
                    End If
                    .Add("cm.ClientID,c.ConfigurationDesc")
                End With
                PCCDT = .ExecuteDataTable()

                TempTable = TempPCCDT.DefaultView.ToTable(True, TempClientIDArr)
                PCCMasterDT = TempPCCDT.Clone()
                AddPCCDT = TempPCCDT.Clone()
                For count = 0 To TempTable.Rows.Count - 1
                    foundRow = PCCDT.Select("ClientID='" + TempTable.Rows(count).Item("ClientID").ToString() + "'")
                    If foundRow.Length > 0 Then
                        For count2 = 0 To foundRow.Length - 1
                            PCCMasterDT.ImportRow(foundRow(count2))
                        Next count2
                    End If
                Next
                ''//Fliter Configuration update records
                'TempTable = PCCDT.DefaultView.ToTable(True, ClientIDArr)
                'For count = 0 To TempTable.Rows.Count - 1
                '    foundRow = TempPCCDT.Select("ClientID='" + TempTable.Rows(count).Item("ClientID").ToString() + "' And ConfigurationDesc<>'" + TempTable.Rows(count).Item("ConfigurationDesc").ToString() + "'")
                '    If foundRow.Length > 0 Then
                '        For count2 = 0 To foundRow.Length - 1
                '            AddPCCDT.ImportRow(foundRow(count2))
                '        Next count2
                '    End If
                'Next


                PCCMasterDT.AcceptChanges()
                PCCMasterDT.Merge(TempPCCDT)
                PCCMasterDT.TableName = "PCC"
                ds.Tables.Add(PCCMasterDT)
            End With
            Return ds
        End Function

        Public Function CheckTempClientMasterExist(ByVal ClientDT As DataTable, ByVal ClientRow As DataRow, ByVal ClientDTRow As DataRow)
            Dim check As Boolean
            Dim count As Integer

            If ClientDT.Rows.Count > 0 Then
                For count = 0 To ClientDT.Rows.Count - 1
                    If ClientDT.Rows(count).Item("ClientID").ToString() = ClientRow.Item("ClientID").ToString() And ClientDT.Rows(count).Item("ActivateDate").ToString() = ClientRow.Item("ActivateDate").ToString() And ClientDT.Rows(count).Item("GroupName").ToString() = ClientRow.Item("GroupName").ToString() And ClientDT.Rows(count).Item("SubUnit").ToString() = ClientRow.Item("SubUnit").ToString() And ClientDT.Rows(count).Item("BizPhoneLocalCode").ToString() = ClientRow.Item("BizPhoneLocalCode").ToString() And ClientDT.Rows(count).Item("BizPhoneNumber").ToString() = ClientRow.Item("BizPhoneNumber").ToString() And ClientDT.Rows(count).Item("BizFaxLocalCode").ToString() = ClientRow.Item("BizFaxLocalCode").ToString() And ClientDT.Rows(count).Item("BizFaxNumber").ToString() = ClientRow.Item("BizFaxNumber").ToString() And ClientDT.Rows(count).Item("Email").ToString() = ClientRow.Item("Email").ToString() And ClientDT.Rows(count).Item("Address1").ToString() = ClientRow.Item("Address1").ToString() And ClientDT.Rows(count).Item("Address2").ToString() = ClientRow.Item("Address2").ToString() And ClientDT.Rows(count).Item("Address3").ToString() = ClientRow.Item("Address3").ToString() And ClientDT.Rows(count).Item("Address4").ToString() = ClientRow.Item("Address4").ToString() And ClientDT.Rows(count).Item("Address5").ToString() = ClientRow.Item("Address5").ToString() Then
                        check = True
                        Exit For
                    End If

                    If ClientDT.Rows(count).Item("ClientID").ToString() = ClientDTRow.Item("ClientID").ToString() And ClientDT.Rows(count).Item("ActivateDate").ToString() = ClientDTRow.Item("ActivateDate").ToString() And ClientDT.Rows(count).Item("GroupName").ToString() = ClientDTRow.Item("GroupName").ToString() And ClientDT.Rows(count).Item("SubUnit").ToString() = ClientDTRow.Item("SubUnit").ToString() And ClientDT.Rows(count).Item("BizPhoneLocalCode").ToString() = ClientDTRow.Item("BizPhoneLocalCode").ToString() And ClientDT.Rows(count).Item("BizPhoneNumber").ToString() = ClientDTRow.Item("BizPhoneNumber").ToString() And ClientDT.Rows(count).Item("BizFaxLocalCode").ToString() = ClientDTRow.Item("BizFaxLocalCode").ToString() And ClientDT.Rows(count).Item("BizFaxNumber").ToString() = ClientDTRow.Item("BizFaxNumber").ToString() And ClientDT.Rows(count).Item("Email").ToString() = ClientDTRow.Item("Email").ToString() And ClientDT.Rows(count).Item("Address1").ToString() = ClientDTRow.Item("Address1").ToString() And ClientDT.Rows(count).Item("Address2").ToString() = ClientDTRow.Item("Address2").ToString() And ClientDT.Rows(count).Item("Address3").ToString() = ClientDTRow.Item("Address3").ToString() And ClientDT.Rows(count).Item("Address4").ToString() = ClientDTRow.Item("Address4").ToString() And ClientDT.Rows(count).Item("Address5").ToString() = ClientDTRow.Item("Address5").ToString() Then
                        check = True
                        Exit For
                    End If
                Next count
            End If

            Return check
        End Function

    End Class
End Namespace

@


1.1.1.1
log
@no message
@
text
@@
