head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.22;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.22;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic
Imports System.Collections.Generic

Namespace DataAccessLayer
    Public Class SLADAL
        Inherits BaseDA

        Public Function GetSLATopicList() As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .TableName = CWTMasterDB.Util.StandardDB("tblSLATopic")
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("*")
                End With
                dt = .ExecuteDataTable(.SQLSelect() + " order by ServiceTopic")
            End With
            Return dt
        End Function

        Public Function GetSLAData(ByVal ClientID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .TableName = "tblServiceRequest"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("*")
                End With
                dt = .ExecuteDataTable(.SQLSelect() + " order by SvcReqID")
            End With
            Return dt
        End Function

        Public Function UpdateSLA(ByVal info As DataInfo.CompanySLAInfo) As Integer
            Dim EffectRow As Integer = 1
            Dim SLADT As DataTable
            Try
                SLADT = GetSLAData(info.ClientID)
                With Me.MySQLParser
                    .OpenConnection()
                    .BeginTran()
                    .TableName = "tblServiceRequest"
                    With .Columns
                        .Clear()
                        .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    End With
                    .ExecuteDelete()
                    '//
                    If EffectRow > 0 Then
                        '// 
                        .TableName = "tblServiceRequest"
                        For i As Integer = 0 To info.SLAList.Count - 1
                            With .Columns
                                .Clear()
                                .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum)
                                .Add("SvcReqID", i + 1, SqlBuilder.SQLParserDataType.spNum)
                                .Add("SLA", info.SLAList(i).SLA)
                                .Add("SLAType", info.SLAList(i).SLAType)
                                .Add("ServiceTopicID", info.SLAList(i).ServiceTopicID)
                                .Add("Remarks", info.SLAList(i).Remark)
                            End With
                            EffectRow = .ExecuteInsert()
                            If EffectRow <= 0 Then
                                Exit For
                            End If
                        Next
                    End If
                End With
                MatchSLARecord(SLADT, info)
                If EffectRow > 0 Then
                    Me.MySQLParser.CommitTran()
                Else
                    Me.MySQLParser.RollbackTran()
                End If
            Catch ex As Exception
                EffectRow = -1
                Me.MySQLParser.RollbackTran()
            Finally
                Me.MySQLParser.CloseConnection()
            End Try
            Return EffectRow
        End Function

        Private Sub MatchSLARecord(ByRef SLADT As DataTable, ByRef info As DataInfo.CompanySLAInfo)
            Dim countDT As Integer
            Dim countInfo As Integer
            Dim checkMatch As Boolean
            Dim effectRow As Integer

            If SLADT.Rows.Count > 0 Then
                For countDT = 0 To SLADT.Rows.Count - 1
                    checkMatch = CheckSLAExists(SLADT.Rows(countDT), info)
                    If checkMatch = False Then
                        For countInfo = 0 To info.SLAList.Count - 1
                            If SLADT.Rows(countDT).Item("SvcReqID") = countInfo + 1 AndAlso SLADT.Rows(countDT).Item("ClientID").ToString() = info.ClientID Then
                                With Me.MySQLParser
                                    .TableName = "Temp_tblServiceRequest"
                                    With .Columns
                                        .Clear()
                                        .Add("SvcReqID", SLADT.Rows(countDT).Item("SvcReqID").ToString(), SqlBuilder.SQLParserDataType.spNum)
                                        .Add("ClientID", SLADT.Rows(countDT).Item("ClientID").ToString(), SqlBuilder.SQLParserDataType.spNum)
                                        .Add("ServiceTopicID", SLADT.Rows(countDT).Item("ServiceTopicID").ToString())
                                        .Add("Remarks", SLADT.Rows(countDT).Item("Remarks").ToString())
                                        .Add("SLA", SLADT.Rows(countDT).Item("SLA").ToString())
                                        .Add("SLAType", SLADT.Rows(countDT).Item("SLAType").ToString())
                                        .Add("DateModification", DateTime.Now)
                                        .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                        .Add("ValueTypeChanged", "Update")
                                    End With
                                    effectRow = .ExecuteInsert()
                                    Exit For
                                End With
                            Else
                                If SLADT.Rows.Count > info.SLAList.Count Then
                                    With Me.MySQLParser
                                        .TableName = "Temp_tblServiceRequest"
                                        With .Columns
                                            .Clear()
                                            .Add("SvcReqID", SLADT.Rows(countDT).Item("SvcReqID").ToString(), SqlBuilder.SQLParserDataType.spNum)
                                            .Add("ClientID", SLADT.Rows(countDT).Item("ClientID").ToString(), SqlBuilder.SQLParserDataType.spNum)
                                            .Add("ServiceTopicID", SLADT.Rows(countDT).Item("ServiceTopicID").ToString())
                                            .Add("Remarks", SLADT.Rows(countDT).Item("Remarks").ToString())
                                            .Add("SLA", SLADT.Rows(countDT).Item("SLA").ToString())
                                            .Add("SLAType", SLADT.Rows(countDT).Item("SLAType").ToString())
                                            .Add("DateModification", DateTime.Now)
                                            .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                            .Add("ValueTypeChanged", "Delete")
                                        End With
                                        effectRow = .ExecuteInsert()
                                        Exit For
                                    End With
                                End If
                            End If
                        Next countInfo
                    End If
                Next countDT
            End If

            If info.SLAList.Count > countDT Then
                For countInfo = countDT To info.SLAList.Count - 1
                    With Me.MySQLParser
                        .TableName = "Temp_tblServiceRequest"
                        With .Columns
                            .Clear()
                            .Add("SvcReqID", countInfo + 1, SqlBuilder.SQLParserDataType.spNum)
                            .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum)
                            .Add("ServiceTopicID", info.SLAList(countInfo).ServiceTopicID)
                            .Add("Remarks", info.SLAList(countInfo).Remark)
                            .Add("SLA", info.SLAList(countInfo).SLA)
                            .Add("SLAType", info.SLAList(countInfo).SLAType)
                            .Add("DateModification", DateTime.Now)
                            .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                            .Add("ValueTypeChanged", "Insert")
                        End With
                        effectRow = .ExecuteInsert()
                    End With
                Next
            End If
        End Sub

        Private Function CheckSLAExists(ByVal row As DataRow, ByVal info As DataInfo.CompanySLAInfo)
            Dim countInfo As Integer
            Dim check As Boolean

            For countInfo = 0 To info.SLAList.Count - 1
                If row.Item("ClientID").ToString() = info.ClientID AndAlso row.Item("ServiceTopicID").ToString() = info.SLAList(countInfo).ServiceTopicID AndAlso row.Item("Remarks").ToString() = info.SLAList(countInfo).Remark AndAlso row.Item("SLA").ToString() = info.SLAList(countInfo).SLA AndAlso row.Item("SLAType").ToString() = info.SLAList(countInfo).SLAType Then
                    check = True
                    Exit For
                End If
            Next countInfo

            Return check
        End Function

        Public Function GetTempSLA(Optional ByVal ClientName As String = "", Optional ByVal dateFrom As String = "", Optional ByVal dateTo As String = "") As DataSet
            '//SLA
            Dim SLADT As DataTable
            Dim TempSLADT As DataTable
            Dim SLAMasterDT As DataTable

            Dim ClientID As String = ""
            Dim TempTable As DataTable
            Dim ClientIDArr(1) As String
            Dim count As Integer
            Dim count2 As Integer
            Dim ds As New DataSet
            Dim foundRow() As DataRow

            ClientIDArr(0) = "ClientID"
            ClientIDArr(1) = "ServiceTopic"
            '//Get ClientID 
            If ClientName <> "" Then
                ClientID = GetClientIDByName(ClientName)
            End If

            With Me.MySQLParser
                .TableName = "Temp_tblServiceRequest s inner join " + CWTMasterDB.Util.StandardDB("tblSLATopic") + " t on s.ServiceTopicID=t.ServiceTopicID"
                With .Columns
                    .Clear()
                    If ClientName <> "" Then
                        If ClientID <> "" Then
                            .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        Else
                            .Add("ClientID", "-1", SqlBuilder.SQLParserDataType.spNum, True)
                        End If
                    End If
                    If dateFrom = dateTo Then
                        If dateFrom <> "" And dateTo <> "" Then
                            dateTo = dateTo + " 23:59:59:990"
                            .Add("DateModification", "convert(varchar,cast('" + dateFrom + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, ">")
                            .Add("DateModification", "convert(varchar,cast('" + dateTo + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, "<")
                        End If
                    Else
                        If dateFrom <> "" Then
                            .Add("DateModification", dateFrom, SqlBuilder.SQLParserDataType.spDate, True, ">")
                        End If
                        If dateTo <> "" Then
                            dateTo = dateTo + " 23:59:59:990"
                            .Add("DateModification", dateTo, SqlBuilder.SQLParserDataType.spText, True, "<=")
                        End If
                    End If
                    .Add("s.SvcReqID, s.ClientID,t.ServiceTopic,s.Remarks,s.SLA,s.SLAType,s.DateModification,s.UserName,s.ValueTypeChanged")
                End With
                TempSLADT = .ExecuteDataTable(.SQLSelect + " order by DateModification Desc")

                .TableName = "tblServiceRequest s inner join " + CWTMasterDB.Util.StandardDB("tblSLATopic") + " t on s.ServiceTopicID=t.ServiceTopicID"
                With .Columns
                    .Clear()
                    If ClientName <> "" Then
                        If ClientID <> "" Then
                            .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        Else
                            .Add("ClientID", "-1", SqlBuilder.SQLParserDataType.spNum, True)
                        End If
                    End If
                    .Add("s.SvcReqID, s.ClientID,t.ServiceTopic,s.Remarks,s.SLA,s.SLAType")
                End With
                SLADT = .ExecuteDataTable()

                TempTable = TempSLADT.DefaultView.ToTable(True, ClientIDArr)
                SLAMasterDT = TempSLADT.Clone()
                For count = 0 To TempTable.Rows.Count - 1
                    foundRow = SLADT.Select("ClientID='" + TempTable.Rows(count).Item("ClientID").ToString() + "' and ServiceTopic='" + TempTable.Rows(count).Item("ServiceTopic").ToString() + "'")
                    If foundRow.Length > 0 Then
                        For count2 = 0 To foundRow.Length - 1
                            SLAMasterDT.ImportRow(foundRow(count2))
                        Next count2
                    End If
                Next
                SLAMasterDT.AcceptChanges()
                SLAMasterDT.Merge(TempSLADT)
                SLAMasterDT.TableName = "SLA"
                ds.Tables.Add(SLAMasterDT)
            End With
            Return ds
        End Function

        Public Function GetClientIDByName(ByVal ClientName As String) As String
            Dim retVal As String
            Dim retObj As Object
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblClientMaster"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("Name", ClientName, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("ClientID")
                End With
                retObj = .ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar, CommandType.Text)
                retVal = Util.DBNullToText(retObj)
            End With
            Return retVal
        End Function
    End Class
End Namespace
@


1.1.1.1
log
@no message
@
text
@@
