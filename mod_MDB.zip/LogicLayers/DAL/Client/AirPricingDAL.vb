head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.20;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.20;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic
Imports System.Collections.Generic

Namespace DataAccessLayer
    Public Class ComAirPricingDAL
        Inherits BaseDA

        Public Function GetComAirPricingData(ByVal ClientID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .TableName = "tblClientPricing"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetUsageVariables(ByVal AirPricingID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .TableName = "tblAirPricingVariables"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("AirPricingID", AirPricingID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetAirPriceVariables(ByVal TripType As String, ByVal PricingID As Integer) As DataTable
            Dim dt As DataTable
            Dim oSql As New StringBuilder()
            oSql.AppendLine("declare @@TripType varchar(1);")
            oSql.AppendLine("declare @@PriceID int;")
            oSql.AppendLine("declare @@Formula nvarchar(2000);")
            oSql.AppendLine("set @@TripType='" + TripType.ToString + "';")
            oSql.AppendLine("set @@PriceID=" + PricingID.ToString + ";")
            oSql.AppendLine("select @@Formula=ConcatFormula")
            oSql.AppendLine("from (")
            oSql.AppendLine("    select ")
            oSql.AppendLine("    (")
            oSql.AppendLine("    case @@TripType")
            oSql.AppendLine("    when 'I' then")
            oSql.AppendLine("        isnull(IntTotalAirCom,'')+")
            oSql.AppendLine("        isnull(IntTotalMarkUp,'')+")
            oSql.AppendLine("        isnull(IntTotalDiscount,'')+")
            'oSql.AppendLine("        isnull(IntTotalGST,'')+")
            oSql.AppendLine("        isnull(IntTotalFare,'')+")
            oSql.AppendLine("        isnull(IntTotalORCom,'')+")
            oSql.AppendLine("        isnull(IntTotalORCom2,'')+")
            oSql.AppendLine("        isnull(IntFuelChargeOption,'')+")
            oSql.AppendLine("        isnull(IntMFFee,'')+")
            oSql.AppendLine("        isnull(IntMFFeeTF,'')+")
            'oSql.AppendLine("        isnull(IntMFFeeNoneNetRemit,'')+")
            'oSql.AppendLine("        isnull(IntMgtFeeTotal,'')+")
            oSql.AppendLine("        isnull(IntTotalFareNett,'')+")
            oSql.AppendLine("        isnull(IntTotalCharge,'')")
            oSql.AppendLine("    when 'D' then")
            oSql.AppendLine("      case isnull(DomSameAsInt,0) when 0 then")
            oSql.AppendLine("           isnull(DomTotalAirCom,'')+")
            oSql.AppendLine("           isnull(DomTotalMarkUp,'')+")
            oSql.AppendLine("           isnull(DomTotalDiscount,'')+")
            'oSql.AppendLine("           isnull(DomTotalGST,'')+")
            oSql.AppendLine("           isnull(DomTotalFare,'')+")
            oSql.AppendLine("           isnull(DomTotalORCom,'')+")
            oSql.AppendLine("           isnull(DomTotalORCom2,'')+")
            oSql.AppendLine("           isnull(DomFuelChargeOption,'')+")
            oSql.AppendLine("           isnull(DomMFFee,'')+")
            oSql.AppendLine("           isnull(DomMFFeeTF,'')+")
            'oSql.AppendLine("           isnull(DomMFFeeNoneNetRemit,'')+")
            'oSql.AppendLine("           isnull(DomMgtFeeTotal,'')+")
            oSql.AppendLine("           isnull(DomTotalFareNett,'')+")
            oSql.AppendLine("           isnull(DomTotalCharge,'')")
            oSql.AppendLine("       else")
            oSql.AppendLine("           isnull(IntTotalAirCom,'')+")
            oSql.AppendLine("           isnull(IntTotalMarkUp,'')+")
            oSql.AppendLine("           isnull(IntTotalDiscount,'')+")
            'oSql.AppendLine("           isnull(IntTotalGST,'')+")
            oSql.AppendLine("           isnull(IntTotalFare,'')+")
            oSql.AppendLine("           isnull(IntTotalORCom,'')+")
            oSql.AppendLine("           isnull(IntTotalORCom2,'')+")
            oSql.AppendLine("           isnull(IntFuelChargeOption,'')+")
            oSql.AppendLine("           isnull(IntMFFee,'')+")
            oSql.AppendLine("            isnull(IntMFFeeTF,'')+")
            'oSql.AppendLine("           isnull(IntMFFeeNoneNetRemit,'')+")
            'oSql.AppendLine("           isnull(IntMgtFeeTotal,'')+")
            oSql.AppendLine("           isnull(IntTotalFareNett,'')+")
            oSql.AppendLine("           isnull(IntTotalCharge,'')")
            oSql.AppendLine("      end")
            oSql.AppendLine("    else")
            oSql.AppendLine("      case isnull(LCCSameAsInt,0) when 0 then")
            oSql.AppendLine("           isnull(LCCTotalAirCom,'')+")
            oSql.AppendLine("           isnull(LCCTotalMarkUp,'')+")
            oSql.AppendLine("           isnull(LCCTotalDiscount,'')+")
            ' oSql.AppendLine("           isnull(LCCTotalGST,'')+")
            oSql.AppendLine("           isnull(LCCTotalFare,'')+")
            oSql.AppendLine("           isnull(LCCTotalORCom,'')+")
            oSql.AppendLine("           isnull(LCCTotalORCom2,'')+")
            oSql.AppendLine("           isnull(LCCFuelChargeOption,'')+")
            oSql.AppendLine("           isnull(LCCMFFee,'')+")
            oSql.AppendLine("           isnull(LCCMFFeeTF,'')+")
            'oSql.AppendLine("           isnull(LCCMFFeeNoneNetRemit,'')+")
            'oSql.AppendLine("           isnull(LCCMgtFeeTotal,'')+")
            oSql.AppendLine("           isnull(LCCTotalFareNett,'')+")
            oSql.AppendLine("           isnull(LCCTotalCharge,'')")
            oSql.AppendLine("       else")
            oSql.AppendLine("           isnull(IntTotalAirCom,'')+")
            oSql.AppendLine("           isnull(IntTotalMarkUp,'')+")
            oSql.AppendLine("           isnull(IntTotalDiscount,'')+")
            'oSql.AppendLine("           isnull(IntTotalGST,'')+")
            oSql.AppendLine("           isnull(IntTotalFare,'')+")
            oSql.AppendLine("           isnull(IntTotalORCom,'')+")
            oSql.AppendLine("           isnull(IntTotalORCom2,'')+")
            oSql.AppendLine("           isnull(IntFuelChargeOption,'')+")
            oSql.AppendLine("           isnull(IntMFFee,'')+")
            oSql.AppendLine("           isnull(IntMFFeeTF,'')+")
            'oSql.AppendLine("           isnull(IntMFFeeNoneNetRemit,'')+")
            'oSql.AppendLine("           isnull(IntMgtFeeTotal,'')+")
            oSql.AppendLine("           isnull(IntTotalFareNett,'')+")
            oSql.AppendLine("           isnull(IntTotalCharge,'')")
            oSql.AppendLine("      end")
            oSql.AppendLine("end")
            oSql.AppendLine("    ) as ConcatFormula")
            oSql.AppendLine("from tblAirPricingFormula")
            oSql.AppendLine("    where AirPricingID=@@PriceID")
            oSql.AppendLine(") as FormulaQuery;")
            oSql.AppendLine("select *,'' as [Value],@@PriceID as PricingID,'' as ValueOption,0 as Override,@@TripType as TripType from  " + Util.StandardDB("tblAirVariables"))
            oSql.AppendLine("where")
            oSql.AppendLine("charindex('{'+FieldName+'}',@@Formula)>0")
            oSql.AppendLine("and DefineAtClientLevel=1 and BrowseEnabled=0;")
            dt = Me.MySQLParser.ExecuteDataTable(oSql.ToString)
            Return dt
        End Function

        Public Function GetClientMasterAirPrice(ByVal ClientID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .TableName = "tblClientMasterPricing"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetClientAirPriceVariables(ByVal TripType As String, ByVal ClientID As String) As DataTable
            Dim dt As DataTable
            Dim oSql As New StringBuilder()
            oSql.AppendLine("declare @@TripType varchar(1);")
            oSql.AppendLine("declare @@PriceID int;")
            oSql.AppendLine("declare @@Formula nvarchar(2000);")
            oSql.AppendLine("declare @@ClientID int;")
            oSql.AppendLine("declare @@CMPID int;")
            oSql.AppendLine("set @@TripType='" + TripType + "';")
            oSql.AppendLine("set @@ClientID=" + ClientID + ";")
            oSql.AppendLine("select @@CMPID=CMPID,@@PriceID=PricingID from tblClientMasterPricing where ClientID=@@ClientID;")
            oSql.AppendLine("select @@Formula=ConcatFormula")
            oSql.AppendLine("from (")
            oSql.AppendLine("    select ")
            oSql.AppendLine("    (")
            oSql.AppendLine("    case @@TripType")
            oSql.AppendLine("    when 'I' then")
            oSql.AppendLine("        isnull(IntTotalAirCom,'')+")
            oSql.AppendLine("        isnull(IntTotalMarkUp,'')+")
            oSql.AppendLine("        isnull(IntTotalDiscount,'')+")
            'oSql.AppendLine("        isnull(IntTotalGST,'')+")
            oSql.AppendLine("        isnull(IntTotalFare,'')+")
            oSql.AppendLine("        isnull(IntTotalORCom,'')+")
            oSql.AppendLine("        isnull(IntTotalORCom2,'')+")
            oSql.AppendLine("        isnull(IntFuelChargeOption,'')+")
            oSql.AppendLine("        isnull(IntMFFee,'')+")
            oSql.AppendLine("        isnull(IntMFFeeTF,'')+")
            'oSql.AppendLine("        isnull(IntMFFeeNoneNetRemit,'')+")
            'oSql.AppendLine("        isnull(IntMgtFeeTotal,'')+")
            oSql.AppendLine("        isnull(IntTotalFareNett,'')+")
            oSql.AppendLine("        isnull(IntTotalCharge,'')")
            oSql.AppendLine("    when 'D' then")
            oSql.AppendLine("      case isnull(DomSameAsInt,0) when 0 then")
            oSql.AppendLine("           isnull(DomTotalAirCom,'')+")
            oSql.AppendLine("           isnull(DomTotalMarkUp,'')+")
            oSql.AppendLine("           isnull(DomTotalDiscount,'')+")
            'oSql.AppendLine("           isnull(DomTotalGST,'')+")
            oSql.AppendLine("           isnull(DomTotalFare,'')+")
            oSql.AppendLine("           isnull(DomTotalORCom,'')+")
            oSql.AppendLine("           isnull(DomTotalORCom2,'')+")
            oSql.AppendLine("           isnull(DomFuelChargeOption,'')+")
            oSql.AppendLine("           isnull(DomMFFee,'')+")
            oSql.AppendLine("           isnull(DomMFFeeTF,'')+")
            'oSql.AppendLine("           isnull(DomMFFeeNoneNetRemit,'')+")
            'oSql.AppendLine("           isnull(DomMgtFeeTotal,'')+")
            oSql.AppendLine("           isnull(DomTotalFareNett,'')+")
            oSql.AppendLine("           isnull(DomTotalCharge,'')")
            oSql.AppendLine("       else")
            oSql.AppendLine("           isnull(IntTotalAirCom,'')+")
            oSql.AppendLine("           isnull(IntTotalMarkUp,'')+")
            oSql.AppendLine("           isnull(IntTotalDiscount,'')+")
            'oSql.AppendLine("           isnull(IntTotalGST,'')+")
            oSql.AppendLine("           isnull(IntTotalFare,'')+")
            oSql.AppendLine("           isnull(IntTotalORCom,'')+")
            oSql.AppendLine("           isnull(IntTotalORCom2,'')+")
            oSql.AppendLine("           isnull(IntFuelChargeOption,'')+")
            oSql.AppendLine("           isnull(IntMFFee,'')+")
            oSql.AppendLine("           isnull(IntMFFeeTF,'')+")
            'oSql.AppendLine("           isnull(IntMFFeeNoneNetRemit,'')+")
            'oSql.AppendLine("           isnull(IntMgtFeeTotal,'')+")
            oSql.AppendLine("           isnull(IntTotalFareNett,'')+")
            oSql.AppendLine("           isnull(IntTotalCharge,'')")
            oSql.AppendLine("      end")
            oSql.AppendLine("    else")
            oSql.AppendLine("      case isnull(LCCSameAsInt,0) when 0 then")
            oSql.AppendLine("           isnull(LCCTotalAirCom,'')+")
            oSql.AppendLine("           isnull(LCCTotalMarkUp,'')+")
            oSql.AppendLine("           isnull(LCCTotalDiscount,'')+")
            'oSql.AppendLine("           isnull(LCCTotalGST,'')+")
            oSql.AppendLine("           isnull(LCCTotalFare,'')+")
            oSql.AppendLine("           isnull(LCCTotalORCom,'')+")
            oSql.AppendLine("           isnull(LCCTotalORCom2,'')+")
            oSql.AppendLine("           isnull(LCCFuelChargeOption,'')+")
            oSql.AppendLine("           isnull(LCCMFFee,'')+")
            oSql.AppendLine("           isnull(LCCMFFeeTF,'')+")
            'oSql.AppendLine("           isnull(LCCMFFeeNoneNetRemit,'')+")
            'oSql.AppendLine("           isnull(LCCMgtFeeTotal,'')+")
            oSql.AppendLine("           isnull(LCCTotalFareNett,'')+")
            oSql.AppendLine("           isnull(LCCTotalCharge,'')")
            oSql.AppendLine("       else")
            oSql.AppendLine("           isnull(IntTotalAirCom,'')+")
            oSql.AppendLine("           isnull(IntTotalMarkUp,'')+")
            oSql.AppendLine("           isnull(IntTotalDiscount,'')+")
            'oSql.AppendLine("           isnull(IntTotalGST,'')+")
            oSql.AppendLine("           isnull(IntTotalFare,'')+")
            oSql.AppendLine("           isnull(IntTotalORCom,'')+")
            oSql.AppendLine("           isnull(IntTotalORCom2,'')+")
            oSql.AppendLine("           isnull(IntFuelChargeOption,'')+")
            oSql.AppendLine("           isnull(IntMFFee,'')+")
            oSql.AppendLine("           isnull(IntMFFeeTF,'')+")
            'oSql.AppendLine("           isnull(IntMFFeeNoneNetRemit,'')+")
            'oSql.AppendLine("           isnull(IntMgtFeeTotal,'')+")
            oSql.AppendLine("           isnull(IntTotalFareNett,'')+")
            oSql.AppendLine("           isnull(IntTotalCharge,'')")
            oSql.AppendLine("      end")
            oSql.AppendLine("end")
            oSql.AppendLine("    ) as ConcatFormula")
            oSql.AppendLine("from tblAirPricingFormula")
            oSql.AppendLine("    where AirPricingID=@@PriceID")
            oSql.AppendLine(") as FormulaQuery;")
            oSql.AppendLine("select a.*,p.[Value],@@PriceID as PricingID,isnull(p.ValueOption,'') as ValueOption,p.Override,p.TripType from " + Util.StandardDB("tblAirVariables") + " a left join tblClientPricing p on a.FieldID=p.FieldID and p.TripType=@@TripType and p.CMPID=@@CMPID")
            oSql.AppendLine("where ")
            oSql.AppendLine("charindex('{'+FieldName+'}',@@Formula)>0")
            oSql.AppendLine("and DefineAtClientLevel=1 and BrowseEnabled=0;")
            dt = Me.MySQLParser.ExecuteDataTable(oSql.ToString)
            Return dt
        End Function

        Public Function GetFieldIDByProgramName(ByVal ProgramName As String) As String
            Dim retVal As String = ""
            Dim retObj As Object
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = Util.StandardDB("tblAirVariables")
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("ProgramName", ProgramName, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("FieldID")
                End With
                retObj = .ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar, CommandType.Text)
                retVal = Util.DBNullToText(retObj)
            End With
            Return retVal
        End Function

        Public Function GetCMPIDByClientID(ByVal ClientID) As String
            Dim retVal As String = ""
            Dim retObj As Object
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblClientMasterPricing"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("CMPID")
                End With
                retObj = .ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar, CommandType.Text)
                retVal = Util.DBNullToText(retObj)
            End With
            Return retVal
        End Function

        Public Function GetClientMasterPricing(ByVal ClientID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .TableName = "tblClientMasterPricing m inner join tblAirPricingFormula f on m.PricingID=f.AirPricingID"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("m.ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("m.*")
                    .Add("f.IntApplyFee")
                    .Add("f.IntApplyMarkUp")
                    .Add("(case f.DomSameAsInt when 1 then f.IntApplyFee else f.DomApplyFee end) as DomApplyFee")
                    .Add("(case f.DomSameAsInt when 1 then f.IntApplyMarkUp else f.DomApplyMarkUp end) as DomApplyMarkUp")
                    .Add("(case f.LCCSameAsInt when 1 then f.IntApplyFee else f.LccApplyFee end) as LCCApplyFee")
                    .Add("(case f.LCCSameAsInt when 1 then f.IntApplyMarkUp else f.LccApplyMarkUp end) as LCCApplyMarkUp")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetSettingPricing(ByVal AirPricingID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .TableName = "tblAirPricingFormula"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("AirPricingID", AirPricingID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("IntDDLFeeApply")
                    .Add("IntApplyMarkUp")
                    .Add("(case DomSameAsInt when 1 then IntDDLFeeApply else DomDDLFeeApply end) as DomDDLFeeApply")
                    .Add("(case DomSameAsInt when 1 then IntApplyMarkUp else DomApplyMarkUp end) as DomApplyMarkUp")
                    .Add("(case LCCSameAsInt when 1 then IntDDLFeeApply else LccDDLFeeApply end) as LCCDDLFeeApply")
                    .Add("(case LCCSameAsInt when 1 then IntApplyMarkUp else LccApplyMarkUp end) as LCCApplyMarkUp")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetClientFeeData(ByVal CMPID As String, ByVal TripType As String, ByVal FieldID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .TableName = "tblClientPricing"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("CMPID", CMPID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("TripType", TripType, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("FieldID", FieldID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Sub FliterClientAirPricing(ByVal info As DataInfo.ComAirPricingInfo)
            Dim dt As DataTable
            Dim count As Integer
            Dim boolChk As Boolean
            Dim Type1 As String
            Dim count2 As Integer
            Dim boolUpdate As Boolean
            Try
                With Me.MySQLParser
                    .TableName = "tblClientPricing"
                    With .Columns
                        .IncludeKey = False
                        .Clear()
                        .Add("CMPID", info.CMPID, SqlBuilder.SQLParserDataType.spText, True)
                        .Add("*")
                    End With
                    dt = .ExecuteDataTable()
                End With

                For count = 0 To dt.Rows.Count - 1
                    With info
                        boolChk = Me.FindMatchRecords(dt.Rows(count).Item("FieldID").ToString(), dt.Rows(count).Item("TripType").ToString(), dt)
                        If boolChk Then
                            Select Case dt.Rows(count).Item("TripType").ToString()
                                Case "D"  'Dom

                                    Select Case info.DomSetting.Fee.FeeType
                                        Case "0"
                                            Type1 = "P"
                                        Case "1"
                                            Type1 = "T"
                                        Case Else
                                            Type1 = "C"
                                    End Select

                                    For count2 = 0 To info.DomSetting.Variables.Count - 1
                                        If info.DomSetting.Variables(count2).FieldID = dt.Rows(count).Item("FieldID") Then
                                            If dt.Rows(count).Item("Value").ToString() <> .DomSetting.Variables(count2).FieldValue Or dt.Rows(count).Item("Override") <> .DomSetting.Variables(count2).Override Then
                                                Me.CallProcedure(dt.Rows(count).Item(0), dt.Rows(count).Item("FieldID"), dt.Rows(count).Item("TripType"), "Update", "")
                                                boolUpdate = True
                                                Exit For
                                            End If
                                        End If
                                    Next

                                    If boolUpdate = False Then
                                        If info.DomSetting.Fee.FieldID = dt.Rows(count).Item("FieldID") Then
                                            If dt.Rows(count).Item("Value").ToString() <> .DomSetting.Fee.FieldValue Or dt.Rows(count).Item("Override") <> .DomSetting.Fee.Override Then
                                                Me.CallProcedure(dt.Rows(count).Item(0), dt.Rows(count).Item("FieldID"), dt.Rows(count).Item("TripType"), "Update", "")
                                            End If
                                        ElseIf info.DomSetting.AddOn.FieldID = dt.Rows(count).Item("FieldID") Then
                                            If dt.Rows(count).Item("Value").ToString() <> .DomSetting.AddOn.FieldValue Or dt.Rows(count).Item("Override") <> .DomSetting.AddOn.Override Then
                                                Me.CallProcedure(dt.Rows(count).Item(0), dt.Rows(count).Item("FieldID"), dt.Rows(count).Item("TripType"), "Update", "")
                                            End If
                                        End If
                                    End If

                                    boolUpdate = False
                                Case "I" 'Int
                                    Select Case info.IntSetting.Fee.FeeType
                                        Case "0"
                                            Type1 = "P"
                                        Case "1"
                                            Type1 = "T"
                                        Case Else
                                            Type1 = "C"
                                    End Select



                                    For count2 = 0 To info.IntSetting.Variables.Count - 1
                                        If info.IntSetting.Variables(count2).FieldID = dt.Rows(count).Item("FieldID") Then
                                            If dt.Rows(count).Item("Value").ToString() <> .IntSetting.Variables(count2).FieldValue Or dt.Rows(count).Item("Override") <> .IntSetting.Variables(count2).Override Then
                                                Me.CallProcedure(dt.Rows(count).Item(0), dt.Rows(count).Item("FieldID"), dt.Rows(count).Item("TripType"), "Update", "")
                                                boolUpdate = True
                                                Exit For
                                            End If
                                        End If
                                    Next

                                    If boolUpdate = False Then
                                        If info.IntSetting.Fee.FieldID = dt.Rows(count).Item("FieldID") Then
                                            If dt.Rows(count).Item("Value").ToString() <> .IntSetting.Fee.FieldValue Or dt.Rows(count).Item("Override") <> .IntSetting.Fee.Override Then
                                                Me.CallProcedure(dt.Rows(count).Item(0), dt.Rows(count).Item("FieldID"), dt.Rows(count).Item("TripType"), "Update", "")
                                            End If
                                        ElseIf info.IntSetting.AddOn.FieldID = dt.Rows(count).Item("FieldID") Then
                                            If dt.Rows(count).Item("Value").ToString() <> .IntSetting.AddOn.FieldValue Or dt.Rows(count).Item("Override") <> .IntSetting.AddOn.Override Then
                                                Me.CallProcedure(dt.Rows(count).Item(0), dt.Rows(count).Item("FieldID"), dt.Rows(count).Item("TripType"), "Update", "")
                                            End If
                                        End If
                                    End If

                                    boolUpdate = False
                                Case "L"  'LCC
                                    Select Case info.LccSetting.Fee.FeeType
                                        Case "0"
                                            Type1 = "P"
                                        Case "1"
                                            Type1 = "T"
                                        Case Else
                                            Type1 = "C"
                                    End Select

                                    For count2 = 0 To info.LccSetting.Variables.Count - 1
                                        If info.LccSetting.Variables(count2).FieldID = dt.Rows(count).Item("FieldID") Then
                                            If dt.Rows(count).Item("Value").ToString() <> .LccSetting.Variables(count2).FieldValue Or dt.Rows(count).Item("Override") <> .LccSetting.Variables(count2).Override Then
                                                Me.CallProcedure(dt.Rows(count).Item(0), dt.Rows(count).Item("FieldID"), dt.Rows(count).Item("TripType"), "Update", "")
                                                boolUpdate = True
                                                Exit For
                                            End If
                                        End If
                                    Next
                                    If boolUpdate = False Then
                                        If info.LccSetting.Fee.FieldID = dt.Rows(count).Item("FieldID") Then
                                            If dt.Rows(count).Item("Value").ToString() <> .LccSetting.Fee.FieldValue Or dt.Rows(count).Item("Override") <> .LccSetting.Fee.Override Then
                                                Me.CallProcedure(dt.Rows(count).Item(0), dt.Rows(count).Item("FieldID"), dt.Rows(count).Item("TripType"), "Update", "")
                                            End If
                                        ElseIf info.LccSetting.AddOn.FieldID = dt.Rows(count).Item("FieldID") Then
                                            If dt.Rows(count).Item("Value").ToString() <> .LccSetting.AddOn.FieldValue Or dt.Rows(count).Item("Override") <> .LccSetting.AddOn.Override Then
                                                Me.CallProcedure(dt.Rows(count).Item(0), dt.Rows(count).Item("FieldID"), dt.Rows(count).Item("TripType"), "Update", "")
                                            End If
                                        End If
                                    End If
                                    boolUpdate = False
                            End Select

                        End If
                    End With

                Next

            Catch ex As Exception

            End Try
        End Sub

        Public Sub CallProcedure(ByVal ID As String, ByVal FID As String, ByVal TripType As String, ByVal Type As String, ByVal StorProcType As String)
            With Me.MySQLParser
                If StorProcType = "Master" Then
                    .ExecuteStoreProcedure("exec sp_ClientMasterPricing '" + ID + "','" + ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName + "','" + Type + "'")
                Else
                    .ExecuteStoreProcedure("exec sp_ClientPricing '" + ID + "','" + FID + "','" + TripType + "','" + ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName + "','" + Type + "'")
                End If

            End With
        End Sub

        Public Function FindMatchRecords(ByVal ID As String, ByVal TripType As String, ByVal dt As DataTable)
            Dim count2 As Integer
            Dim bool As Boolean = False
            For count2 = 0 To dt.Rows.Count - 1
                If dt.Rows(count2).Item("FieldID") = ID And dt.Rows(count2).Item("TripType") = TripType Then
                    bool = True
                    Exit For
                End If
            Next
            Return bool
        End Function

        Public Function UpdateComAirPricing(ByVal info As DataInfo.ComAirPricingInfo) As Integer
            Dim EffectRow As Integer = -1
            Dim KeyID As String = ""
            Dim type1, type2, type3 As String
            Dim CMPID As String = ""
            FliterClientAirPricing(info)
            Try
                With Me.MySQLParser
                    '//
                    .TableName = "tblClientMasterPricing"
                    With .Columns
                        .Clear()
                        .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum, (info.PageMode = CWTMasterDB.TransactionMode.UpdateMode))
                        .Add("PricingID", info.ID)
                        .Add("ExemptTax", info.ExemptGovTax, SqlBuilder.SQLParserDataType.spBoolean)
                    End With
                    Select Case info.PageMode
                        Case TransactionMode.AddNewMode
                            EffectRow = .ExecuteInsert()
                            info.CMPID = GetCMPIDByClientID(info.ClientID)
                            Me.CallProcedure(CMPID, "", "", "Insert", "Master")
                        Case TransactionMode.UpdateMode
                            Me.CallProcedure(info.CMPID, "", "", "Update", "Master")
                            EffectRow = .ExecuteUpdate()
                    End Select
                    '//
                    .TableName = "tblClientPricing"
                    With .Columns
                        .Clear()
                        .Add("CMPID", info.CMPID, SqlBuilder.SQLParserDataType.spNum, True)
                    End With
                    .ExecuteDelete()
                    '// INT
                    If EffectRow > 0 Then
                        .TableName = "tblClientPricing"
                        For i As Integer = 0 To info.IntSetting.Variables.Count - 1
                            With .Columns
                                .Clear()
                                .Add("CMPID", info.CMPID, SqlBuilder.SQLParserDataType.spNum)
                                .Add("FieldID", info.IntSetting.Variables(i).FieldID)
                                .Add("[Value]", info.IntSetting.Variables(i).FieldValue)
                                .Add("Override", info.IntSetting.Variables(i).Override, SqlBuilder.SQLParserDataType.spBoolean)
                                .Add("TripType", "I")
                            End With
                            EffectRow = .ExecuteInsert()
                            If EffectRow <= 0 Then
                                Exit For
                            End If
                        Next
                    End If
                    ' FEE
                    If EffectRow > 0 AndAlso info.IntSetting.HaveFee Then
                        With .Columns
                            .Clear()
                            .Add("CMPID", info.CMPID, SqlBuilder.SQLParserDataType.spNum)
                            .Add("FieldID", info.IntSetting.Fee.FieldID)
                            .Add("[Value]", info.IntSetting.Fee.FieldValue)
                            If info.IntSetting.Fee.FeeType = "0" Then
                                type1 = "P"
                            ElseIf info.IntSetting.Fee.FeeType = "1" Then
                                type1 = "T"
                            Else
                                type1 = "C"
                            End If
                            .Add("ValueOption", type1)
                            .Add("Override", info.IntSetting.Fee.Override, SqlBuilder.SQLParserDataType.spBoolean)
                            .Add("TripType", "I")
                        End With
                        EffectRow = .ExecuteInsert()
                    End If
                    ' ADD ON
                    If EffectRow > 0 AndAlso info.IntSetting.HaveAddOn Then
                        With .Columns
                            .Clear()
                            .Add("CMPID", info.CMPID, SqlBuilder.SQLParserDataType.spNum)
                            .Add("FieldID", info.IntSetting.AddOn.FieldID)
                            .Add("[Value]", info.IntSetting.AddOn.FieldValue)
                            .Add("ValueOption", "A")
                            .Add("Override", info.IntSetting.AddOn.Override, SqlBuilder.SQLParserDataType.spBoolean)
                            .Add("TripType", "I")
                        End With
                        EffectRow = .ExecuteInsert()
                    End If
                    '// DOM
                    If EffectRow > 0 Then
                        .TableName = "tblClientPricing"
                        For i As Integer = 0 To info.DomSetting.Variables.Count - 1
                            With .Columns
                                .Clear()
                                .Add("CMPID", info.CMPID, SqlBuilder.SQLParserDataType.spNum)
                                .Add("FieldID", info.DomSetting.Variables(i).FieldID)
                                .Add("[Value]", info.DomSetting.Variables(i).FieldValue)
                                .Add("Override", info.DomSetting.Variables(i).Override, SqlBuilder.SQLParserDataType.spBoolean)
                                .Add("TripType", "D")
                            End With
                            EffectRow = .ExecuteInsert()
                            If EffectRow <= 0 Then
                                Exit For
                            End If
                        Next
                    End If
                    ' FEE
                    If EffectRow > 0 AndAlso info.DomSetting.HaveFee Then
                        With .Columns
                            .Clear()
                            .Add("CMPID", info.CMPID, SqlBuilder.SQLParserDataType.spNum)
                            .Add("FieldID", info.DomSetting.Fee.FieldID)
                            .Add("[Value]", info.DomSetting.Fee.FieldValue)
                            If info.DomSetting.Fee.FeeType = "0" Then
                                type2 = "P"
                            ElseIf info.DomSetting.Fee.FeeType = "1" Then
                                type2 = "T"
                            Else
                                type2 = "C"
                            End If
                            .Add("ValueOption", type2)
                            .Add("Override", info.DomSetting.Fee.Override, SqlBuilder.SQLParserDataType.spBoolean)
                            .Add("TripType", "D")
                        End With
                        EffectRow = .ExecuteInsert()
                    End If
                    ' ADD ON
                    If EffectRow > 0 AndAlso info.DomSetting.HaveAddOn Then
                        With .Columns
                            .Clear()
                            .Add("CMPID", info.CMPID, SqlBuilder.SQLParserDataType.spNum)
                            .Add("FieldID", info.DomSetting.AddOn.FieldID)
                            .Add("[Value]", info.DomSetting.AddOn.FieldValue)
                            .Add("ValueOption", "A")
                            .Add("Override", info.DomSetting.AddOn.Override, SqlBuilder.SQLParserDataType.spBoolean)
                            .Add("TripType", "D")
                        End With
                        EffectRow = .ExecuteInsert()
                    End If
                    '// LCC
                    If EffectRow > 0 Then
                        .TableName = "tblClientPricing"
                        For i As Integer = 0 To info.LccSetting.Variables.Count - 1
                            With .Columns
                                .Clear()
                                .Add("CMPID", info.CMPID, SqlBuilder.SQLParserDataType.spNum)
                                .Add("FieldID", info.LccSetting.Variables(i).FieldID)
                                .Add("[Value]", info.LccSetting.Variables(i).FieldValue)
                                .Add("Override", info.LccSetting.Variables(i).Override, SqlBuilder.SQLParserDataType.spBoolean)
                                .Add("TripType", "L")
                            End With
                            EffectRow = .ExecuteInsert()
                            If EffectRow <= 0 Then
                                Exit For
                            End If
                        Next
                    End If
                    ' FEE
                    If EffectRow > 0 AndAlso info.LccSetting.HaveFee Then
                        With .Columns
                            .Clear()
                            .Add("CMPID", info.CMPID, SqlBuilder.SQLParserDataType.spNum)
                            .Add("FieldID", info.LccSetting.Fee.FieldID)
                            .Add("[Value]", info.LccSetting.Fee.FieldValue)
                            If info.LccSetting.Fee.FeeType = "0" Then
                                type3 = "P"
                            ElseIf info.LccSetting.Fee.FeeType = "1" Then
                                type3 = "T"
                            Else
                                type3 = "C"
                            End If
                            .Add("ValueOption", type3)
                            .Add("Override", info.LccSetting.Fee.Override, SqlBuilder.SQLParserDataType.spBoolean)
                            .Add("TripType", "L")
                        End With
                        EffectRow = .ExecuteInsert()
                    End If
                    ' ADD ON
                    If EffectRow > 0 AndAlso info.LccSetting.HaveAddOn Then
                        With .Columns
                            .Clear()
                            .Add("CMPID", info.CMPID, SqlBuilder.SQLParserDataType.spNum)
                            .Add("FieldID", info.LccSetting.AddOn.FieldID)
                            .Add("[Value]", info.LccSetting.AddOn.FieldValue)
                            .Add("ValueOption", "A")
                            .Add("Override", info.LccSetting.AddOn.Override, SqlBuilder.SQLParserDataType.spBoolean)
                            .Add("TripType", "L")
                        End With
                        EffectRow = .ExecuteInsert()
                    End If
                    '//
                End With
                If EffectRow > 0 Then
                    Me.MySQLParser.CommitTran()
                Else
                    Me.MySQLParser.RollbackTran()
                End If
            Catch ex As Exception
                EffectRow = -1
                Me.MySQLParser.RollbackTran()
            Finally
                Me.MySQLParser.CloseConnection()
            End Try
            Return EffectRow
        End Function

        Public Function GetTempClientAirPricing() As DataTable
            Dim dt As DataTable
            Dim dt2 As DataTable
            Dim resultTable As DataTable
            Dim TempTable As DataTable
            Dim foundRow() As DataRow
            Dim count As Integer
            Dim ArrString(2) As String
            ArrString(0) = "CMPID"
            ArrString(1) = "FieldID"
            ArrString(2) = "TripType"

            With Me.MySQLParser
                .TableName = "Temp_tblClientPricing"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("*")
                End With
                dt = .ExecuteDataTable(.SQLSelect + " order by DateModification Desc")

                .TableName = "tblClientPricing"
                With .Columns
                    .Clear()
                    .IncludeKey = False
                    .Add("*")
                End With
                dt2 = .ExecuteDataTable()
            End With

            TempTable = dt.DefaultView.ToTable(True, ArrString)
            resultTable = dt.Clone()
            For count = 0 To TempTable.Rows.Count - 1
                foundRow = dt2.Select("CMPID='" + TempTable.Rows(count).Item("CMPID").ToString() + "' And FieldID='" + TempTable.Rows(count).Item("FieldID").ToString() + "'And TripType='" + TempTable.Rows(count).Item("TripType").ToString() + "'")
                If foundRow.Length > 0 Then
                    resultTable.ImportRow(foundRow(0))
                End If
            Next
            resultTable.AcceptChanges()
            resultTable.Merge(dt)
            Return resultTable
        End Function

        Public Function GetTempClientMasterAirPricing() As DataTable
            Dim dt As DataTable
            Dim dt2 As DataTable
            Dim resultTable As DataTable
            Dim TempTable As DataTable
            Dim foundRow() As DataRow
            Dim count As Integer
            Dim ArrString(2) As String
            ArrString(0) = "CMPID"
            ArrString(1) = "ClientID"
            ArrString(2) = "PricingID"

            With Me.MySQLParser
                .TableName = "Temp_tblClientMasterPricing TCP"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("TCP.*")
                    .Add("(select AirPricingName From tblAirPricingFormula Where AirPricingID = TCP.PricingID)As PricingName")
                End With
                dt = .ExecuteDataTable(.SQLSelect + " order by DateModification Desc")

                .TableName = "tblClientMasterPricing TCP"
                With .Columns
                    .Clear()
                    .IncludeKey = False
                    .Add("TCP.*")
                    .Add("(select AirPricingName From tblAirPricingFormula Where AirPricingID = TCP.PricingID)As PricingName")
                End With
                dt2 = .ExecuteDataTable()
            End With

            TempTable = dt.DefaultView.ToTable(True, ArrString)
            resultTable = dt.Clone()
            For count = 0 To TempTable.Rows.Count - 1
                foundRow = dt2.Select("CMPID='" + TempTable.Rows(count).Item("CMPID").ToString() + "' And ClientID='" + TempTable.Rows(count).Item("ClientID").ToString() + "'And PricingID='" + TempTable.Rows(count).Item("PricingID").ToString() + "'")
                If foundRow.Length > 0 Then
                    resultTable.ImportRow(foundRow(0))
                End If
            Next
            resultTable.AcceptChanges()
            resultTable.Merge(dt)
            Return resultTable
        End Function

        Public Function GetTempClientPricingByID(ByVal ID As String, ByVal DateFrom As String, ByVal DateTo As String)
            Dim dt As DataTable = New DataTable()
            Dim dt2 As DataTable
            Dim resultTable As DataTable
            Dim ReturnTable As New DataTable
            Dim Row As DataRow

            Dim TempTable As DataTable
            Dim foundRow() As DataRow
            Dim count As Integer
            Dim ArrString(2) As String
            ArrString(0) = "CMPID"
            ArrString(1) = "FieldID"
            ArrString(2) = "TripType"

            With Me.MySQLParser
                .TableName = "Temp_tblClientPricing"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    If ID <> "" Then
                        .Add("CMPID", "(Select CMP.CMPID from tblClientMasterPricing CMP inner join tblClientMaster CP on CMP.ClientID = CP.ClientID Where CP.Name='" + ID + "')", SqlBuilder.SQLParserDataType.spFunction, True)
                    End If
                    If DateFrom = DateTo Then
                        If DateFrom <> "" And DateTo <> "" Then
                            DateTo = DateTo + " 23:59:59:997"
                            .Add("DateModification", "convert(varchar,cast('" + DateFrom + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, ">")
                            .Add("DateModification", "convert(varchar,cast('" + DateTo + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, "<")
                        End If
                    Else
                        If DateFrom <> "" Then
                            .Add("DateModification", DateFrom, SqlBuilder.SQLParserDataType.spDate, True, ">")
                        End If
                        If DateTo <> "" Then
                            DateTo = DateTo + " 23:59:59:990"
                            .Add("DateModification", DateTo, SqlBuilder.SQLParserDataType.spText, True, "<=")
                        End If
                    End If
                    .Add("*")
                End With
                dt = .ExecuteDataTable(.SQLSelect() + " order by DateModification Desc")
                .TableName = "tblClientPricing"
                With .Columns
                    .Clear()
                    .IncludeKey = False
                    If ID <> "" Then
                        .Add("CMPID", "(Select CMP.CMPID from tblClientMasterPricing CMP inner join tblClientMaster CP on CMP.ClientID = CP.ClientID Where CP.GroupName='" + ID + "')", SqlBuilder.SQLParserDataType.spFunction, True)
                    End If
                    .Add("*")
                End With
                dt2 = .ExecuteDataTable()
            End With

            TempTable = dt.DefaultView.ToTable(True, ArrString)
            resultTable = dt.Clone()
            For count = 0 To TempTable.Rows.Count - 1
                foundRow = dt2.Select("CMPID='" + TempTable.Rows(count).Item("CMPID").ToString() + "' And FieldID='" + TempTable.Rows(count).Item("FieldID").ToString() + "'And TripType='" + TempTable.Rows(count).Item("TripType").ToString() + "'")
                If foundRow.Length > 0 Then
                    resultTable.ImportRow(foundRow(0))
                End If
            Next
            resultTable.AcceptChanges()
            resultTable.Merge(dt)
            ReturnTable.Columns.Add("CMPID")
            ReturnTable.Columns.Add("FieldID")
            ReturnTable.Columns.Add("Value")
            ReturnTable.Columns.Add("ValueOption")
            ReturnTable.Columns.Add("Override")
            ReturnTable.Columns.Add("TripType")
            ReturnTable.Columns.Add("DateModification")
            ReturnTable.Columns.Add("UserName")
            ReturnTable.Columns.Add("ValueTypeChanged")

            For count = 0 To resultTable.Rows.Count - 1
                Row = ReturnTable.NewRow()
                Row.Item("CMPID") = resultTable.Rows(count).Item("CMPID").ToString()
                If resultTable.Rows(count).Item("FieldID").ToString() = "3" Then
                    Row.Item("FieldID") = "Discount"
                    Row.Item("Value") = resultTable.Rows(count).Item("Value").ToString()
                    Row.Item("ValueOption") = resultTable.Rows(count).Item("ValueOption").ToString()
                ElseIf resultTable.Rows(count).Item("FieldID").ToString() = "5" Then
                    Row.Item("FieldID") = "Transaction Fee"
                    If resultTable.Rows(count).Item("ValueOption").ToString() = "P" Then
                        Row.Item("Value") = GetFeeNameByValue(resultTable.Rows(count).Item("Value").ToString(), "P")
                        Row.Item("ValueOption") = "Fee By PNR"
                    ElseIf resultTable.Rows(count).Item("ValueOption").ToString() = "T" Then
                        Row.Item("Value") = GetFeeNameByValue(resultTable.Rows(count).Item("Value").ToString(), "T")
                        Row.Item("ValueOption") = "Fee By Ticket"
                    ElseIf resultTable.Rows(count).Item("ValueOption").ToString() = "C" Then
                        Row.Item("Value") = GetFeeNameByValue(resultTable.Rows(count).Item("Value").ToString(), "C")
                        Row.Item("ValueOption") = "Fee By Coupon"
                    End If
                ElseIf resultTable.Rows(count).Item("FieldID").ToString() = "31" Then
                    Row.Item("FieldID") = "Client Return or Commision %"
                    Row.Item("Value") = resultTable.Rows(count).Item("Value").ToString()
                    Row.Item("ValueOption") = resultTable.Rows(count).Item("ValueOption").ToString()
                End If
                Row.Item("Override") = resultTable.Rows(count).Item("Override").ToString()
                If resultTable.Rows(count).Item("TripType").ToString() = "I" Then
                    Row.Item("TripType") = "International"
                ElseIf resultTable.Rows(count).Item("TripType").ToString() = "D" Then
                    Row.Item("TripType") = "Domestic"
                ElseIf resultTable.Rows(count).Item("TripType").ToString() = "L" Then
                    Row.Item("TripType") = "LCC"
                End If
                Row.Item("DateModification") = resultTable.Rows(count).Item("DateModification").ToString()
                Row.Item("UserName") = resultTable.Rows(count).Item("UserName").ToString()
                Row.Item("ValueTypeChanged") = resultTable.Rows(count).Item("ValueTypeChanged").ToString()
                ReturnTable.Rows.Add(Row)
            Next

            Return ReturnTable
        End Function

        Public Function GetTempClientMasterPricingByID(ByVal Name As String, ByVal DateFrom As String, ByVal DateTo As String)
            Dim dt As DataTable
            Dim dt2 As DataTable
            Dim resultTable As DataTable
            Dim TempTable As DataTable
            Dim foundRow() As DataRow
            Dim count As Integer
            Dim ArrString(1) As String
            ArrString(0) = "CMPID"
            ArrString(1) = "ClientID"
            'ArrString(2) = "PricingID"

            With Me.MySQLParser
                .TableName = "Temp_tblClientMasterPricing TCP inner join tblClientMaster CM on TCP.ClientID = CM.ClientID"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    If Name <> "" Then
                        .Add("CM.Name", Name, SqlBuilder.SQLParserDataType.spText, True)
                    End If
                    If DateFrom = DateTo Then
                        If DateFrom <> "" And DateTo <> "" Then
                            DateTo = DateTo + " 23:59:59:997"
                            .Add("TCP.DateModification", "convert(varchar,cast('" + DateFrom + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, ">")
                            .Add("TCP.DateModification", "convert(varchar,cast('" + DateTo + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, "<")
                        End If
                    Else
                        If DateFrom <> "" Then
                            .Add("TCP.DateModification", DateFrom, SqlBuilder.SQLParserDataType.spDate, True, ">")
                        End If
                        If DateTo <> "" Then
                            DateTo = DateTo + " 23:59:59:990"
                            .Add("DateModification", DateTo, SqlBuilder.SQLParserDataType.spText, True, "<=")
                        End If
                    End If
                    .Add("TCP.*")
                    .Add("(select AirPricingName From tblAirPricingFormula Where AirPricingID = TCP.PricingID)As PricingName")
                End With
                dt = .ExecuteDataTable(.SQLSelect + " order by DateModification Desc")
                .TableName = "tblClientMasterPricing TCP inner join tblClientMaster CM on TCP.ClientID = CM.ClientID"
                With .Columns
                    .Clear()
                    .IncludeKey = False
                    If Name <> "" Then
                        .Add("CM.GroupName", Name, SqlBuilder.SQLParserDataType.spText, True)
                    End If
                    .Add("TCP.*")
                    .Add("(select AirPricingName From tblAirPricingFormula Where AirPricingID = TCP.PricingID)As PricingName")
                End With
                dt2 = .ExecuteDataTable()
            End With


            TempTable = dt.DefaultView.ToTable(True, ArrString)
            resultTable = dt.Clone()
            For count = 0 To TempTable.Rows.Count - 1
                foundRow = dt2.Select("CMPID='" + TempTable.Rows(count).Item("CMPID").ToString() + "' And ClientID='" + TempTable.Rows(count).Item("ClientID").ToString() + "'")
                If foundRow.Length > 0 Then
                    resultTable.ImportRow(foundRow(0))
                End If
            Next
            resultTable.AcceptChanges()
            resultTable.Merge(dt)
            Return resultTable
        End Function

        Public Function GetFeeNameByValue(ByVal ValueID As String, ByVal FeeType As String)
            Dim retVal As String = ""
            Dim retObj As Object
            With Me.MySQLParser
                .AutoParameter = False
                If FeeType = "P" Then
                    .TableName = "tblFeeByPNR"
                ElseIf FeeType = "T" Then
                    .TableName = "tblFeeByTicket"
                Else
                    .TableName = "tblFeeByCoupon"
                End If
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("FeeID", ValueID, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("FeeName")
                End With
                retObj = .ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar, CommandType.Text)
                retVal = Util.DBNullToText(retObj)
            End With
            Return retVal
        End Function

    End Class
End Namespace


@


1.1.1.1
log
@no message
@
text
@@
