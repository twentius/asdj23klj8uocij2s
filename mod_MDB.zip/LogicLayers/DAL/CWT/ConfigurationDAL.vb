head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.23;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.23;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic
Imports System.Collections.Generic

Namespace DataAccessLayer
    Public Class ConfigurationDAL
        Inherits BaseDA

        Public Function GetRegion(ByVal IsInCity As Boolean, Optional ByVal FilterOutList As String = "") As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = CWTMasterDB.Util.StandardDB("tblRegion")
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    If IsInCity Then
                        .Add("RegionCode", "(select RegionCode from " + CWTMasterDB.Util.StandardDB("tblCity") + ")", SqlBuilder.SQLParserDataType.spFunction, True, "in")
                    End If
                    If FilterOutList <> "" Then .Add("RegionCode", "(" + FilterOutList + ")", SqlBuilder.SQLParserDataType.spFunction, True, "not in")
                    .Add("*")
                End With
                dt = .ExecuteDataTable(.SQLSelect + " order by Description")
            End With
            Return dt
        End Function

        Public Function GetCountry(ByVal IsInCity As Boolean) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = CWTMasterDB.Util.StandardDB("tblCountry")
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    If IsInCity Then
                        .Add("CountryCode", "(select CountryCode from " + CWTMasterDB.Util.StandardDB("tblCity") + ")", SqlBuilder.SQLParserDataType.spFunction, True, "in")
                    End If
                    .Add("*")
                End With
                dt = .ExecuteDataTable(.SQLSelect + " order by CountryName")
            End With
            Return dt
        End Function

        Public Function GetCountry() As DataTable
            Return Me.GetCountry(True)
        End Function

        Public Function GetCountryByCity(ByVal CityCode As String) As String
            Dim retVal As String
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = CWTMasterDB.Util.StandardDB("tblCity")
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("CityCode", CityCode, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("CountryCode")
                End With
                retVal = .ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar)
            End With
            Return retVal
        End Function

        Public Function GetCountryByRegion(ByVal RegionCode As String, Optional ByVal FilterOutList As String = "") As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = CWTMasterDB.Util.StandardDB("tblCountry")
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("CountryCode", "(select CountryCode from " + CWTMasterDB.Util.StandardDB("tblCity") + " WHERE RegionCode=" + CWTMasterDB.Util.LimitTheString(RegionCode) + ")", SqlBuilder.SQLParserDataType.spFunction, True, "in")
                    If FilterOutList <> "" Then .Add("CountryCode", "(" + FilterOutList + ")", SqlBuilder.SQLParserDataType.spFunction, True, "not in")
                    .Add("*")
                End With
                dt = .ExecuteDataTable(.SQLSelect + " order by CountryName")
            End With
            Return dt
        End Function

        Public Function GetCity(ByVal CountryCode As String, ByVal FilterOutList As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = CWTMasterDB.Util.StandardDB("tblCity")
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("CountryCode", CountryCode, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("countrycode", "NULL", SqlBuilder.SQLParserDataType.spFunction, True, "is not")
                    .Add("regioncode", "NULL", SqlBuilder.SQLParserDataType.spFunction, True, "is not")
                    If FilterOutList <> "" Then .Add("CityCode", "(" + FilterOutList + ")", SqlBuilder.SQLParserDataType.spFunction, True, "not in")
                    .Add("DISTINCT City")
                    .Add("CityCode")
                End With
                dt = .ExecuteDataTable(.SQLSelect + " order by City")
            End With
            Return dt
        End Function

        Public Function GetCurrency() As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = CWTMasterDB.Util.StandardDB("tblCurrency")
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("*")
                End With
                dt = .ExecuteDataTable(.SQLSelect + " order by CurrencyName")
            End With
            Return dt
        End Function

        Public Function GetGDS() As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = CWTMasterDB.Util.StandardDB("tblGDS")
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("*")
                End With
                dt = .ExecuteDataTable(.SQLSelect + " order by GDSName")
            End With
            Return dt
        End Function

        Public Function IsExistName(ByVal Name As String, ByVal ID As String) As Boolean
            Dim EffectRow As Integer
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblConfiguration"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("ConfigurationDesc", Name, SqlBuilder.SQLParserDataType.spText, True)
                    If ID <> "" Then .Add("ConfigurationID", ID, SqlBuilder.SQLParserDataType.spText, True, "<>")
                    .Add("Count(*) as NumRec")
                End With
                EffectRow = .ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar)
            End With
            Return (EffectRow > 0)
        End Function

        Public Function GetRegionByID(ByVal ItemID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = CWTMasterDB.Util.StandardDB("tblCity") + " a"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("RegionCode", ItemID, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("a.countrycode", "NULL", SqlBuilder.SQLParserDataType.spFunction, True, "is not")
                    .Add("a.regioncode", "NULL", SqlBuilder.SQLParserDataType.spFunction, True, "is not")
                    .Add("DISTINCT RegionCode")
                    .Add("(select top 1 Description from " + CWTMasterDB.Util.StandardDB("tblRegion") + " where regioncode=a.regioncode) as RegionName")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetRegionByID2() As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = CWTMasterDB.Util.StandardDB("tblRegion")
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("*")

                End With
                dt = .ExecuteDataTable(.SQLSelect + " order by Description")
            End With
            Return dt
        End Function


        Public Function GetRegionByID3(ByVal ctry As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = CWTMasterDB.Util.StandardDB("tblCity")
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("CountryCode", ctry, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("RegionCode")

                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetRegionByID4(ByVal city As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = CWTMasterDB.Util.StandardDB("tblCity")
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("CityCode", city, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("CountryCode")

                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetCountryByID(ByVal ItemID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = CWTMasterDB.Util.StandardDB("tblCity") + " a"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("CountryCode", ItemID, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("a.countrycode", "NULL", SqlBuilder.SQLParserDataType.spFunction, True, "is not")
                    .Add("a.regioncode", "NULL", SqlBuilder.SQLParserDataType.spFunction, True, "is not")
                    .Add("DISTINCT RegionCode")
                    .Add("CountryCode")
                    .Add("(select top 1 countryname from " + CWTMasterDB.Util.StandardDB("tblCountry") + " where countrycode=a.countrycode) as CountryName")
                    .Add("(select top 1 Description from " + CWTMasterDB.Util.StandardDB("tblRegion") + " where regioncode=a.regioncode) as RegionName")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetCityByID(ByVal ItemID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = CWTMasterDB.Util.StandardDB("tblCity") + " a"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("CityCode", ItemID, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("a.countrycode", "NULL", SqlBuilder.SQLParserDataType.spFunction, True, "is not")
                    .Add("a.regioncode", "NULL", SqlBuilder.SQLParserDataType.spFunction, True, "is not")
                    .Add("DISTINCT RegionCode")
                    .Add("CountryCode")
                    .Add("CityCode")
                    .Add("City")
                    .Add("(select top 1 countryname from " + CWTMasterDB.Util.StandardDB("tblCountry") + " where countrycode=a.countrycode) as CountryName")
                    .Add("(select top 1 Description from " + CWTMasterDB.Util.StandardDB("tblRegion") + " where regioncode=a.regioncode) as RegionName")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetConfigurationData() As DataTable
            Dim oDataTable As DataTable
            Dim query As New StringBuilder
            query.Append(" select *")
            query.Append(" from tblConfiguration")
            With Me.MySQLParser
                oDataTable = .ExecuteDataTable(query.ToString())
            End With
            Return oDataTable
        End Function
        Public Function GetConfigurationByConfigurationID(ByVal ConfigurationID As Integer) As DataTable
            Dim oDataTable As DataTable
            Dim query As New StringBuilder
            query.Append(" select *")
            query.Append(" from tblConfiguration")
            query.Append(" where(ConfigurationID = " + ConfigurationID.ToString() + ")")

            With Me.MySQLParser
                oDataTable = .ExecuteDataTable(query.ToString())
            End With
            Return oDataTable
        End Function
        Public Function UpdateConfigurationByConfigurationID(ByVal ConfigurationID As Integer, ByVal ConfigurationDesc As String, ByVal GDS As String _
, ByVal BookingPCC As String, ByVal FarePCC As String, ByVal Currency As String, ByVal CityCode As String, ByVal TicketPCC As String _
, ByVal TicketAddress As String, ByVal ItinPCC As String, ByVal ItinAddress As String, ByVal ItinDYO As String, ByVal InvPCC As String, ByVal InvAddress As String, ByVal InvDYO As String _
, ByVal MirPCC As String, ByVal IATA As String, ByVal MirAddress As String, ByVal DecimalPlc As String) As Integer
            Dim EffectRow As Integer
            With Me.MySQLParser
                .TableName = "tblConfiguration"
                With .Columns
                    .Clear()
                    .IncludeKey = False
                    .Add("ConfigurationID", ConfigurationID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("ConfigurationDesc", ConfigurationDesc)
                    .Add("GDS", GDS)
                    .Add("BookingPCC", BookingPCC)
                    .Add("FarePCC", FarePCC)
                    '.Add("Currency", Currency)
                    .Add("CityCode", CityCode)
                    .Add("TicketPCC", TicketPCC)
                    .Add("TicketAddress", TicketAddress)
                    .Add("ItinPCC", ItinPCC)
                    .Add("ItinAddress", ItinAddress)
                    .Add("ItinDYO", ItinDYO)
                    .Add("InvPCC", InvPCC)
                    .Add("InvAddress", InvAddress)
                    .Add("InvDYO", InvDYO)
                    .Add("MirPCC", MirPCC)
                    .Add("TicketIATA", IATA)
                    .Add("MIRAddress", MirAddress)
                    '.Add("DecimalPlc", DecimalPlc, SqlBuilder.SQLParserDataType.spNum)
                End With
                CallProcedure(ConfigurationID, "Update", "sp_Configuration")
                EffectRow = .ExecuteUpdate()
            End With
            Return EffectRow
        End Function
        Public Function DeleteConfigurationByConfigurationID(ByVal ConfigurationID As Integer) As Integer
            Dim EffectRow As Integer
            With Me.MySQLParser
                .TableName = "tblConfiguration"
                With .Columns
                    .Clear()
                    .Add("ConfigurationID", ConfigurationID, SqlBuilder.SQLParserDataType.spNum, True)
                End With
                CallProcedure(ConfigurationID, "Delete", "sp_Configuration")
                EffectRow = .ExecuteDelete()
            End With
            Return EffectRow
        End Function
        Public Function InsertConfiguration(ByVal ConfigurationDesc As String, ByVal GDS As String _
, ByVal BookingPCC As String, ByVal FarePCC As String, ByVal Currency As String, ByVal CityCode As String, ByVal TicketPCC As String _
, ByVal TicketAddress As String, ByVal ItinPCC As String, ByVal ItinAddress As String, ByVal ItinDYO As String, ByVal InvPCC As String, ByVal InvAddress As String, ByVal InvDYO As String _
, ByVal MirPCC As String, ByVal IATA As String, ByVal MirAddress As String, ByVal DecimalPlc As String) As Integer
            Dim EffectRow As Integer
            With Me.MySQLParser
                .TableName = "tblConfiguration"
                With .Columns
                    .Clear()
                    .Add("ConfigurationDesc", ConfigurationDesc)
                    .Add("GDS", GDS)
                    .Add("BookingPCC", BookingPCC)
                    .Add("FarePCC", FarePCC)
                    '.Add("Currency", Currency)
                    .Add("CityCode", CityCode)
                    .Add("TicketPCC", TicketPCC)
                    .Add("TicketAddress", TicketAddress)
                    .Add("ItinPCC", ItinPCC)
                    .Add("ItinAddress", ItinAddress)
                    .Add("ItinDYO", ItinDYO)
                    .Add("InvPCC", InvPCC)
                    .Add("InvAddress", InvAddress)
                    .Add("InvDYO", InvDYO)
                    .Add("MirPCC", MirPCC)
                    .Add("TicketIATA", IATA)
                    .Add("MIRAddress", MirAddress)
                    '.Add("DecimalPlc", DecimalPlc, SqlBuilder.SQLParserDataType.spNum)
                End With
                EffectRow = .ExecuteInsert()
                GetLastAndInsertToTemp()
            End With
            Return EffectRow
        End Function

        Private Sub CallProcedure(ByVal ID As String, ByVal Type As String, ByVal StoreProdType As String)
            With Me.MySQLParser
                .ExecuteStoreProcedure("exec " + StoreProdType + " '" + ID + "','" + ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName + "','" + Type + "'")
            End With
        End Sub

        Private Sub GetLastAndInsertToTemp()
            Dim LastID As String
            With Me.MySQLParser
                .TableName = "tblConfiguration"
                With .Columns
                    .Clear()
                    .Add("max(ConfigurationID)")
                End With
                LastID = .ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar)
            End With
            CallProcedure(LastID, "Insert", "sp_Configuration")
        End Sub

        Public Function GetTempConfiguration(Optional ByVal Name As String = "", Optional ByVal dateFrom As String = "", Optional ByVal dateTo As String = "") As DataSet
            Dim ConfigDT As DataTable
            Dim TempConfigDT As DataTable
            Dim ConfigMasterDT As DataTable

            Dim TempTable As DataTable
            Dim ClientIDArr(0) As String
            Dim count As Integer
            Dim count2 As Integer
            Dim ds As New DataSet
            Dim foundRow() As DataRow

            ClientIDArr(0) = "ConfigurationID"

            With Me.MySQLParser
                .TableName = "Temp_tblConfiguration"
                With .Columns
                    .Clear()
                    If Name <> "" Then
                        .Add("ConfigurationDesc", Name, SqlBuilder.SQLParserDataType.spText, True)
                    End If
                    If dateFrom = dateTo Then
                        If dateFrom <> "" And dateTo <> "" Then
                            dateTo = dateTo + " 23:59:59:990"
                            .Add("DateModification", "convert(varchar,cast('" + dateFrom + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, ">")
                            .Add("DateModification", "convert(varchar,cast('" + dateTo + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, "<")
                        End If
                    Else
                        If dateFrom <> "" Then
                            .Add("DateModification", dateFrom, SqlBuilder.SQLParserDataType.spDate, True, ">")
                        End If
                        If dateTo <> "" Then
                            dateTo = dateTo + " 23:59:59:999"
                            .Add("DateModification", dateTo, SqlBuilder.SQLParserDataType.spText, True, "<=")
                        End If
                    End If
                    .Add("ConfigurationID,ConfigurationDesc,GDS,BookingPCC,FarePCC,CityCode,TicketPCC,TicketAddress,ItinPCC,ItinAddress,ItinDYO,InvPCC,InvAddress,InvDYO,MirPCC,TicketIATA,MIRAddress,DateModification,UserName,ValueChangeType")
                End With
                TempConfigDT = .ExecuteDataTable(.SQLSelect + " order by DateModification Desc")


                .TableName = "tblConfiguration"
                With .Columns
                    .Clear()
                    If Name <> "" Then
                        .Add("ConfigurationDesc", Name, SqlBuilder.SQLParserDataType.spText, True)
                    End If
                    .Add("ConfigurationID,ConfigurationDesc,GDS,BookingPCC,FarePCC,CityCode,TicketPCC,TicketAddress,ItinPCC,ItinAddress,ItinDYO,InvPCC,InvAddress,InvDYO,MirPCC,TicketIATA,MIRAddress")
                End With
                ConfigDT = .ExecuteDataTable()

                TempTable = TempConfigDT.DefaultView.ToTable(True, ClientIDArr)
                ConfigMasterDT = TempConfigDT.Clone()
                For count = 0 To TempTable.Rows.Count - 1
                    foundRow = ConfigDT.Select("ConfigurationID='" + TempTable.Rows(count).Item("ConfigurationID").ToString() + "'")
                    If foundRow.Length > 0 Then
                        For count2 = 0 To foundRow.Length - 1
                            ConfigMasterDT.ImportRow(foundRow(count2))
                        Next count2
                    End If
                Next
                ConfigMasterDT.AcceptChanges()
                ConfigMasterDT.Merge(TempConfigDT)
                ConfigMasterDT.TableName = "Config"
                ds.Tables.Add(ConfigMasterDT)
            End With
            Return ds
        End Function


    End Class
End Namespace

@


1.1.1.1
log
@no message
@
text
@@
