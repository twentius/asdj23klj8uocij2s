head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.22;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.22;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic
Imports System.Collections.Generic

Namespace DataAccessLayer
    Public Class AirlineDAL
        Inherits BaseDA

        Public Function GetAirlineList() As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = CWTMasterDB.Util.StandardDB("tblAirlines")
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("AirlineCode", "(select AirlineCode from tblAirlineAgreement)", SqlBuilder.SQLParserDataType.spFunction, True, "not in")
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetAirlineList(ByVal AirlineName As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = CWTMasterDB.Util.StandardDB("tblAirlines") + " a inner join tblAirlineAgreement f on a.AirlineCode=f.AirlineCode"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    If AirlineName <> "" Then .Add("a.AirlineDescription", "%" + AirlineName + "%", SqlBuilder.SQLParserDataType.spText, True, "LIKE")
                    .Add("a.*")
                    .Add("isnull(f.FuelCharge,0) as FuelCharge")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetAirlineFuelData(ByVal AirlineCode As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = CWTMasterDB.Util.StandardDB("tblAirlines") + " a inner join tblAirlineAgreement f on a.AirlineCode=f.AirlineCode"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("a.AirlineCode", AirlineCode, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("a.*")
                    .Add("isnull(f.FuelCharge,0) as FuelCharge")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetAirlineName(ByVal AirlineName As String) As String()
            Dim dt As DataTable
            Dim retVal As New List(Of String)
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = CWTMasterDB.Util.StandardDB("tblAirlines")
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("AirlineDescription", AirlineName + "%", SqlBuilder.SQLParserDataType.spText, True, "LIKE")
                    .Add("Distinct AirlineDescription")
                End With
                dt = .ExecuteDataTable()
            End With
            If dt IsNot Nothing AndAlso dt.Rows.Count > 0 Then
                For i As Integer = 0 To dt.Rows.Count - 1
                    retVal.Add(dt.Rows(i).Item("AirlineDescription").ToString)
                Next
            End If
            Return retVal.ToArray
        End Function

        Public Function DeleteAirlineFuelByCode(ByVal AirlineCode As Integer) As Integer
            Dim EffectRow As Integer
            With Me.MySQLParser
                .TableName = "tblAirlineAgreement"
                With .Columns
                    .Clear()
                    .Add("AirlineCode", AirlineCode, SqlBuilder.SQLParserDataType.spText, True)
                End With
                EffectRow = .ExecuteDelete()
            End With
            Return EffectRow
        End Function

        Public Function UpdateAirlineFuel(ByVal info As DataInfo.AirlineInfo) As Integer
            Dim EffectRow As Integer
            Try
                With Me.MySQLParser
                    .TableName = "tblAirlineAgreement"
                    With .Columns
                        .Clear()
                        .Add("AirlineCode", info.AirlineCode, SqlBuilder.SQLParserDataType.spText, (info.PageMode = CWTMasterDB.TransactionMode.UpdateMode))
                        .Add("FuelCharge", info.FuelCharge, SqlBuilder.SQLParserDataType.spNum)
                    End With

                    Select Case info.PageMode
                        Case CWTMasterDB.TransactionMode.AddNewMode
                            EffectRow = .ExecuteInsert()
                        Case CWTMasterDB.TransactionMode.UpdateMode
                            EffectRow = .ExecuteUpdate()
                    End Select
                End With
            Catch ex As Exception
                EffectRow = -1
            End Try
            Return EffectRow
        End Function

    End Class
End Namespace

@


1.1.1.1
log
@no message
@
text
@@
