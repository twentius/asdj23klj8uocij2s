head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.23;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.23;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic
Namespace DataAccessLayer
    Public Class ProductDAL
        Inherits BaseDA

        Public Function GetProductType() As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = CWTMasterDB.Util.StandardDB("tblProductType")
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetProductData() As DataTable
            Dim oDataTable As DataTable
            With Me.MySQLParser
                .TableName = "tblProducts p inner join " + CWTMasterDB.Util.StandardDB("tblProductType") + " t on p.[Type]=t.ProductTypeCode"
                With .Columns
                    .Clear()
                    .Add("p.*")
                    .Add("t.ProductTypeName as typeName")
                End With
                oDataTable = .ExecuteDataTable()
            End With
            Return oDataTable
        End Function
        Public Function GetProductByNumber(ByVal Number As Integer) As DataTable
            Dim oDataTable As DataTable
            With Me.MySQLParser
                .TableName = "tblProducts p inner join " + CWTMasterDB.Util.StandardDB("tblProductType") + " t on p.[Type]=t.ProductTypeCode"
                With .Columns
                    .Clear()
                    .Add("Number", Number, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("p.*")
                    .Add("t.ProductTypeName as typeName")
                End With
                oDataTable = .ExecuteDataTable()
            End With
            Return oDataTable
        End Function
        Public Function InsertProduct(ByVal Number As Integer, ByVal Name As String, ByVal GDSCode As String, ByVal Type As String, ByVal RequireCDR As Boolean, ByVal RequireTicket As Boolean, ByVal GST As String, ByVal OT1 As String, ByVal OT2 As String, ByVal SuppressMI As Boolean, ByVal TicketPrefix As String, ByVal AppMF As Boolean, ByVal AppHotelFee As Boolean) As Integer
            Dim EffectRow As Integer
            Dim proID As Integer = Number
            Dim chkAppMF As Boolean = AppMF
            With Me.MySQLParser
                .TableName = "tblProducts"
                With .Columns
                    .Clear()
                    .Add("Number", Number, SqlBuilder.SQLParserDataType.spNum)
                    .Add("Name", Name)
                    .Add("GDSCode", GDSCode)
                    .Add("Type", Type)
                    '.Add("TktPrefix", TktPrefix)
                    '.Add("TktFormat", TktFormat)
                    .Add("RequireCDR", RequireCDR, SqlBuilder.SQLParserDataType.spBoolean)
                    .Add("RequireTicket", RequireTicket, SqlBuilder.SQLParserDataType.spBoolean)
                    .Add("SuppressMI", SuppressMI, SqlBuilder.SQLParserDataType.spBoolean)
                    .Add("TktPrefix", TicketPrefix)
                    .Add("GST", GST)
                    .Add("OT1", OT1)
                    .Add("OT2", OT2)
                    .Add("AppMF", AppMF, SqlBuilder.SQLParserDataType.spBoolean)
                    .Add("HotelFee", AppHotelFee, SqlBuilder.SQLParserDataType.spBoolean)
                End With
                EffectRow = .ExecuteInsert()

                '//

            End With

            Call Me.InsertMFByProduct(proID, chkAppMF)
            Return EffectRow
        End Function
        Public Function InsertMFByProduct(ByVal Number As Integer, ByVal AppMF As Boolean) As Integer
            Dim EffectRow As Integer
            With Me.MySQLParser
                .TableName = "tblMFByProduct"
                With .Columns
                    .Clear()
                    .Add("ClientID", "-1", SqlBuilder.SQLParserDataType.spNum)
                    .Add("ProductCode", Number, SqlBuilder.SQLParserDataType.spNum)
                    .Add("SubjectToMF", AppMF, SqlBuilder.SQLParserDataType.spBoolean)
                    .Add("Standard", True, SqlBuilder.SQLParserDataType.spBoolean)
                End With
                EffectRow = .ExecuteInsert()
            End With
            Return EffectRow
        End Function
        Public Function UpdateProductByNumber(ByVal Number As Integer, ByVal Name As String, ByVal GDSCode As String, ByVal Type As String, ByVal RequireCDR As Boolean, ByVal RequireTicket As Boolean, ByVal GST As String, ByVal OT1 As String, ByVal OT2 As String, ByVal SuppressMI As Boolean, ByVal TicketPrefix As String, ByVal AppMF As Boolean, ByVal AppHotelFee As Boolean) As Integer
            Dim EffectRow As Integer
            With Me.MySQLParser
                .TableName = "tblProducts"
                With .Columns
                    .Clear()
                    .IncludeKey = False
                    .Add("Number", Number, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("Name", Name)
                    .Add("GDSCode", GDSCode)
                    .Add("Type", Type)
                    '.Add("TktPrefix", TktPrefix)
                    '.Add("TktFormat", TktFormat)
                    .Add("RequireCDR", RequireCDR, SqlBuilder.SQLParserDataType.spBoolean)
                    .Add("RequireTicket", RequireTicket, SqlBuilder.SQLParserDataType.spBoolean)
                    .Add("SuppressMI", SuppressMI, SqlBuilder.SQLParserDataType.spBoolean)
                    .Add("TktPrefix", TicketPrefix)
                    .Add("GST", GST)
                    .Add("OT1", OT1)
                    .Add("OT2", OT2)
                    .Add("AppMF", AppMF, SqlBuilder.SQLParserDataType.spBoolean)
                    .Add("HotelFee", AppHotelFee, SqlBuilder.SQLParserDataType.spBoolean)
                End With
                CallProcedure(Number, "Update", "sp_Products")
                EffectRow = .ExecuteUpdate()
            End With
            Call Me.UpdateMFByproduct(Number, AppMF)
            Return EffectRow
        End Function

        Public Function UpdateMFByproduct(ByVal Number As Integer, ByVal AppMF As Boolean) As Integer
            Dim EffectRow As Integer
            With Me.MySQLParser
                .TableName = "tblMFByProduct"
                With .Columns
                    .Clear()
                    .Add("ClientID", "-1", SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("ProductCode", Number, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("SubjectToMF", AppMF, SqlBuilder.SQLParserDataType.spBoolean)

                End With
                CallProcedure("-1", "Update", "sp_MFByProduct")
                EffectRow = .ExecuteUpdate()
            End With
            Return EffectRow
        End Function

        Public Function CheckHotelFee() As Boolean
            Dim count As Integer
            Dim boolFee As Boolean
            Dim dt As New DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblProducts"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("HotelFee")
                End With
                dt = .ExecuteDataTable()
            End With

            If dt.Rows.Count > 0 Then
                For count = 0 To dt.Rows.Count - 1
                    If dt.Rows(count).Item("HotelFee").ToString = True Then
                        boolFee = True
                        Return boolFee
                    End If
                Next count
            End If
            Return boolFee
        End Function

        Public Function DeleteProductByNumber(ByVal Number As Integer) As Integer
            Dim EffectRow As Integer
            Dim TempEffRow As Integer
            With Me.MySQLParser
                .TableName = "tblProducts"
                With .Columns
                    .Clear()
                    .Add("Number", Number, SqlBuilder.SQLParserDataType.spNum, True)
                End With
                CallProcedure(Number, "Delete", "sp_Products")
                EffectRow = .ExecuteDelete()
                '//

                .TableName = "tblMFByProduct"
                With .Columns
                    .Clear()
                    .Add("ClientID", "-1", SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("ProductCode", Number, SqlBuilder.SQLParserDataType.spNum, True)
                End With
                EffectRow = .ExecuteDelete()

                'caused by ClientID logic.. (ClientID -1 ??)
                .TableName = "Temp_tblMFByProduct"
                With .Columns
                    .Clear()
                    .Add("ClientID", "-1", SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("ProductCode", Number, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("DateModification", DateTime.Now)
                    .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                    .Add("ValueTypeChanged", "Delete")
                End With
                TempEffRow = .ExecuteInsert()
            End With
            Return EffectRow
        End Function

        Private Sub CallProcedure(ByVal ID As String, ByVal Type As String, ByVal StoreProdType As String)
            With Me.MySQLParser
                .ExecuteStoreProcedure("exec " + StoreProdType + " '" + ID + "','" + ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName + "','" + Type + "'")
            End With
        End Sub

        Public Function GetTempProduct(Optional ByVal ProductName As String = "", Optional ByVal dateFrom As String = "", Optional ByVal dateTo As String = "") As DataSet

            Dim ds As New DataSet
            Dim ProductDT As DataTable
            Dim TempProductDT As DataTable
            Dim ProductMasterDT As DataTable

            'Dim MFProductDT As DataTable
            'Dim TempMFProductDT As DataTable
            'Dim MFProductMasterDT As DataTable

            Dim TempTable As DataTable
            Dim ProductNo As String = ""
            Dim ClientIDArr(0) As String
            'Dim MFProductArr(1) As String
            Dim count As Integer
            Dim count2 As Integer
            Dim foundRow() As DataRow


            ClientIDArr(0) = "Number"
            'MFProductArr(0) = "ProductCode"
            'MFProductArr(1) = "ClientID"
            If ProductName <> "" Then
                ProductNo = GetProductNumberByName(ProductName)
            End If

            With Me.MySQLParser
                .TableName = "Temp_tblProducts tp inner join " + CWTMasterDB.Util.StandardDB("tblProductType") + " t on tp.[Type]=t.ProductTypeCode"
                With .Columns
                    .Clear()
                    If ProductName <> "" Then
                        .Add("Name", ProductName, SqlBuilder.SQLParserDataType.spText, True)
                    End If
                    If dateFrom = dateTo Then
                        If dateFrom <> "" And dateTo <> "" Then
                            dateTo = dateTo + " 23:59:59:990"
                            .Add("DateModification", "convert(varchar,cast('" + dateFrom + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, ">")
                            .Add("DateModification", "convert(varchar,cast('" + dateTo + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, "<")
                        End If
                    Else
                        If dateFrom <> "" Then
                            .Add("DateModification", dateFrom, SqlBuilder.SQLParserDataType.spDate, True, ">")
                        End If
                        If dateTo <> "" Then
                            dateTo = dateTo + " 23:59:59:999"
                            .Add("DateModification", dateTo, SqlBuilder.SQLParserDataType.spText, True, "<=")
                        End If
                    End If
                    .Add("tp.Number,tp.Name,tp.GDSCode,t.ProductTypeName,tp.TktPrefix,tp.GST,tp.OT1,tp.OT2,tp.RequireCDR As EnableMI,tp.RequireTicket As EnableTicketNumber,tp.SuppressMI As ExcludeMIReport,tp.AppMF,tp.HotelFee,tp.DateModification,tp.UserName,tp.ValueChangeType")
                End With
                TempProductDT = .ExecuteDataTable(.SQLSelect + " order by DateModification Desc")

                .TableName = "tblProducts tp inner join " + CWTMasterDB.Util.StandardDB("tblProductType") + " t on tp.[Type]=t.ProductTypeCode"
                With .Columns
                    .Clear()
                    If ProductName <> "" Then
                        .Add("Name", ProductName, SqlBuilder.SQLParserDataType.spText, True)
                    End If
                    .Add("tp.Number,tp.Name,tp.GDSCode,t.ProductTypeName,tp.TktPrefix,tp.GST,tp.OT1,tp.OT2,tp.RequireCDR As EnableMI,tp.RequireTicket As EnableTicketNumber,tp.SuppressMI As ExcludeMIReport,tp.AppMF,tp.HotelFee")
                End With
                ProductDT = .ExecuteDataTable()

                TempTable = TempProductDT.DefaultView.ToTable(True, ClientIDArr)
                ProductMasterDT = TempProductDT.Clone()
                For count = 0 To TempTable.Rows.Count - 1
                    foundRow = ProductDT.Select("Number='" + TempTable.Rows(count).Item("Number").ToString() + "'")
                    If foundRow.Length > 0 Then
                        For count2 = 0 To foundRow.Length - 1
                            ProductMasterDT.ImportRow(foundRow(count2))
                        Next count2
                    End If
                Next
                ProductMasterDT.AcceptChanges()
                ProductMasterDT.Merge(TempProductDT)
                ProductMasterDT.TableName = "Product"
                ds.Tables.Add(ProductMasterDT)

                '.TableName = "Temp_tblMFByProduct"
                'With .Columns
                '    .Clear()
                '    If ProductNo <> "" Then
                '        .Add("ProductCode", ProductNo, SqlBuilder.SQLParserDataType.spNum, True)
                '    End If
                '    If dateFrom = dateTo Then
                '        If dateFrom <> "" And dateTo <> "" Then
                '            dateTo = dateTo + " 23:59:59:990"
                '            .Add("DateModification", "convert(varchar,cast('" + dateFrom + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, ">")
                '            .Add("DateModification", "convert(varchar,cast('" + dateTo + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, "<")
                '        End If
                '    Else
                '        If dateFrom <> "" Then
                '            .Add("DateModification", dateFrom, SqlBuilder.SQLParserDataType.spDate, True, ">")
                '        End If
                '        If dateTo <> "" Then
                '            dateTo = dateTo + " 23:59:59:999"
                '            .Add("DateModification", dateTo, SqlBuilder.SQLParserDataType.spDate, True, "<=")
                '        End If
                '    End If
                '    .Add("*")
                'End With
                'TempMFProductDT = .ExecuteDataTable(.SQLSelect + " order by DateModification Desc")

                '.TableName = "tblMFByProduct"
                'With .Columns
                '    .Clear()
                '    If ProductNo <> "" Then
                '        .Add("ProductCode", ProductNo, SqlBuilder.SQLParserDataType.spNum, True)
                '    End If
                '    .Add("*")
                'End With
                'MFProductDT = .ExecuteDataTable()

                'TempTable = TempMFProductDT.DefaultView.ToTable(True, MFProductArr)
                'MFProductMasterDT = TempMFProductDT.Clone()
                'For count = 0 To TempTable.Rows.Count - 1
                '    foundRow = MFProductDT.Select("ProductCode='" + TempTable.Rows(count).Item("ProductCode").ToString() + "' and ClientID='" + TempTable.Rows(count).Item("ClientID").ToString() + "'")
                '    If foundRow.Length > 0 Then
                '        For count2 = 0 To foundRow.Length - 1
                '            MFProductMasterDT.ImportRow(foundRow(count2))
                '        Next count2
                '    End If
                'Next
                'MFProductMasterDT.AcceptChanges()
                'MFProductMasterDT.Merge(TempMFProductDT)
                'MFProductMasterDT.TableName = "MFByProduct"
                'ds.Tables.Add(MFProductMasterDT)
            End With
            Return ds
        End Function

        Public Function GetProductNumberByName(ByVal Name As String) As String
            Dim retVal As String
            Dim retObj As Object
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblProducts"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("Name", Name, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("Number")
                End With
                retObj = .ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar, CommandType.Text)
                retVal = Util.DBNullToText(retObj)
            End With
            Return retVal
        End Function
    End Class
End Namespace

@


1.1.1.1
log
@no message
@
text
@@
