head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.23;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.23;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic

Namespace DataAccessLayer

    Public Class DivisionDAL
        Inherits BaseDA
        Private AgentInsertID As ArrayList

        Public Function GetDivisionAgentTree() As DataTable
            Dim oDataTable As DataTable
            With Me.MySQLParser
                .TableName = "tblDivision d left join tblAgent a on d.divisionid=a.divisionid"
                With .Columns
                    .Clear()
                    .IncludeKey = False
                    .Add("a.*")
                    .Add("d.DivisionID as DivID")
                    .Add("d.DivisionDesc")
                End With
                oDataTable = .ExecuteDataTable(.SQLSelect() + " order by d.DivisionDesc,a.AgentID")
            End With
            Return oDataTable
        End Function

        Public Function GetDivisionList2(ByVal divisionID As String, ByVal divisionName As String, ByVal uid As String, ByVal agentName As String, ByVal SignOn As String) As DataTable
            Dim oDataTable As DataTable

            '            SELECT DISTINCT a.DivisionID, a.DivisionDesc
            'FROM         tblDivision AS a INNER JOIN
            '                      tblAgent AS b ON a.DivisionID = b.DivisionID
            'WHERE     (b.FirstName LIKE '%a%')
            With Me.MySQLParser
                .TableName = "tblDivision AS a FULL OUTER JOIN tblAgent AS b ON a.DivisionID = b.DivisionID"
                With .Columns
                    .Clear()
                    .IncludeKey = False
                    If divisionName <> "" Then
                        .Add("a.DivisionDesc", "%" + divisionName + "%", SqlBuilder.SQLParserDataType.spText, True, "LIKE")
                    End If
                    If divisionID <> "" Then
                        .Add("a.DivisionID", divisionID, SqlBuilder.SQLParserDataType.spNum, True)
                    End If
                    If uid <> "" Then
                        .Add("b.AgentID", uid, SqlBuilder.SQLParserDataType.spText, True)
                    End If
                    If agentName <> "" Then
                        .Add("b.FirstName", "%" + agentName + "%", SqlBuilder.SQLParserDataType.spText, True, "LIKE")
                    End If
                    If SignOn <> "" Then
                        .Add("b.SignOn", SignOn, SqlBuilder.SQLParserDataType.spText, True)
                    End If

                    If agentName <> "" And uid <> "" And SignOn <> "" Then
                        .Add("Distinct a.*, b.FirstName, b.AgentID")
                    ElseIf agentName <> "" And uid = "" And SignOn = "" Then
                        .Add("Distinct a.*, b.FirstName, b.AgentID")
                    ElseIf agentName = "" And uid <> "" And SignOn = "" Then
                        .Add("Distinct a.*, b.FirstName, b.AgentID")
                    ElseIf agentName = "" And uid = "" And SignOn <> "" Then
                        .Add("Distinct a.*, b.FirstName, b.AgentID")
                    Else
                        .Add("Distinct a.* ,'' as FirstName, '' as AgentID")
                    End If

                End With
                oDataTable = .ExecuteDataTable(.SQLSelect() + " order by DivisionDesc")
            End With
            Return oDataTable
        End Function

        Public Function GetDivisionList() As DataTable
            Dim oDataTable As DataTable
            With Me.MySQLParser
                .TableName = "tblDivision"
                With .Columns
                    .Clear()
                    .IncludeKey = False

                    .Add("*")
                End With
                oDataTable = .ExecuteDataTable(.SQLSelect() + " order by DivisionDesc")
            End With
            Return oDataTable
        End Function

        Public Function GetDivisionByID(ByVal DivisionID As String) As DataTable
            Dim oDataTable As DataTable
            With Me.MySQLParser
                .TableName = "tblDivision"
                With .Columns
                    .Clear()
                    .IncludeKey = False
                    .Add("DivisionID", DivisionID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("*")
                End With
                oDataTable = .ExecuteDataTable(.SQLSelect())
            End With
            Return oDataTable
        End Function


        Public Function GetTempAgent() As DataTable
            Dim oDataTable As DataTable
            Dim dt As DataTable
            Dim resultTable As DataTable
            Dim TempTable As DataTable
            Dim foundRow() As DataRow
            Dim count As Integer
            Dim ArrString(1) As String
            ArrString(0) = "AgentID"
            ArrString(1) = "DivisionID"


            With Me.MySQLParser
                .TableName = "Temp_tblAgent"
                With .Columns
                    .Clear()
                    .IncludeKey = False
                    .Add("*")
                End With
                oDataTable = .ExecuteDataTable(.SQLSelect() + " order by DateModification Desc")
                .TableName = "tblAgent"
                With .Columns
                    .Clear()
                    .IncludeKey = False
                    .Add("Distinct *")
                End With
                dt = .ExecuteDataTable()
            End With

            TempTable = oDataTable.DefaultView.ToTable(True, ArrString)
            resultTable = oDataTable.Clone()
            For count = 0 To TempTable.Rows.Count - 1
                foundRow = dt.Select("AgentID='" + TempTable.Rows(count).Item("AgentID").ToString() + "' And DivisionID = '" + TempTable.Rows(count).Item("DivisionID").ToString() + "'")
                If foundRow.Length > 0 Then
                    resultTable.ImportRow(foundRow(0))
                End If
            Next
            resultTable.AcceptChanges()
            resultTable.Merge(oDataTable)
            Return resultTable
        End Function


        Public Sub FlitterAgent(ByVal info As DataInfo.DivisionAgentInfo)
            Dim oDataTable As DataTable
            Dim foundRow() As DataRow
            Dim count As Integer
            Dim count2 As Integer
            Dim totalRowRecord As Integer
            Dim boolChk As Boolean
            Dim boolChk2 As Boolean
            AgentInsertID = New ArrayList()
            Dim AgentInfo As New DataInfo.DivisionAgentInfo()
            AgentInfo = info
            Try
                With Me.MySQLParser
                    .TableName = "tblAgent"
                    With .Columns
                        .Clear()
                        .IncludeKey = False
                        .Add("*")
                    End With
                    oDataTable = .ExecuteDataTable()
                End With


                foundRow = oDataTable.Select("DivisionID ='" + AgentInfo.DivisionID + "'")
                totalRowRecord = AgentInfo.AgentItem.Count

                If totalRowRecord > 0 Then
                    For count = 0 To totalRowRecord - 1
                        boolChk = FindMatchRecords(AgentInfo.AgentItem(count).UserName, foundRow)
                        If foundRow.Length > 0 Then
                            For count2 = 0 To foundRow.Length - 1
                                With AgentInfo.AgentItem(count)
                                    If boolChk And foundRow(count2).Item(0) = .UserName Then ' Update
                                        If foundRow(count2).Item(1).ToString() <> .DivID Or foundRow(count2).Item(2).ToString() <> .FirstName Or foundRow(count2).Item(3).ToString() <> .LastName Or foundRow(count2).Item(5).ToString() <> .Title Or foundRow(count2).Item(6).ToString() <> .JobTitle Or foundRow(count2).Item(7).ToString() <> .BizPhoneCode Or foundRow(count2).Item(8).ToString() <> .BizPhoneNo Or foundRow(count2).Item(9).ToString() <> .SignOn Or foundRow(count2).Item(10).ToString() <> .QueuePCC1 Or foundRow(count2).Item(11).ToString() <> .QueueNo1 Or foundRow(count2).Item(12).ToString() <> .QueuePCC2 Or foundRow(count2).Item(13).ToString() <> .QueueNo2 Or foundRow(count2).Item(14).ToString() <> .QueuePCC3 Or foundRow(count2).Item(15).ToString() <> .QueueNo3 Or foundRow(count2).Item(16).ToString() <> .BackOfficeCode Or foundRow(count2).Item(17).ToString() <> .Email Or foundRow(count2).Item(18).ToString() <> .Status Then
                                            Me.CallProcedure(.UserName, "Update")
                                        End If
                                        Exit For
                                    ElseIf boolChk = False And .UserName <> "" Then 'Insert
                                        AgentInsertID.Add(.UserName)
                                        Exit For
                                    End If
                                End With
                            Next
                        ElseIf AgentInfo.AgentItem(count).UserName <> "" Then 'Insert 
                            AgentInsertID.Add(AgentInfo.AgentItem(count).UserName)

                        End If
                    Next

                    For count = 0 To foundRow.Length - 1
                        boolChk2 = FindDeleteRecords(foundRow(count).Item(0), info)
                        If boolChk2 = False Then
                            Me.CallProcedure(foundRow(count).Item(0), "Delete")
                        End If
                    Next
                End If
            Catch ex As Exception

            End Try
        End Sub

        Public Sub InsertNewRecords()
            Dim count As Integer
            If Me.AgentInsertID.Count > 0 Then
                For count = 0 To Me.AgentInsertID.Count - 1
                    Me.CallProcedure(AgentInsertID(count), "Insert")
                Next
            End If
        End Sub

        Public Function FindMatchRecords(ByVal ID As String, ByVal Row() As DataRow)
            Dim count2 As Integer
            Dim bool As Boolean = False
            For count2 = 0 To Row.Length - 1
                If Row(count2).Item(0) = ID Then
                    bool = True
                    Exit For
                End If
            Next
            Return bool
        End Function

        Public Function FindDeleteRecords(ByVal ID As String, ByVal info As DataInfo.DivisionAgentInfo)
            Dim bool As Boolean
            Dim count As Integer
            If info.AgentItem.Count > 0 Then
                For count = 0 To info.AgentItem.Count - 1
                    If ID = info.AgentItem(count).UserName Then
                        bool = True
                        Exit For
                    End If
                Next
            Else
                bool = False
            End If
            Return bool
        End Function

        Public Sub CallProcedure(ByVal ID As String, ByVal Type As String)
            With Me.MySQLParser
                .ExecuteStoreProcedure("exec sp_Agent '" + ID + "','" + ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName + "','" + Type + "'")
            End With
        End Sub

        Public Function GetTempDivision() As DataTable
            Dim oDataTable As DataTable
            Dim dt As DataTable
            Dim resultTable As DataTable
            Dim TempTable As DataTable
            Dim foundRow() As DataRow
            Dim count As Integer
            Dim ArrString(0) As String
            ArrString(0) = "DivisionID"

            With Me.MySQLParser
                .TableName = "Temp_tblDivision"
                With .Columns
                    .Clear()
                    .IncludeKey = False
                    .Add("*")
                End With
                oDataTable = .ExecuteDataTable(.SQLSelect() + " order by DateModification Desc")

                .TableName = "tblDivision"
                With .Columns
                    .Clear()
                    .IncludeKey = False
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With

            TempTable = oDataTable.DefaultView.ToTable(True, ArrString)
            resultTable = oDataTable.Clone()
            For count = 0 To TempTable.Rows.Count - 1
                foundRow = dt.Select("DivisionID = '" + TempTable.Rows(count).Item("DivisionID").ToString() + "'")
                If foundRow.Length > 0 Then
                    resultTable.ImportRow(foundRow(0))
                End If
            Next
            resultTable.AcceptChanges()
            resultTable.Merge(oDataTable)
            Return resultTable
        End Function

        Public Function GetTempAgentByID(Optional ByVal AID As String = "", Optional ByVal dateFrom As String = "", Optional ByVal dateTo As String = "") As DataTable
            Dim oDataTable As DataTable
            Dim dt As DataTable
            Dim resultTable As DataTable
            Dim TempTable As DataTable
            Dim foundRow() As DataRow
            Dim count As Integer
            Dim ArrString(1) As String
            ArrString(0) = "AgentID"
            ArrString(1) = "DivisionID"

            With Me.MySQLParser
                .TableName = "Temp_tblAgent"
                With .Columns
                    .Clear()
                    .IncludeKey = False
                    If AID <> "" Then
                        .Add("AgentID", AID, SqlBuilder.SQLParserDataType.spText, True)
                    End If
                    If dateFrom = dateTo Then
                        If dateFrom <> "" And dateTo <> "" Then
                            dateTo = dateTo + " 23:59:59:990"
                            .Add("DateModification", "convert(varchar,cast('" + dateFrom + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, ">")
                            .Add("DateModification", "convert(varchar,cast('" + dateTo + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, "<")
                        End If
                    Else
                        If dateFrom <> "" Then
                            .Add("DateModification", dateFrom, SqlBuilder.SQLParserDataType.spDate, True, ">")
                        End If
                        If dateTo <> "" Then
                            dateTo = dateTo + " 23:59:59:999"
                            .Add("DateModification", dateTo, SqlBuilder.SQLParserDataType.spText, True, "<=")
                        End If
                    End If
                    .Add("*")
                End With
                oDataTable = .ExecuteDataTable(.SQLSelect() + " order by DateModification Desc")
                .TableName = "tblAgent"
                With .Columns
                    .Clear()
                    .IncludeKey = False
                    If AID <> "" Then
                        .Add("AgentID", AID, SqlBuilder.SQLParserDataType.spText, True)
                    End If
                    .Add("Distinct *")
                End With
                dt = .ExecuteDataTable()
            End With
                TempTable = oDataTable.DefaultView.ToTable(True, ArrString)
                resultTable = oDataTable.Clone()
                For count = 0 To TempTable.Rows.Count - 1
                    foundRow = dt.Select("AgentID='" + TempTable.Rows(count).Item("AgentID").ToString() + "' And DivisionID = '" + TempTable.Rows(count).Item("DivisionID").ToString() + "'")
                    If foundRow.Length > 0 Then
                        resultTable.ImportRow(foundRow(0))
                    End If
                Next
                resultTable.AcceptChanges()
                resultTable.Merge(oDataTable)
                Return resultTable
        End Function

        Public Function GetTempDivisionByID(ByVal ID As String, ByVal DateFrom As String, ByVal DateTo As String)
            Dim oDataTable As DataTable
            Dim dt As DataTable
            Dim resultTable As DataTable
            Dim TempTable As DataTable
            Dim foundRow() As DataRow
            Dim count As Integer
            Dim ArrString(0) As String
            ArrString(0) = "DivisionID"

            With Me.MySQLParser
                .TableName = "Temp_tblDivision"
                With .Columns
                    .Clear()
                    .IncludeKey = False
                    If ID <> "" Then
                        .Add("DivisionID", ID, SqlBuilder.SQLParserDataType.spText, True)
                    End If
                    If DateFrom = DateTo Then
                        If DateFrom <> "" And DateTo <> "" Then
                            DateTo = DateTo + " 23:59:59:997"
                            .Add("DateModification", "convert(varchar,cast('" + DateFrom + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, ">")
                            .Add("DateModification", "convert(varchar,cast('" + DateTo + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, "<")
                        End If
                    Else
                        If DateFrom <> "" Then
                            .Add("DateModification", DateFrom, SqlBuilder.SQLParserDataType.spDate, True, ">")
                        End If
                        If DateTo <> "" Then
                            DateTo = DateTo + " 23:59:59:999"
                            .Add("DateModification", DateTo, SqlBuilder.SQLParserDataType.spText, True, "<=")
                        End If
                    End If
                    .Add("*")
                End With
                oDataTable = .ExecuteDataTable(.SQLSelect() + " order by DateModification Desc")
                .TableName = "tblDivision"
                With .Columns
                    .Clear()
                    .IncludeKey = False
                    If ID <> "" Then
                        .Add("DivisionID", ID, SqlBuilder.SQLParserDataType.spText, True)
                    End If
                    .Add("Distinct * ")
                End With
                dt = .ExecuteDataTable()
            End With

            TempTable = oDataTable.DefaultView.ToTable(True, ArrString)
            resultTable = oDataTable.Clone()
            For count = 0 To TempTable.Rows.Count - 1
                foundRow = dt.Select("DivisionID = '" + TempTable.Rows(count).Item("DivisionID").ToString() + "'")
                If foundRow.Length > 0 Then
                    resultTable.ImportRow(foundRow(0))
                End If
            Next
            resultTable.AcceptChanges()
            resultTable.Merge(oDataTable)
            Return resultTable
        End Function


        Public Function IsExistCode(ByVal DivID As String) As Boolean
            Dim retVal As Boolean
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblDivision"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("DivisionID", DivID, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("count(*) as RecordCount")
                End With
                retVal = (CWTMasterDB.Util.DBNullToZero(.ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar)) > 0)
            End With
            Return retVal
        End Function

        Public Function IsExistAgentID(ByVal AgentID As String) As Boolean
            Dim retVal As Boolean
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblAgent"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("AgentID", AgentID, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("count(*) as RecordCount")
                End With
                retVal = (CWTMasterDB.Util.DBNullToZero(.ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar)) > 0)
            End With
            Return retVal
        End Function

        Public Function UpdateDivision(ByVal info As DataInfo.DivisionInfo) As Integer
            Dim EffectRow As Integer
            Dim pwdManager As New Securities.DataEncryption()
            Dim encPassword As String = ""
            'Dim oSql As String
            'Dim KeyID As String
            Try
                With Me.MySQLParser
                    .TableName = "tblDivision"
                    With .Columns
                        .Clear()
                        .Add("DivisionID", info.ID, SqlBuilder.SQLParserDataType.spText, (info.PageMode = CWTMasterDB.TransactionMode.UpdateMode))
                        .Add("DivisionDesc", info.Name)
                        '.Add("JobTitle", info.JobTitle)
                        .Add("Status", info.Status, SqlBuilder.SQLParserDataType.spBoolean)
                    End With

                    Select Case info.PageMode
                        Case CWTMasterDB.TransactionMode.UpdateMode
                            .ExecuteStoreProcedure("exec sp_Division '" + info.ID + "','" + ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName + "','Update'")
                            EffectRow = .ExecuteUpdate()
                        Case Else
                            EffectRow = .ExecuteInsert()
                            .ExecuteStoreProcedure("exec sp_Division '" + info.ID + "','" + ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName + "','Insert'")

                    End Select
                End With
            Catch ex As Exception
                EffectRow = -1
            End Try
            Return EffectRow
        End Function

        Public Function GetAgentByID(ByVal AgentID As String) As DataTable
            Dim oDataTable As DataTable
            With Me.MySQLParser
                .TableName = "tblAgent"
                With .Columns
                    .Clear()
                    .IncludeKey = False
                    .Add("AgentID", AgentID, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("*")
                End With
                oDataTable = .ExecuteDataTable(.SQLSelect())
            End With
            Return oDataTable
        End Function

        Public Function GetAgentByID2(ByVal DivisionID As String, ByVal AgentName As String, ByVal AgentID As String) As DataTable
            Dim oDataTable As DataTable
            With Me.MySQLParser
                .TableName = "tblAgent"
                With .Columns
                    .Clear()
                    .IncludeKey = False
                    .Add("DivisionID", DivisionID, SqlBuilder.SQLParserDataType.spText, True)
                    If Trim(AgentName) <> "" Then
                        .Add("FirstName", AgentName, SqlBuilder.SQLParserDataType.spText, True)
                    End If
                    If Trim(AgentID) <> "" Then
                        .Add("AgentID", AgentID, SqlBuilder.SQLParserDataType.spText, True)
                    End If
                    .Add("*")
                End With
                oDataTable = .ExecuteDataTable(.SQLSelect())
            End With
            Return oDataTable
        End Function

        Public Function UpdateAgent(ByVal info As DataInfo.DivisionAgentInfo) As Integer
            Dim EffectRow As Integer
            Try
                FlitterAgent(info)
                With Me.MySQLParser
                    .OpenConnection()
                    .BeginTran()
                    .TableName = "tblAgent"
                    With .Columns
                        .Clear()
                        .Add("DivisionID", info.DivisionID, SqlBuilder.SQLParserDataType.spNum, True)
                    End With
                    EffectRow = .ExecuteDelete()

                    '//
                    .TableName = "tblAgent"
                    If info.AgentItem.Count > 0 Then
                        For i As Integer = 0 To info.AgentItem.Count - 1
                            With .Columns
                                .Clear()
                                .Add("AgentID", info.AgentItem.Item(i).UserName, SqlBuilder.SQLParserDataType.spText)
                                .Add("DivisionID", info.AgentItem.Item(i).DivID, SqlBuilder.SQLParserDataType.spNum)
                                .Add("Title", info.AgentItem.Item(i).Title, SqlBuilder.SQLParserDataType.spText)
                                .Add("FirstName", info.AgentItem.Item(i).FirstName, SqlBuilder.SQLParserDataType.spText)
                                .Add("LastName", info.AgentItem.Item(i).LastName, SqlBuilder.SQLParserDataType.spText)
                                .Add("BizPhoneLocalCode", info.AgentItem.Item(i).BizPhoneCode, SqlBuilder.SQLParserDataType.spText)
                                .Add("BizPhone", info.AgentItem.Item(i).BizPhoneNo, SqlBuilder.SQLParserDataType.spText)
                                .Add("AgentEmail", info.AgentItem.Item(i).Email, SqlBuilder.SQLParserDataType.spText)
                                .Add("JobTitle", info.AgentItem.Item(i).JobTitle, SqlBuilder.SQLParserDataType.spText)
                                .Add("SignOn", info.AgentItem.Item(i).SignOn, SqlBuilder.SQLParserDataType.spText)
                                .Add("BackOfficeCode", info.AgentItem.Item(i).BackOfficeCode, SqlBuilder.SQLParserDataType.spText)
                                .Add("QueuePCC1", info.AgentItem.Item(i).QueuePCC1, SqlBuilder.SQLParserDataType.spText)
                                .Add("QueuePCC2", info.AgentItem.Item(i).QueuePCC2, SqlBuilder.SQLParserDataType.spText)
                                .Add("QueuePCC3", info.AgentItem.Item(i).QueuePCC3, SqlBuilder.SQLParserDataType.spText)
                                .Add("QueueNumber1", info.AgentItem.Item(i).QueueNo1, SqlBuilder.SQLParserDataType.spText)
                                .Add("QueueNumber2", info.AgentItem.Item(i).QueueNo2, SqlBuilder.SQLParserDataType.spText)
                                .Add("QueueNumber3", info.AgentItem.Item(i).QueueNo3, SqlBuilder.SQLParserDataType.spText)
                                .Add("Status", info.AgentItem.Item(i).Status, SqlBuilder.SQLParserDataType.spBoolean)
                            End With
                            EffectRow = .ExecuteInsert()
                            If EffectRow <= 0 Then
                                Exit For
                            End If
                        Next
                    End If

                    'Insert record into Temp Table tblAgent
                    InsertNewRecords()
                End With

                If EffectRow > 0 Then
                    Me.MySQLParser.CommitTran()
                Else
                    Me.MySQLParser.RollbackTran()
                End If




            Catch ex As Exception
                EffectRow = -1
                Me.MySQLParser.RollbackTran()
            Finally
                Me.MySQLParser.CloseConnection()
            End Try
            Return EffectRow
        End Function

        Public Function DeleteAgent(ByVal AgentID As String) As Integer
            Dim EffectRow As Integer

            Try

                With Me.MySQLParser
                    .OpenConnection()
                    .BeginTran()
                    .TableName = "tblAgent"
                    With .Columns
                        .Clear()
                        .Add("AgentID", AgentID, SqlBuilder.SQLParserDataType.spText, True)
                    End With
                    EffectRow = .ExecuteDelete()
                End With
            Catch ex As Exception
                EffectRow = -1
                Me.MySQLParser.RollbackTran()

            Finally
                Me.MySQLParser.CloseConnection()
            End Try

            Return EffectRow
        End Function


    End Class

End Namespace@


1.1.1.1
log
@no message
@
text
@@
