head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.23;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.23;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic
Namespace DataAccessLayer
    Public Class HolidayDAL
        Inherits BaseDA
        Public Function GetHolidayData(Optional ByVal HolidayDate As String = Nothing) As DataTable
            Dim oDataTable As DataTable
            Dim query As New StringBuilder
            query.Append(" select *")
            query.Append(" from tblHoliday")
            If (Not String.IsNullOrEmpty(HolidayDate)) Then
                query.Append(" where(HolidayDate = " + CWTMasterDB.Util.LimitTheString(HolidayDate.ToString()) + ")")
            End If
            With Me.MySQLParser
                oDataTable = .ExecuteDataTable(query.ToString())
            End With
            Return oDataTable
        End Function
        Public Function GetHolidayByHolidayID(ByVal HolidayID As Integer) As DataTable
            Dim oDataTable As DataTable
            Dim query As New StringBuilder
            query.Append(" select *")
            query.Append(" from tblHoliday")
            query.Append(" where(HolidayID = " + HolidayID.ToString() + ")")

            With Me.MySQLParser                
                oDataTable = .ExecuteDataTable(query.ToString())
            End With
            Return oDataTable
        End Function
        Public Function UpdateHolidayByHolidayID(ByVal HolidayID As Integer, ByVal HolidayDate As String, ByVal HolidayName As String) As Integer
            Dim EffectRow As Integer
            With Me.MySQLParser
                .TableName = "tblHoliday"
                With .Columns
                    .Clear()
                    .IncludeKey = False
                    .Add("HolidayID", HolidayID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("HolidayDate", HolidayDate, SqlBuilder.SQLParserDataType.spDate)
                    .Add("HolidayName", HolidayName)
                End With
                CallProcedure(HolidayID, "Update", "sp_Holiday")
                EffectRow = .ExecuteUpdate()
            End With
            Return EffectRow
        End Function
        Public Function DeleteHolidayByHolidayID(ByVal HolidayID As Integer) As Integer
            Dim EffectRow As Integer
            With Me.MySQLParser
                .TableName = "tblHoliday"
                With .Columns
                    .Clear()
                    .Add("HolidayID", HolidayID, SqlBuilder.SQLParserDataType.spNum, True)
                End With
                CallProcedure(HolidayID, "Delete", "sp_Holiday")
                EffectRow = .ExecuteDelete()
            End With
            Return EffectRow
        End Function
        Public Function InsertHoliday(ByVal HolidayDate As Date, ByVal HolidayName As String) As Integer
            Dim EffectRow As Integer
            With Me.MySQLParser
                .TableName = "tblHoliday"
                With .Columns
                    .Clear()
                    .Add("HolidayDate", HolidayDate, SqlBuilder.SQLParserDataType.spDate)
                    .Add("HolidayName", HolidayName)
                End With
                EffectRow = .ExecuteInsert()
                CallProcedure(GetLastID(), "Insert", "sp_Holiday")
            End With
            Return EffectRow
        End Function

        Private Sub CallProcedure(ByVal ID As String, ByVal Type As String, ByVal StoreProdType As String)
            With Me.MySQLParser
                .ExecuteStoreProcedure("exec " + StoreProdType + " '" + ID + "','" + ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName + "','" + Type + "'")
            End With
        End Sub

        Private Function GetLastID() As String
            Dim ID As String
            With Me.MySQLParser
                .TableName = "tblHoliday"
                With .Columns
                    .Clear()
                    .Add("max(HolidayID)")
                End With
                ID = .ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar)
            End With
            Return ID
        End Function

        Public Function GetTempHoliday(Optional ByVal dateFrom As String = "", Optional ByVal dateTo As String = "") As DataSet
            Dim HolidayDT As DataTable
            Dim TempHolidayDT As DataTable
            Dim HolidayMasterDT As DataTable

            Dim TempTable As DataTable
            Dim ClientIDArr(0) As String
            Dim count As Integer
            Dim count2 As Integer
            Dim ds As New DataSet
            Dim foundRow() As DataRow

            ClientIDArr(0) = "HolidayID"

            With Me.MySQLParser
                .TableName = "Temp_tblHoliday"
                With .Columns
                    .Clear()
                    If dateFrom = dateTo Then
                        If dateFrom <> "" And dateTo <> "" Then
                            dateTo = dateTo + " 23:59:59:990"
                            .Add("DateModification", "convert(varchar,cast('" + dateFrom + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, ">")
                            .Add("DateModification", "convert(varchar,cast('" + dateTo + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, "<")
                        End If
                    Else
                        If dateFrom <> "" Then
                            .Add("DateModification", dateFrom, SqlBuilder.SQLParserDataType.spDate, True, ">")
                        End If
                        If dateTo <> "" Then
                            dateTo = dateTo + " 23:59:59:999"
                            .Add("DateModification", dateTo, SqlBuilder.SQLParserDataType.spText, True, "<=")
                        End If
                    End If
                    .Add("*")
                End With
                TempHolidayDT = .ExecuteDataTable(.SQLSelect + " order by DateModification Desc")

                .TableName = "tblHoliday"
                With .Columns
                    .Clear()
                    .Add("*")
                End With
                HolidayDT = .ExecuteDataTable()

                TempTable = TempHolidayDT.DefaultView.ToTable(True, ClientIDArr)
                HolidayMasterDT = TempHolidayDT.Clone()
                For count = 0 To TempTable.Rows.Count - 1
                    foundRow = HolidayDT.Select("HolidayID='" + TempTable.Rows(count).Item("HolidayID").ToString() + "'")
                    If foundRow.Length > 0 Then
                        For count2 = 0 To foundRow.Length - 1
                            HolidayMasterDT.ImportRow(foundRow(count2))
                        Next count2
                    End If
                Next
                HolidayMasterDT.AcceptChanges()
                HolidayMasterDT.Merge(TempHolidayDT)
                HolidayMasterDT.TableName = "Holiday"
                ds.Tables.Add(HolidayMasterDT)
            End With
            Return ds
        End Function

    End Class
End Namespace

@


1.1.1.1
log
@no message
@
text
@@
