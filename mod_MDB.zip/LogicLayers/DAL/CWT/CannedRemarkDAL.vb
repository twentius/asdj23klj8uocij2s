head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.23;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.23;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic
Imports System.Collections.Generic

Namespace DataAccessLayer
    Public Class CannedRemarkDAL
        Inherits BaseDA

        Public Function GetCannedRemark() As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblCannedRemark"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function UpdateCannedRemark(ByVal info As DataInfo.CannedRemarkInfo) As Integer
            Dim EffectRow As Integer = 1
            Dim CanDT As DataTable
            Try
                CanDT = GetCannedRemark()
                With Me.MySQLParser
                    .TableName = "tblCannedRemark"
                    .ExecuteDeleteAll()
                    For i As Integer = 0 To info.Remarks.Count - 1
                        With .Columns
                            .Clear()
                            .Add("CannedID", i + 1, SqlBuilder.SQLParserDataType.spNum)
                            .Add("CannedRmk", info.Remarks(i), SqlBuilder.SQLParserDataType.spText, , , True)

                        End With
                        EffectRow = .ExecuteInsert()
                        If EffectRow <= 0 Then
                            Exit For
                        End If
                    Next
                End With
                MatchCanRecord(CanDT, info)
            Catch ex As Exception
                EffectRow = -1
            End Try
            Return EffectRow
        End Function

        Private Sub MatchCanRecord(ByVal CanDT As DataTable, ByVal info As DataInfo.CannedRemarkInfo)
            Dim countInfo As Integer
            Dim countDT As Integer
            Dim checkMatch As Boolean
            Dim effectRow As Integer

            If CanDT.Rows.Count > 0 Then
                For countDT = 0 To CanDT.Rows.Count - 1
                    checkMatch = CheckCanExist(CanDT.Rows(countDT), info)

                    If checkMatch = True Then
                        For countInfo = 0 To info.Remarks.Count - 1
                            If CanDT.Rows(countDT).Item("CannedID").ToString() = countInfo + 1 And CanDT.Rows(countDT).Item("CannedRmk").ToString() <> info.Remarks(countInfo) And CanDT.Rows.Count = info.Remarks.Count Then
                                With Me.MySQLParser
                                    .TableName = "Temp_tblCannedRemark"
                                    With .Columns
                                        .Clear()
                                        .Add("CannedID", CanDT.Rows(countDT).Item("CannedID").ToString(), SqlBuilder.SQLParserDataType.spNum)
                                        .Add("CannedRmk", CanDT.Rows(countDT).Item("CannedRmk").ToString())
                                        .Add("DateModification", DateTime.Now)
                                        .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                        .Add("ValueTypeChanged", "Update")
                                    End With
                                    effectRow = .ExecuteInsert()
                                    Exit For
                                End With
                            End If
                        Next countInfo

                        If CanDT.Rows.Count > info.Remarks.Count And CheckRmkExist(CanDT.Rows(countDT).Item("CannedRmk").ToString(), info.Remarks) = False Then
                            With Me.MySQLParser
                                .TableName = "Temp_tblCannedRemark"
                                With .Columns
                                    .Clear()
                                    .Add("CannedID", CanDT.Rows(countDT).Item("CannedID").ToString(), SqlBuilder.SQLParserDataType.spNum)
                                    .Add("CannedRmk", CanDT.Rows(countDT).Item("CannedRmk").ToString())
                                    .Add("DateModification", DateTime.Now)
                                    .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                    .Add("ValueTypeChanged", "Delete")
                                End With
                                effectRow = .ExecuteInsert()
                            End With
                        End If
                    ElseIf CheckRmkExist(CanDT.Rows(countDT).Item("CannedRmk").ToString(), info.Remarks) = False Then
                        With Me.MySQLParser
                            .TableName = "Temp_tblCannedRemark"
                            With .Columns
                                .Clear()
                                .Add("CannedID", CanDT.Rows(countDT).Item("CannedID").ToString(), SqlBuilder.SQLParserDataType.spNum)
                                .Add("CannedRmk", CanDT.Rows(countDT).Item("CannedRmk").ToString())
                                .Add("DateModification", DateTime.Now)
                                .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                .Add("ValueTypeChanged", "Delete")
                            End With
                            effectRow = .ExecuteInsert()
                        End With
                    End If
                Next countDT
            End If

            If info.Remarks.Count > CanDT.Rows.Count Then
                For countInfo = countDT To info.Remarks.Count - 1
                    With Me.MySQLParser
                        .TableName = "Temp_tblCannedRemark"
                        With .Columns
                            .Clear()
                            .Add("CannedID", countInfo + 1, SqlBuilder.SQLParserDataType.spNum)
                            .Add("CannedRmk", info.Remarks(countInfo))
                            .Add("DateModification", DateTime.Now)
                            .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                            .Add("ValueTypeChanged", "Insert")
                        End With
                        effectRow = .ExecuteInsert()
                    End With
                Next countInfo
            End If
        End Sub

        Private Function CheckCanExist(ByVal row As DataRow, ByVal info As DataInfo.CannedRemarkInfo)
            Dim check As Boolean
            Dim countInfo As Integer

            For countInfo = 0 To info.Remarks.Count - 1
                If Convert.ToInt32(row.Item("CannedID")) = countInfo + 1 Then
                    check = True
                    Exit For
                End If
            Next countInfo
            Return check
        End Function

        Private Function CheckRmkExist(ByVal Rmk As String, ByVal Remark As List(Of String))
            Dim check As Boolean = False

            Dim countList As Integer
            For countList = 0 To Remark.Count - 1
                If Rmk = Remark(countList) Then
                    check = True
                    Exit For
                End If
            Next countList

            Return check
        End Function

        Private Function CheckRmkUpdate(ByVal RmkDT As DataTable, ByVal Remark As List(Of String))
            Dim check As Boolean = False
            Dim countDT As Integer
            Dim countList As Integer

            For countDT = 0 To RmkDT.Rows.Count - 1
                For countList = 0 To Remark.Count - 1
                    If RmkDT.Rows(countDT).Item("CannedRmk") = Remark(countList) Then
                        check = True
                        Exit For
                    End If
                Next countList
            Next countDT
            Return check

        End Function

        Public Function GetTempCannedRemark(Optional ByVal dateFrom As String = "", Optional ByVal dateTo As String = "") As DataSet
            Dim CannedDT As DataTable
            Dim TempCannedDT As DataTable
            Dim CannedMasterDT As DataTable

            Dim ds As New DataSet
            Dim TempTable As DataTable
            Dim ClientIDArr(0) As String
            Dim count As Integer
            Dim count2 As Integer
            Dim foundRow() As DataRow

            ClientIDArr(0) = "CannedID"


            With Me.MySQLParser
                .TableName = "Temp_tblCannedRemark"
                With .Columns
                    .Clear()
                    If dateFrom = dateTo Then
                        If dateFrom <> "" And dateTo <> "" Then
                            dateTo = dateTo + " 23:59:59:990"
                            .Add("DateModification", "convert(varchar,cast('" + dateFrom + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, ">")
                            .Add("DateModification", "convert(varchar,cast('" + dateTo + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, "<")
                        End If
                    Else
                        If dateFrom <> "" Then
                            .Add("DateModification", dateFrom, SqlBuilder.SQLParserDataType.spDate, True, ">")
                        End If
                        If dateTo <> "" Then
                            dateTo = dateTo + " 23:59:59:999"
                            .Add("DateModification", dateTo, SqlBuilder.SQLParserDataType.spText, True, "<=")
                        End If
                    End If
                    .Add("*")
                End With
                TempCannedDT = .ExecuteDataTable(.SQLSelect + " order by DateModification Desc")

                .TableName = "tblCannedRemark"
                With .Columns
                    .Clear()
                    .Add("*")
                End With
                CannedDT = .ExecuteDataTable()

                TempTable = TempCannedDT.DefaultView.ToTable(True, ClientIDArr)
                CannedMasterDT = TempCannedDT.Clone()
                For count = 0 To TempTable.Rows.Count - 1
                    foundRow = CannedDT.Select("CannedID='" + TempTable.Rows(count).Item("CannedID").ToString() + "'")
                    If foundRow.Length > 0 Then
                        For count2 = 0 To foundRow.Length - 1
                            CannedMasterDT.ImportRow(foundRow(count2))
                        Next count2
                    End If
                Next
                CannedMasterDT.AcceptChanges()
                CannedMasterDT.Merge(TempCannedDT)
                CannedMasterDT.TableName = "Canned"
                ds.Tables.Add(CannedMasterDT)
            End With
            Return ds
        End Function
    End Class

End Namespace





@


1.1.1.1
log
@no message
@
text
@@
