head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.23;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.23;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic
Imports System.Collections.Generic


Namespace DataAccessLayer
    Public Class HotelFeeDAL
        Inherits BaseDA

        Public Function GetHotelFeeByName(Optional ByVal Name As String = "") As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblHotelFee"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    If Not Name = "" Then
                        .Add("Name", Name, SqlBuilder.SQLParserDataType.spText, True)
                    End If
                    .Add("*")
                    .Add("(Select Count (c.[HotelFeeName]) From tblHotelClientFee c Where c.HotelFeeName = Name) As InUsed")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetHotelFee() As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblHotelFee"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("*")
                    .Add("(Select Count (c.[HotelFeeName]) From tblHotelClientFee c Where c.HotelFeeName = Name) As InUsed")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function DeleteHotelFee(ByVal Number As Integer) As Integer
            Dim effectRow As Integer
            With Me.MySQLParser
                .TableName = "tblHotelFee"
                With .Columns
                    .Clear()
                    .Add("Number", Number, SqlBuilder.SQLParserDataType.spNum, True)
                End With
                CallProcedure(Number, "", "Delete", "sp_HotelFee")
                effectRow = .ExecuteDelete()
            End With
            DeleteDataFrHotelClient(Number)
            Return effectRow
        End Function

        'Comment : set Amount As string because i nid to determine whether the value is $ or %
        Public Function InsertFee(ByVal HotelFee As DataTable) As Integer
            Dim effectRow As Integer
            Dim countDT As Integer
            With Me.MySQLParser
                .TableName = "tblHotelFee"
                For countDT = 0 To HotelFee.Rows.Count - 1
                    If HotelFee.Rows(countDT).Item("Status").ToString() = "Insert" Then
                        With .Columns
                            .IncludeKey = False
                            .Clear()
                            .Add("Name", HotelFee.Rows(countDT).Item("Name").ToString(), SqlBuilder.SQLParserDataType.spText)
                            .Add("Criteria", HotelFee.Rows(countDT).Item("Criteria").ToString(), SqlBuilder.SQLParserDataType.spText)
                            .Add("Amount", HotelFee.Rows(countDT).Item("Amount").ToString(), SqlBuilder.SQLParserDataType.spText)
                        End With
                        effectRow = .ExecuteInsert()
                        CallProcedure(GetLastID, "", "Insert", "sp_HotelFee")
                    ElseIf HotelFee.Rows(countDT).Item("Status").ToString() = "Update" Then
                        With .Columns
                            .Clear()
                            .Add("Number", HotelFee.Rows(countDT).Item("Number").ToString(), SqlBuilder.SQLParserDataType.spNum, True)
                            .Add("Name", HotelFee.Rows(countDT).Item("Name").ToString())
                            .Add("Criteria", HotelFee.Rows(countDT).Item("Criteria").ToString())
                            .Add("Amount", HotelFee.Rows(countDT).Item("Amount").ToString())
                        End With
                        CallProcedure(HotelFee.Rows(countDT).Item("Number").ToString(), "", "Update", "sp_HotelFee")
                        effectRow = .ExecuteUpdate()
                    ElseIf HotelFee.Rows(countDT).Item("Status").ToString() = "" Then  'delete no need to run this part
                        effectRow = 1
                    End If
                Next
            End With
            Return effectRow
        End Function

        Public Function GetFeeName()
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblHotelFee"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("Name")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetClientFeeName(ByVal ClientID As String)
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblHotelClientFee"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("HotelFeeName")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function SaveData(ByVal ClientID As Integer, ByVal FeeName As String) As Integer
            Dim effectRow As Integer
            Dim dt As DataTable

            dt = GetClientFeeName(ClientID)

            If dt.Rows.Count > 0 Then
                CallProcedure(ClientID, dt.Rows(0).Item(0), "Update", "sp_HotelClientFee")
            End If

            With Me.MySQLParser
                .TableName = "tblHotelClientFee"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    '.Add("HotelFeeName", FeeName, SqlBuilder.SQLParserDataType.spText, True)
                End With
                effectRow = .ExecuteDelete()

                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum)
                    .Add("HotelFeeName", FeeName, SqlBuilder.SQLParserDataType.spText)
                End With
                effectRow = .ExecuteInsert()

                If dt.Rows.Count < 1 Then
                    CallProcedure(ClientID, FeeName, "Insert", "sp_HotelClientFee")
                End If

            End With
            Return effectRow
        End Function

        Private Sub CallProcedure(ByVal ID As String, ByVal HotelFeeName As String, ByVal Type As String, ByVal StoreProdType As String)
            If HotelFeeName = "" Then
                With Me.MySQLParser
                    .ExecuteStoreProcedure("exec " + StoreProdType + " '" + ID + "','" + ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName + "','" + Type + "'")
                End With
            Else
                With Me.MySQLParser
                    .ExecuteStoreProcedure("exec " + StoreProdType + " '" + ID + "','" + HotelFeeName + "','" + ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName + "','" + Type + "'")
                End With
            End If
        End Sub

        Public Function DeleteDataFrHotelClient(ByVal Number As String)
            Dim effect As Integer
            With Me.MySQLParser
                .TableName = "tblHotelClientFee"
                With .Columns
                    .Clear()
                    .Add("HotelFeeName", "(select Name from tblHotelFee)", SqlBuilder.SQLParserDataType.spFunction, True, "not in")
                    '.Add("hf.Number", Number, SqlBuilder.SQLParserDataType.spNum, True)
                    '.Add("hc")
                End With
                effect = .ExecuteDelete()
            End With
            Return effect
        End Function

        Public Function UpdateHotelFee(ByVal HotelFee As DataTable)
            Dim effect As Integer
            Dim countDT As Integer
            With Me.MySQLParser
                .TableName = "tblHotelFee"
                For countDT = 0 To HotelFee.Rows.Count - 1
                    If HotelFee.Rows(countDT).Item("Status").ToString() = "Update" Then
                        With .Columns
                            .Clear()
                            .Add("Number", HotelFee.Rows(countDT).Item("Number").ToString(), SqlBuilder.SQLParserDataType.spNum, True)
                            .Add("Name", HotelFee.Rows(countDT).Item("Name").ToString())
                            .Add("Criteria", HotelFee.Rows(countDT).Item("Criteria").ToString())
                            .Add("Amount", HotelFee.Rows(countDT).Item("Amount").ToString())
                        End With
                        CallProcedure(HotelFee.Rows(countDT).Item("Number").ToString(), "", "Update", "sp_HotelFee")
                        effect = .ExecuteUpdate()
                    End If
                Next
            End With
            Return effect
        End Function

        Public Function GetHotelByNumber(ByVal Number As Integer) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblHotelFee"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("Number", Number, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function UpdateHotelFeeName(ByVal Number As Integer, ByVal Name As String)
            Dim effect As Integer
            With Me.MySQLParser
                .TableName = "tblHotelFee"
                With .Columns
                    .Clear()
                    .Add("Number", Number, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("Name", Name)
                End With
                CallProcedure(Number, "", "Update", "sp_HotelFee")
                effect = .ExecuteUpdate()
            End With
            Return effect
        End Function

        Private Function GetLastID() As String
            Dim ID As String
            With Me.MySQLParser
                .TableName = "tblHotelFee"
                With .Columns
                    .Clear()
                    .Add("max(Number)")
                End With
                ID = .ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar)
            End With
            Return ID
        End Function

        Public Function GetTempHotelFee(Optional ByVal HotelName As String = "", Optional ByVal dateFrom As String = "", Optional ByVal dateTo As String = "") As DataSet
            Dim HotelDT As DataTable
            Dim TempHotelDT As DataTable
            Dim HotelMasterDT As DataTable

            Dim ds As New DataSet
            Dim TempTable As DataTable
            Dim ClientIDArr(0) As String
            Dim count As Integer
            Dim count2 As Integer
            Dim foundRow() As DataRow


            ClientIDArr(0) = "Number"

            With Me.MySQLParser
                .TableName = "Temp_tblHotelFee"
                With .Columns
                    .Clear()
                    If HotelName <> "" Then
                        .Add("Name", HotelName, SqlBuilder.SQLParserDataType.spText, True)
                    End If
                    If dateFrom = dateTo Then
                        If dateFrom <> "" And dateTo <> "" Then
                            dateTo = dateTo + " 23:59:59:990"
                            .Add("DateModification", "convert(varchar,cast('" + dateFrom + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, ">")
                            .Add("DateModification", "convert(varchar,cast('" + dateTo + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, "<")
                        End If
                    Else
                        If dateFrom <> "" Then
                            .Add("DateModification", dateFrom, SqlBuilder.SQLParserDataType.spDate, True, ">")
                        End If
                        If dateTo <> "" Then
                            dateTo = dateTo + " 23:59:59:999"
                            .Add("DateModification", dateTo, SqlBuilder.SQLParserDataType.spText, True, "<=")
                        End If
                    End If
                    .Add("*")
                End With
                TempHotelDT = .ExecuteDataTable(.SQLSelect + " order by DateModification Desc")

                .TableName = "tblHotelFee"
                With .Columns
                    .Clear()
                    If HotelName <> "" Then
                        .Add("Name", HotelName, SqlBuilder.SQLParserDataType.spText, True)
                    End If
                    .Add("*")
                End With
                HotelDT = .ExecuteDataTable()

                TempTable = TempHotelDT.DefaultView.ToTable(True, ClientIDArr)
                HotelMasterDT = TempHotelDT.Clone()
                For count = 0 To TempTable.Rows.Count - 1
                    foundRow = HotelDT.Select("Number='" + TempTable.Rows(count).Item("Number").ToString() + "'")
                    If foundRow.Length > 0 Then
                        For count2 = 0 To foundRow.Length - 1
                            HotelMasterDT.ImportRow(foundRow(count2))
                        Next count2
                    End If
                Next
                HotelMasterDT.AcceptChanges()
                HotelMasterDT.Merge(TempHotelDT)
                HotelMasterDT.TableName = "HotelFee"
                ds.Tables.Add(HotelMasterDT)
            End With
            Return ds
        End Function

        Public Function GetClientIDByName(ByVal ClientName As String) As String
            Dim retVal As String
            Dim retObj As Object
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblClientMaster"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("Name", ClientName, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("ClientID")
                End With
                retObj = .ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar, CommandType.Text)
                retVal = Util.DBNullToText(retObj)
            End With
            Return retVal
        End Function

        Public Function GetTempClientHotelFee(Optional ByVal ClientName As String = "", Optional ByVal dateFrom As String = "", Optional ByVal dateTo As String = "") As DataSet
            '//Client Hotel Fee
            Dim HotelDT As DataTable
            Dim TempHotelDT As DataTable
            Dim HotelMasterDT As DataTable

            Dim ClientID As String = ""
            Dim TempTable As DataTable
            Dim ClientIDArr(0) As String
            Dim count As Integer
            Dim count2 As Integer
            Dim ds As New DataSet
            Dim foundRow() As DataRow

            ClientIDArr(0) = "ClientID"
            'ClientIDArr(1) = "HotelClientFeeID"

            '//Get ClientID 
            If ClientName <> "" Then
                ClientID = GetClientIDByName(ClientName)
            End If

            With Me.MySQLParser
                .TableName = "Temp_tblHotelClientFee"
                With .Columns
                    .Clear()
                    If ClientName <> "" Then
                        If ClientID <> "" Then
                            .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        Else
                            .Add("ClientID", "-1", SqlBuilder.SQLParserDataType.spNum, True)
                        End If
                    End If
                    If dateFrom = dateTo Then
                        If dateFrom <> "" And dateTo <> "" Then
                            dateTo = dateTo + " 23:59:59:990"
                            .Add("DateModification", "convert(varchar,cast('" + dateFrom + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, ">")
                            .Add("DateModification", "convert(varchar,cast('" + dateTo + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, "<")
                        End If
                    Else
                        If dateFrom <> "" Then
                            .Add("DateModification", dateFrom, SqlBuilder.SQLParserDataType.spDate, True, ">")
                        End If
                        If dateTo <> "" Then
                            dateTo = dateTo + " 23:59:59:999"
                            .Add("DateModification", dateTo, SqlBuilder.SQLParserDataType.spText, True, "<=")
                        End If
                    End If
                    .Add("*")
                End With
                TempHotelDT = .ExecuteDataTable(.SQLSelect + " order by DateModification Desc")

                .TableName = "tblHotelClientFee"
                With .Columns
                    .Clear()
                    If ClientName <> "" Then
                        If ClientID <> "" Then
                            .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        Else
                            .Add("ClientID", "-1", SqlBuilder.SQLParserDataType.spNum, True)
                        End If
                    End If
                    .Add("*")
                End With
                HotelDT = .ExecuteDataTable()

                TempTable = TempHotelDT.DefaultView.ToTable(True, ClientIDArr)
                HotelMasterDT = TempHotelDT.Clone()
                For count = 0 To TempTable.Rows.Count - 1
                    foundRow = HotelDT.Select("ClientID='" + TempTable.Rows(count).Item("ClientID").ToString() + "'")
                    If foundRow.Length > 0 Then
                        For count2 = 0 To foundRow.Length - 1
                            HotelMasterDT.ImportRow(foundRow(count2))
                        Next count2
                    End If
                Next
                HotelMasterDT.AcceptChanges()
                HotelMasterDT.Merge(TempHotelDT)
                HotelMasterDT.TableName = "HotelClient"
                ds.Tables.Add(HotelMasterDT)
            End With
            Return ds
        End Function

        'Public Function UpdateDataToHotellClient(ByVal Name As String)
        '    Dim effect As Integer
        '    With Me.MySQLParser
        '        .TableName = "tblHotelClientFee"
        '        With .Columns
        '            .Clear()
        '            .Add("HotelFeeName", "(select Name From tblHotelFee)", SqlBuilder.SQLParserDataType.spFunction, True, )
        '        End With
        '    End With
        'End Function
    End Class
End Namespace@


1.1.1.1
log
@no message
@
text
@@
