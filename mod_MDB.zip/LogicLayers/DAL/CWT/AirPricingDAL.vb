head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.23;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.23;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic
Imports System.Collections.Generic

Namespace DataAccessLayer
    Public Class AirPricingDAL
        Inherits BaseDA

        Public Function GetAirVariablesList() As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = CWTMasterDB.Util.StandardDB("tblAirVariables")
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetAirVariableGroups() As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = CWTMasterDB.Util.StandardDB("vw_AirPricing_VariablesGroups")
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetAirOperatorList() As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = CWTMasterDB.Util.StandardDB("tblAirOperator")
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetUsageAirVariables() As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = CWTMasterDB.Util.StandardDB("tblAirVariables")
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("FieldID", "(3,4,5,6,7,9,10,11)", SqlBuilder.SQLParserDataType.spFunction, True, "in")
                    .Add("FieldID")
                    .Add("FieldName")
                    .Add("1 as Usage")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetUsageAirVariables(ByVal AirPricingID As String, ByVal IsInt As Boolean) As DataTable
            Dim dt As DataTable
            Dim IsIntVal As String
            If IsInt Then
                IsIntVal = "1"
            Else
                IsIntVal = "0"
            End If
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = CWTMasterDB.Util.StandardDB("tblAirVariables") + " a left join tblAirPricingVariables p on a.FieldID=p.FieldID and isint=" + IsIntVal + " and AirPricingID=" + AirPricingID
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("a.FieldID", "(3,4,5,6,7,9,10,11)", SqlBuilder.SQLParserDataType.spFunction, True, "in")
                    .Add("a.FieldID")
                    .Add("a.FieldName")
                    .Add("(case when p.FieldID  is not null then 1 else 0 end) as Usage")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetAirPriceList() As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblAirPricingFormula a"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("a.AirPricingID")
                    .Add("a.AirPricingName")
                    .Add("(select count(PricingID) from tblClientMasterPricing where PricingID=a.AirPricingID) as InUse")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetAirPriceData(ByVal RecordID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblAirPricingFormula "
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("AirPricingID", RecordID, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function IsExistName(ByVal Name As String, ByVal ID As String) As Boolean
            Dim EffectRow As Integer
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblAirPricingFormula"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("AirPricingName", Name, SqlBuilder.SQLParserDataType.spText, True)
                    If ID <> "" Then .Add("AirPricingID", ID, SqlBuilder.SQLParserDataType.spText, True, "<>")
                    .Add("Count(*) as NumRec")
                End With
                EffectRow = .ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar)
            End With
            Return (EffectRow > 0)
        End Function

        Public Function UpdateAirPrice(ByVal info As DataInfo.AirPriceInfo) As Integer
            Dim EffectRow As Integer
            Dim dt As DataTable

            If info.PageMode = TransactionMode.UpdateMode Then
                dt = GetAirPriceData(info.ID)
                InsertTempRecord(info, dt, "Int", "Temp_tblAirPricingFormula_Int")
                InsertTempRecord(info, dt, "Dom", "Temp_tblAirPricingFormula_Dom")
                InsertTempRecord(info, dt, "LCC", "Temp_tblAirPricingFormula_LCC")
            End If
                 
            Try
                With Me.MySQLParser
                    .OpenConnection()
                    .BeginTran()
                    .TableName = "tblAirPricingFormula"
                    With .Columns
                        .Clear()
                        If info.ID <> "" Then .Add("AirPricingID", info.ID, SqlBuilder.SQLParserDataType.spNum, True)
                        .Add("AirPricingName", info.Name)
                        .Add("IntTotalAirCom", info.IntFomula.AirCom)
                        .Add("IntTotalMarkUp", info.IntFomula.MarkUp)
                        .Add("IntTotalDiscount", info.IntFomula.Discount)
                        '.Add("IntTotalGST", info.IntFomula.GST)
                        .Add("IntTotalORCom", info.IntFomula.ORCommission)
                        .Add("IntTotalORCom2", info.IntFomula.OrCommission2)
                        '.Add("IntMgtFeeTotal", info.IntFomula.ManagementFee)
                        .Add("IntTotalFare", info.IntFomula.Fare)
                        .Add("IntTotalFareNett", info.IntFomula.NetFare)
                        .Add("IntTotalFee", info.IntFomula.Fee)
                        .Add("IntFuelChargeOption", info.IntFomula.FuelChargeOption)
                        .Add("IntMFFee", info.IntFomula.MFFee)
                        .Add("IntMFFeeTF", info.IntFomula.MFFeeTF)
                        .Add("IntTotalSellingFare", info.IntFomula.SellingFare)
                        .Add("IntTotalCharge", info.IntFomula.Charge)
                        '.Add("IntApplyFee", info.IntFomula.ApplyFee, SqlBuilder.SQLParserDataType.spBoolean)
                        .Add("IntDDLFeeApply", info.IntFomula.DDLFeeApply)
                        .Add("IntApplyMarkUp", info.IntFomula.ApplyMarkUp, SqlBuilder.SQLParserDataType.spBoolean)
                        '.Add("IntMgtFeeApply", info.IntFomula.MgtFeeApply, SqlBuilder.SQLParserDataType.spBoolean)
                        '//
                        .Add("DomSameAsInt", info.DomSameAsInt, SqlBuilder.SQLParserDataType.spBoolean)
                        .Add("LCCSameAsInt", info.LCCSameAsInt, SqlBuilder.SQLParserDataType.spBoolean)
                        If Not info.DomSameAsInt Then
                            .Add("DomTotalAirCom", info.DomFomula.AirCom)
                            .Add("DomTotalMarkUp", info.DomFomula.MarkUp)
                            .Add("DomTotalDiscount", info.DomFomula.Discount)
                            '.Add("DomTotalGST", info.DomFomula.GST)
                            .Add("DomTotalORCom", info.DomFomula.ORCommission)
                            .Add("DomTotalORCom2", info.DomFomula.OrCommission2)
                            '.Add("DomMgtFeeTotal", info.DomFomula.ManagementFee)
                            .Add("DomTotalFare", info.DomFomula.Fare)
                            .Add("DomTotalFareNett", info.DomFomula.NetFare)
                            .Add("DomTotalFee", info.DomFomula.Fee)
                            .Add("DomFuelChargeOption", info.DomFomula.FuelChargeOption)
                            .Add("DomMFFee", info.DomFomula.MFFee)
                            .Add("DomMFFeeTF", info.DomFomula.MFFeeTF)
                            .Add("DomTotalSellingFare", info.DomFomula.SellingFare)
                            .Add("DomTotalCharge", info.DomFomula.Charge)
                            '.Add("DomApplyFee", info.DomFomula.ApplyFee, SqlBuilder.SQLParserDataType.spBoolean)
                            .Add("DOMDDLFeeApply", info.IntFomula.DDLFeeApply)
                            .Add("DomApplyMarkUp", info.DomFomula.ApplyMarkUp, SqlBuilder.SQLParserDataType.spBoolean)
                            '.Add("DomMgtFeeApply", info.DomFomula.MgtFeeApply, SqlBuilder.SQLParserDataType.spBoolean)
                        End If
                        If Not info.LCCSameAsInt Then
                            .Add("LCCTotalAirCom", info.LCCFomula.AirCom)
                            .Add("LCCTotalMarkUp", info.LCCFomula.MarkUp)
                            .Add("LCCTotalDiscount", info.LCCFomula.Discount)
                            '.Add("LCCTotalGST", info.LCCFomula.GST)
                            .Add("LCCTotalSellingFare", info.LCCFomula.SellingFare)
                            .Add("LCCTotalCharge", info.LCCFomula.Charge)
                            .Add("LCCTotalORCom", info.LCCFomula.ORCommission)
                            .Add("LCCTotalORCom2", info.LCCFomula.OrCommission2)
                            .Add("LCCFuelChargeOption", info.LCCFomula.FuelChargeOption)
                            .Add("LCCMFFee", info.LCCFomula.MFFee)
                            .Add("LCCMFFeeTF", info.LCCFomula.MFFeeTF)
                            '.Add("LCCApplyFee", info.LCCFomula.ApplyFee, SqlBuilder.SQLParserDataType.spBoolean)
                            .Add("LCCDDLFeeApply", info.IntFomula.DDLFeeApply)
                            .Add("LCCApplyMarkUp", info.LCCFomula.ApplyMarkUp, SqlBuilder.SQLParserDataType.spBoolean)
                            ' .Add("LCCMgtFeeApply", info.LCCFomula.MgtFeeApply, SqlBuilder.SQLParserDataType.spBoolean)
                            '.Add("LCCMgtFeeTotal", info.LCCFomula.ManagementFee)
                            .Add("LCCTotalFare", info.LCCFomula.Fare)
                            .Add("LCCTotalFareNett", info.LCCFomula.NetFare)
                            .Add("LCCTotalFee", info.LCCFomula.Fee)
                        End If
                    End With

                    Select Case info.PageMode
                        Case CWTMasterDB.TransactionMode.AddNewMode
                            EffectRow = .ExecuteInsert()
                            '.ExecuteStoreProcedure("exec sp_AirPricingFormula '" + info.ID + "','" + ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName + "','Insert'")
                            info.ID = .GetLastIdentity
                        Case CWTMasterDB.TransactionMode.UpdateMode
                            '.ExecuteStoreProcedure("exec sp_AirPricingFormula '" + info.ID + "','" + ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName + "','Update'")
                            EffectRow = .ExecuteUpdate()
                            '//
                            .TableName = "tblAirPricingVariables"
                            With .Columns
                                .Clear()
                                .Add("AirPricingID", info.ID, SqlBuilder.SQLParserDataType.spNum, True)
                            End With
                            'not using anymore. 
                            '.ExecuteStoreProcedure("exec sp_AirPricingVariables '" + info.ID + "','" + ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName + "','Delete'")
                            .ExecuteDelete()
                    End Select
                    'If EffectRow > 0 Then
                    '    For i As Integer = 0 To info.IntFomula.UsageList.Count - 1
                    '        .TableName = "tblAirPricingVariables"
                    '        With .Columns
                    '            .Clear()
                    '            .Add("AirPricingID", info.ID, SqlBuilder.SQLParserDataType.spNum)
                    '            .Add("FieldID", info.IntFomula.UsageList(i), SqlBuilder.SQLParserDataType.spNum)
                    '            .Add("IsInt", True, SqlBuilder.SQLParserDataType.spBoolean)
                    '        End With
                    '        EffectRow = .ExecuteInsert()
                    '        If EffectRow <= 0 Then
                    '            Exit For
                    '        End If
                    '    Next
                    '    If EffectRow > 0 AndAlso Not info.DomSameAsInt Then
                    '        For i As Integer = 0 To info.DomFomula.UsageList.Count - 1
                    '            .TableName = "tblAirPricingVariables"
                    '            With .Columns
                    '                .Clear()
                    '                .Add("AirPricingID", info.ID, SqlBuilder.SQLParserDataType.spNum)
                    '                .Add("FieldID", info.DomFomula.UsageList(i), SqlBuilder.SQLParserDataType.spNum)
                    '                .Add("IsInt", False, SqlBuilder.SQLParserDataType.spBoolean)
                    '            End With
                    '            EffectRow = .ExecuteInsert()
                    '            If EffectRow <= 0 Then
                    '                Exit For
                    '            End If
                    '        Next
                    '    End If
                    'End If
                End With
                If EffectRow > 0 Then
                    Me.MySQLParser.CommitTran()
                Else
                    Me.MySQLParser.RollbackTran()
                End If

                If info.PageMode = TransactionMode.AddNewMode Then
                    InsertNewRecordToTemp(info, "Int", "Temp_tblAirPricingFormula_Int")
                    InsertNewRecordToTemp(info, "Dom", "Temp_tblAirPricingFormula_Dom")
                    InsertNewRecordToTemp(info, "LCC", "Temp_tblAirPricingFormula_LCC")
                End If
               

            Catch ex As Exception
                EffectRow = -1
                Me.MySQLParser.RollbackTran()
            Finally
                Me.MySQLParser.CloseConnection()
            End Try
            Return EffectRow
        End Function

        Public Function DeleteAirPricing(ByVal AirPricingID As String) As Integer
            Dim EffectRow As Integer
            'Dim dt As DataTable
            'Dim CMPID As Integer

            Dim AirPricingDT As DataTable
            AirPricingDT = GetAirPriceData(AirPricingID)
            InsertDeletedRecordToTemp(AirPricingDT, "Int", AirPricingID, "Temp_tblAirPricingFormula_Int")
            InsertDeletedRecordToTemp(AirPricingDT, "Dom", AirPricingID, "Temp_tblAirPricingFormula_Dom")
            InsertDeletedRecordToTemp(AirPricingDT, "LCC", AirPricingID, "Temp_tblAirPricingFormula_LCC")
            Try
                With Me.MySQLParser
                    .TableName = "tblAirPricingFormula"
                    With .Columns
                        .Clear()
                        .Add("AirPricingID", AirPricingID, SqlBuilder.SQLParserDataType.spNum, True)
                    End With
                    '.ExecuteStoreProcedure("exec sp_AirPricingFormula '" + AirPricingID + "','" + ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName + "','Delete'")
                    EffectRow = .ExecuteDelete()
                End With

                'With Me.MySQLParser
                '    .TableName = "tblClientMasterPricing"
                '    With .Columns
                '        .Clear()
                '        .Add("PricingID", AirPricingID, SqlBuilder.SQLParserDataType.spNum, True)
                '        .Add("CMPID")
                '    End With
                '    dt = .ExecuteDataTable()
                'End With

                'For i As Integer = 0 To dt.Rows.Count - 1
                '    CMPID = dt.Rows(i).Item("CMPID")

                '    With Me.MySQLParser
                '        .TableName = "tblClientPricing"
                '        With .Columns
                '            .Clear()
                '            .Add("CMPID", CMPID, SqlBuilder.SQLParserDataType.spNum, True)
                '        End With
                '        EffectRow = .ExecuteDelete()
                '    End With
                'Next

                'With Me.MySQLParser
                '    .TableName = "tblClientMasterPricing"
                '    With .Columns
                '        .Clear()
                '        .Add("PricingID", AirPricingID, SqlBuilder.SQLParserDataType.spNum, True)
                '    End With
                '    EffectRow = .ExecuteDelete()
                'End With

                If EffectRow > 0 Then
                    Me.MySQLParser.CommitTran()
                Else
                    Me.MySQLParser.RollbackTran()
                End If

            Catch ex As Exception
                EffectRow = -1
                Me.MySQLParser.RollbackTran()
            Finally
                Me.MySQLParser.CloseConnection()
            End Try

            Return EffectRow
        End Function

        Public Function ModifiedRecordAirPricing(ByVal info As DataInfo.AirPriceInfo, ByVal AirPricingDT As DataTable, ByVal Type As String) As Boolean
            Dim MatchRecord As Boolean = False

            Try

                For i As Integer = 0 To AirPricingDT.Rows.Count - 1
                    If Type = "Dom" Then
                        If info.DomFomula IsNot Nothing Then
                            If AirPricingDT.Rows(i).Item("AirPricingID").ToString() = info.ID And AirPricingDT.Rows(i).Item("AirPricingName").ToString() = info.Name And AirPricingDT.Rows(i).Item("DomSameAsInt").ToString() = info.DomSameAsInt And AirPricingDT.Rows(i).Item("DomTotalAirCom").ToString() = info.DomFomula.AirCom And AirPricingDT.Rows(i).Item("DomTotalMarkUp").ToString() = info.DomFomula.MarkUp And AirPricingDT.Rows(i).Item("DomTotalDiscount").ToString() = info.DomFomula.Discount And AirPricingDT.Rows(i).Item("DomTotalFare").ToString() = info.DomFomula.Fare And AirPricingDT.Rows(i).Item("DomTotalORCom").ToString() = info.DomFomula.ORCommission And AirPricingDT.Rows(i).Item("DomTotalORCom2").ToString() = info.DomFomula.OrCommission2 And AirPricingDT.Rows(i).Item("DomFuelChargeOption").ToString() = info.DomFomula.FuelChargeOption And AirPricingDT.Rows(i).Item("DomMFFee").ToString() = info.DomFomula.MFFee And AirPricingDT.Rows(i).Item("DOMMFFeeTF").ToString() = info.DomFomula.MFFeeTF And AirPricingDT.Rows(i).Item("DomDDLFeeApply").ToString() = info.DomFomula.DDLFeeApply And AirPricingDT.Rows(i).Item("DomApplyMarkUp").ToString() = info.DomFomula.ApplyMarkUp And AirPricingDT.Rows(i).Item("DomTotalFareNett").ToString() = info.DomFomula.NetFare And AirPricingDT.Rows(i).Item("DomTotalFee").ToString() = info.DomFomula.Fee And AirPricingDT.Rows(i).Item("DomTotalSellingFare").ToString() = info.DomFomula.SellingFare And AirPricingDT.Rows(i).Item("DomTotalCharge").ToString() = info.DomFomula.Charge Then
                                MatchRecord = False
                            Else
                                MatchRecord = True
                            End If
                        Else
                            MatchRecord = False
                        End If
                    End If


                    If Type = "Int" Then
                        If info.IntFomula IsNot Nothing Then
                            If AirPricingDT.Rows(i).Item("AirPricingID").ToString() = info.ID And AirPricingDT.Rows(i).Item("AirPricingName").ToString() = info.Name And AirPricingDT.Rows(i).Item("IntTotalAirCom").ToString() = info.IntFomula.AirCom And AirPricingDT.Rows(i).Item("IntTotalMarkUp").ToString() = info.IntFomula.MarkUp And AirPricingDT.Rows(i).Item("IntTotalDiscount").ToString() = info.IntFomula.Discount And AirPricingDT.Rows(i).Item("IntTotalFare").ToString() = info.IntFomula.Fare And AirPricingDT.Rows(i).Item("IntTotalORCom").ToString() = info.IntFomula.ORCommission And AirPricingDT.Rows(i).Item("IntTotalORCom2").ToString() = info.IntFomula.OrCommission2 And AirPricingDT.Rows(i).Item("IntFuelChargeOption").ToString() = info.IntFomula.FuelChargeOption And AirPricingDT.Rows(i).Item("IntMFFee").ToString() = info.IntFomula.MFFee And AirPricingDT.Rows(i).Item("IntMFFeeTF").ToString() = info.IntFomula.MFFeeTF And AirPricingDT.Rows(i).Item("IntDDLFeeApply").ToString() = info.IntFomula.DDLFeeApply And AirPricingDT.Rows(i).Item("IntApplyMarkUp").ToString() = info.IntFomula.ApplyMarkUp And AirPricingDT.Rows(i).Item("IntTotalFareNett").ToString() = info.IntFomula.NetFare And AirPricingDT.Rows(i).Item("IntTotalFee").ToString() = info.IntFomula.Fee And AirPricingDT.Rows(i).Item("IntTotalSellingFare").ToString() = info.IntFomula.SellingFare And AirPricingDT.Rows(i).Item("IntTotalCharge").ToString() = info.IntFomula.Charge Then
                                MatchRecord = False
                            Else
                                MatchRecord = True
                            End If
                        Else
                            MatchRecord = False
                        End If
                        
                    End If

                    If Type = "LCC" Then
                        If info.LCCFomula IsNot Nothing Then
                            If AirPricingDT.Rows(i).Item("AirPricingID").ToString() = info.ID And AirPricingDT.Rows(i).Item("AirPricingName").ToString() = info.Name And AirPricingDT.Rows(i).Item("LCCSameAsInt").ToString() = info.LCCSameAsInt And AirPricingDT.Rows(i).Item("LCCTotalAirCom").ToString() = info.LCCFomula.AirCom And AirPricingDT.Rows(i).Item("LCCTotalMarkUp").ToString() = info.LCCFomula.MarkUp And AirPricingDT.Rows(i).Item("LCCTotalDiscount").ToString() = info.LCCFomula.Discount And AirPricingDT.Rows(i).Item("LCCTotalFare").ToString() = info.LCCFomula.Fare And AirPricingDT.Rows(i).Item("LCCTotalORCom").ToString() = info.LCCFomula.ORCommission And AirPricingDT.Rows(i).Item("LCCTotalORCom2").ToString() = info.LCCFomula.OrCommission2 And AirPricingDT.Rows(i).Item("LCCFuelChargeOption").ToString() = info.LCCFomula.FuelChargeOption And AirPricingDT.Rows(i).Item("LCCMFFee").ToString() = info.LCCFomula.MFFee And AirPricingDT.Rows(i).Item("LCCMFFeeTF").ToString() = info.LCCFomula.MFFeeTF And AirPricingDT.Rows(i).Item("LCCDDLFeeApply").ToString() = info.LCCFomula.DDLFeeApply And AirPricingDT.Rows(i).Item("LCCApplyMarkUp").ToString() = info.LCCFomula.ApplyMarkUp And AirPricingDT.Rows(i).Item("LCCTotalFareNett").ToString() = info.LCCFomula.NetFare And AirPricingDT.Rows(i).Item("LCCTotalFee").ToString() = info.LCCFomula.Fee And AirPricingDT.Rows(i).Item("LCCTotalSellingFare").ToString() = info.LCCFomula.SellingFare And AirPricingDT.Rows(i).Item("LCCTotalCharge").ToString() = info.LCCFomula.Charge Then
                                MatchRecord = False
                            Else
                                MatchRecord = True
                            End If
                        Else
                            MatchRecord = False
                        End If
                        
                    End If



                Next


            Catch ex As Exception

            End Try
            Return MatchRecord
        End Function

        Public Sub InsertTempRecord(ByVal info As DataInfo.AirPriceInfo, ByVal AirPricingDT As DataTable, ByVal Type As String, ByVal TableName As String)
            Dim InsertRecord As Boolean = False
            Dim EffectRow As Integer

            Try
                If info.ID <> "" Then
                    If ModifiedRecordAirPricing(info, AirPricingDT, Type) Then
                        With Me.MySQLParser
                            .OpenConnection()
                            .BeginTran()
                            .TableName = TableName
                            With .Columns
                                .Clear()
                                For i As Integer = 0 To AirPricingDT.Rows.Count - 1
                                    .Add("AirPricingID", AirPricingDT.Rows(i).Item("AirPricingID"), SqlBuilder.SQLParserDataType.spNum)
                                    .Add("AirPricingName", AirPricingDT.Rows(i).Item("AirPricingName"))
                                    If Type = "Int" Then
                                        .Add("IntTotalAirCom", AirPricingDT.Rows(i).Item("IntTotalAirCom").ToString())
                                        .Add("IntTotalMarkUp", AirPricingDT.Rows(i).Item("IntTotalMarkUp").ToString())
                                        .Add("IntTotalDiscount", AirPricingDT.Rows(i).Item("IntTotalDiscount").ToString())
                                        .Add("IntTotalORCom", AirPricingDT.Rows(i).Item("IntTotalORCom").ToString())
                                        .Add("IntTotalORCom2", AirPricingDT.Rows(i).Item("IntTotalORCom2").ToString())
                                        .Add("IntTotalFare", AirPricingDT.Rows(i).Item("IntTotalFare").ToString())
                                        .Add("IntTotalFareNett", AirPricingDT.Rows(i).Item("IntTotalFareNett").ToString())
                                        .Add("IntTotalFee", AirPricingDT.Rows(i).Item("IntTotalFee").ToString())
                                        .Add("IntFuelChargeOption", AirPricingDT.Rows(i).Item("IntFuelChargeOption").ToString())
                                        .Add("IntMFFee", AirPricingDT.Rows(i).Item("IntMFFee").ToString())
                                        .Add("IntMFFeeTF", AirPricingDT.Rows(i).Item("IntMFFeeTF").ToString())
                                        .Add("IntTotalSellingFare", AirPricingDT.Rows(i).Item("IntTotalSellingFare").ToString())
                                        .Add("IntTotalCharge", AirPricingDT.Rows(i).Item("IntTotalCharge").ToString())
                                        .Add("IntDDLFeeApply", AirPricingDT.Rows(i).Item("IntDDLFeeApply").ToString())
                                        .Add("IntApplyMarkUp", AirPricingDT.Rows(i).Item("IntApplyMarkUp").ToString(), SqlBuilder.SQLParserDataType.spBoolean)
                                    ElseIf Type = "Dom" Then
                                        .Add("DomSameAsInt", AirPricingDT.Rows(i).Item("DomSameAsInt"), SqlBuilder.SQLParserDataType.spBoolean)
                                        .Add("DomTotalAirCom", AirPricingDT.Rows(i).Item("DomTotalAirCom").ToString())
                                        .Add("DomTotalMarkUp", AirPricingDT.Rows(i).Item("DomTotalMarkUp").ToString())
                                        .Add("DomTotalDiscount", AirPricingDT.Rows(i).Item("DomTotalDiscount").ToString())
                                        .Add("DomTotalORCom", AirPricingDT.Rows(i).Item("DomTotalORCom2").ToString())
                                        .Add("DomTotalORCom2", AirPricingDT.Rows(i).Item("DomTotalORCom2").ToString())
                                        .Add("DomTotalFare", AirPricingDT.Rows(i).Item("DomTotalFare").ToString().ToString())
                                        .Add("DomTotalFareNett", AirPricingDT.Rows(i).Item("DomTotalFareNett").ToString())
                                        .Add("DomTotalFee", AirPricingDT.Rows(i).Item("DomTotalFee").ToString())
                                        .Add("DomFuelChargeOption", AirPricingDT.Rows(i).Item("DomFuelChargeOption").ToString())
                                        .Add("DomMFFee", AirPricingDT.Rows(i).Item("DomMFFee").ToString())
                                        .Add("DomMFFeeTF", AirPricingDT.Rows(i).Item("DomMFFeeTF").ToString())
                                        .Add("DomTotalSellingFare", AirPricingDT.Rows(i).Item("DomTotalSellingFare").ToString())
                                        .Add("DomTotalCharge", AirPricingDT.Rows(i).Item("DomTotalCharge").ToString())
                                        .Add("DOMDDLFeeApply", AirPricingDT.Rows(i).Item("DOMDDLFeeApply").ToString())
                                        .Add("DomApplyMarkUp", AirPricingDT.Rows(i).Item("DomApplyMarkUp").ToString(), SqlBuilder.SQLParserDataType.spBoolean)
                                    ElseIf Type = "LCC" Then
                                        .Add("LCCSameAsInt", AirPricingDT.Rows(i).Item("LCCSameAsInt"), SqlBuilder.SQLParserDataType.spBoolean)
                                        .Add("LCCTotalAirCom", AirPricingDT.Rows(i).Item("LCCTotalAirCom").ToString())
                                        .Add("LCCTotalMarkUp", AirPricingDT.Rows(i).Item("LCCTotalMarkUp").ToString())
                                        .Add("LCCTotalDiscount", AirPricingDT.Rows(i).Item("LCCTotalDiscount").ToString())
                                        .Add("LCCTotalSellingFare", AirPricingDT.Rows(i).Item("LCCTotalSellingFare").ToString())
                                        .Add("LCCTotalCharge", AirPricingDT.Rows(i).Item("LCCTotalCharge").ToString())
                                        .Add("LCCTotalORCom", AirPricingDT.Rows(i).Item("LCCTotalORCom").ToString())
                                        .Add("LCCTotalORCom2", AirPricingDT.Rows(i).Item("LCCTotalORCom2").ToString())
                                        .Add("LCCFuelChargeOption", AirPricingDT.Rows(i).Item("LCCFuelChargeOption").ToString())
                                        .Add("LCCMFFee", AirPricingDT.Rows(i).Item("LCCMFFee").ToString())
                                        .Add("LCCMFFeeTF", AirPricingDT.Rows(i).Item("LCCMFFeeTF").ToString())
                                        .Add("LCCDDLFeeApply", AirPricingDT.Rows(i).Item("LCCDDLFeeApply").ToString())
                                        .Add("LCCApplyMarkUp", AirPricingDT.Rows(i).Item("LCCApplyMarkUp").ToString(), SqlBuilder.SQLParserDataType.spBoolean)
                                        .Add("LCCTotalFare", AirPricingDT.Rows(i).Item("LCCTotalFare").ToString())
                                        .Add("LCCTotalFareNett", AirPricingDT.Rows(i).Item("LCCTotalFareNett").ToString())
                                        .Add("LCCTotalFee", AirPricingDT.Rows(i).Item("LCCTotalFee").ToString())
                                    End If
                                    .Add("DateModification", DateTime.Now)
                                    .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                    .Add("ValueChangeType", "Update")
                                Next

                            End With
                            EffectRow = .ExecuteInsert()
                        End With

                        If EffectRow > 0 Then
                            Me.MySQLParser.CommitTran()
                        Else
                            Me.MySQLParser.RollbackTran()
                        End If
                    End If
                End If
            Catch ex As Exception
                EffectRow = -1
                Me.MySQLParser.RollbackTran()
            Finally
                Me.MySQLParser.CloseConnection()
            End Try
        End Sub

        Public Sub InsertNewRecordToTemp(ByVal info As DataInfo.AirPriceInfo, ByVal Type As String, ByVal TableName As String)
            Dim EffectRow As Integer

            Try
                With Me.MySQLParser
                    .OpenConnection()
                    .BeginTran()
                    .TableName = TableName
                    With .Columns
                        .Clear()
                        .Add("AirPricingID", info.ID, SqlBuilder.SQLParserDataType.spNum)
                        .Add("AirPricingName", info.Name)
                        If Type = "Int" Then
                            .Add("IntTotalAirCom", info.IntFomula.AirCom)
                            .Add("IntTotalMarkUp", info.IntFomula.MarkUp)
                            .Add("IntTotalDiscount", info.IntFomula.Discount)
                            .Add("IntTotalORCom", info.IntFomula.ORCommission)
                            .Add("IntTotalORCom2", info.IntFomula.OrCommission2)
                            .Add("IntTotalFare", info.IntFomula.Fare)
                            .Add("IntTotalFareNett", info.IntFomula.NetFare)
                            .Add("IntTotalFee", info.IntFomula.Fee)
                            .Add("IntFuelChargeOption", info.IntFomula.FuelChargeOption)
                            .Add("IntMFFee", info.IntFomula.MFFee)
                            .Add("IntMFFeeTF", info.IntFomula.MFFeeTF)
                            .Add("IntTotalSellingFare", info.IntFomula.SellingFare)
                            .Add("IntTotalCharge", info.IntFomula.Charge)
                            .Add("IntDDLFeeApply", info.IntFomula.DDLFeeApply)
                            .Add("IntApplyMarkUp", info.IntFomula.ApplyMarkUp, SqlBuilder.SQLParserDataType.spBoolean)
                        ElseIf Type = "Dom" Then
                            If info.DomSameAsInt Then
                                .Add("DomSameAsInt", info.DomSameAsInt, SqlBuilder.SQLParserDataType.spBoolean)
                            Else
                                .Add("DomSameAsInt", info.DomSameAsInt, SqlBuilder.SQLParserDataType.spBoolean)
                                .Add("DomTotalAirCom", info.DomFomula.AirCom)
                                .Add("DomTotalMarkUp", info.DomFomula.MarkUp)
                                .Add("DomTotalDiscount", info.DomFomula.Discount)
                                .Add("DomTotalORCom", info.DomFomula.ORCommission)
                                .Add("DomTotalORCom2", info.DomFomula.OrCommission2)
                                .Add("DomTotalFare", info.DomFomula.Fare)
                                .Add("DomTotalFareNett", info.DomFomula.NetFare)
                                .Add("DomTotalFee", info.DomFomula.Fee)
                                .Add("DomFuelChargeOption", info.DomFomula.FuelChargeOption)
                                .Add("DomMFFee", info.DomFomula.MFFee)
                                .Add("DomMFFeeTF", info.DomFomula.MFFeeTF)
                                .Add("DomTotalSellingFare", info.DomFomula.SellingFare)
                                .Add("DomTotalCharge", info.DomFomula.Charge)
                                .Add("DOMDDLFeeApply", info.IntFomula.DDLFeeApply)
                                .Add("DomApplyMarkUp", info.DomFomula.ApplyMarkUp, SqlBuilder.SQLParserDataType.spBoolean)
                            End If
                            ElseIf Type = "LCC" Then
                            If info.LCCSameAsInt Then
                                .Add("LCCSameAsInt", info.LCCSameAsInt, SqlBuilder.SQLParserDataType.spBoolean)
                            Else
                                .Add("LCCSameAsInt", info.LCCSameAsInt, SqlBuilder.SQLParserDataType.spBoolean)
                                .Add("LCCTotalAirCom", info.LCCFomula.AirCom)
                                .Add("LCCTotalMarkUp", info.LCCFomula.MarkUp)
                                .Add("LCCTotalDiscount", info.LCCFomula.Discount)
                                .Add("LCCTotalSellingFare", info.LCCFomula.SellingFare)
                                .Add("LCCTotalCharge", info.LCCFomula.Charge)
                                .Add("LCCTotalORCom", info.LCCFomula.ORCommission)
                                .Add("LCCTotalORCom2", info.LCCFomula.OrCommission2)
                                .Add("LCCFuelChargeOption", info.LCCFomula.FuelChargeOption)
                                .Add("LCCMFFee", info.LCCFomula.MFFee)
                                .Add("LCCMFFeeTF", info.LCCFomula.MFFeeTF)
                                .Add("LCCDDLFeeApply", info.IntFomula.DDLFeeApply)
                                .Add("LCCApplyMarkUp", info.LCCFomula.ApplyMarkUp, SqlBuilder.SQLParserDataType.spBoolean)
                                .Add("LCCTotalFare", info.LCCFomula.Fare)
                                .Add("LCCTotalFareNett", info.LCCFomula.NetFare)
                                .Add("LCCTotalFee", info.LCCFomula.Fee)
                            End If
                        End If
                            .Add("DateModification", DateTime.Now)
                            .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                            .Add("ValueChangeType", "Insert")
                    End With
                    EffectRow = .ExecuteInsert()
                End With

                If EffectRow > 0 Then
                    Me.MySQLParser.CommitTran()
                Else
                    Me.MySQLParser.RollbackTran()
                End If
            Catch ex As Exception
                EffectRow = -1
                Me.MySQLParser.RollbackTran()
            Finally
                Me.MySQLParser.CloseConnection()
            End Try

        End Sub

        Public Sub InsertDeletedRecordToTemp(ByVal AirPricingDT As DataTable, ByVal Type As String, ByVal AirPricingID As String, ByVal TableName As String)

            Dim EffectRow As Integer

            Try
                With Me.MySQLParser
                    .OpenConnection()
                    .BeginTran()
                    .TableName = TableName
                    With .Columns
                        .Clear()
                        For i As Integer = 0 To AirPricingDT.Rows.Count - 1
                            .Add("AirPricingID", AirPricingDT.Rows(i).Item("AirPricingID"), SqlBuilder.SQLParserDataType.spNum)
                            .Add("AirPricingName", AirPricingDT.Rows(i).Item("AirPricingName"))
                            If Type = "Int" Then
                                .Add("IntTotalAirCom", AirPricingDT.Rows(i).Item("IntTotalAirCom").ToString())
                                .Add("IntTotalMarkUp", AirPricingDT.Rows(i).Item("IntTotalMarkUp").ToString())
                                .Add("IntTotalDiscount", AirPricingDT.Rows(i).Item("IntTotalDiscount").ToString())
                                .Add("IntTotalORCom", AirPricingDT.Rows(i).Item("IntTotalORCom").ToString())
                                .Add("IntTotalORCom2", AirPricingDT.Rows(i).Item("IntTotalORCom2").ToString())
                                .Add("IntTotalFare", AirPricingDT.Rows(i).Item("IntTotalFare").ToString())
                                .Add("IntTotalFareNett", AirPricingDT.Rows(i).Item("IntTotalFareNett").ToString())
                                .Add("IntTotalFee", AirPricingDT.Rows(i).Item("IntTotalFee").ToString())
                                .Add("IntFuelChargeOption", AirPricingDT.Rows(i).Item("IntFuelChargeOption").ToString())
                                .Add("IntMFFee", AirPricingDT.Rows(i).Item("IntMFFee").ToString())
                                .Add("IntMFFeeTF", AirPricingDT.Rows(i).Item("IntMFFeeTF").ToString())
                                .Add("IntTotalSellingFare", AirPricingDT.Rows(i).Item("IntTotalSellingFare").ToString())
                                .Add("IntTotalCharge", AirPricingDT.Rows(i).Item("IntTotalCharge").ToString())
                                .Add("IntDDLFeeApply", AirPricingDT.Rows(i).Item("IntDDLFeeApply").ToString())
                                .Add("IntApplyMarkUp", AirPricingDT.Rows(i).Item("IntApplyMarkUp").ToString(), SqlBuilder.SQLParserDataType.spBoolean)
                            ElseIf Type = "Dom" Then
                                .Add("DomSameAsInt", AirPricingDT.Rows(i).Item("DomSameAsInt"), SqlBuilder.SQLParserDataType.spBoolean)
                                .Add("DomTotalAirCom", AirPricingDT.Rows(i).Item("DomTotalAirCom").ToString())
                                .Add("DomTotalMarkUp", AirPricingDT.Rows(i).Item("DomTotalMarkUp").ToString())
                                .Add("DomTotalDiscount", AirPricingDT.Rows(i).Item("DomTotalDiscount").ToString())
                                .Add("DomTotalORCom", AirPricingDT.Rows(i).Item("DomTotalORCom2").ToString())
                                .Add("DomTotalORCom2", AirPricingDT.Rows(i).Item("DomTotalORCom2").ToString())
                                .Add("DomTotalFare", AirPricingDT.Rows(i).Item("DomTotalFare").ToString().ToString())
                                .Add("DomTotalFareNett", AirPricingDT.Rows(i).Item("DomTotalFareNett").ToString())
                                .Add("DomTotalFee", AirPricingDT.Rows(i).Item("DomTotalFee").ToString())
                                .Add("DomFuelChargeOption", AirPricingDT.Rows(i).Item("DomFuelChargeOption").ToString())
                                .Add("DomMFFee", AirPricingDT.Rows(i).Item("DomMFFee").ToString())
                                .Add("DomMFFeeTF", AirPricingDT.Rows(i).Item("DomMFFeeTF").ToString())
                                .Add("DomTotalSellingFare", AirPricingDT.Rows(i).Item("DomTotalSellingFare").ToString())
                                .Add("DomTotalCharge", AirPricingDT.Rows(i).Item("DomTotalCharge").ToString())
                                .Add("DOMDDLFeeApply", AirPricingDT.Rows(i).Item("DOMDDLFeeApply").ToString())
                                .Add("DomApplyMarkUp", AirPricingDT.Rows(i).Item("DomApplyMarkUp").ToString(), SqlBuilder.SQLParserDataType.spBoolean)
                            ElseIf Type = "LCC" Then
                                .Add("LCCSameAsInt", AirPricingDT.Rows(i).Item("LCCSameAsInt"), SqlBuilder.SQLParserDataType.spBoolean)
                                .Add("LCCTotalAirCom", AirPricingDT.Rows(i).Item("LCCTotalAirCom").ToString())
                                .Add("LCCTotalMarkUp", AirPricingDT.Rows(i).Item("LCCTotalMarkUp").ToString())
                                .Add("LCCTotalDiscount", AirPricingDT.Rows(i).Item("LCCTotalDiscount").ToString())
                                .Add("LCCTotalSellingFare", AirPricingDT.Rows(i).Item("LCCTotalSellingFare").ToString())
                                .Add("LCCTotalCharge", AirPricingDT.Rows(i).Item("LCCTotalCharge").ToString())
                                .Add("LCCTotalORCom", AirPricingDT.Rows(i).Item("LCCTotalORCom").ToString())
                                .Add("LCCTotalORCom2", AirPricingDT.Rows(i).Item("LCCTotalORCom2").ToString())
                                .Add("LCCFuelChargeOption", AirPricingDT.Rows(i).Item("LCCFuelChargeOption").ToString())
                                .Add("LCCMFFee", AirPricingDT.Rows(i).Item("LCCMFFee").ToString())
                                .Add("LCCMFFeeTF", AirPricingDT.Rows(i).Item("LCCMFFeeTF").ToString())
                                .Add("LCCDDLFeeApply", AirPricingDT.Rows(i).Item("LCCDDLFeeApply").ToString())
                                .Add("LCCApplyMarkUp", AirPricingDT.Rows(i).Item("LCCApplyMarkUp").ToString(), SqlBuilder.SQLParserDataType.spBoolean)
                                .Add("LCCTotalFare", AirPricingDT.Rows(i).Item("LCCTotalFare").ToString())
                                .Add("LCCTotalFareNett", AirPricingDT.Rows(i).Item("LCCTotalFareNett").ToString())
                                .Add("LCCTotalFee", AirPricingDT.Rows(i).Item("LCCTotalFee").ToString())
                            End If
                            .Add("DateModification", DateTime.Now)
                            .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                            .Add("ValueChangeType", "Delete")
                        Next

                    End With
                    EffectRow = .ExecuteInsert()
                End With

                If EffectRow > 0 Then
                    Me.MySQLParser.CommitTran()
                Else
                    Me.MySQLParser.RollbackTran()
                End If
            Catch ex As Exception
                EffectRow = -1
                Me.MySQLParser.RollbackTran()
            Finally
                Me.MySQLParser.CloseConnection()
            End Try
        End Sub

        Public Function getPricingInUsed(ByVal PricingID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblClientMasterPricing"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("PricingID", PricingID, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetTempAirPricingFormulaByNameInt(ByVal Name As String, ByVal DateFrom As String, ByVal DateTo As String) As DataTable
            Dim dt As DataTable
            Dim dt2 As DataTable
            Dim resultTable As DataTable
            Dim TempTable As DataTable
            Dim foundRow() As DataRow
            Dim count As Integer
            Dim ArrString(0) As String
            ArrString(0) = "AirPricingID"

            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "Temp_tblAirPricingFormula_Int"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    If Name <> "" Then
                        .Add("AirPricingName", Name, SqlBuilder.SQLParserDataType.spText, True)
                    End If
                    If DateFrom = DateTo Then
                        If DateFrom <> "" And DateTo <> "" Then
                            DateTo = DateTo + " 23:59:59:990"
                            .Add("DateModification", "convert(varchar,cast('" + DateFrom + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, ">")
                            .Add("DateModification", "convert(varchar,cast('" + DateTo + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, "<")
                        End If
                    Else
                        If DateFrom <> "" Then
                            .Add("DateModification", DateFrom, SqlBuilder.SQLParserDataType.spDate, True, ">")
                        End If
                        If DateTo <> "" Then
                            DateTo = DateTo + " 23:59:59:999"
                            .Add("DateModification", DateTo, SqlBuilder.SQLParserDataType.spText, True, "<=")
                        End If
                    End If
                    .Add("*")
                End With
                dt = .ExecuteDataTable(.SQLSelect + " order by DateModification Desc")
                .TableName = "tblAirPricingFormula"
                With .Columns
                    .Clear()
                    .IncludeKey = False
                    If Name <> "" Then
                        .Add("AirPricingName", Name, SqlBuilder.SQLParserDataType.spText, True)
                    End If
                    .Add("Distinct AirPricingID,AirPricingName,IntTotalAirCom,IntTotalMarkUp,IntTotalDiscount,IntTotalORCom,IntTotalORCom2,IntTotalFare,IntTotalFareNett,IntTotalFee,IntFuelChargeOption,IntMFFee,IntMFFeeTF,IntTotalSellingFare,IntTotalCharge,IntDDLFeeApply,IntApplyMarkUp")
                End With
                dt2 = .ExecuteDataTable()
            End With

            If Name <> "" Then
                dt2.Merge(dt)
                Return dt2
            Else
                TempTable = dt.DefaultView.ToTable(True, ArrString)
                resultTable = dt.Clone()
                For count = 0 To TempTable.Rows.Count - 1
                    foundRow = dt2.Select("AirPricingID='" + TempTable.Rows(count).Item("AirPricingID").ToString() + "'")
                    If foundRow.Length > 0 Then
                        resultTable.ImportRow(foundRow(0))
                    End If
                Next
                resultTable.AcceptChanges()
                resultTable.Merge(dt)
                Return resultTable
            End If
        End Function

        Public Function GetTempAirPricingFormulaByNameDom(ByVal Name As String, ByVal DateFrom As String, ByVal DateTo As String) As DataTable
            Dim dt As DataTable
            Dim dt2 As DataTable
            Dim resultTable As DataTable
            Dim TempTable As DataTable
            Dim foundRow() As DataRow
            Dim count As Integer
            Dim ArrString(0) As String
            ArrString(0) = "AirPricingID"

            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "Temp_tblAirPricingFormula_Dom"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    If Name <> "" Then
                        .Add("AirPricingName", Name, SqlBuilder.SQLParserDataType.spText, True)
                    End If
                    If DateFrom = DateTo Then
                        If DateFrom <> "" And DateTo <> "" Then
                            DateTo = DateTo + " 23:59:59:990"
                            .Add("DateModification", "convert(varchar,cast('" + DateFrom + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, ">")
                            .Add("DateModification", "convert(varchar,cast('" + DateTo + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, "<")
                        End If
                    Else
                        If DateFrom <> "" Then
                            .Add("DateModification", DateFrom, SqlBuilder.SQLParserDataType.spDate, True, ">")
                        End If
                        If DateTo <> "" Then
                            DateTo = DateTo + " 23:59:59:999"
                            .Add("DateModification", DateTo, SqlBuilder.SQLParserDataType.spText, True, "<=")
                        End If
                    End If
                    .Add("*")
                End With
                dt = .ExecuteDataTable(.SQLSelect + " order by DateModification Desc")
                .TableName = "tblAirPricingFormula"
                With .Columns
                    .Clear()
                    .IncludeKey = False
                    If Name <> "" Then
                        .Add("AirPricingName", Name, SqlBuilder.SQLParserDataType.spText, True)
                    End If
                    .Add("Distinct AirPricingID,AirPricingName,DomSameAsInt,DomTotalAirCom,DomTotalMarkUp,DomTotalDiscount,DomTotalORCom,DomTotalORCom2,DomTotalFare,DomTotalFareNett,DomTotalFee,DomFuelChargeOption,DomMFFee,DomMFFeeTF,DomTotalSellingFare,DomTotalCharge,DomDDLFeeApply,DomApplyMarkUp")
                End With
                dt2 = .ExecuteDataTable()
            End With

            If Name <> "" Then
                dt2.Merge(dt)
                Return dt2
            Else
                TempTable = dt.DefaultView.ToTable(True, ArrString)
                resultTable = dt.Clone()
                For count = 0 To TempTable.Rows.Count - 1
                    foundRow = dt2.Select("AirPricingID='" + TempTable.Rows(count).Item("AirPricingID").ToString() + "'")
                    If foundRow.Length > 0 Then
                        resultTable.ImportRow(foundRow(0))
                    End If
                Next
                resultTable.AcceptChanges()
                resultTable.Merge(dt)
                Return resultTable
            End If
        End Function

        Public Function GetTempAirPricingFormulaByNameLCC(ByVal Name As String, ByVal DateFrom As String, ByVal DateTo As String) As DataTable
            Dim dt As DataTable
            Dim dt2 As DataTable
            Dim resultTable As DataTable
            Dim TempTable As DataTable
            Dim foundRow() As DataRow
            Dim count As Integer
            Dim ArrString(0) As String
            ArrString(0) = "AirPricingID"

            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "Temp_tblAirPricingFormula_LCC"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    If Name <> "" Then
                        .Add("AirPricingName", Name, SqlBuilder.SQLParserDataType.spText, True)
                    End If
                    If DateFrom = DateTo Then
                        If DateFrom <> "" And DateTo <> "" Then
                            DateTo = DateTo + " 23:59:59:990"
                            .Add("DateModification", "convert(varchar,cast('" + DateFrom + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, ">")
                            .Add("DateModification", "convert(varchar,cast('" + DateTo + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, "<")
                        End If
                    Else
                        If DateFrom <> "" Then
                            .Add("DateModification", DateFrom, SqlBuilder.SQLParserDataType.spDate, True, ">")
                        End If
                        If DateTo <> "" Then
                            DateTo = DateTo + " 23:59:59:999"
                            .Add("DateModification", DateTo, SqlBuilder.SQLParserDataType.spText, True, "<=")
                        End If
                    End If
                    .Add("*")
                End With
                dt = .ExecuteDataTable(.SQLSelect + " order by DateModification Desc")
                .TableName = "tblAirPricingFormula"
                With .Columns
                    .Clear()
                    .IncludeKey = False
                    If Name <> "" Then
                        .Add("AirPricingName", Name, SqlBuilder.SQLParserDataType.spText, True)
                    End If
                    .Add("Distinct AirPricingID,AirPricingName,LCCSameAsInt,LCCTotalAirCom,LCCTotalMarkUp,LCCTotalDiscount,LCCTotalORCom,LCCTotalORCom2,LCCTotalFare,LCCTotalFareNett,LCCTotalFee,LCCFuelChargeOption,LCCMFFee,LCCMFFeeTF,LCCTotalSellingFare,LCCTotalCharge,LCCDDLFeeApply,LCCApplyMarkUp")
                End With
                dt2 = .ExecuteDataTable()
            End With

            If Name <> "" Then
                dt2.Merge(dt)
                Return dt2
            Else
                TempTable = dt.DefaultView.ToTable(True, ArrString)
                resultTable = dt.Clone()
                For count = 0 To TempTable.Rows.Count - 1
                    foundRow = dt2.Select("AirPricingID='" + TempTable.Rows(count).Item("AirPricingID").ToString() + "'")
                    If foundRow.Length > 0 Then
                        resultTable.ImportRow(foundRow(0))
                    End If
                Next
                resultTable.AcceptChanges()
                resultTable.Merge(dt)
                Return resultTable
            End If
        End Function


        'Public Function GetTempAirPricingFormula() As DataTable
        '    Dim dt As DataTable
        '    Dim dt2 As DataTable
        '    Dim resultTable As DataTable
        '    Dim TempTable As DataTable
        '    Dim foundRow() As DataRow
        '    Dim count As Integer
        '    Dim ArrString(0) As String
        '    ArrString(0) = "AirPricingID"

        '    With Me.MySQLParser
        '        .AutoParameter = False
        '        .TableName = "Temp_tblAirPricingFormula "
        '        With .Columns
        '            .IncludeKey = False
        '            .Clear()
        '            .Add("*")
        '        End With
        '        dt = .ExecuteDataTable(.SQLSelect + " order by DateModification Desc")
        '        .TableName = "tblAirPricingFormula"
        '        With .Columns
        '            .Clear()
        '            .IncludeKey = False
        '            .Add("Distinct *")
        '        End With
        '        dt2 = .ExecuteDataTable()
        '    End With

        '    TempTable = dt.DefaultView.ToTable(True, ArrString)
        '    resultTable = dt.Clone()
        '    For count = 0 To TempTable.Rows.Count - 1
        '        foundRow = dt2.Select("AirPricingID='" + TempTable.Rows(count).Item("AirPricingID").ToString() + "'")
        '        If foundRow.Length > 0 Then
        '            resultTable.ImportRow(foundRow(0))
        '        End If
        '    Next
        '    resultTable.AcceptChanges()
        '    resultTable.Merge(dt)
        '    Return resultTable
        'End Function

        'Public Function GetTempAirPricingFormulaInt()
        '    Dim dt As DataTable
        '    Dim dt2 As DataTable
        '    Dim resultTable As DataTable
        '    Dim TempTable As DataTable
        '    Dim foundRow() As DataRow
        '    Dim count As Integer
        '    Dim ArrString(0) As String
        '    ArrString(0) = "AirPricingID"

        '    With Me.MySQLParser
        '        .AutoParameter = False
        '        .TableName = "Temp_tblAirPricingFormula_Int"
        '        With .Columns
        '            .IncludeKey = False
        '            .Clear()
        '            .Add("*")
        '        End With
        '        dt = .ExecuteDataTable(.SQLSelect + " order by DateModification Desc")
        '        .TableName = "tblAirPricingFormula"
        '        With .Columns
        '            .Clear()
        '            .IncludeKey = False
        '            .Add("Distinct IntTotalAirCom,IntTotalMarkUp,IntTotalDiscount,IntTotalORCom,IntTotalORCom2,IntTotalFare,IntTotalFareNett,IntTotalFee,IntFuelChargeOption,IntMFFee,IntMFFeeTF,IntTotalSellingFare,IntTotalCharge,IntDDLFeeApply,IntApplyMarkUp")
        '        End With
        '        dt2 = .ExecuteDataTable()
        '    End With

        '    TempTable = dt.DefaultView.ToTable(True, ArrString)
        '    resultTable = dt.Clone()
        '    For count = 0 To TempTable.Rows.Count - 1
        '        foundRow = dt2.Select("AirPricingID='" + TempTable.Rows(count).Item("AirPricingID").ToString() + "'")
        '        If foundRow.Length > 0 Then
        '            resultTable.ImportRow(foundRow(0))
        '        End If
        '    Next
        '    resultTable.AcceptChanges()
        '    resultTable.Merge(dt)
        '    Return resultTable
        'End Function

        'Public Function GetTempAirPricingFormulaByName(ByVal Name As String, ByVal DateFrom As String, ByVal DateTo As String) As DataTable
        '    Dim dt As DataTable
        '    Dim dt2 As DataTable
        '    Dim resultTable As DataTable
        '    Dim TempTable As DataTable
        '    Dim foundRow() As DataRow
        '    Dim count As Integer
        '    Dim ArrString(0) As String
        '    ArrString(0) = "AirPricingID"

        '    With Me.MySQLParser
        '        .AutoParameter = False
        '        .TableName = "Temp_tblAirPricingFormula "
        '        With .Columns
        '            .IncludeKey = False
        '            .Clear()
        '            If Name <> "" Then
        '                .Add("AirPricingName", Name, SqlBuilder.SQLParserDataType.spText, True)
        '            End If
        '            If DateFrom = DateTo Then
        '                If DateFrom <> "" And DateTo <> "" Then
        '                    DateTo = DateTo + " 23:59:59:990"
        '                    .Add("DateModification", "convert(varchar,cast('" + DateFrom + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, ">")
        '                    .Add("DateModification", "convert(varchar,cast('" + DateTo + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, "<")
        '                End If
        '            Else
        '                If DateFrom <> "" Then
        '                    .Add("DateModification", DateFrom, SqlBuilder.SQLParserDataType.spDate, True, ">")
        '                End If
        '                If DateTo <> "" Then
        '                    DateTo = DateTo + " 23:59:59:999"
        '                    .Add("DateModification", DateTo, SqlBuilder.SQLParserDataType.spText, True, "<=")
        '                End If
        '            End If
        '            .Add("*")
        '        End With
        '        dt = .ExecuteDataTable(.SQLSelect + " order by DateModification Desc")
        '        .TableName = "tblAirPricingFormula"
        '        With .Columns
        '            .Clear()
        '            .IncludeKey = False
        '            If Name <> "" Then
        '                .Add("AirPricingName", Name, SqlBuilder.SQLParserDataType.spText, True)
        '            End If
        '            .Add("Distinct *")
        '        End With
        '        dt2 = .ExecuteDataTable()
        '    End With

        '    If Name <> "" Then
        '        dt2.Merge(dt)
        '        Return dt2
        '    Else
        '        TempTable = dt.DefaultView.ToTable(True, ArrString)
        '        resultTable = dt.Clone()
        '        For count = 0 To TempTable.Rows.Count - 1
        '            foundRow = dt2.Select("AirPricingID='" + TempTable.Rows(count).Item("AirPricingID").ToString() + "'")
        '            If foundRow.Length > 0 Then
        '                resultTable.ImportRow(foundRow(0))
        '            End If
        '        Next
        '        resultTable.AcceptChanges()
        '        resultTable.Merge(dt)
        '        Return resultTable
        '    End If
        'End Function

        'Public Function GetTempAirPricingVariables() As DataTable
        '    Dim dt As DataTable
        '    Dim dt2 As DataTable
        '    Dim resultTable As DataTable
        '    Dim TempTable As DataTable
        '    Dim foundRow() As DataRow
        '    Dim count As Integer
        '    Dim ArrString(1) As String
        '    ArrString(0) = "AirPricingID"
        '    ArrString(1) = "FieldID"

        '    With Me.MySQLParser
        '        .AutoParameter = False
        '        .TableName = "Temp_tblAirPricingVariables "
        '        With .Columns
        '            .IncludeKey = False
        '            .Clear()
        '            .Add("*")
        '        End With
        '        dt = .ExecuteDataTable(.SQLSelect + " order by DateModification Desc")
        '        .TableName = "tblAirPricingVariables"
        '        With .Columns
        '            .Clear()
        '            .IncludeKey = False
        '            .Add("Distinct *")
        '        End With
        '        dt2 = .ExecuteDataTable()
        '    End With

        '    TempTable = dt.DefaultView.ToTable(True, ArrString)
        '    resultTable = dt.Clone()
        '    For count = 0 To TempTable.Rows.Count - 1
        '        foundRow = dt2.Select("AirPricingID='" + TempTable.Rows(count).Item("AirPricingID").ToString() + "' And FieldID='" + TempTable.Rows(count).Item("FieldID").ToString() + "'")
        '        If foundRow.Length > 0 Then
        '            resultTable.ImportRow(foundRow(0))
        '        End If
        '    Next
        '    resultTable.AcceptChanges()
        '    resultTable.Merge(dt)
        '    Return resultTable
        '    Return dt
        'End Function

        'Public Function GetTempAirPricingVariablesByName(ByVal ID As String, ByVal DateFrom As String, ByVal DateTo As String) As DataTable
        '    Dim dt As DataTable
        '    Dim dt2 As DataTable
        '    Dim resultTable As DataTable
        '    Dim TempTable As DataTable
        '    Dim foundRow() As DataRow
        '    Dim count As Integer
        '    Dim ArrString(1) As String
        '    ArrString(0) = "AirPricingID"
        '    ArrString(1) = "FieldID"

        '    With Me.MySQLParser
        '        .AutoParameter = False
        '        .TableName = "Temp_tblAirPricingVariables "
        '        With .Columns
        '            .IncludeKey = False
        '            .Clear()
        '            If ID <> "" Then
        '                .Add("AirPricingID", ID, SqlBuilder.SQLParserDataType.spText, True)
        '            End If
        '            If DateFrom = DateTo Then
        '                If DateFrom <> "" And DateTo <> "" Then
        '                    DateTo = DateTo + " 23:59:59:997"
        '                    .Add("DateModification", "convert(varchar,cast('" + DateFrom + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, ">")
        '                    .Add("DateModification", "convert(varchar,cast('" + DateTo + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, "<")
        '                End If
        '            Else
        '                If DateFrom <> "" Then
        '                    .Add("DateModification", DateFrom, SqlBuilder.SQLParserDataType.spDate, True, ">")
        '                End If
        '                If DateTo <> "" Then
        '                    DateTo = DateTo + " 23:59:59:999"
        '                    .Add("DateModification", DateTo, SqlBuilder.SQLParserDataType.spText, True, "<=")
        '                End If
        '            End If
        '            .Add("*")
        '        End With
        '        dt = .ExecuteDataTable(.SQLSelect + " order by DateModification Desc")
        '        .TableName = "tblAirPricingVariables"
        '        With .Columns
        '            .Clear()
        '            .IncludeKey = False
        '            .Add("AirPricingID", ID, SqlBuilder.SQLParserDataType.spText, True)
        '            .Add("Distinct * ")
        '        End With
        '        dt2 = .ExecuteDataTable()
        '    End With
        '    If ID <> "" Then
        '        dt2.Merge(dt)
        '        Return dt2
        '    Else
        '        TempTable = dt.DefaultView.ToTable(True, ArrString)
        '        resultTable = dt.Clone()
        '        For count = 0 To TempTable.Rows.Count - 1
        '            foundRow = dt2.Select("AirPricingID='" + TempTable.Rows(count).Item("AirPricingID").ToString() + "' And FieldID='" + TempTable.Rows(count).Item("FieldID").ToString() + "'")
        '            If foundRow.Length > 0 Then
        '                resultTable.ImportRow(foundRow(0))
        '            End If
        '        Next
        '        resultTable.AcceptChanges()
        '        resultTable.Merge(dt)
        '        Return resultTable
        '    End If
        'End Function




    End Class
End Namespace


@


1.1.1.1
log
@no message
@
text
@@
