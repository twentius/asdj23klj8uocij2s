head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.23;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.23;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic
Imports system.Data.SqlClient

Namespace DataAccessLayer

    Public Class DatabaseDA

        Public MySQLParser As SqlBuilder.SQLParser

        Public Sub New()

            Dim cn As String = ""
            cn = CWTMasterDB.Util.CreateConnection(CWTMasterDB.Util.GetAppConfig("StdSvr"), CWTMasterDB.Util.GetAppConfig("StdDatabase"), CWTMasterDB.Util.GetAppConfig("StdUsr"), CWTMasterDB.Util.GetAppConfig("StdPwd"))
            Me.MySQLParser = New SqlBuilder.SQLParser(cn)
            Me.MySQLParser.Columns.IncludeKey = False
        End Sub

        Public Sub New(ByVal ParserObject As SqlBuilder.SQLParser)
            Me.MySQLParser = ParserObject
        End Sub

        Public Function GetServer() As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "configInstances"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetConnectionInfo(ByVal KeyID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "configInstances"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("KeyID", KeyID, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetCountryConfig(ByVal KeyID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "configInstances"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("KeyID", KeyID, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function UpdateCountryConfig(ByVal info As DataInfo.CountryInfo) As Integer
            Dim EffectRow As Integer
            Try
                With Me.MySQLParser
                    .TableName = "configInstances"
                    With .Columns
                        .IncludeKey = False
                        .Clear()
                        .Add("KeyID", info.KeyID, SqlBuilder.SQLParserDataType.spText, True)
                        .Add("ConfigurationID", info.ConfigurationID)
                        .Add("CurrencyCode", info.Currency)
                        '.Add("GST", info.GST, SqlBuilder.SQLParserDataType.spNum)
                        .Add("DecimalPoint", info.DecimalPt, SqlBuilder.SQLParserDataType.spNum)
                        .Add("RoundUnit", info.RoundUnit, SqlBuilder.SQLParserDataType.spNum)
                        .Add("DefaultTktAll", info.DefaultTkAll, SqlBuilder.SQLParserDataType.spBoolean)
                        .Add("DefaultTktTicket", info.DefaultTktTicket, SqlBuilder.SQLParserDataType.spBoolean)
                        .Add("DefaultTktItin", info.DefaultTktItin, SqlBuilder.SQLParserDataType.spBoolean)
                        .Add("DefaultTktInv", info.DefaultTktInv, SqlBuilder.SQLParserDataType.spBoolean)
                        .Add("DefaultTktMir", info.DefaultTktMir, SqlBuilder.SQLParserDataType.spBoolean)
                    End With
                    CallProcedure(info.KeyID, "Update", "sp_configInstances")
                    EffectRow = .ExecuteUpdate()
                End With
            Catch ex As Exception
                EffectRow = -1
            End Try
            Return EffectRow
        End Function

        Private Sub CallProcedure(ByVal ID As String, ByVal Type As String, ByVal StoreProdType As String)
            With Me.MySQLParser
                .ExecuteStoreProcedure("exec " + StoreProdType + " '" + ID + "','" + ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName + "','" + Type + "'")
            End With
        End Sub

        'Public Function GetTempCountryConfig(Optional ByVal dateFrom As String = "", Optional ByVal dateTo As String = "") As DataSet
        '    Dim CountryDT As DataTable
        '    Dim TempCountryDT As DataTable
        '    Dim CountryMasterDT As DataTable

        '    Dim TempTable As DataTable
        '    Dim CountryArr(0) As String
        '    Dim count As Integer
        '    Dim count2 As Integer
        '    Dim ds As New DataSet
        '    Dim foundRow() As DataRow

        '    CountryArr(0) = "KeyID"

        '    With Me.MySQLParser
        '        .TableName = "Temp_configInstances"
        '        With .Columns
        '            .Clear()
        '            If dateFrom = dateTo Then
        '                If dateFrom <> "" And dateTo <> "" Then
        '                    dateTo = dateTo + " 23:59:59:990"
        '                    .Add("DateModification", "convert(varchar,cast('" + dateFrom + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, ">")
        '                    .Add("DateModification", "convert(varchar,cast('" + dateTo + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, "<")
        '                End If
        '            Else
        '                If dateFrom <> "" Then
        '                    .Add("DateModification", dateFrom, SqlBuilder.SQLParserDataType.spDate, True, ">")
        '                End If
        '                If dateTo <> "" Then
        '                    dateTo = dateTo + " 23:59:59:999"
        '                    .Add("DateModification", dateTo, SqlBuilder.SQLParserDataType.spDate, True, "<=")
        '                End If
        '            End If
        '            .Add("*")
        '        End With
        '        TempCountryDT = .ExecuteDataTable(.SQLSelect + " order by DateModification Desc")

        '        .TableName = "configInstances"
        '        With .Columns
        '            .Clear()
        '            .Add("*")
        '        End With
        '        CountryDT = .ExecuteDataTable()

        '        TempTable = TempCountryDT.DefaultView.ToTable(True, CountryArr)
        '        CountryMasterDT = TempCountryDT.Clone()
        '        For count = 0 To TempTable.Rows.Count - 1
        '            foundRow = CountryDT.Select("KeyID='" + TempTable.Rows(count).Item("KeyID").ToString() + "'")
        '            If foundRow.Length > 0 Then
        '                For count2 = 0 To foundRow.Length - 1
        '                    CountryMasterDT.ImportRow(foundRow(count2))
        '                Next count2
        '            End If
        '        Next
        '        CountryMasterDT.AcceptChanges()
        '        CountryMasterDT.Merge(TempCountryDT)
        '        CountryMasterDT.TableName = "Country"
        '        ds.Tables.Add(CountryMasterDT)
        '    End With
        '    Return ds
        'End Function
    End Class

End Namespace

@


1.1.1.1
log
@no message
@
text
@@
