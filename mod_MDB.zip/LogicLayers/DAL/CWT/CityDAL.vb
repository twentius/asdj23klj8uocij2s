head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.23;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.23;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic
Imports System.Collections.Generic

Namespace DataAccessLayer
    Public Class CityDAL
        Inherits BaseDA

        Public Function IsExistName(ByVal ID As String) As Boolean
            Dim EffectRow As Integer
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = CWTMasterDB.Util.StandardDB("tblCity")
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("AirportCode", ID, SqlBuilder.SQLParserDataType.spText, True, )
                    .Add("Count(*) as NumRec")
                End With
                EffectRow = .ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar)
            End With
            Return (EffectRow > 0)
        End Function

        Public Function GetCityList(ByVal ID As String, ByVal CityType As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = CWTMasterDB.Util.StandardDB("tblCity")
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    If ID <> "" Then .Add("AirportCode", "%" + ID + "%", SqlBuilder.SQLParserDataType.spText, True, "LIKE")
                    If CityType <> "" Then .Add("[Type]", CityType, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetRegionList() As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = CWTMasterDB.Util.StandardDB("tblRegion")
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetCountryList() As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = CWTMasterDB.Util.StandardDB("tblCountry")
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetCityTypeList() As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = CWTMasterDB.Util.StandardDB("tblCityType")
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetCityByAirportCode(ByVal AirportCode As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = CWTMasterDB.Util.StandardDB("tblCity")
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("AirportCode", AirportCode, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function DeleteCityByCode(ByVal AirportCode As String) As Integer
            Dim EffectRow As Integer
            With Me.MySQLParser
                .TableName = CWTMasterDB.Util.StandardDB("tblCity")
                With .Columns
                    .Clear()
                    .Add("AirportCode", AirportCode, SqlBuilder.SQLParserDataType.spText, True)
                End With
                CallProcedure(AirportCode, "Delete", "sp_City")
                EffectRow = .ExecuteDelete()
            End With
            Return EffectRow
        End Function

        Public Function UpdateCity(ByVal info As DataInfo.CityInfo) As Integer
            Dim EffectRow As Integer
            Try
                With Me.MySQLParser
                    .TableName = CWTMasterDB.Util.StandardDB("tblCity")
                    With .Columns
                        .Clear()
                        .Add("AirportCode", info.AirportCode, SqlBuilder.SQLParserDataType.spText, (info.PageMode = CWTMasterDB.TransactionMode.UpdateMode))
                        .Add("Airport", info.Airport)
                        .Add("Type", info.Type)
                        .Add("City", info.City)
                        .Add("CityCode", info.CityCode)
                        .Add("CountryCode", info.CountryCode)
                        .Add("CoTerminal", info.CoTerminal)
                        .Add("DiffGMT", info.DiffGMT, SqlBuilder.SQLParserDataType.spNum)
                        .Add("CountrySubDivCode", info.CountrySubDivCode)
                        .Add("RegionCode", info.RegionCode)
                        .Add("IATAArea", info.IATAArea)
                        .Add("Latitude", info.Latitude, SqlBuilder.SQLParserDataType.spNum)
                        .Add("Longtitude", info.Longtitude, SqlBuilder.SQLParserDataType.spNum)
                    End With

                    Select Case info.PageMode
                        Case CWTMasterDB.TransactionMode.AddNewMode
                            EffectRow = .ExecuteInsert()
                            CallProcedure(info.AirportCode, "Insert", "sp_City")
                        Case CWTMasterDB.TransactionMode.UpdateMode
                            CallProcedure(info.AirportCode, "Update", "sp_City")
                            EffectRow = .ExecuteUpdate()
                    End Select
                End With
            Catch ex As Exception
                EffectRow = -1
            End Try
            Return EffectRow
        End Function

        Private Sub CallProcedure(ByVal ID As String, ByVal Type As String, ByVal StoreProdType As String)
            With Me.MySQLParser
                .ExecuteStoreProcedure("exec " + CWTMasterDB.Util.StandardDBForStoredProcedure(StoreProdType) + " '" + ID + "','" + ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName + "','" + Type + "'")
            End With
        End Sub

        Public Function GetTempAirportCity(Optional ByVal AirportName As String = "", Optional ByVal dateFrom As String = "", Optional ByVal dateTo As String = "") As DataSet
            Dim CityDT As DataTable
            Dim TempCityDT As DataTable
            Dim CityMasterDT As DataTable

            Dim ds As New DataSet
            Dim TempTable As DataTable
            Dim ClientIDArr(0) As String
            Dim count As Integer
            Dim count2 As Integer
            Dim foundRow() As DataRow

            ClientIDArr(0) = "AirportCode"

            With Me.MySQLParser
                .TableName = CWTMasterDB.Util.StandardDB("Temp_tblCity") + " ci inner join " + CWTMasterDB.Util.StandardDB("tblRegion") + " r on ci.RegionCode= r.RegionCode inner join " + CWTMasterDB.Util.StandardDB("tblCountry") + " co on ci.CountryCode = co.CountryCode"
                With .Columns
                    .Clear()
                    If AirportName <> "" Then
                        .Add("Airport", AirportName, SqlBuilder.SQLParserDataType.spText, True)
                    End If
                    If dateFrom = dateTo Then
                        If dateFrom <> "" And dateTo <> "" Then
                            dateTo = dateTo + " 23:59:59:990"
                            .Add("DateModification", "convert(varchar,cast('" + dateFrom + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, ">")
                            .Add("DateModification", "convert(varchar,cast('" + dateTo + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, "<")
                        End If
                    Else
                        If dateFrom <> "" Then
                            .Add("DateModification", dateFrom, SqlBuilder.SQLParserDataType.spDate, True, ">")
                        End If
                        If dateTo <> "" Then
                            dateTo = dateTo + " 23:59:59:999"
                            .Add("DateModification", dateTo, SqlBuilder.SQLParserDataType.spText, True, "<=")
                        End If
                    End If
                    .Add("ci.AirportCode,ci.Airport,ci.Type,ci.City As CityName,co.CountryName,ci.CoTerminal,ci.DiffGMT,ci.CountrySubDivCode,r.Description As Region,ci.IATAArea,ci.Latitude,ci.Longtitude,ci.DateModification,ci.UserName,ci.ValueChangeType")
                End With
                TempCityDT = .ExecuteDataTable(.SQLSelect + " order by DateModification Desc")

                .TableName = CWTMasterDB.Util.StandardDB("tblCity") + " ci inner join " + CWTMasterDB.Util.StandardDB("tblRegion") + " r on ci.RegionCode= r.RegionCode inner join " + CWTMasterDB.Util.StandardDB("tblCountry") + " co on ci.CountryCode = co.CountryCode"
                With .Columns
                    .Clear()
                    If AirportName <> "" Then
                        .Add("Airport", AirportName, SqlBuilder.SQLParserDataType.spText, True)
                    End If
                    .Add("ci.AirportCode,ci.Airport,ci.Type,ci.City As CityName,co.CountryName,ci.CoTerminal,ci.DiffGMT,ci.CountrySubDivCode,r.Description As Region,ci.IATAArea,ci.Latitude,ci.Longtitude")
                End With
                CityDT = .ExecuteDataTable()

                TempTable = TempCityDT.DefaultView.ToTable(True, ClientIDArr)
                CityMasterDT = TempCityDT.Clone()
                For count = 0 To TempTable.Rows.Count - 1
                    foundRow = CityDT.Select("AirportCode='" + TempTable.Rows(count).Item("AirportCode").ToString() + "'")
                    If foundRow.Length > 0 Then
                        For count2 = 0 To foundRow.Length - 1
                            CityMasterDT.ImportRow(foundRow(count2))
                        Next count2
                    End If
                Next
                CityMasterDT.AcceptChanges()
                CityMasterDT.Merge(TempCityDT)
                CityMasterDT.TableName = "City"
                ds.Tables.Add(CityMasterDT)           
            End With
            Return ds
        End Function

    End Class
End Namespace

@


1.1.1.1
log
@no message
@
text
@@
