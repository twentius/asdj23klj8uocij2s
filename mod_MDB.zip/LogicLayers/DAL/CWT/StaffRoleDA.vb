head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.23;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.23;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic

Namespace DataAccessLayer

    Public Class StaffRoleDA
        Inherits BaseDA

        Public Function GetUserRole() As DataTable
            Dim oDataTable As DataTable
            With Me.MySQLParser
                .TableName = "tblStaffRole"
                With .Columns
                    .Add("*")
                End With
                oDataTable = .ExecuteDataTable()
            End With
            Return oDataTable
        End Function

        Public Function GetUserRoleByRoleID(ByVal RoleID As Integer) As DataTable
            Dim oDataTable As DataTable
            With Me.MySQLParser
                .TableName = "tblStaffRole"
                With .Columns
                    .Clear()
                    .Add("RoleID", RoleID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("*")
                End With
                oDataTable = .ExecuteDataTable()
            End With
            Return oDataTable
        End Function

        Public Function InsertRole(ByVal RoleName As String) As Integer
            Dim EffectRow As Integer
            With Me.MySQLParser
                .TableName = "tblStaffRole"
                With .Columns
                    .Clear()
                    .Add("Role", RoleName)
                End With
                EffectRow = .ExecuteInsert()
                InsertTempRole(RoleName)
            End With
            Return EffectRow
        End Function

        Private Sub InsertTempRole(ByVal RoleName As String)
            Dim dt As DataTable
            With Me.MySQLParser
                .TableName = "tblStaffRole"
                With .Columns
                    .Clear()
                    .Add("Role", RoleName, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            If dt.Rows.Count > 0 Then
                CallProcedure(dt.Rows(0).Item("RoleID").ToString(), "Insert", "sp_StaffRole")
            End If
        End Sub

        Public Function UpdateRoleByRoleID(ByVal RoleID As Integer, ByVal RoleName As String) As Integer
            Dim EffectRow As Integer
            With Me.MySQLParser
                .TableName = "tblStaffRole"
                With .Columns
                    .Clear()
                    .Add("RoleID", RoleID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("Role", "Admin", SqlBuilder.SQLParserDataType.spText, True, "<>")
                    .Add("Role", RoleName)
                End With
                CallProcedure(RoleID, "Update", "sp_StaffRole")
                EffectRow = .ExecuteUpdate()
            End With
            Return EffectRow
        End Function

        Public Function DeleteRoleByRoleID(ByVal RoleID As Integer) As Integer
            Dim EffectRow As Integer
            With Me.MySQLParser
                .TableName = "tblStaffRole"
                With .Columns
                    .Clear()
                    .Add("RoleID", RoleID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("Role", "Admin", SqlBuilder.SQLParserDataType.spText, True, "<>")
                End With
                CallProcedure(RoleID, "Delete", "sp_StaffRole")
                EffectRow = .ExecuteDelete()
            End With
            Return EffectRow
        End Function

        Private Sub CallProcedure(ByVal ClientID As String, ByVal Type As String, ByVal StoreProdType As String)
            With Me.MySQLParser
                .ExecuteStoreProcedure("exec " + StoreProdType + " '" + ClientID + "','" + ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName + "','" + Type + "'")
            End With
        End Sub

        Public Function GetTempRoleByRoleName(Optional ByVal RoleName As String = "", Optional ByVal dateFrom As String = "", Optional ByVal dateTo As String = "") As DataSet
            Dim TempRoleDT As DataTable
            Dim RoleDT As DataTable
            Dim RoleMasterDT As DataTable

            Dim ClientID As String = ""
            Dim TempTable As DataTable
            Dim ClientIDArr(0) As String
            Dim count As Integer
            Dim count2 As Integer
            Dim ds As New DataSet
            Dim foundRow() As DataRow

            ClientIDArr(0) = "RoleID"

            With Me.MySQLParser
                .TableName = "Temp_tblStaffRole"
                With .Columns
                    .Clear()
                    If RoleName <> "" Then
                        .Add("Role", RoleName, SqlBuilder.SQLParserDataType.spText, True)
                    End If
                    If dateFrom = dateTo Then
                        If dateFrom <> "" And dateTo <> "" Then
                            dateTo = dateTo + " 23:59:59:990"
                            .Add("DateModification", "convert(varchar,cast('" + dateFrom + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, ">")
                            .Add("DateModification", "convert(varchar,cast('" + dateTo + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, "<")
                        End If
                    Else
                        If dateFrom <> "" Then
                            .Add("DateModification", dateFrom, SqlBuilder.SQLParserDataType.spDate, True, ">")
                        End If
                        If dateTo <> "" Then
                            dateTo = dateTo + " 23:59:59:999"
                            .Add("DateModification", dateTo, SqlBuilder.SQLParserDataType.spText, True, "<=")
                        End If
                    End If
                    .Add("*")
                End With
                TempRoleDT = .ExecuteDataTable(.SQLSelect + " order by DateModification Desc")

                .TableName = "tblStaffRole"
                With .Columns
                    .Clear()
                    If RoleName <> "" Then
                        .Add("Role", RoleName, SqlBuilder.SQLParserDataType.spText, True)
                    End If
                    .Add("*")
                End With
                RoleDT = .ExecuteDataTable()

                If RoleName <> "" Then
                    RoleDT.Merge(TempRoleDT)
                    RoleDT.TableName = "Role"
                    ds.Tables.Add(RoleDT)
                Else
                    TempTable = TempRoleDT.DefaultView.ToTable(True, ClientIDArr)
                    RoleMasterDT = TempRoleDT.Clone()
                    For count = 0 To TempTable.Rows.Count - 1
                        foundRow = RoleDT.Select("RoleID='" + TempTable.Rows(count).Item("RoleID").ToString() + "'")
                        If foundRow.Length > 0 Then
                            For count2 = 0 To foundRow.Length - 1
                                RoleMasterDT.ImportRow(foundRow(count2))
                            Next count2
                        End If
                    Next
                    RoleMasterDT.AcceptChanges()
                    RoleMasterDT.Merge(TempRoleDT)
                    RoleMasterDT.TableName = "Role"
                    ds.Tables.Add(RoleMasterDT)
                End If
            End With
            Return ds
        End Function
    End Class

End Namespace

@


1.1.1.1
log
@no message
@
text
@@
