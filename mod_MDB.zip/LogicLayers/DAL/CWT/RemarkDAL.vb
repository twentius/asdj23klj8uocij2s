head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.23;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.23;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic

Namespace DataAccessLayer

    Public Class RemarkDAL
        Inherits BaseDA

        Public Function GetRemarkList(ByVal location As String, ByVal type As String, ByVal SubType1 As String, ByVal SubType2 As String, ByVal RefValue1 As String) As DataTable
            Dim oDataTable As DataTable
            With Me.MySQLParser
                .TableName = "tblItinRemarks i inner join " + CWTMasterDB.Util.StandardDB("tblRemarkType") + "  r on i.RemarkCode=r.RemarkCode"
                With .Columns
                    .Clear()
                    If location <> "" Then
                        .Add("r.Location", location, SqlBuilder.SQLParserDataType.spText, True)
                    End If
                    If type <> "" Then
                        .Add("r.[Type]", type, SqlBuilder.SQLParserDataType.spText, True)
                    End If
                    If SubType1 <> "" Then
                        .Add("r.SubType1", SubType1, SqlBuilder.SQLParserDataType.spText, True)
                    End If
                    If SubType2 <> "" Then
                        .Add("r.SubType2", SubType2, SqlBuilder.SQLParserDataType.spText, True)
                    End If
                    If RefValue1 <> "" Then
                        .Add("i.RefValue1", RefValue1, SqlBuilder.SQLParserDataType.spText, True)
                    End If
                    .Add("i.*")
                End With
                oDataTable = .ExecuteDataTable()
            End With
            Return oDataTable
        End Function

        Public Function GetRemarkList(ByVal location As String) As DataTable
            Dim oDataTable As DataTable
            With Me.MySQLParser
                .TableName = "tblItinRemarks i inner join " + CWTMasterDB.Util.StandardDB("tblRemarkType") + "  r on i.RemarkCode=r.RemarkCode"
                With .Columns
                    .Clear()
                    If location <> "" Then
                        .Add("r.Location", location, SqlBuilder.SQLParserDataType.spText, True)
                    End If
                    .Add("i.*")
                    .Add("r.[Type]")
                    .Add("r.SubType1")
                End With
                oDataTable = .ExecuteDataTable()
            End With
            Return oDataTable
        End Function

        Public Function GetRemarkCode(ByVal location As String, ByVal type As String, ByVal SubType1 As String, ByVal SubType2 As String) As String
            Dim retVal As Object
            With Me.MySQLParser
                .TableName = CWTMasterDB.Util.StandardDB("tblRemarkType")
                With .Columns
                    .Clear()
                    If location <> "" Then
                        .Add("Location", location, SqlBuilder.SQLParserDataType.spText, True)
                    Else
                        .Add("Location", "NULL", SqlBuilder.SQLParserDataType.spFunction, True, "IS")
                    End If
                    If type <> "" Then
                        .Add("[Type]", type, SqlBuilder.SQLParserDataType.spText, True)
                    Else
                        .Add("[Type]", "NULL", SqlBuilder.SQLParserDataType.spFunction, True, "IS")
                    End If
                    If SubType1 <> "" Then
                        .Add("SubType1", SubType1, SqlBuilder.SQLParserDataType.spText, True)
                    Else
                        .Add("SubType1", "NULL", SqlBuilder.SQLParserDataType.spFunction, True, "IS")
                    End If
                    If SubType2 <> "" Then
                        .Add("SubType2", SubType2, SqlBuilder.SQLParserDataType.spText, True)
                    Else
                        .Add("SubType2", "NULL", SqlBuilder.SQLParserDataType.spFunction, True, "IS")
                    End If
                    .Add("RemarkCode")
                End With
                retVal = .ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar)
                If retVal Is Nothing Then
                    Return ""
                Else
                    Return retVal.ToString
                End If
            End With
        End Function

        Public Function GetRemarkByID(ByVal SeqNo As String) As DataTable
            Dim oDataTable As DataTable
            With Me.MySQLParser
                .TableName = "tblItinRemarks i inner join " + CWTMasterDB.Util.StandardDB("tblRemarkType") + " r on i.RemarkCode=r.RemarkCode"
                With .Columns
                    .Clear()
                    .IncludeKey = False
                    .Add("i.SeqNo", SeqNo, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("i.*")
                    .Add("r.Location")
                    .Add("r.Type")
                    .Add("r.SubType1")
                    .Add("r.SubType2")
                    .Add("i.RefValue1")
                End With
                oDataTable = .ExecuteDataTable(.SQLSelect() + " order by i.SeqNo")
            End With
            Return oDataTable
        End Function

        Public Function GetLocation() As DataTable
            Dim oDataTable As DataTable
            With Me.MySQLParser
                .TableName = CWTMasterDB.Util.StandardDB("tblRemarkType")
                With .Columns
                    .Clear()
                    .IncludeKey = False
                    .Add("distinct location")
                    .Add("isnull(location,'Null') as Caption")
                End With
                oDataTable = .ExecuteDataTable(.SQLSelect() + " order by location")
            End With
            Return oDataTable
        End Function

        Public Function GetRemarkInfoByCode(ByVal RemarkCode As String) As DataTable
            Dim oDataTable As DataTable
            With Me.MySQLParser
                .TableName = CWTMasterDB.Util.StandardDB("tblRemarkType")
                With .Columns
                    .Clear()
                    .IncludeKey = False
                    .Add("RemarkCode", RemarkCode, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("top 1 *")
                End With
                oDataTable = .ExecuteDataTable(.SQLSelect())
            End With
            Return oDataTable
        End Function

        Public Function GetRemarkType(ByVal location As String) As DataTable
            Dim oDataTable As DataTable
            With Me.MySQLParser
                .TableName = CWTMasterDB.Util.StandardDB("tblRemarkType")
                With .Columns
                    .Clear()
                    .IncludeKey = False
                    If location <> "" Then
                        .Add("Location", location, SqlBuilder.SQLParserDataType.spText, True)
                    Else
                        .Add("Location", "NULL", SqlBuilder.SQLParserDataType.spFunction, True, "IS")
                    End If
                    .Add("distinct [type]")
                    .Add("isnull([type],'Null') as Caption")
                End With
                oDataTable = .ExecuteDataTable(.SQLSelect() + " order by [type]")
            End With
            Return oDataTable
        End Function

        Public Function GetSubType1(ByVal location As String, ByVal type As String) As DataTable
            Dim oDataTable As DataTable
            With Me.MySQLParser
                .TableName = CWTMasterDB.Util.StandardDB("tblRemarkType")
                With .Columns
                    .Clear()
                    .IncludeKey = False
                    If location <> "" Then
                        .Add("Location", location, SqlBuilder.SQLParserDataType.spText, True)
                    Else
                        .Add("Location", "NULL", SqlBuilder.SQLParserDataType.spFunction, True, "IS")
                    End If
                    If type <> "" Then
                        .Add("[Type]", type, SqlBuilder.SQLParserDataType.spText, True)
                    Else
                        .Add("[Type]", "NULL", SqlBuilder.SQLParserDataType.spFunction, True, "IS")
                    End If
                    .Add("RemarkCode")
                    .Add("isnull(SubType2,'') as SubType2")
                    .Add("isnull(SubType1,'Null') as Caption")
                End With
                oDataTable = .ExecuteDataTable(.SQLSelect() + " order by SubType2")
            End With
            Return oDataTable
        End Function

        Public Function GetSubType2(ByVal location As String, ByVal type As String, ByVal subtype1 As String) As DataTable
            Dim oDataTable As DataTable
            With Me.MySQLParser
                .TableName = CWTMasterDB.Util.StandardDB("tblRemarkType")
                With .Columns
                    .Clear()
                    .IncludeKey = False
                    If location <> "" Then
                        .Add("Location", location, SqlBuilder.SQLParserDataType.spText, True)
                    Else
                        .Add("Location", "NULL", SqlBuilder.SQLParserDataType.spFunction, True, "IS")
                    End If
                    If type <> "" Then
                        .Add("[Type]", type, SqlBuilder.SQLParserDataType.spText, True)
                    Else
                        .Add("[Type]", "NULL", SqlBuilder.SQLParserDataType.spFunction, True, "IS")
                    End If
                    If subtype1 <> "" Then
                        .Add("SubType1", subtype1, SqlBuilder.SQLParserDataType.spText, True)
                    Else
                        .Add("SubType1", "NULL", SqlBuilder.SQLParserDataType.spFunction, True, "IS")
                    End If
                    .Add("distinct isnull(SubType2,'') as SubType2")
                    .Add("isnull(SubType2,'Null') as Caption")
                End With
                oDataTable = .ExecuteDataTable(.SQLSelect() + " order by SubType2")
            End With
            Return oDataTable
        End Function
        Public Function GetCountryList() As DataTable
            Dim oDataTable As DataTable
            With Me.MySQLParser
                .TableName = CWTMasterDB.Util.StandardDB("tblCountry")
                With .Columns
                    .Clear()
                    .Add("*")
                End With
                oDataTable = .ExecuteDataTable()
            End With
            Return oDataTable
        End Function
        Public Function GetCountryName(ByVal Code As String) As String
            Dim retVal As String = ""
            With Me.MySQLParser
                .TableName = CWTMasterDB.Util.StandardDB("tblCountry")
                With .Columns
                    .Clear()
                    .Add("CountryCode", Code, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("CountryName")
                End With
                retVal = .ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar)
            End With
            Return retVal
        End Function

        Public Function UpdateRemark(ByVal info As DataInfo.RemarkInfo) As Integer
            Dim EffectRow As Integer
            Try
                With Me.MySQLParser
                    .TableName = "tblItinRemarks"
                    With .Columns
                        .Clear()
                        If info.PageMode = CWTMasterDB.TransactionMode.UpdateMode Then
                            .Add("SeqNo", info.ID, SqlBuilder.SQLParserDataType.spNum, True)
                        End If
                        .Add("RemarkCode", info.RemarkCode)
                        .Add("RmkDesc", info.Description, , , , True)
                        If info.RefValue1 <> "" Then .Add("RefValue1", info.RefValue1)
                    End With
                    Select Case info.PageMode
                        Case CWTMasterDB.TransactionMode.AddNewMode
                            EffectRow = .ExecuteInsert()
                            CallProcedure(GetLastID(), "Insert", "sp_Remarks")
                        Case CWTMasterDB.TransactionMode.UpdateMode
                            CallProcedure(info.ID, "Update", "sp_Remarks")
                            EffectRow = .ExecuteUpdate()
                    End Select
                End With
            Catch ex As Exception
                EffectRow = -1
            End Try
            Return EffectRow
        End Function

        Public Function DeleteRemark(ByVal SeqNo As String) As Integer
            Dim EffectRow As Integer
            Try
                With Me.MySQLParser
                    .TableName = "tblItinRemarks"
                    With .Columns
                        .Clear()
                        .Add("SeqNo", SeqNo, SqlBuilder.SQLParserDataType.spNum, True)
                    End With
                    CallProcedure(SeqNo, "Delete", "sp_Remarks")
                    EffectRow = .ExecuteDelete()
                End With
            Catch ex As Exception
                EffectRow = -1
            End Try
            Return EffectRow
        End Function

        Private Sub CallProcedure(ByVal ID As String, ByVal Type As String, ByVal StoreProdType As String)
            With Me.MySQLParser
                .ExecuteStoreProcedure("exec " + StoreProdType + " '" + ID + "','" + ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName + "','" + Type + "'")
            End With
        End Sub

        Private Function GetLastID() As String
            Dim ID As Integer
            With Me.MySQLParser
                .TableName = "tblItinRemarks"
                With .Columns
                    .Clear()
                    .Add("max(SeqNo)")
                End With
                ID = .ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar)
            End With
            Return ID
        End Function

        Public Function GetTempItinRemark(Optional ByVal RmkCode As String = "", Optional ByVal dateFrom As String = "", Optional ByVal dateTo As String = "") As DataSet
            Dim RemarkDT As DataTable
            Dim TempRemarkDT As DataTable
            Dim RemarkMasterDT As DataTable


            Dim TempTable As DataTable
            Dim ClientIDArr(0) As String
            Dim count As Integer
            Dim count2 As Integer
            Dim ds As New DataSet
            Dim foundRow() As DataRow

            ClientIDArr(0) = "SeqNo"


            With Me.MySQLParser
                .TableName = "Temp_tblItinRemarks rmk inner join " + CWTMasterDB.Util.StandardDB("tblRemarkType") + " rt on rmk.RemarkCode = rt.RemarkCode"
                With .Columns
                    .Clear()
                    If RmkCode <> "" Then
                        .Add("rt.Location", RmkCode, SqlBuilder.SQLParserDataType.spText, True)
                        'If RmkCode <> "0" Then
                        '    .Add("rmk.RemarkCode", RmkCode, SqlBuilder.SQLParserDataType.spText, True)
                        'Else
                        '    .Add("rmk.RemarkCode", "1", SqlBuilder.SQLParserDataType.spText, True, "!=")
                        '    .Add("rmk.RemarkCode", "2", SqlBuilder.SQLParserDataType.spText, True, "!=")
                        'End If
                    End If
                    If dateFrom = dateTo Then
                        If dateFrom <> "" And dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:990"
                            .Add("rmk.DateModification", "convert(varchar,cast('" + dateFrom + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, ">")
                            .Add("rmk.DateModification", "convert(varchar,cast('" + dateTo + " 23:59:59:999" + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, "<")
                        End If
                    Else
                        If dateFrom <> "" Then
                            .Add("rmk.DateModification", dateFrom, SqlBuilder.SQLParserDataType.spDate, True, ">")
                        End If
                        If dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:999"
                            .Add("rmk.DateModification", dateTo + " 23:59:59:999", SqlBuilder.SQLParserDataType.spText, True, "<=")
                        End If
                    End If
                    .Add("rmk.SeqNo,rt.Location,rt.Type,rt.SubType1,rt.SubType2,rmk.RmkDesc,rmk.RefValue1,rmk.DateModification,rmk.UserName,rmk.ValueChangeType")
                End With
                TempRemarkDT = .ExecuteDataTable(.SQLSelect + " order by DateModification Desc")

                .TableName = "tblItinRemarks rmk inner join " + CWTMasterDB.Util.StandardDB("tblRemarkType") + " rt on rmk.RemarkCode = rt.RemarkCode"
                With .Columns
                    .Clear()
                    If RmkCode <> "" Then
                        .Add("rt.Location", RmkCode, SqlBuilder.SQLParserDataType.spText, True)
                        'If RmkCode <> "0" Then
                        '    .Add("rmk.RemarkCode", RmkCode, SqlBuilder.SQLParserDataType.spText, True)
                        'Else
                        '    .Add("rmk.RemarkCode", "1", SqlBuilder.SQLParserDataType.spText, True, "!=")
                        '    .Add("rmk.RemarkCode", "2", SqlBuilder.SQLParserDataType.spText, True, "!=")
                        'End If
                    End If
                    .Add("rmk.SeqNo,rt.Location,rt.Type,rt.SubType1,rt.SubType2,rmk.RmkDesc,rmk.RefValue1")
                End With
                RemarkDT = .ExecuteDataTable()

                TempTable = TempRemarkDT.DefaultView.ToTable(True, ClientIDArr)
                RemarkMasterDT = TempRemarkDT.Clone()
                For count = 0 To TempTable.Rows.Count - 1
                    foundRow = RemarkDT.Select("SeqNo='" + TempTable.Rows(count).Item("SeqNo").ToString() + "'")
                    If foundRow.Length > 0 Then
                        For count2 = 0 To foundRow.Length - 1
                            RemarkMasterDT.ImportRow(foundRow(count2))
                        Next count2
                    End If
                Next
                RemarkMasterDT.AcceptChanges()
                RemarkMasterDT.Merge(TempRemarkDT)
                RemarkMasterDT.TableName = "Remark"
                ds.Tables.Add(RemarkMasterDT)
            End With
            Return ds
        End Function
    End Class

End Namespace

@


1.1.1.1
log
@no message
@
text
@@
