head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.23;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.23;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic

Namespace DataAccessLayer
    Public Class tblFunctionDA
        Inherits BaseDA

        Public Function GetLinkList(ByVal FunctionID As Integer, ByVal WMode As String) As DataTable
            Dim oDataTable As DataTable
            Dim query As New StringBuilder()
            query.Append("exec ")
            query.Append(Util.StandardDB("sp_CWT_GetLinkList") + " ")
            query.Append(FunctionID.ToString + ",")
            query.Append(Util.LimitTheString(WMode))
            With Me.MySQLParser
                oDataTable = .ExecuteDataTable(query.ToString())
            End With
            Return oDataTable
        End Function

        Public Function getAllData(ByVal RoleID As Integer) As DataTable
            Dim oDataTable As DataTable

            Dim query As New StringBuilder
            query.AppendLine(" select temp.functionID,temp.orderNo,temp.functionName,temp.functionGroup,temp.parentID,temp.RoleID,temp.Role,")
            query.AppendLine("isnull(permission,'F') as permission")
            query.AppendLine(" from(")
            query.AppendLine(" select f.functionID as functionID,f.functionName as functionName,f.orderNo as orderNo,f.functionGroup as functionGroup,f.parentID as parentID,r.RoleID as RoleID,r.Role as Role")
            query.AppendLine(" from " + ("tblFunctions") + " f,tblStaffRole r left outer join tblPermission p on r.roleid=p.roleid")
            query.AppendLine(" where(r.roleid = " + RoleID.ToString() + ") group by f.functionID,f.functionName,f.orderNo,f.functionGroup, f.parentID, r.RoleID,r.Role)temp left outer join tblPermission p on temp.roleid = p.RoleID AND temp.functionID = p.functionGroup")
            query.AppendLine(" order by orderNo ASC")
            With Me.MySQLParser
                oDataTable = .ExecuteDataTable(query.ToString())
            End With
            Return oDataTable
        End Function

        Public Function getAllData2(ByVal RoleID As Integer) As DataTable
            Dim oDataTable As DataTable

            Dim query As New StringBuilder
            query.AppendLine(" select temp.functionID,temp.orderNo,temp.functionName,temp.functionGroup,temp.parentID,temp.RoleID,temp.Role")
            query.AppendLine(" from(")
            query.AppendLine(" select f.functionID as functionID,f.functionName as functionName,f.orderNo as orderNo,f.functionGroup as functionGroup,f.parentID as parentID,r.RoleID as RoleID,r.Role as Role")
            query.AppendLine(" from " + ("tblFunctions") + " f,tblStaffRole r left outer join tblPermission p on r.roleid=p.roleid")
            query.AppendLine(" where(r.roleid = " + RoleID.ToString() + ") group by f.functionID,f.functionName,f.orderNo,f.functionGroup, f.parentID, r.RoleID,r.Role)temp left outer join tblPermission p on temp.roleid = p.RoleID AND temp.functionID = p.functionGroup")
            query.AppendLine(" order by orderNo ASC")
            With Me.MySQLParser
                oDataTable = .ExecuteDataTable(query.ToString())
            End With
            Return oDataTable
        End Function

        Public Function getPermission() As DataTable
            Dim oDataTable As DataTable
            With Me.MySQLParser
                .TableName = Util.StandardDB("tblPermissionValue")
                With .Columns
                    .Clear()
                    .Add("*")
                End With
                oDataTable = .ExecuteDataTable()
            End With
            Return oDataTable
        End Function

        'Public Function GetAccessByPath(ByVal RoleID As Integer, ByVal PathURL As String) As DataTable
        '    Dim oDataTable As DataTable
        '    Dim query As New StringBuilder
        '    query.AppendLine(" select temp.functionID,temp.functionName,temp.pathurl,temp.RoleID,temp.Role,")
        '    query.AppendLine("isnull(permission,'N') as permission")
        '    query.AppendLine(" from(")
        '    query.AppendLine(" select f.functionID,f.functionName,min(f.pathurl) as pathurl,r.RoleID,r.Role")
        '    query.AppendLine(" from tblFunctions f,tblStaffRole r left outer join tblPermission p on r.roleid=p.roleid")
        '    query.AppendLine(" where(r.roleid = " + RoleID.ToString() + ") and f.AuthenRequired=1 and f.AdminRequired=0 ")
        '    query.AppendLine(" and f.pathurl=" + CWTMasterDB.Util.LimitTheString(PathURL))
        '    query.AppendLine(" group by f.functionID,f.functionName,r.RoleID,r.Role)temp left outer join tblPermission p on temp.roleid = p.RoleID and temp.functionid = p.functionid")
        '    With Me.MySQLParser
        '        oDataTable = .ExecuteDataTable(query.ToString())
        '    End With
        '    Return oDataTable
        'End Function

        Public Function GetFunctionGroup(ByVal url As String) As CWTMasterDB.Util.TabNameType
            Dim retVal As CWTMasterDB.Util.TabNameType = CWTMasterDB.Util.TabNameType.CWTData
            Dim oDataTable As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = Util.StandardDB("tblFunctionGroup") + " g inner join " + Util.StandardDB("tblFunctions") + " f on g.functiongroup=f.functiongroup"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("f.PathURL", url, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("g.*")
                End With
                oDataTable = .ExecuteDataTable()
                If oDataTable IsNot Nothing AndAlso oDataTable.Rows.Count > 0 Then
                    retVal = CWTMasterDB.Util.DBNullToZero(oDataTable.Rows(0).Item("functiongroup"))
                End If
            End With
            Return retVal
        End Function

        Public Function GetFunctionIDByUrl(ByVal url As String) As Integer
            Dim retVal As Integer = -1
            Dim retObj As Object
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = Util.StandardDB("tblFunctions")
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("PathURL", url, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("FunctionID")
                End With
                retObj = .ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar, CommandType.Text)
                retVal = Util.DBNullToZero(retObj)
            End With
            Return retVal
        End Function

        Public Function SaveData(ByVal info As DataInfo.PermissionServiceInfo) As Integer
            Dim EffectRow As Integer = 1
            Dim PermissionDT As DataTable
            PermissionDT = GetPermissionValue(info.RoleID)
            Try
                With Me.MySQLParser
                    .OpenConnection()
                    .BeginTran()
                    .TableName = "tblPermission"
                    With .Columns
                        .Clear()
                        .Add("RoleID", info.RoleID, SqlBuilder.SQLParserDataType.spNum, True)
                    End With
                    .ExecuteDelete()
                    If EffectRow > 0 Then
                        For i As Integer = 0 To info.PermissionList.Count - 1
                            .TableName = "tblPermission"
                            With .Columns
                                .Clear()
                                .Add("FunctionGroup", info.PermissionList(i).functionID)
                                .Add("RoleID", info.RoleID, SqlBuilder.SQLParserDataType.spNum)
                                .Add("Permission", info.PermissionList(i).permission)
                                '.Add("Role", "Admin", SqlBuilder.SQLParserDataType.spText, True, "<>")
                            End With
                            EffectRow = .ExecuteInsert()
                            If EffectRow <= 0 Then
                                Exit For
                            End If
                        Next
                    End If
                End With
                MatchPermissionRecord(PermissionDT, info)
                If EffectRow > 0 Then
                    Me.MySQLParser.CommitTran()
                Else
                    Me.MySQLParser.RollbackTran()
                End If
                Return EffectRow
            Catch ex As Exception
                EffectRow = -1
                Me.MySQLParser.RollbackTran()
            Finally
                Me.MySQLParser.CloseConnection()
            End Try
        End Function

        Public Function GetUserLevelByUrl(ByVal url As String) As CWTCustomControls.UserLevelControl
            Dim retVal As CWTCustomControls.UserLevelControl = CWTCustomControls.UserLevelControl.None
            Dim oDataTable As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = Util.StandardDB("tblFunctions") + " f inner join tblPermission p on f.FunctionGroup=p.FunctionGroup"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("f.PathURL", url, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("p.RoleID", ServiceLogicLayer.ProfilerSLL.CurrentProfile.RoleID, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("p.*")
                End With
                oDataTable = .ExecuteDataTable()
                If oDataTable IsNot Nothing AndAlso oDataTable.Rows.Count > 0 Then
                    Select Case oDataTable.Rows(0).Item("Permission")
                        Case "F"
                            retVal = CWTCustomControls.UserLevelControl.FullFunctional
                        Case "V"
                            retVal = CWTCustomControls.UserLevelControl.ViewOnly
                        Case "N"
                            retVal = CWTCustomControls.UserLevelControl.None
                    End Select
                End If
            End With
            Return retVal
        End Function

        Private Sub MatchPermissionRecord(ByVal PermissionDT As DataTable, ByVal info As DataInfo.PermissionServiceInfo)
            Dim countDT As Integer
            Dim countInfo As Integer
            Dim checkBool As Boolean
            Dim effectRow As Integer

            If PermissionDT.Rows.Count > 0 Then
                For countDT = 0 To PermissionDT.Rows.Count - 1
                    checkBool = CheckExists(PermissionDT.Rows(countDT), info)
                    If checkBool = False Then

                        For countInfo = 0 To info.PermissionList.Count - 1
                            If PermissionDT.Rows(countDT).Item("FunctionGroup").ToString() = info.PermissionList(countInfo).functionID AndAlso PermissionDT.Rows(countDT).Item("RoleID").ToString() = info.RoleID Then
                                With Me.MySQLParser
                                    .TableName = "Temp_tblPermission"
                                    With .Columns
                                        .Clear()
                                        .Add("FunctionGroup", PermissionDT.Rows(countDT).Item("FunctionGroup").ToString())
                                        .Add("RoleID", PermissionDT.Rows(countDT).Item("RoleID").ToString())
                                        .Add("Permission", PermissionDT.Rows(countDT).Item("Permission").ToString())
                                        .Add("DateModification", DateTime.Now)
                                        .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                        .Add("ValueTypeChanged", "Update")
                                    End With
                                    effectRow = .ExecuteInsert()
                                    Exit For
                                End With
                            End If
                        Next countInfo

                        If countDT > info.PermissionList.Count Then
                            With Me.MySQLParser
                                .TableName = "Temp_tblPermission"
                                With .Columns
                                    .Clear()
                                    .Add("FunctionGroup", PermissionDT.Rows(countDT).Item("FunctionGroup").ToString())
                                    .Add("RoleID", PermissionDT.Rows(countDT).Item("RoleID").ToString())
                                    .Add("Permission", PermissionDT.Rows(countDT).Item("Permission").ToString())
                                    .Add("DateModification", DateTime.Now)
                                    .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                    .Add("ValueTypeChanged", "Delete")
                                End With
                                effectRow = .ExecuteInsert()
                            End With
                        End If
                        
                    End If
                Next countDT

            Else
                For countInfo = 0 To info.PermissionList.Count - 1
                    With Me.MySQLParser
                        .TableName = "Temp_tblPermission"
                        With .Columns
                            .Clear()
                            .Add("FunctionGroup", info.PermissionList(countInfo).functionID)
                            .Add("RoleID", info.RoleID)
                            .Add("Permission", info.PermissionList(countInfo).permission)
                            .Add("DateModification", DateTime.Now)
                            .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                            .Add("ValueTypeChanged", "Insert")
                        End With
                        effectRow = .ExecuteInsert()
                    End With
                Next countInfo
            End If
        End Sub

        Private Function CheckExists(ByVal row As DataRow, ByVal info As DataInfo.PermissionServiceInfo)
            Dim check As Boolean
            Dim countInfo As Integer

            For countInfo = 0 To info.PermissionList.Count - 1
                If row("FunctionGroup").ToString() = info.PermissionList(countInfo).functionID AndAlso row("RoleID").ToString() = info.RoleID AndAlso row("Permission").ToString() = info.PermissionList(countInfo).permission Then
                    check = True
                    Exit For
                End If
            Next

            Return check
        End Function

        Private Function GetPermissionValue(ByVal RoleID)
            Dim dt As DataTable
            With Me.MySQLParser
                .TableName = "tblPermission"
                With .Columns
                    .Clear()
                    .Add("RoleID", RoleID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetTempPermissionValue(Optional ByVal RoleName As String = "", Optional ByVal dateFrom As String = "", Optional ByVal dateTo As String = "") As DataSet
            Dim TempStaffPermissionDT As DataTable
            Dim StaffPermissionDT As DataTable
            Dim StaffPermissionMasterDT As DataTable

            Dim ClientID As String = ""
            Dim TempTable As DataTable
            Dim ClientIDArr(2) As String
            Dim count As Integer
            Dim count2 As Integer
            Dim ds As New DataSet
            Dim foundRow() As DataRow

            ClientIDArr(0) = "RoleID"
            ClientIDArr(1) = "GroupName"
            ClientIDArr(2) = "FunctionName"

            With Me.MySQLParser
                .TableName = "Temp_tblPermission p inner join tblStaffRole r on p.RoleID = r.RoleID inner join tblFunctions g on p.FunctionGroup = g.FunctionID inner join tblFunctionGroup fg on g.FunctionGroup = fg.FunctionGroup"
                With .Columns
                    .Clear()
                    If RoleName <> "" Then
                        .Add("r.Role", RoleName, SqlBuilder.SQLParserDataType.spText, True)
                    End If
                    If dateFrom = dateTo Then
                        If dateFrom <> "" And dateTo <> "" Then
                            dateTo = dateTo + " 23:59:59:990"
                            .Add("p.DateModification", "convert(varchar,cast('" + dateFrom + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, ">")
                            .Add("p.DateModification", "convert(varchar,cast('" + dateTo + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, "<")
                        End If
                    Else
                        If dateFrom <> "" Then
                            .Add("p.DateModification", dateFrom, SqlBuilder.SQLParserDataType.spDate, True, ">")
                        End If
                        If dateTo <> "" Then
                            dateTo = dateTo + " 23:59:59:999"
                            .Add("p.DateModification", dateTo, SqlBuilder.SQLParserDataType.spDate, True, "<=")
                        End If
                    End If
                    .Add("p.RoleID,fg.GroupName,g.FunctionName,r.Role,p.Permission,p.DateModification,p.UserName,p.ValueTypeChanged")
                End With
                TempStaffPermissionDT = .ExecuteDataTable(.SQLSelect + " order by DateModification Desc")


                .TableName = "tblPermission p inner join tblStaffRole r on p.RoleID = r.RoleID inner join tblFunctions g on p.FunctionGroup = g.FunctionID inner join tblFunctionGroup fg on g.FunctionGroup = fg.FunctionGroup"
                With .Columns
                    .Clear()
                    If RoleName <> "" Then
                        .Add("r.Role", RoleName, SqlBuilder.SQLParserDataType.spText, True)
                    End If
                    .Add("p.RoleID,fg.GroupName,g.FunctionName,r.Role,p.Permission")
                End With
                StaffPermissionDT = .ExecuteDataTable()
            End With

                TempTable = TempStaffPermissionDT.DefaultView.ToTable(True, ClientIDArr)
                StaffPermissionMasterDT = TempStaffPermissionDT.Clone()
                For count = 0 To TempTable.Rows.Count - 1
                foundRow = StaffPermissionDT.Select("RoleID='" + TempTable.Rows(count).Item("RoleID").ToString() + "' and GroupName='" + TempTable.Rows(count).Item("GroupName").ToString() + "' and FunctionName='" + TempTable.Rows(count).Item("FunctionName").ToString() + "'")
                    If foundRow.Length > 0 Then
                        For count2 = 0 To foundRow.Length - 1
                            StaffPermissionMasterDT.ImportRow(foundRow(count2))
                        Next count2
                    End If
                Next
                StaffPermissionMasterDT.AcceptChanges()
                StaffPermissionMasterDT.Merge(TempStaffPermissionDT)
                StaffPermissionMasterDT.TableName = "Permission"
                ds.Tables.Add(StaffPermissionMasterDT)
                Return ds
        End Function

        Public Function GetTempCountryConfig(Optional ByVal dateFrom As String = "", Optional ByVal dateTo As String = "") As DataSet
            Dim CountryDT As DataTable
            Dim TempCountryDT As DataTable
            Dim CountryMasterDT As DataTable

            Dim TempTable As DataTable
            Dim CountryArr(0) As String
            Dim count As Integer
            Dim count2 As Integer
            Dim ds As New DataSet
            Dim foundRow() As DataRow

            CountryArr(0) = "KeyID"

            With Me.MySQLParser
                .TableName = CWTMasterDB.Util.StandardDB("Temp_configInstances") + " cs inner join tblConfiguration c on cs.ConfigurationID = c.ConfigurationID"
                With .Columns
                    .Clear()
                    If dateFrom = dateTo Then
                        If dateFrom <> "" And dateTo <> "" Then
                            dateTo = dateTo + " 23:59:59:990"
                            .Add("cs.DateModification", "convert(varchar,cast('" + dateFrom + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, ">")
                            .Add("cs.DateModification", "convert(varchar,cast('" + dateTo + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, "<")
                        End If
                    Else
                        If dateFrom <> "" Then
                            .Add("cs.DateModification", dateFrom, SqlBuilder.SQLParserDataType.spDate, True, ">")
                        End If
                        If dateTo <> "" Then
                            dateTo = dateTo + " 23:59:59:999"
                            .Add("cs.DateModification", dateTo, SqlBuilder.SQLParserDataType.spText, True, "<=")
                        End If
                    End If
                    .Add("cs.KeyID,c.ConfigurationDesc,cs.CurrencyCode,cs.DecimalPoint,cs.RoundUnit,cs.DefaultTktAll,cs.DefaultTktTicket,cs.DefaultTktItin,cs.DefaultTktInv,cs.DefaultTktMir,cs.DateModification,cs.DUSerName,cs.ValueChangeType")
                End With
                TempCountryDT = .ExecuteDataTable(.SQLSelect + " order by DateModification Desc")



                .TableName = CWTMasterDB.Util.StandardDB("configInstances") + " cs inner join tblConfiguration c on cs.ConfigurationID = c.ConfigurationID"
                With .Columns
                    .Clear()
                    .Add("cs.KeyID,c.ConfigurationDesc,cs.CurrencyCode,cs.DecimalPoint,cs.RoundUnit,cs.DefaultTktAll,cs.DefaultTktTicket,cs.DefaultTktItin,cs.DefaultTktInv,cs.DefaultTktMir")
                End With
                CountryDT = .ExecuteDataTable()

                TempTable = TempCountryDT.DefaultView.ToTable(True, CountryArr)
                CountryMasterDT = TempCountryDT.Clone()
                For count = 0 To TempTable.Rows.Count - 1
                    foundRow = CountryDT.Select("KeyID='" + TempTable.Rows(count).Item("KeyID").ToString() + "'")
                    If foundRow.Length > 0 Then
                        For count2 = 0 To foundRow.Length - 1
                            CountryMasterDT.ImportRow(foundRow(count2))
                        Next count2
                    End If
                Next
                CountryMasterDT.AcceptChanges()
                CountryMasterDT.Merge(TempCountryDT)
                CountryMasterDT.TableName = "Country"
                ds.Tables.Add(CountryMasterDT)
            End With
            Return ds
        End Function

    End Class
End Namespace

@


1.1.1.1
log
@no message
@
text
@@
