head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.22;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.22;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic
Imports System.Collections.Generic

Namespace DataAccessLayer
    Public Class AirFeeDAL
        Inherits BaseDA
        Private TransInsert As TransInsert

#Region "General"
        Public Function GetFeeList(ByVal FeeName As String, ByVal FeeType As DataInfo.AirFeeInfo.AirFeeManagerType) As DataTable
            Dim dt As DataTable
            Dim tblName As String = ""
            Dim FeeTypeName As String
            Select Case FeeType
                Case DataInfo.AirFeeInfo.AirFeeManagerType.FeeByPNR
                    tblName = "tblFeeByPNR f"
                    FeeTypeName = "P"
                Case DataInfo.AirFeeInfo.AirFeeManagerType.FeeByTicket
                    tblName = "tblFeeByTicket f"
                    FeeTypeName = "T"
                Case DataInfo.AirFeeInfo.AirFeeManagerType.FeeByCoupon
                    tblName = "tblFeeByCoupon f"
                    FeeTypeName = "C"
                Case DataInfo.AirFeeInfo.AirFeeManagerType.ConditionalMarkUp
                    tblName = "tblFeeByConditional f"
                    FeeTypeName = "A"
                Case Else
                    Return (New DataTable)
            End Select
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = tblName
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    If FeeName <> "" Then .Add("f.FeeName", "%" + FeeName + "%", SqlBuilder.SQLParserDataType.spText, True, "LIKE")
                    .Add("f.*")
                    .Add("(select count(*) from tblClientPricing c inner join " + Util.StandardDB("tblAirVariables") + " v on c.FieldID=v.FieldID " + _
                         "where (cast(c.Value as int)=f.FeeID and c.ValueOption=" + CWTMasterDB.Util.LimitTheString(FeeTypeName) + " and c.TripType='I' and v.ProgramName='Fee') or " + _
                         "(cast(c.Value as int)=f.FeeID and c.ValueOption=" + CWTMasterDB.Util.LimitTheString(FeeTypeName) + " and c.TripType='D' and v.ProgramName='Fee') or " + _
                         "(cast(c.Value as int)=f.FeeID and c.ValueOption=" + CWTMasterDB.Util.LimitTheString(FeeTypeName) + " and c.TripType='L' and v.ProgramName='Fee') " + _
                         ") as InUse")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetFeeName(ByVal FeeName As String, ByVal FeeType As String) As String()
            Dim dt As DataTable
            Dim tblName As String = ""
            Dim retVal As New List(Of String)
            Select Case FeeType
                Case DataInfo.AirFeeInfo.AirFeeManagerType.FeeByPNR.ToString
                    tblName = "tblFeeByPNR"
                Case DataInfo.AirFeeInfo.AirFeeManagerType.FeeByTicket.ToString
                    tblName = "tblFeeByTicket"
                Case DataInfo.AirFeeInfo.AirFeeManagerType.FeeByCoupon.ToString
                    tblName = "tblFeeByCoupon"
                Case DataInfo.AirFeeInfo.AirFeeManagerType.ConditionalMarkUp.ToString
                    tblName = "tblFeeByConditional"
                Case Else
                    Return retVal.ToArray
            End Select
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = tblName
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("FeeName", FeeName + "%", SqlBuilder.SQLParserDataType.spText, True, "LIKE")
                    .Add("Distinct FeeName")
                End With
                dt = .ExecuteDataTable()
            End With
            If dt IsNot Nothing AndAlso dt.Rows.Count > 0 Then
                For i As Integer = 0 To dt.Rows.Count - 1
                    retVal.Add(dt.Rows(i).Item("FeeName").ToString)
                Next
            End If
            Return retVal.ToArray
        End Function

        Public Function GetFeeNameByID(ByVal FeeID As String, ByVal FeeType As DataInfo.AirFeeInfo.AirFeeManagerType) As String
            Dim retVal As String = ""
            Dim tblName As String = ""
            Select Case FeeType
                Case DataInfo.AirFeeInfo.AirFeeManagerType.FeeByPNR
                    tblName = "tblFeeByPNR"
                Case DataInfo.AirFeeInfo.AirFeeManagerType.FeeByTicket
                    tblName = "tblFeeByTicket"
                Case DataInfo.AirFeeInfo.AirFeeManagerType.FeeByCoupon
                    tblName = "tblFeeByCoupon"
                Case DataInfo.AirFeeInfo.AirFeeManagerType.ConditionalMarkUp
                    tblName = "tblFeeByConditional"
                Case Else
                    Return ""
            End Select
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = tblName
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("FeeID", FeeID, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("FeeName")
                End With
                retVal = .ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar)
            End With
            Return retVal
        End Function

        Public Function GetAirCalcName(ByVal AirPricingID As String) As String
            Dim retVal As String = ""
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblAirPricingFormula "
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("AirPricingID", AirPricingID, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("AirPricingName")
                End With
                retVal = .ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar)
            End With
            Return retVal
        End Function

        Public Function IsExistName(ByVal FeeName As String, ByVal ID As String, ByVal FeeType As DataInfo.AirFeeInfo.AirFeeManagerType) As Boolean
            Dim retVal As Boolean
            Dim tblName As String = ""
            Dim rCount As Integer
            Select Case FeeType
                Case DataInfo.AirFeeInfo.AirFeeManagerType.FeeByPNR
                    tblName = "tblFeeByPNR"
                Case DataInfo.AirFeeInfo.AirFeeManagerType.FeeByTicket
                    tblName = "tblFeeByTicket"
                Case DataInfo.AirFeeInfo.AirFeeManagerType.FeeByCoupon
                    tblName = "tblFeeByCoupon"
                Case DataInfo.AirFeeInfo.AirFeeManagerType.ConditionalMarkUp
                    tblName = "tblFeeByConditional"
                Case Else
                    Return False
            End Select
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = tblName
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("FeeName", FeeName, SqlBuilder.SQLParserDataType.spText, True)
                    If ID <> "" Then .Add("FeeID", ID, SqlBuilder.SQLParserDataType.spText, True, "<>")
                    .Add("count(*) as RecordCount")
                End With
                rCount = CWTMasterDB.Util.DBNullToZero(.ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar))
                retVal = (rCount > 0)
            End With
            Return retVal
        End Function
#End Region

#Region "Coupon"
        Public Function GetFeeByCouponData(ByVal FeeID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblTransactionFeebyCoupon"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("FeeID", FeeID, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Sub FliterCouponRecords(ByVal info As DataInfo.TransCouponInfo)
            Dim count As Integer
            Dim count2 As Integer
            Dim InsertFeeID As DataTable = New DataTable()
            Dim oDataTable As DataTable
            Dim boolChk As Boolean
            Dim boolChk2 As Boolean
            TransInsert = New TransInsert()
            Dim DeleteCoupon As ArrayList = New ArrayList()
            Try

                With Me.MySQLParser
                    .TableName = "tblTransactionFeeByCoupon"
                    With .Columns
                        .Clear()
                        .IncludeKey = False
                        .Add("FeeID", info.FeeID, SqlBuilder.SQLParserDataType.spText, True)
                        .Add("*")
                    End With
                    oDataTable = .ExecuteDataTable()

                    If info.PageMode = CWTMasterDB.TransactionMode.AddNewMode Then
                        .TableName = "tblFeeByCoupon"
                        With .Columns
                            .Clear()
                            .IncludeKey = False
                            .Add("max(FeeID)")
                        End With
                        InsertFeeID = .ExecuteDataTable()
                        If InsertFeeID.Rows.Count > 0 Then
                            info.FeeID = InsertFeeID.Rows(0).Item(0) + 1
                        Else
                            info.FeeID = 1
                        End If
                    End If
                End With

                If info.CouponList.Count > 0 Then

                    For count = 0 To info.CouponList.Count - 1
                        boolChk = Me.FindMatchRecords(count + 1, oDataTable)
                        With info.CouponList(count)
                            If boolChk Then
                                For count2 = 0 To oDataTable.Rows.Count - 1
                                    If oDataTable.Rows(count2).Item(1) = count + 1 Then
                                        If oDataTable.Rows(count2).Item(2) <> .StartCoupon Or oDataTable.Rows(count2).Item(3) <> .EndCoupon Or oDataTable.Rows(count2).Item(4) <> .Type Or oDataTable.Rows(count2).Item(5) <> .Threshold Or oDataTable.Rows(count2).Item(6) <> .FeeAmt Then
                                            Me.CallProcedure("Coupon", oDataTable.Rows(count2).Item(0), oDataTable.Rows(count2).Item(1), "Update")
                                        End If
                                    End If
                                    Exit For
                                Next
                            ElseIf boolChk = False And info.FeeName <> "" Then
                                ReDim Preserve TransInsert.FeeTrans(TransInsert.FeeTrans.Length)
                                TransInsert.FeeTrans(TransInsert.FeeTrans.Length - 1) = New FeeTrans()
                                TransInsert.FeeTrans(TransInsert.FeeTrans.Length - 1).FeeID = info.FeeID
                                TransInsert.FeeTrans(TransInsert.FeeTrans.Length - 1).TransID = count + 1
                                Exit For
                            End If
                        End With
                    Next
                End If

                For count = 0 To oDataTable.Rows.Count - 1
                    boolChk2 = Me.FindDeleteCouponRecords(oDataTable.Rows(count).Item(1), info)
                    If boolChk2 = False Then
                        Me.CallProcedure("Coupon", oDataTable.Rows(count).Item(0).ToString(), oDataTable.Rows(count).Item(1).ToString(), "Delete")
                    End If
                Next
            Catch ex As Exception

            End Try
        End Sub

        Public Function FindDeleteCouponRecords(ByVal ID As String, ByVal info As DataInfo.TransCouponInfo)
            Dim bool As Boolean
            Dim count As Integer
            If info.CouponList.Count > 0 Then
                For count = 0 To info.CouponList.Count - 1
                    If ID = count + 1 Then
                        bool = True
                        Exit For
                    End If
                Next
            Else
                bool = False
            End If
            Return bool
        End Function

        Public Sub InsertCouponRecords()
            Dim count As Integer
            If Me.TransInsert.FeeTrans.Length > 0 Then
                For count = 0 To Me.TransInsert.FeeTrans.Length - 1
                    Me.CallProcedure("Coupon", TransInsert.FeeTrans(count).FeeID, TransInsert.FeeTrans(count).TransID, "Insert")
                Next
            End If
        End Sub

        Public Function UpdateFeeByCouponData(ByVal info As DataInfo.TransCouponInfo) As Integer
            Dim EffectRow As Integer
            Try
                FliterCouponRecords(info)
                With Me.MySQLParser
                    .OpenConnection()
                    .BeginTran()
                    .TableName = "tblTransactionFeebyCoupon"
                    With .Columns
                        .Clear()
                        .Add("FeeID", info.FeeID, SqlBuilder.SQLParserDataType.spNum, True)
                    End With
                    .ExecuteDelete()
                    '//
                    .TableName = "tblFeeByCoupon"
                    With .Columns
                        .Clear()
                        If info.PageMode = CWTMasterDB.TransactionMode.UpdateMode Then
                            .Add("FeeID", info.FeeID, SqlBuilder.SQLParserDataType.spNum, True)
                        End If
                        .Add("FeeName", info.FeeName)
                    End With

                    Select Case info.PageMode
                        Case CWTMasterDB.TransactionMode.AddNewMode
                            EffectRow = .ExecuteInsert()
                            .ExecuteStoreProcedure("exec sp_FeebyCoupon '" + info.FeeID + "','" + ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName + "','Insert'")
                            info.FeeID = .GetLastIdentity
                        Case CWTMasterDB.TransactionMode.UpdateMode
                            .ExecuteStoreProcedure("exec sp_FeebyCoupon '" + info.FeeID + "','" + ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName + "','Update'")
                            EffectRow = .ExecuteUpdate()
                    End Select
                    If EffectRow > 0 Then
                        '// 
                        .TableName = "tblTransactionFeebyCoupon"
                        For i As Integer = 0 To info.CouponList.Count - 1
                            With .Columns
                                .Clear()
                                .Add("FeeID", info.FeeID, SqlBuilder.SQLParserDataType.spNum)
                                .Add("TransID", i + 1, SqlBuilder.SQLParserDataType.spNum)
                                .Add("Type", info.CouponList(i).Type)
                                .Add("StartCoupon", info.CouponList(i).StartCoupon, SqlBuilder.SQLParserDataType.spNum)
                                .Add("EndCoupon", info.CouponList(i).EndCoupon, SqlBuilder.SQLParserDataType.spNum)
                                .Add("Threshold", info.CouponList(i).Threshold, SqlBuilder.SQLParserDataType.spNum)
                                .Add("TFAmount", info.CouponList(i).FeeAmt, SqlBuilder.SQLParserDataType.spNum)
                            End With
                            EffectRow = .ExecuteInsert()
                            If EffectRow <= 0 Then
                                Exit For
                            End If
                        Next
                    End If
                End With

                If EffectRow > 0 Then
                    Me.MySQLParser.CommitTran()
                    InsertCouponRecords()
                Else
                    Me.MySQLParser.RollbackTran()
                End If
            Catch ex As Exception
                EffectRow = -1
                Me.MySQLParser.RollbackTran()
            Finally
                Me.MySQLParser.CloseConnection()
            End Try
            Return EffectRow
        End Function
#End Region

#Region "Conditional"
        Public Function GetFeeByConditionalData(ByVal FeeID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblConditionalMarkup"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("FeeID", FeeID, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Sub FliterCondRecords(ByVal info As DataInfo.TransConditionalInfo)
            Dim count As Integer
            Dim count2 As Integer
            Dim InsertFeeID As DataTable = New DataTable()
            Dim oDataTable As DataTable
            Dim boolChk As Boolean
            Dim boolChk2 As Boolean
            TransInsert = New TransInsert()
            Dim DeleteCond As ArrayList = New ArrayList()
            Try

                With Me.MySQLParser
                    .TableName = "tblConditionalMarkup"
                    With .Columns
                        .Clear()
                        .IncludeKey = False
                        .Add("FeeID", info.FeeID, SqlBuilder.SQLParserDataType.spText, True)
                        .Add("*")
                    End With
                    oDataTable = .ExecuteDataTable()

                    If info.PageMode = CWTMasterDB.TransactionMode.AddNewMode Then
                        .TableName = "tblFeeByConditional"
                        With .Columns
                            .Clear()
                            .IncludeKey = False
                            .Add("max(FeeID)")
                        End With
                        InsertFeeID = .ExecuteDataTable()
                        If InsertFeeID.Rows.Count > 0 Then
                            info.FeeID = InsertFeeID.Rows(0).Item(0) + 1
                        Else
                            info.FeeID = 1
                        End If
                    End If
                End With

                If info.ConditionalList.Count > 0 Then

                    For count = 0 To info.ConditionalList.Count - 1
                        boolChk = Me.FindMatchRecords(count + 1, oDataTable)
                        With info.ConditionalList(count)
                            If boolChk Then
                                For count2 = 0 To oDataTable.Rows.Count - 1
                                    If oDataTable.Rows(count2).Item(1) = count + 1 Then
                                        If oDataTable.Rows(count2).Item(2).ToString <> .StartAmount Or oDataTable.Rows(count2).Item(3).ToString <> .EndAmount Or oDataTable.Rows(count2).Item(4).ToString <> .FeeAmt Then
                                            Me.CallProcedure("Conditional", oDataTable.Rows(count2).Item(0), oDataTable.Rows(count2).Item(1), "Update")
                                        End If
                                        Exit For
                                    End If
                                Next
                            ElseIf boolChk = False And info.FeeName <> "" Then
                                ReDim Preserve TransInsert.FeeTrans(TransInsert.FeeTrans.Length)
                                TransInsert.FeeTrans(TransInsert.FeeTrans.Length - 1) = New FeeTrans()
                                TransInsert.FeeTrans(TransInsert.FeeTrans.Length - 1).FeeID = info.FeeID
                                TransInsert.FeeTrans(TransInsert.FeeTrans.Length - 1).TransID = count + 1
                                Exit For
                            End If
                        End With
                    Next
                End If

                For count = 0 To oDataTable.Rows.Count - 1
                    boolChk2 = Me.FindDeleteCondRecords(oDataTable.Rows(count).Item(1), info)
                    If boolChk2 = False Then
                        Me.CallProcedure("Conditional", oDataTable.Rows(count).Item(0).ToString(), oDataTable.Rows(count).Item(1).ToString(), "Delete")
                    End If
                Next
            Catch ex As Exception

            End Try
        End Sub

        Public Function FindDeleteCondRecords(ByVal ID As String, ByVal info As DataInfo.TransConditionalInfo)
            Dim bool As Boolean
            Dim count As Integer
            If info.ConditionalList.Count > 0 Then
                For count = 0 To info.ConditionalList.Count - 1
                    If ID = count + 1 Then
                        bool = True
                        Exit For
                    End If
                Next
            Else
                bool = False
            End If
            Return bool
        End Function

        Public Sub InsertConditionalRecords()
            Dim count As Integer
            If Me.TransInsert.FeeTrans.Length > 0 Then
                For count = 0 To Me.TransInsert.FeeTrans.Length - 1
                    Me.CallProcedure("Conditional", TransInsert.FeeTrans(count).FeeID, TransInsert.FeeTrans(count).TransID, "Insert")
                Next
            End If
        End Sub


        Public Function UpdateFeeByConditionalData(ByVal info As DataInfo.TransConditionalInfo) As Integer
            Dim EffectRow As Integer
            Try
                FliterCondRecords(info)
                With Me.MySQLParser
                    .OpenConnection()
                    .BeginTran()
                    .TableName = "tblConditionalMarkup"
                    With .Columns
                        .Clear()
                        .Add("FeeID", info.FeeID, SqlBuilder.SQLParserDataType.spNum, True)
                    End With
                    .ExecuteDelete()
                    '//
                    .TableName = "tblFeeByConditional"
                    With .Columns
                        .Clear()
                        If info.PageMode = CWTMasterDB.TransactionMode.UpdateMode Then
                            .Add("FeeID", info.FeeID, SqlBuilder.SQLParserDataType.spNum, True)
                        End If
                        .Add("FeeName", info.FeeName)
                    End With

                    Select Case info.PageMode
                        Case CWTMasterDB.TransactionMode.AddNewMode
                            EffectRow = .ExecuteInsert()
                            .ExecuteStoreProcedure("exec sp_FeeByConditional '" + info.FeeID + "','" + ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName + "','Insert'")
                            info.FeeID = .GetLastIdentity
                        Case CWTMasterDB.TransactionMode.UpdateMode
                            .ExecuteStoreProcedure("exec sp_FeeByConditional '" + info.FeeID + "','" + ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName + "','Update'")
                            EffectRow = .ExecuteUpdate()
                    End Select
                    If EffectRow > 0 Then
                        '// 
                        .TableName = "tblConditionalMarkup"
                        For i As Integer = 0 To info.ConditionalList.Count - 1
                            With .Columns
                                .Clear()
                                .Add("FeeID", info.FeeID, SqlBuilder.SQLParserDataType.spNum)
                                .Add("TransID", i + 1, SqlBuilder.SQLParserDataType.spNum)
                                .Add("StartAmount", info.ConditionalList(i).StartAmount, SqlBuilder.SQLParserDataType.spNum)
                                .Add("EndAmount", info.ConditionalList(i).EndAmount, SqlBuilder.SQLParserDataType.spNum)
                                .Add("MarkUpAmount", info.ConditionalList(i).FeeAmt, SqlBuilder.SQLParserDataType.spNum)
                            End With
                            EffectRow = .ExecuteInsert()
                            If EffectRow <= 0 Then
                                Exit For
                            End If
                        Next
                    End If
                End With

                If EffectRow > 0 Then
                    Me.MySQLParser.CommitTran()
                    InsertConditionalRecords()
                Else
                    Me.MySQLParser.RollbackTran()
                End If
            Catch ex As Exception
                EffectRow = -1
                Me.MySQLParser.RollbackTran()
            Finally
                Me.MySQLParser.CloseConnection()
            End Try
            Return EffectRow
        End Function
#End Region

#Region "PNR"
        Public Function GetFeeByPNRData(ByVal FeeID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblTransactionFeebyPNR"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("FeeID", FeeID, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Sub FliterPNRRecords(ByVal info As DataInfo.TransPNRInfo)
            Dim count As Integer
            Dim count2 As Integer

            Dim chkRegion As String
            Dim chkCountry As String
            Dim chkCity As String
            Dim getCountry As String()
            Dim getCity As String()
            Dim ctry As String
            Dim ctrytable As DataTable
            Dim city As String
            Dim citytable As DataTable
            Dim RegionCode As String = ""
            Dim CountryCode As String = ""
            Dim ConBLL As New BusinessLogicLayer.ConfigurationBLL()
            Dim TerritoryCode As String = ""

            Dim InsertFeeID As DataTable = New DataTable()
            Dim oDataTable As DataTable
            'Dim foundRow() As DataRow
            Dim boolChk As Boolean
            Dim boolChk2 As Boolean
            TransInsert = New TransInsert()
            Dim DeletePNR As ArrayList = New ArrayList()
            Try

                With Me.MySQLParser
                    .TableName = "tblTransactionFeeByPNR"
                    With .Columns
                        .Clear()
                        .IncludeKey = False
                        .Add("FeeID", info.FeeID, SqlBuilder.SQLParserDataType.spText, True)
                        .Add("*")
                    End With
                    oDataTable = .ExecuteDataTable()


                    If info.PageMode = CWTMasterDB.TransactionMode.AddNewMode Then
                        .TableName = "tblFeeByPNR"
                        With .Columns
                            .Clear()
                            .IncludeKey = False
                            .Add("max(FeeID)")
                        End With
                        InsertFeeID = .ExecuteDataTable()
                        If InsertFeeID.Rows.Count > 0 Then
                            info.FeeID = InsertFeeID.Rows(0).Item(0) + 1
                        Else
                            info.FeeID = 1
                        End If
                    End If
                End With

                If info.PNRList.Count > 0 Then
                    For count = 0 To info.PNRList.Count - 1

                        chkRegion = info.PNRList(count).RegionSelect
                        chkCountry = info.PNRList(count).CountrySelect
                        chkCity = info.PNRList(count).CitySelect


                        Select Case info.PNRList(count).ApplyMode
                            Case DataInfo.PNRItemInfo.ApplyByItem.Region
                                If chkRegion = ("All") AndAlso chkRegion IsNot Nothing Then
                                    TerritoryCode = "X"
                                Else
                                    TerritoryCode = info.PNRList(count).RegionSQLString
                                End If

                            Case DataInfo.PNRItemInfo.ApplyByItem.Country
                                getCountry = info.PNRList(count).CountrySQLString.Split(";"c)
                                ctry = getCountry(0)

                                ctrytable = ConBLL.GetRegionByID3(ctry)
                                If ctrytable IsNot Nothing AndAlso ctrytable.Rows.Count > 0 Then
                                    RegionCode = ctrytable.Rows(0).Item("RegionCode").ToString
                                End If
                                If chkCountry = ("All") AndAlso chkCountry IsNot Nothing Then
                                    TerritoryCode = RegionCode
                                Else
                                    TerritoryCode = info.PNRList(count).CountrySQLString
                                End If

                            Case DataInfo.PNRItemInfo.ApplyByItem.City

                                getCity = info.PNRList(count).CitySQLString.Split(";"c)
                                city = getCity(0)
                                citytable = ConBLL.GetRegionByID4(city)
                                If citytable IsNot Nothing AndAlso citytable.Rows.Count > 0 Then
                                    CountryCode = citytable.Rows(0).Item("CountryCode").ToString
                                End If

                                If chkCity = ("All") AndAlso chkCity IsNot Nothing Then
                                    TerritoryCode = CountryCode
                                Else
                                    TerritoryCode = info.PNRList(count).CitySQLString
                                End If

                        End Select

                        boolChk = Me.FindMatchRecords(count + 1, oDataTable)
                        With info.PNRList(count)
                            If boolChk Then
                                For count2 = 0 To oDataTable.Rows.Count - 1
                                    If oDataTable.Rows(count2).Item(1) = count + 1 Then
                                        If oDataTable.Rows(count2).Item(2).ToString <> .FareFrom Or oDataTable.Rows(count2).Item(3).ToString <> .FareTo Or oDataTable.Rows(count2).Item(6).ToString <> .ApplyMode Or oDataTable.Rows(count2).Item(7).ToString <> .FareAmt Or oDataTable.Rows(count2).Item("TerritoryCode").ToString <> TerritoryCode Then
                                            Me.CallProcedure("PNR", oDataTable.Rows(count2).Item(0), oDataTable.Rows(count2).Item(1), "Update")
                                        End If
                                        Exit For
                                    End If
                                Next
                            ElseIf boolChk = False And info.FeeName <> "" Then
                                ReDim Preserve TransInsert.FeeTrans(TransInsert.FeeTrans.Length)
                                TransInsert.FeeTrans(TransInsert.FeeTrans.Length - 1) = New FeeTrans()
                                TransInsert.FeeTrans(TransInsert.FeeTrans.Length - 1).FeeID = info.FeeID
                                TransInsert.FeeTrans(TransInsert.FeeTrans.Length - 1).TransID = count + 1
                                Exit For
                            End If
                        End With
                    Next
                End If

                For count = 0 To oDataTable.Rows.Count - 1
                    boolChk2 = Me.FindDeletePNRRecords(oDataTable.Rows(count).Item(1), info)
                    If boolChk2 = False Then
                        Me.CallProcedure("PNR", oDataTable.Rows(count).Item(0).ToString(), oDataTable.Rows(count).Item(1).ToString(), "Delete")
                    End If
                Next
            Catch ex As Exception

            End Try
        End Sub

        Public Function FindDeletePNRRecords(ByVal ID As String, ByVal info As DataInfo.TransPNRInfo)
            Dim bool As Boolean
            Dim count As Integer
            If info.PNRList.Count > 0 Then
                For count = 0 To info.PNRList.Count - 1
                    If ID = count + 1 Then
                        bool = True
                        Exit For
                    End If
                Next
            Else
                bool = False
            End If
            Return bool
        End Function

        Public Sub InsertPNRRecords()
            Dim count As Integer
            If Me.TransInsert.FeeTrans.Length > 0 Then
                For count = 0 To Me.TransInsert.FeeTrans.Length - 1
                    Me.CallProcedure("PNR", TransInsert.FeeTrans(count).FeeID, TransInsert.FeeTrans(count).TransID, "Insert")
                Next
            End If
        End Sub

        Public Function UpdateFeeByPNRData(ByVal info As DataInfo.TransPNRInfo) As Integer
            Dim EffectRow As Integer
            Dim chkRegion As String
            Dim chkCountry As String
            Dim chkCity As String
            Dim getCountry As String()
            Dim getCity As String()
            Dim ctry As String
            Dim ctrytable As DataTable
            Dim city As String
            Dim citytable As DataTable
            Dim RegionCode As String = ""
            Dim CountryCode As String = ""
            Dim ConBLL As New BusinessLogicLayer.ConfigurationBLL()
            Try
                FliterPNRRecords(info)
                With Me.MySQLParser
                    .OpenConnection()
                    .BeginTran()
                    .TableName = "tblTransactionFeebyPNR"
                    If info.PageMode = CWTMasterDB.TransactionMode.UpdateMode Then
                        With .Columns
                            .Clear()
                            .Add("FeeID", info.FeeID, SqlBuilder.SQLParserDataType.spNum, True)
                        End With
                        .ExecuteDelete()
                    End If
                    '//
                    .TableName = "tblFeeByPNR"
                    With .Columns
                        .Clear()
                        If info.PageMode = CWTMasterDB.TransactionMode.UpdateMode Then
                            .Add("FeeID", info.FeeID, SqlBuilder.SQLParserDataType.spNum, True)
                        End If
                        .Add("FeeName", info.FeeName)
                    End With

                    Select Case info.PageMode
                        Case CWTMasterDB.TransactionMode.AddNewMode
                            EffectRow = .ExecuteInsert()
                            .ExecuteStoreProcedure("exec sp_FeeByPNR '" + info.FeeID + "','" + ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName + "','Insert'")
                            info.FeeID = .GetLastIdentity
                        Case CWTMasterDB.TransactionMode.UpdateMode
                            .ExecuteStoreProcedure("exec sp_FeeByPNR '" + info.FeeID + "','" + ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName + "','Update'")
                            EffectRow = .ExecuteUpdate()
                    End Select
                    If EffectRow > 0 Then

                        '// 
                        .TableName = "tblTransactionFeebyPNR"
                        For i As Integer = 0 To info.PNRList.Count - 1
                            If info.PNRList(i) Is Nothing Then

                            Else
                                chkRegion = info.PNRList(i).RegionSelect
                                chkCountry = info.PNRList(i).CountrySelect
                                chkCity = info.PNRList(i).CitySelect
                                With .Columns
                                    .Clear()
                                    .Add("FeeID", info.FeeID, SqlBuilder.SQLParserDataType.spNum)
                                    .Add("TransID", i + 1, SqlBuilder.SQLParserDataType.spNum)
                                    '.Add("ApplyAll", info.PNRList(i).IsApplyAll, SqlBuilder.SQLParserDataType.spBoolean)
                                    .Add("TerritoryType", info.PNRList(i).ApplyMode)
                                    Select Case info.PNRList(i).ApplyMode
                                        Case DataInfo.PNRItemInfo.ApplyByItem.Region
                                            If chkRegion = ("All") AndAlso chkRegion IsNot Nothing Then
                                                .Add("TerritoryCode", "X")
                                            Else
                                                .Add("TerritoryCode", info.PNRList(i).RegionSQLString)
                                            End If

                                        Case DataInfo.PNRItemInfo.ApplyByItem.Country
                                            getCountry = info.PNRList(i).CountrySQLString.Split(";"c)
                                            ctry = getCountry(0)

                                            ctrytable = ConBLL.GetRegionByID3(ctry)
                                            If ctrytable IsNot Nothing AndAlso ctrytable.Rows.Count > 0 Then
                                                RegionCode = ctrytable.Rows(0).Item("RegionCode").ToString
                                            End If
                                            If chkCountry = ("All") AndAlso chkCountry IsNot Nothing Then
                                                .Add("TerritoryCode", RegionCode)
                                            Else
                                                .Add("TerritoryCode", info.PNRList(i).CountrySQLString)
                                            End If

                                        Case DataInfo.PNRItemInfo.ApplyByItem.City

                                            getCity = info.PNRList(i).CitySQLString.Split(";"c)
                                            city = getCity(0)
                                            citytable = ConBLL.GetRegionByID4(city)
                                            If citytable IsNot Nothing AndAlso citytable.Rows.Count > 0 Then
                                                CountryCode = citytable.Rows(0).Item("CountryCode").ToString
                                            End If

                                            If chkCity = ("All") AndAlso chkCity IsNot Nothing Then
                                                .Add("TerritoryCode", CountryCode)
                                            Else
                                                .Add("TerritoryCode", info.PNRList(i).CitySQLString)
                                            End If

                                    End Select
                                    .Add("StartAmount", info.PNRList(i).FareFrom, SqlBuilder.SQLParserDataType.spNum)
                                    .Add("EndAmount", info.PNRList(i).FareTo, SqlBuilder.SQLParserDataType.spNum)
                                    .Add("TFAmount", info.PNRList(i).FareAmt, SqlBuilder.SQLParserDataType.spNum)
                                End With
                                EffectRow = .ExecuteInsert()
                                If EffectRow <= 0 Then
                                    Exit For
                                End If
                            End If
                        Next
                    End If
                End With

                If EffectRow > 0 Then
                    Me.MySQLParser.CommitTran()
                    InsertPNRRecords()
                Else
                    Me.MySQLParser.RollbackTran()
                End If
            Catch ex As Exception
                EffectRow = -1
                Me.MySQLParser.RollbackTran()
            Finally
                Me.MySQLParser.CloseConnection()
            End Try
            Return EffectRow
        End Function
#End Region

#Region "Ticket"
        Public Function GetFeeByTicketData(ByVal FeeID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblTransactionFeebyTicket"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("FeeID", FeeID, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Sub FliterFeeRecords(ByVal info As DataInfo.TransTicketInfo)
            Dim count As Integer
            Dim count2 As Integer
            Dim chkRegion As String
            Dim chkCountry As String
            Dim chkCity As String
            Dim getCountry As String()
            Dim getCity As String()
            Dim ctry As String
            Dim ctrytable As DataTable
            Dim city As String
            Dim citytable As DataTable
            Dim RegionCode As String = ""
            Dim CountryCode As String = ""
            Dim ConBLL As New BusinessLogicLayer.ConfigurationBLL()

            Dim InsertFeeID As DataTable = New DataTable
            Dim RegionCountry As String = ""
            Dim oDataTable As DataTable
            Dim boolChk As Boolean
            Dim boolChk2 As Boolean
            TransInsert = New TransInsert()
            '  Dim DeleteTicket As ArrayList = New ArrayList()
            Try

                With Me.MySQLParser
                    .TableName = "tblTransactionFeeByTicket"
                    With .Columns
                        .Clear()
                        .IncludeKey = False
                        .Add("FeeID", info.FeeID, SqlBuilder.SQLParserDataType.spText, True)
                        .Add("*")
                    End With
                    oDataTable = .ExecuteDataTable()


                    If info.PageMode = CWTMasterDB.TransactionMode.AddNewMode Then
                        .TableName = "tblFeeByTicket"
                        With .Columns
                            .Clear()
                            .IncludeKey = False
                            .Add("max(FeeID)")
                        End With
                        InsertFeeID = .ExecuteDataTable()
                        If InsertFeeID.Rows.Count > 0 Then
                            info.FeeID = InsertFeeID.Rows(0).Item(0) + 1
                        Else
                            info.FeeID = 1
                        End If

                    End If

                End With




                If info.TicketList.Count > 0 Then

                    For count = 0 To info.TicketList.Count - 1
                        boolChk = Me.FindMatchRecords(count + 1, oDataTable)
                        With info.TicketList(count)
                            chkRegion = info.TicketList(count).RegionSelect
                            chkCountry = info.TicketList(count).CountrySelect
                            chkCity = info.TicketList(count).CitySelect


                            Select Case info.TicketList(count).ApplyMode
                                Case DataInfo.PNRItemInfo.ApplyByItem.Region

                                    If chkRegion = ("All") AndAlso chkRegion IsNot Nothing Then
                                        '.Add("TerritoryCode", "X")
                                        RegionCountry = "X"
                                    Else
                                        RegionCountry = info.TicketList(count).RegionSQLString
                                        '.Add("TerritoryCode", info.TicketList(count).RegionSQLString)
                                    End If

                                Case DataInfo.PNRItemInfo.ApplyByItem.Country

                                    getCountry = info.TicketList(count).CountrySQLString.Split(";"c)
                                    ctry = getCountry(0)

                                    ctrytable = ConBLL.GetRegionByID3(ctry)
                                    If ctrytable IsNot Nothing AndAlso ctrytable.Rows.Count > 0 Then
                                        RegionCode = ctrytable.Rows(0).Item("RegionCode").ToString
                                    End If
                                    If chkCountry = ("All") AndAlso chkCountry IsNot Nothing Then
                                        RegionCountry = RegionCode
                                    Else
                                        RegionCountry = info.TicketList(count).CountrySQLString
                                    End If

                                Case DataInfo.PNRItemInfo.ApplyByItem.City
                                    getCity = info.TicketList(count).CitySQLString.Split(";"c)
                                    city = getCity(0)
                                    citytable = ConBLL.GetRegionByID4(city)
                                    If citytable IsNot Nothing AndAlso citytable.Rows.Count > 0 Then
                                        CountryCode = citytable.Rows(0).Item("CountryCode").ToString
                                    End If

                                    If chkCity = "All" AndAlso chkCity IsNot Nothing Then
                                        RegionCountry = CountryCode
                                    Else
                                        RegionCountry = info.TicketList(count).CitySQLString
                                    End If


                            End Select


                            If boolChk Then
                                For count2 = 0 To oDataTable.Rows.Count - 1
                                    If oDataTable.Rows(count2).Item(1) = count + 1 Then
                                        If oDataTable.Rows(count2).Item(2) <> .FareFrom Or oDataTable.Rows(count2).Item(3) <> .FareTo Or oDataTable.Rows(count2).Item(4) <> .FareAmt Or oDataTable.Rows(count2).Item(5) <> .ExtraAmt Or oDataTable.Rows(count2).Item(6) <> .MinAmt Or oDataTable.Rows(count2).Item(7) <> .MaxAmt Or oDataTable.Rows(count2).Item(8) <> .PerAmt Or oDataTable.Rows(count2).Item(9) <> .IsExtraFee Or oDataTable.Rows(count2).Item(10) <> .OperatorAmt Or oDataTable.Rows(count2).Item("TerritoryType") <> .ApplyMode Or oDataTable.Rows(count2).Item("TerritoryCode").ToString <> RegionCountry Then
                                            Me.CallProcedure("Ticket", oDataTable.Rows(count2).Item(0), oDataTable.Rows(count2).Item(1), "Update")
                                        End If
                                        Exit For
                                    End If
                                Next
                            ElseIf boolChk = False And info.FeeName <> "" Then
                                ReDim Preserve TransInsert.FeeTrans(TransInsert.FeeTrans.Length)
                                TransInsert.FeeTrans(TransInsert.FeeTrans.Length - 1) = New FeeTrans()
                                TransInsert.FeeTrans(TransInsert.FeeTrans.Length - 1).FeeID = info.FeeID
                                TransInsert.FeeTrans(TransInsert.FeeTrans.Length - 1).TransID = count + 1
                                Exit For
                            End If
                        End With
                    Next
                End If

                For count = 0 To oDataTable.Rows.Count - 1
                    boolChk2 = Me.FindDeleteTicketRecords(oDataTable.Rows(count).Item(1), info)
                    If boolChk2 = False Then
                        Me.CallProcedure("Ticket", oDataTable.Rows(count).Item(0).ToString(), oDataTable.Rows(count).Item(1).ToString(), "Delete")
                    End If
                Next
            Catch ex As Exception

            End Try
        End Sub

        Public Function FindDeleteTicketRecords(ByVal ID As String, ByVal info As DataInfo.TransTicketInfo)
            Dim bool As Boolean
            Dim count As Integer
            If info.TicketList.Count > 0 Then
                For count = 0 To info.TicketList.Count - 1
                    If ID = count + 1 Then
                        bool = True
                        Exit For
                    End If
                Next
            Else
                bool = False
            End If
            Return bool
        End Function

        Public Sub InsertTicketRecords()
            Dim count As Integer
            If Me.TransInsert.FeeTrans.Length > 0 Then
                For count = 0 To Me.TransInsert.FeeTrans.Length - 1
                    Me.CallProcedure("Ticket", TransInsert.FeeTrans(count).FeeID, TransInsert.FeeTrans(count).TransID, "Insert")
                Next
            End If
        End Sub

        Public Function UpdateFeeByTicketData(ByVal info As DataInfo.TransTicketInfo) As String
            Dim EffectRow As Integer
            Dim chkRegion As String
            Dim chkCountry As String
            Dim chkCity As String
            Dim getCountry As String()
            Dim getCity As String()
            Dim ctry As String
            Dim ctrytable As DataTable
            Dim city As String
            Dim citytable As DataTable
            Dim RegionCode As String = ""
            Dim CountryCode As String = ""
            Dim ConBLL As New BusinessLogicLayer.ConfigurationBLL()
            Try
                Me.FliterFeeRecords(info)
                With Me.MySQLParser
                    .OpenConnection()
                    .BeginTran()
                    .TableName = "tblTransactionFeebyTicket"
                    If info.PageMode = CWTMasterDB.TransactionMode.UpdateMode Then
                        With .Columns
                            .Clear()
                            .Add("FeeID", info.FeeID, SqlBuilder.SQLParserDataType.spNum, True)
                        End With
                        .ExecuteDelete()
                    End If
                    '//
                    .TableName = "tblFeeByTicket"
                    With .Columns
                        .Clear()
                        If info.PageMode = CWTMasterDB.TransactionMode.UpdateMode Then
                            .Add("FeeID", info.FeeID, SqlBuilder.SQLParserDataType.spNum, True)
                        End If
                        .Add("FeeName", info.FeeName)
                    End With

                    Select Case info.PageMode
                        Case CWTMasterDB.TransactionMode.AddNewMode
                            EffectRow = .ExecuteInsert()
                            .ExecuteStoreProcedure("exec sp_FeeByTicket '" + info.FeeID + "','" + ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName + "','Insert'")
                            info.FeeID = .GetLastIdentity
                        Case CWTMasterDB.TransactionMode.UpdateMode
                            .ExecuteStoreProcedure("exec sp_FeeByTicket '" + info.FeeID + "','" + ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName + "','Update'")
                            EffectRow = .ExecuteUpdate()
                    End Select
                    If EffectRow > 0 Then
                        '// 
                        .TableName = "tblTransactionFeebyTicket"

                        For i As Integer = 0 To info.TicketList.Count - 1
                            If info.TicketList(i) Is Nothing Then

                            Else
                                chkRegion = info.TicketList(i).RegionSelect
                                chkCountry = info.TicketList(i).CountrySelect
                                chkCity = info.TicketList(i).CitySelect
                                With .Columns
                                    .Clear()
                                    .Add("FeeID", info.FeeID, SqlBuilder.SQLParserDataType.spNum)
                                    .Add("TransID", i + 1, SqlBuilder.SQLParserDataType.spNum)
                                    '.Add("ApplyAll", info.TicketList(i).IsApplyAll, SqlBuilder.SQLParserDataType.spBoolean)
                                    .Add("ExtraFee", info.TicketList(i).IsExtraFee, SqlBuilder.SQLParserDataType.spBoolean)
                                    .Add("TerritoryType", info.TicketList(i).ApplyMode)
                                    Select Case info.TicketList(i).ApplyMode
                                        Case DataInfo.PNRItemInfo.ApplyByItem.Region

                                            If chkRegion = ("All") AndAlso chkRegion IsNot Nothing Then
                                                .Add("TerritoryCode", "X")
                                            Else
                                                .Add("TerritoryCode", info.TicketList(i).RegionSQLString)
                                            End If

                                        Case DataInfo.PNRItemInfo.ApplyByItem.Country

                                            getCountry = info.TicketList(i).CountrySQLString.Split(";"c)
                                            ctry = getCountry(0)

                                            ctrytable = ConBLL.GetRegionByID3(ctry)
                                            If ctrytable IsNot Nothing AndAlso ctrytable.Rows.Count > 0 Then
                                                RegionCode = ctrytable.Rows(0).Item("RegionCode").ToString
                                            End If
                                            If chkCountry = ("All") AndAlso chkCountry IsNot Nothing Then
                                                .Add("TerritoryCode", RegionCode)
                                            Else
                                                .Add("TerritoryCode", info.TicketList(i).CountrySQLString)
                                            End If

                                        Case DataInfo.PNRItemInfo.ApplyByItem.City
                                            getCity = info.TicketList(i).CitySQLString.Split(";"c)
                                            city = getCity(0)
                                            citytable = ConBLL.GetRegionByID4(city)
                                            If citytable IsNot Nothing AndAlso citytable.Rows.Count > 0 Then
                                                CountryCode = citytable.Rows(0).Item("CountryCode").ToString
                                            End If

                                            If chkCity = "All" AndAlso chkCity IsNot Nothing Then
                                                .Add("TerritoryCode", CountryCode)
                                            Else
                                                .Add("TerritoryCode", info.TicketList(i).CitySQLString)
                                            End If


                                    End Select
                                    .Add("StartAmount", info.TicketList(i).FareFrom, SqlBuilder.SQLParserDataType.spNum)
                                    .Add("EndAmount", info.TicketList(i).FareTo, SqlBuilder.SQLParserDataType.spNum)
                                    .Add("TFAmount", info.TicketList(i).FareAmt, SqlBuilder.SQLParserDataType.spNum)
                                    .Add("ExtraAmount", info.TicketList(i).ExtraAmt, SqlBuilder.SQLParserDataType.spNum)
                                    .Add("MinAmount", info.TicketList(i).MinAmt, SqlBuilder.SQLParserDataType.spNum)
                                    .Add("MaxAmount", info.TicketList(i).MaxAmt, SqlBuilder.SQLParserDataType.spNum)
                                    .Add("PerAmount", info.TicketList(i).PerAmt, SqlBuilder.SQLParserDataType.spNum)
                                    .Add("[Operator]", info.TicketList(i).OperatorAmt)
                                End With
                                EffectRow = .ExecuteInsert()
                            End If

                            If EffectRow <= 0 Then
                                Exit For
                            End If
                        Next
                    End If
                End With

                If EffectRow > 0 Then
                    Me.MySQLParser.CommitTran()
                    'Insert records
                    InsertTicketRecords()
                Else
                    Me.MySQLParser.RollbackTran()
                End If
            Catch ex As Exception
                EffectRow = -1
                Me.MySQLParser.RollbackTran()
            Finally
                Me.MySQLParser.CloseConnection()
            End Try
            Return EffectRow
        End Function
#End Region

      

        Public Sub CallProcedure(ByVal FeeType As String, ByVal ID As String, ByVal TID As String, ByVal Type As String)
            With Me.MySQLParser
                .OpenConnection()
                .BeginTran()
                Select Case FeeType
                    Case "Ticket"
                        .ExecuteStoreProcedure("exec sp_TransactionFeeByTicket '" + ID + "','" + TID + "','" + ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName + "','" + Type + "'")
                    Case "PNR"
                        .ExecuteStoreProcedure("exec sp_TransactionFeeByPNR '" + ID + "','" + TID + "','" + ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName + "','" + Type + "'")
                    Case "Coupon"
                        .ExecuteStoreProcedure("exec sp_TransactionFeeByCoupon '" + ID + "','" + TID + "','" + ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName + "','" + Type + "'")
                    Case "Conditional"
                        .ExecuteStoreProcedure("exec sp_ConditionalMarkup '" + ID + "','" + TID + "','" + ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName + "','" + Type + "'")
                End Select
                .CommitTran()
                .CloseConnection()
            End With
        End Sub

        Public Function FindMatchRecords(ByVal ID As String, ByVal dt As DataTable)
            Dim count2 As Integer
            Dim bool As Boolean = False
            For count2 = 0 To dt.Rows.Count - 1
                If dt.Rows(count2).Item(1) = ID Then
                    bool = True
                    Exit For
                End If
            Next
            Return bool
        End Function

        Public Function GetTempFeeData(ByVal FeeType) As DataTable
            Dim dt As DataTable
            Dim dt2 As DataTable
            Dim resultTable As DataTable
            Dim TempTable As DataTable
            Dim foundRow() As DataRow
            Dim count As Integer
            Dim tblName As String = ""
            Dim tblName2 As String = ""
            Dim ArrString(0) As String
            ArrString(0) = "FeeID"

            Select Case FeeType
                Case "PNR"
                    tblName = "Temp_tblFeeByPNR"
                    tblName2 = "tblFeeByPNR"
                Case "Ticket"
                    tblName = "Temp_tblFeeByTicket"
                    tblName2 = "tblFeeByTicket"
                Case "Coupon"
                    tblName = "Temp_tblFeeByCoupon"
                    tblName2 = "tblFeeByCoupon"
                Case "Conditional"
                    tblName = "Temp_tblFeeByConditional"
                    tblName2 = "tblFeeByConditional"
                Case Else
                    Return Nothing
            End Select
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = tblName
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("*")
                End With
                dt = .ExecuteDataTable(.SQLSelect + " order by DateModification Desc")

                .TableName = tblName2
                With .Columns
                    .Clear()
                    .IncludeKey = False
                    .Add("*")
                End With
                dt2 = .ExecuteDataTable()
            End With
            TempTable = dt.DefaultView.ToTable(True, ArrString)
            resultTable = dt.Clone()
            For count = 0 To TempTable.Rows.Count - 1
                foundRow = dt2.Select("FeeID='" + TempTable.Rows(count).Item("FeeID").ToString() + "'")
                If foundRow.Length > 0 Then
                    resultTable.ImportRow(foundRow(0))
                End If
            Next
            resultTable.AcceptChanges()
            resultTable.Merge(dt)
            Return resultTable
        End Function

        Public Function GetTempFeeDataByName(ByVal Name As String, ByVal FeeType As String, ByVal DateFrom As String, ByVal DateTo As String) As DataTable
            Dim dt As DataTable
            Dim dt2 As DataTable
            Dim tblName As String = ""
            Dim tblName2 As String = ""

            Dim resultTable As DataTable
            Dim TempTable As DataTable
            Dim foundRow() As DataRow
            Dim count As Integer
            Dim ArrString(0) As String
            ArrString(0) = "FeeID"


            Select Case FeeType
                Case "PNR"
                    tblName = "Temp_tblFeeByPNR"
                    tblName2 = "tblFeeByPNR"
                Case "Ticket"
                    tblName = "Temp_tblFeeByTicket"
                    tblName2 = "tblFeeByTicket"
                Case "Coupon"
                    tblName = "Temp_tblFeeByCoupon"
                    tblName2 = "tblFeeByCoupon"
                Case "Conditional"
                    tblName = "Temp_tblFeeByConditional"
                    tblName2 = "tblFeeByConditional"
                Case Else
                    Return Nothing
            End Select
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = tblName
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    If Name <> "" Then
                        .Add("FeeName", Name, SqlBuilder.SQLParserDataType.spText, True)
                    End If
                    If DateFrom = DateTo Then
                        If DateFrom <> "" And DateTo <> "" Then
                            DateTo = DateTo + " 23:59:59:997"
                            .Add("DateModification", "convert(varchar,cast('" + DateFrom + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, ">")
                            .Add("DateModification", "convert(varchar,cast('" + DateTo + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, "<")
                        End If
                    Else
                        If DateFrom <> "" Then
                            .Add("DateModification", DateFrom, SqlBuilder.SQLParserDataType.spDate, True, ">")
                        End If
                        If DateTo <> "" Then
                            DateTo = DateTo + " 23:59:59:999"
                            .Add("DateModification", DateTo, SqlBuilder.SQLParserDataType.spText, True, "<=")
                        End If
                    End If
                    .Add("*")
                End With
                dt = .ExecuteDataTable(.SQLSelect + " order by DateModification Desc")
                .TableName = tblName2
                With .Columns
                    .Clear()
                    .IncludeKey = False
                    If Name <> "" Then
                        .Add("FeeName", Name, SqlBuilder.SQLParserDataType.spText, True)
                    End If
                    .Add("Distinct * ")
                End With
                dt2 = .ExecuteDataTable()
            End With
            If Name <> "" Then
                dt2.Merge(dt)
                Return dt2
            Else
                TempTable = dt.DefaultView.ToTable(True, ArrString)
                resultTable = dt.Clone()
                For count = 0 To TempTable.Rows.Count - 1
                    foundRow = dt2.Select("FeeID='" + TempTable.Rows(count).Item("FeeID").ToString() + "'")
                    If foundRow.Length > 0 Then
                        resultTable.ImportRow(foundRow(0))
                    End If
                Next
                resultTable.AcceptChanges()
                resultTable.Merge(dt)
                Return resultTable
            End If
        End Function

        Public Function GetTempTransactionFeeData(ByVal FeeType) As DataTable
            Dim dt As DataTable
            Dim dt2 As DataTable
            Dim TempTable As DataTable
            Dim resultTable As DataTable
            Dim foundRow() As DataRow
            Dim count As Integer
            Dim tblName As String = ""
            Dim tblName2 As String = ""
            Dim ArrString(1) As String
            ArrString(0) = "FeeID"
            ArrString(1) = "TransID"

            Select Case FeeType
                Case "PNR"
                    tblName = "Temp_tblTransactionFeeByPNR"
                    tblName2 = "tblTransactionFeeByPNR"
                Case "Ticket"
                    tblName = "Temp_tblTransactionFeeByTicket"
                    tblName2 = "tblTransactionFeeByTicket"
                Case "Coupon"
                    tblName = "Temp_tblTransactionFeeByCoupon"
                    tblName2 = "tblTransactionFeeByCoupon"
                Case "Conditional"
                    tblName = "Temp_tblConditionalMarkup"
                    tblName2 = "tblConditionalMarkup"
                Case Else
                    Return Nothing
            End Select
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = tblName
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("*")
                End With
                dt = .ExecuteDataTable(.SQLSelect + " order by DateModification Desc")
                .TableName = tblName2
                With .Columns
                    .Clear()
                    .IncludeKey = False
                    .Add("*")
                End With
                dt2 = .ExecuteDataTable()
            End With
            TempTable = dt.DefaultView.ToTable(True, ArrString)

            resultTable = dt.Clone()
            For count = 0 To TempTable.Rows.Count - 1
                foundRow = dt2.Select("TransID ='" + TempTable.Rows(count).Item("TransID").ToString() + "' And FeeID='" + TempTable.Rows(count).Item("FeeID").ToString() + "'")
                If foundRow.Length > 0 Then
                    resultTable.ImportRow(foundRow(0))
                End If
            Next
            resultTable.AcceptChanges()
            resultTable.Merge(dt)
            Return resultTable
        End Function

        Public Function GetTempTransactionFeeDataByName(ByVal Name As String, ByVal FeeType As String, ByVal DateFrom As String, ByVal DateTo As String) As DataTable
            Dim dt As DataTable
            Dim dt2 As DataTable
            Dim resultTable As DataTable
            Dim TempTable As DataTable
            Dim foundRow() As DataRow
            Dim count As Integer
            Dim view As New DataView()
            Dim tblName As String = ""
            Dim tblName2 As String = ""
            Dim ArrString(1) As String
            ArrString(0) = "FeeID"
            ArrString(1) = "TransID"


            Select Case FeeType
                Case "PNR"
                    tblName = "Temp_tblTransactionFeeByPNR p inner join tblFeeByPNR fp on p.FeeID = fp.FeeID"
                    tblName2 = "tblTransactionFeeByPNR p inner join tblFeeByPNR fp on p.FeeID = fp.FeeID"
                Case "Ticket"
                    tblName = "Temp_tblTransactionFeeByTicket p inner join tblFeeByTicket fp on p.FeeID = fp.FeeID"
                    tblName2 = "tblTransactionFeeByTicket p inner join tblFeeByTicket fp on p.FeeID = fp.FeeID"
                Case "Coupon"
                    tblName = "Temp_tblTransactionFeeByCoupon p inner join tblFeeByCoupon fp on p.FeeID = fp.FeeID"
                    tblName2 = "tblTransactionFeeByCoupon p inner join tblFeeByCoupon fp on p.FeeID = fp.FeeID"
                Case "Conditional"
                    tblName = "Temp_tblConditionalMarkup p inner join tblFeeByConditional fp on p.FeeID = fp.FeeID"
                    tblName2 = "tblConditionalMarkup p inner join tblFeeByConditional fp on p.FeeID = fp.FeeID"
                Case Else
                    Return Nothing
            End Select
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = tblName
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    If Name <> "" Then
                        .Add("fp.FeeName", Name, SqlBuilder.SQLParserDataType.spText, True)
                    End If
                    If DateFrom = DateTo Then
                        If DateFrom <> "" And DateTo <> "" Then
                            DateTo = DateTo + " 23:59:59:997"
                            .Add("DateModification", "convert(varchar,cast('" + DateFrom + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, ">")
                            .Add("DateModification", "convert(varchar,cast('" + DateTo + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, "<")
                        End If
                    Else
                        If DateFrom <> "" Then
                            .Add("DateModification", DateFrom, SqlBuilder.SQLParserDataType.spDate, True, ">")
                        End If
                        If DateTo <> "" Then
                            DateTo = DateTo + " 23:59:59:999"
                            .Add("DateModification", DateTo, SqlBuilder.SQLParserDataType.spText, True, "<=")
                        End If
                    End If
                    .Add("p.*")
                End With
                dt = .ExecuteDataTable(.SQLSelect + " order by DateModification Desc")
                TempTable = dt.DefaultView.ToTable(True, ArrString)
                .TableName = tblName2
                With .Columns
                    .Clear()
                    .IncludeKey = False
                    If Name <> "" Then
                        .Add("fp.FeeName", Name, SqlBuilder.SQLParserDataType.spText, True)
                    End If
                    .Add("Distinct p.* ")
                End With
                dt2 = .ExecuteDataTable()
            End With

            resultTable = dt.Clone()
            For count = 0 To TempTable.Rows.Count - 1
                foundRow = dt2.Select("TransID ='" + TempTable.Rows(count).Item("TransID").ToString() + "'")
                If foundRow.Length > 0 Then
                    resultTable.ImportRow(foundRow(0))
                End If
            Next
            resultTable.AcceptChanges()
            resultTable.Merge(dt)
            Return resultTable
        End Function

    End Class

    <Serializable()> _
Public Class FeeTrans
        Public FeeID As String
        Public TransID As String
    End Class

    <Serializable()> _
    Public Class TransInsert
        Public FeeTrans() As FeeTrans = New FeeTrans() {}

    End Class
End Namespace


@


1.1.1.1
log
@no message
@
text
@@
