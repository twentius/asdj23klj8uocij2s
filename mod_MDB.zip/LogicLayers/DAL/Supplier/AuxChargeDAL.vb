head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.23;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.23;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic
Imports System.Collections.Generic

Namespace DataAccessLayer
    Public Class AuxChargeDAL
        Inherits BaseDA

        Public Function GetProductList() As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblVendorProduct v inner join tblProducts p on v.ProductID=p.[Number]"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("distinct p.*")
                End With
                dt = .ExecuteDataTable(.SQLSelect + " order by Name")
            End With
            Return dt
        End Function

        Public Function GetVendorList(ByVal ProductID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblVendors inner join tblVendorProduct on tblVendors.VendorNumber = tblVendorProduct.VendorNumber"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("tblVendorProduct.ProductID", ProductID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("distinct VendorName")
                End With
                dt = .ExecuteDataTable(.SQLSelect + " order by VendorName")
            End With
            Return dt
        End Function

        Public Function GetAuxChargeList(ByVal ProductID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblAuxCharge"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    If ProductID <> "" Then
                        .Add("ApplytoProduct", ProductID, SqlBuilder.SQLParserDataType.spNum, True)
                    End If
                    .Add("*")
                    .Add("(select top 1 p.[Name] from tblProducts p where p.[Number]=ApplytoProduct) as ApplytoProductName")
                    .Add("isnull((select top 1 v.[VendorName] from tblVendors v where v.VendorNumber=ApplytoVendor),'All') as ApplytoVendorName")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetAuxChargeByID(ByVal FeeID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblAuxCharge"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("AuxVendorChargeID", FeeID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("*")
                    .Add("(select top 1 p.[Name] from tblProducts p where p.[Number]=ApplytoProduct) as ApplytoProductName")
                    .Add("(select top 1 v.[VendorName] from tblVendors v where v.VendorNumber=ApplytoVendor) as ApplytoVendorName")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetVendorNumber(ByVal VendorName)
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblVendors"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("VendorName", VendorName, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("VendorNumber")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function UpdateAuxCharge(ByVal info As DataInfo.AuxChargeInfo) As Integer
            Dim EffectRow As Integer
            Try
                With Me.MySQLParser
                    .TableName = "tblAuxCharge"
                    With .Columns
                        .Clear()
                        If info.ID <> "" Then .Add("AuxVendorChargeID", info.ID, SqlBuilder.SQLParserDataType.spNum, True)
                        If info.PageMode = CWTMasterDB.TransactionMode.AddNewMode Then
                            .Add("ApplytoProduct", info.ApplyProduct, SqlBuilder.SQLParserDataType.spNum)
                            .Add("ApplytoVendor", info.ApplyVendor, SqlBuilder.SQLParserDataType.spText)
                        End If
                        .Add("FeeMode", info.FeeMode, SqlBuilder.SQLParserDataType.spText)
                        .Add("FeeAmount", info.FeeAmount, SqlBuilder.SQLParserDataType.spNum)
                        .Add("FeeCommission", info.ComAmount, SqlBuilder.SQLParserDataType.spNum)
                        .Add("Cost", info.CostAmount, SqlBuilder.SQLParserDataType.spNum)
                        .Add("ItemProductName", info.ItemProductName)
                    End With

                    Select Case info.PageMode
                        Case CWTMasterDB.TransactionMode.AddNewMode
                            EffectRow = .ExecuteInsert()
                            CallProcedure(GetLastID(), "Insert", "sp_AuxCharge")
                        Case CWTMasterDB.TransactionMode.UpdateMode
                            CallProcedure(info.ID, "Update", "sp_AuxCharge")
                            EffectRow = .ExecuteUpdate()
                    End Select
                End With
            Catch ex As Exception
                EffectRow = -1
            End Try
            Return EffectRow
        End Function

        Public Function DeleteFuelCharge(ByVal AuxVendorChargeID As Integer) As Integer
            Dim EffectRow As Integer
            Try
                With Me.MySQLParser
                    .TableName = "tblAuxCharge"
                    With .Columns
                        .Add("AuxVendorChargeID", AuxVendorChargeID, SqlBuilder.SQLParserDataType.spNum, True)
                    End With
                    CallProcedure(AuxVendorChargeID, "Delete", "sp_AuxCharge")
                    EffectRow = .ExecuteDelete()
                End With
            Catch ex As Exception
                EffectRow = -1
            End Try
            Return EffectRow
        End Function

        Private Function GetLastID() As String
            Dim ID As String
            With Me.MySQLParser
                .TableName = "tblAuxCharge"
                With .Columns
                    .Clear()
                    .Add("max(AuxVendorChargeID)")
                End With
                ID = .ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar)
            End With
            Return ID
        End Function

        Private Sub CallProcedure(ByVal ID As String, ByVal Type As String, ByVal StoreProdType As String)
            With Me.MySQLParser
                .ExecuteStoreProcedure("exec " + StoreProdType + " '" + ID + "','" + ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName + "','" + Type + "'")
            End With
        End Sub

        Public Function GetTempAuxCharge(Optional ByVal ProductItemName As String = "", Optional ByVal dateFrom As String = "", Optional ByVal dateTo As String = "") As DataSet
            Dim ChargeDT As DataTable
            Dim TempChargeDT As DataTable
            Dim ChargeMasterDT As DataTable

            Dim TempTable As DataTable
            Dim ClientIDArr(0) As String
            Dim count As Integer
            Dim count2 As Integer
            Dim ds As New DataSet
            Dim foundRow() As DataRow

            ClientIDArr(0) = "AuxVendorChargeID"


            With Me.MySQLParser
                .TableName = "Temp_tblAuxCharge"
                With .Columns
                    .Clear()
                    If ProductItemName <> "" Then
                        .Add("ItemProductName", ProductItemName, SqlBuilder.SQLParserDataType.spText, True)
                    End If
                    If dateFrom = dateTo Then
                        If dateFrom <> "" And dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:990"
                            .Add("DateModification", "convert(varchar,cast('" + dateFrom + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, ">")
                            .Add("DateModification", "convert(varchar,cast('" + dateTo + " 23:59:59:990" + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, "<")
                        End If
                    Else
                        If dateFrom <> "" Then
                            .Add("DateModification", dateFrom, SqlBuilder.SQLParserDataType.spDate, True, ">")
                        End If
                        If dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:999"
                            .Add("DateModification", dateTo + " 23:59:59:990", SqlBuilder.SQLParserDataType.spText, True, "<=")
                        End If
                    End If
                    .Add("*")
                End With
                TempChargeDT = .ExecuteDataTable(.SQLSelect + " order by DateModification Desc")

                .TableName = "tblAuxCharge"
                With .Columns
                    .Clear()
                    If ProductItemName <> "" Then
                        .Add("ItemProductName", ProductItemName, SqlBuilder.SQLParserDataType.spText, True)
                    End If
                    .Add("*")
                End With
                ChargeDT = .ExecuteDataTable()

                If ProductItemName <> "" Then
                    ChargeDT.Merge(TempChargeDT)
                    ChargeDT.TableName = "AuxCharge"
                    ds.Tables.Add(ChargeDT)
                Else
                    TempTable = TempChargeDT.DefaultView.ToTable(True, ClientIDArr)
                    ChargeMasterDT = TempChargeDT.Clone()
                    For count = 0 To TempTable.Rows.Count - 1
                        foundRow = ChargeDT.Select("AuxVendorChargeID='" + TempTable.Rows(count).Item("AuxVendorChargeID").ToString() + "'")
                        If foundRow.Length > 0 Then
                            For count2 = 0 To foundRow.Length - 1
                                ChargeMasterDT.ImportRow(foundRow(count2))
                            Next count2
                        End If
                    Next
                    ChargeMasterDT.AcceptChanges()
                    ChargeMasterDT.Merge(TempChargeDT)
                    ChargeMasterDT.TableName = "AuxCharge"
                    ds.Tables.Add(ChargeMasterDT)
                End If
            End With
            Return ds
        End Function

    End Class
End Namespace













@


1.1.1.1
log
@no message
@
text
@@
