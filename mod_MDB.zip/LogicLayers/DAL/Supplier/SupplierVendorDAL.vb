head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.24;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.24;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic
Imports System.Collections.Generic

Namespace DataAccessLayer
    Public Class SupplierVendorDAL
        Inherits BaseDA

        Public Function GetVendorList(ByVal VendorName As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .TableName = "tblVendors"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    If VendorName <> "" Then .Add("VendorName", "%" + VendorName + "%", SqlBuilder.SQLParserDataType.spText, True, "LIKE")
                    .Add("*")
                End With
                dt = .ExecuteDataTable(.SQLSelect() + " order by VendorName")
            End With
            Return dt
        End Function

        Public Function GetTravComVendorList(ByVal VendorNumber As String, ByVal VendorName As String, ByVal configKey As String) As DataTable
            Dim dt As DataTable
            Dim Type As Integer = 2
            With Me.MySQLParser
                Select Case configKey
                    Case "2"
                        .TableName = Util.TravComDB2("Profiles")
                    Case "1"
                        .TableName = Util.TravComDB("Profiles")
                    Case "4"
                        .TableName = Util.TravComDB2("Profiles")
                    Case "3"
                        .TableName = Util.TravComDB3("Profiles")
                End Select

                'If configKey = 1 Then
                '    .TableName = Util.TravComDB("Profiles")
                'ElseIf configKey = 2 Then
                '    .TableName = Util.TravComDB2("Profiles")
                'End If

                With .Columns
                    .IncludeKey = False
                    .Clear()
                    If configKey = 2 Then
                        .Add("ProfileNumber collate SQL_Latin1_General_CP1_CI_AS ", "(select VendorNumber as ProfileNumber from " + "CWTMasterDB_IN.dbo.tblVendors)", SqlBuilder.SQLParserDataType.spFunction, True, "not in")
                    Else
                        .Add("ProfileNumber collate SQL_Latin1_General_CP1_CI_AS ", "(select VendorNumber as ProfileNumber from " + "CWTMasterDB.dbo.tblVendors)", SqlBuilder.SQLParserDataType.spFunction, True, "not in")
                    End If

                    .Add("ProfileType", Type, SqlBuilder.SQLParserDataType.spNum, True)
                    If VendorNumber <> "" Then .Add("ProfileNumber", "%" + VendorNumber + "%", SqlBuilder.SQLParserDataType.spText, True, "LIKE")
                    If VendorName <> "" Then .Add("FullName", "%" + VendorName + "%", SqlBuilder.SQLParserDataType.spText, True, "LIKE")
                    .Add("*")
                End With
                dt = .ExecuteDataTable(.SQLSelect() + " order by FullName")
            End With
            Return dt
        End Function

        Public Function GetVendorInfo(ByVal VendorNumber As String, ByVal configKey As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                Select Case configKey
                    Case "2"
                        .TableName = Util.TravComDB2("Profiles") + " p inner join " + Util.TravComDB2("Addresses") + " a on p.profileid=a.profileid"
                    Case "1"
                        .TableName = Util.TravComDB("Profiles") + " p inner join " + Util.TravComDB("Addresses") + " a on p.profileid=a.profileid"
                    Case "4"
                        .TableName = Util.TravComDB2("Profiles") + " p inner join " + Util.TravComDB2("Addresses") + " a on p.profileid=a.profileid"
                    Case "3"
                        .TableName = Util.TravComDB3("Profiles") + " p inner join " + Util.TravComDB3("Addresses") + " a on p.profileid=a.profileid"
                End Select

                'If configKey = 1 Then
                '    .TableName = Util.TravComDB("Profiles") + " p inner join " + Util.TravComDB("Addresses") + " a on p.profileid=a.profileid"
                'ElseIf configKey = 2 Then
                '    .TableName = Util.TravComDB2("Profiles") + " p inner join " + Util.TravComDB2("Addresses") + " a on p.profileid=a.profileid"
                'End If
                '.TableName = Util.TravComDB("Profiles") + " p inner join " + Util.TravComDB("Addresses") + " a on p.profileid=a.profileid"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("p.ProfileNumber", VendorNumber, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("a.AddressType", "*PRIMARY*", SqlBuilder.SQLParserDataType.spText, True)
                    .Add("p.*")
                    .Add("a.Address")
                    .Add("a.City")
                    .Add("a.State")
                    .Add("a.PostalCode")
                    .Add("a.Country")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetVendor(ByVal VendorNumber As String, ByVal configKey As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                Select Case configKey
                    Case "2"
                        .TableName = Util.TravComDB2("Profiles")
                    Case "1"
                        .TableName = Util.TravComDB("Profiles")
                    Case "4"
                        .TableName = Util.TravComDB2("Profiles")
                    Case "3"
                        .TableName = Util.TravComDB3("Profiles")
                End Select

                'If configKey = 1 Then
                '    .TableName = Util.TravComDB("Profiles")
                'ElseIf configKey = 2 Then
                '    .TableName = Util.TravComDB2("Profiles")
                'End If
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("ProfileNumber", VendorNumber, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("*")

                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetVendorDataByID(ByVal VendorNumber As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .TableName = "tblVendors"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("VendorNumber", VendorNumber, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetVendorContactByID(ByVal VendorNumber As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .TableName = "tblVendorContact"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("VendorNumber", VendorNumber, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("*")
                End With
                dt = .ExecuteDataTable(.SQLSelect() + " order by VendorContactID")
            End With
            Return dt
        End Function

        Public Function GetProductList(ByVal FilterOutList As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .TableName = "tblProducts"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    If FilterOutList <> "" Then .Add("Number", "(" + FilterOutList + ")", SqlBuilder.SQLParserDataType.spFunction, True, "not in")
                    .Add("*")
                End With
                dt = .ExecuteDataTable(.SQLSelect() + " order by Name")
            End With
            Return dt
        End Function

        Public Function GetVendorProduct(ByVal VendorNumber As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .TableName = "tblVendorProduct v inner join tblProducts p on v.productid=p.[number]"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("v.VendorNumber", VendorNumber, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("p.*")
                End With
                dt = .ExecuteDataTable(.SQLSelect() + " order by p.Name")
            End With
            Return dt
        End Function

        Public Function GetVendorProductDT(ByVal VendorNumber As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .TableName = "tblVendorProduct"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("VendorNumber", VendorNumber, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function IsExistCode(ByVal VendorNumber As String) As Boolean
            Dim retVal As Boolean
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblVendors"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("VendorNumber", VendorNumber, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("count(*) as RecordCount")
                End With
                retVal = (CWTMasterDB.Util.DBNullToZero(.ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar)) > 0)
            End With
            Return retVal
        End Function

        Public Function UpdateVendor(ByVal info As DataInfo.SupplierVendorInfo) As Integer
            Dim EffectRow As Integer = 1
            Dim VContact As DataTable
            Dim VProduct As DataTable
            Try
                VProduct = GetVendorProductDT(info.Number)
                VContact = GetVendorContactByID(info.Number)
                With Me.MySQLParser
                    .OpenConnection()
                    .BeginTran()
                    '//
                    .TableName = "tblVendorProduct"
                    With .Columns
                        .Clear()
                        .Add("VendorNumber", info.Number, SqlBuilder.SQLParserDataType.spText, True)
                    End With
                    .ExecuteDelete()
                    '//
                    .TableName = "tblVendorContact"
                    With .Columns
                        .Clear()
                        .Add("VendorNumber", info.Number, SqlBuilder.SQLParserDataType.spText, True)
                    End With
                    .ExecuteDelete()
                    '//
                    .TableName = "tblVendors"
                    With .Columns
                        .Clear()
                        .Add("VendorNumber", info.Number, SqlBuilder.SQLParserDataType.spText, (info.PageMode = TransactionMode.UpdateMode))
                        .Add("InterfaceNumber", info.InterfaceCode)
                        .Add("VendorName", info.Name)
                        .Add("ContactPerson", info.ContractPerson)
                        .Add("Address", info.Address)
                        .Add("PostalCode", info.PostalCode)
                        .Add("City", info.City)
                        .Add("State", info.State)
                        .Add("Country", info.Country)
                        .Add("VendorType", info.VendorType)
                        '.Add("RequireEO", info.RequireEO, SqlBuilder.SQLParserDataType.spBoolean)
                        .Add("RequireAdvanced", info.RequireAdvance, SqlBuilder.SQLParserDataType.spBoolean)
                        .Add("HotelFee", info.HotelFee, SqlBuilder.SQLParserDataType.spBoolean)
                    End With
                    If info.PageMode = TransactionMode.AddNewMode Then
                        EffectRow = .ExecuteInsert()
                        CallProcedure(info.Number, "Insert", "sp_Vendors")
                    Else
                        CallProcedure(info.Number, "Update", "sp_Vendors")
                        EffectRow = .ExecuteUpdate()
                    End If
                    '//
                    If EffectRow > 0 Then
                        .TableName = "tblVendorProduct"
                        For i As Integer = 0 To info.Products.Count - 1
                            With .Columns
                                .Clear()
                                .Add("VendorNumber", info.Number)
                                .Add("ProductID", info.Products(i))
                            End With
                            EffectRow = .ExecuteInsert()
                            If EffectRow <= 0 Then
                                Exit For
                            End If
                        Next
                        MatchVendorRecord(VProduct, info, "Product")
                    End If
                    If EffectRow > 0 Then
                        .TableName = "tblVendorContact"
                        For i As Integer = 0 To info.Contacts.Count - 1
                            With .Columns
                                .Clear()
                                .Add("VendorNumber", info.Number)
                                .Add("VendorContactID", i + 1, SqlBuilder.SQLParserDataType.spNum)
                                .Add("ContactType", info.Contacts(i).MethodType)
                                .Add("ContactDetail", info.Contacts(i).MethodValue)
                                .Add("PreferEOSend", info.Contacts(i).IsPrefer, SqlBuilder.SQLParserDataType.spBoolean)
                            End With
                            EffectRow = .ExecuteInsert()
                            If EffectRow <= 0 Then
                                Exit For
                            End If
                        Next
                        MatchVendorRecord(VContact, info, "Contact")
                    End If
                End With
                If EffectRow > 0 Then
                    Me.MySQLParser.CommitTran()
                Else
                    Me.MySQLParser.RollbackTran()
                End If
            Catch ex As Exception
                EffectRow = -1
                Me.MySQLParser.RollbackTran()
            Finally
                Me.MySQLParser.CloseConnection()
            End Try
            Return EffectRow
        End Function

        Private Sub MatchVendorRecord(ByVal VendorDT As DataTable, ByVal info As DataInfo.SupplierVendorInfo, ByVal Type As String)
            Dim countInfo As Integer
            Dim countDT As Integer
            Dim checkMatch As Boolean
            Dim effectRow As Integer

            If VendorDT.Rows.Count > 0 Then
                For countDT = 0 To VendorDT.Rows.Count - 1
                    checkMatch = CheckVendorExist(VendorDT.Rows(countDT), info, Type)

                    If checkMatch = False Then

                        If Type = "Product" Then
                            For countInfo = 0 To info.Products.Count - 1
                                If VendorDT.Rows(countDT).Item("VendorNumber").ToString() = info.Number Then
                                    With Me.MySQLParser
                                        .TableName = "Temp_tblVendorProduct"
                                        With .Columns
                                            .Clear()
                                            .Add("VendorProductID", VendorDT.Rows(countDT).Item("VendorProductID").ToString())
                                            .Add("VendorNumber", VendorDT.Rows(countDT).Item("VendorNumber").ToString())
                                            .Add("ProductID", VendorDT.Rows(countDT).Item("ProductID").ToString())
                                            .Add("DateModification", DateTime.Now)
                                            .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                            .Add("ValueTypeChanged", "Update")
                                        End With
                                        effectRow = .ExecuteInsert()
                                        Exit For
                                    End With
                                End If
                            Next countInfo

                            If countDT > info.Products.Count-1 Then
                                With Me.MySQLParser
                                    .TableName = "Temp_tblVendorProduct"
                                    With .Columns
                                        .Clear()
                                        .Add("VendorProductID", VendorDT.Rows(countDT).Item("VendorProductID").ToString())
                                        .Add("VendorNumber", VendorDT.Rows(countDT).Item("VendorNumber").ToString())
                                        .Add("ProductID", VendorDT.Rows(countDT).Item("ProductID").ToString())
                                        .Add("DateModification", DateTime.Now)
                                        .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                        .Add("ValueTypeChanged", "Delete")
                                    End With
                                    effectRow = .ExecuteInsert()
                                End With
                            End If

                        ElseIf Type = "Contact" Then
                            For countInfo = 0 To info.Contacts.Count - 1
                                If VendorDT.Rows(countInfo).Item("VendorNumber").ToString() = info.Number AndAlso VendorDT.Rows(countDT).Item("VendorContactID").ToString() = countInfo + 1 Then
                                    With Me.MySQLParser
                                        .TableName = "Temp_tblVendorContact"
                                        With .Columns
                                            .Clear()
                                            .Add("VendorContactID", VendorDT.Rows(countDT).Item("VendorContactID").ToString(), SqlBuilder.SQLParserDataType.spNum)
                                            .Add("VendorNumber", VendorDT.Rows(countDT).Item("VendorNumber").ToString())
                                            .Add("ContactType", VendorDT.Rows(countDT).Item("ContactType").ToString())
                                            .Add("ContactDetail", VendorDT.Rows(countDT).Item("ContactDetail").ToString())
                                            .Add("PreferEOSend", VendorDT.Rows(countDT).Item("PreferEOSend").ToString())
                                            .Add("DateModification", DateTime.Now)
                                            .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                            .Add("ValueTypeChanged", "Update")
                                        End With
                                        effectRow = .ExecuteInsert()
                                        Exit For
                                    End With

                                End If



                                'If countDT > info.Contacts.Count - 1 Then
                                '    With Me.MySQLParser
                                '        .TableName = "Temp_tblVendorContact"
                                '        With .Columns
                                '            .Clear()
                                '            .Add("VendorContactID", countInfo + 1, SqlBuilder.SQLParserDataType.spNum)
                                '            .Add("VendorNumber", VendorDT.Rows(countDT).Item("VendorNumber").ToString())
                                '            .Add("ContactType", VendorDT.Rows(countDT).Item("ContactType").ToString())
                                '            .Add("ContactDetail", VendorDT.Rows(countDT).Item("ContactDetail").ToString())
                                '            .Add("PreferEOSend", VendorDT.Rows(countDT).Item("PreferEOSend").ToString())
                                '            .Add("DateModification", DateTime.Now)
                                '            .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                '            .Add("ValueTypeChanged", "Delete")
                                '        End With
                                '        effectRow = .ExecuteInsert()
                                '    End With
                                'End If
                            Next countInfo

                           
                        End If
                    End If
                Next countDT
            End If

            If Type = "Product" Then
                If info.Products.Count > VendorDT.Rows.Count Then
                    For countInfo = countDT To info.Products.Count - 1
                        With Me.MySQLParser
                            .TableName = "Temp_tblVendorProduct"
                            With .Columns
                                .Clear()
                                .Add("VendorProductID", countInfo + 1, SqlBuilder.SQLParserDataType.spNum)
                                .Add("VendorNumber", info.Number)
                                .Add("ProductID", info.Products(countInfo))
                                .Add("DateModification", DateTime.Now)
                                .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                .Add("ValueTypeChanged", "Insert")
                            End With
                            effectRow = .ExecuteInsert()
                        End With
                    Next countInfo
                End If
            ElseIf Type = "Contact" Then
                If info.Contacts.Count > VendorDT.Rows.Count Then
                    For countInfo = 0 To info.Contacts.Count - 1
                        With Me.MySQLParser
                            .TableName = "Temp_tblVendorContact"
                            With .Columns
                                .Clear()
                                .Add("VendorContactID", countInfo + 1, SqlBuilder.SQLParserDataType.spNum)
                                .Add("VendorNumber", info.Number)
                                .Add("ContactType", info.Contacts(countInfo).MethodType)
                                .Add("ContactDetail", info.Contacts(countInfo).MethodValue)
                                .Add("PreferEOSend", info.Contacts(countInfo).IsPrefer)
                                .Add("DateModification", DateTime.Now)
                                .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                .Add("ValueTypeChanged", "Insert")
                            End With
                            effectRow = .ExecuteInsert()
                        End With
                    Next countInfo
                End If
            End If

        End Sub

        Private Function CheckVendorExist(ByVal row As DataRow, ByVal info As DataInfo.SupplierVendorInfo, ByVal Type As String) As Boolean
            Dim countInfo As Integer
            Dim check As Boolean

            If Type = "Product" Then
                For countInfo = 0 To info.Products.Count - 1
                    If row.Item("VendorNumber").ToString() = info.Number AndAlso row.Item("ProductID").ToString() = info.Products(countInfo) Then
                        check = True
                        Exit For
                    End If
                Next countInfo

            ElseIf Type = "Contact" Then
                For countInfo = 0 To info.Contacts.Count - 1
                    If row.Item("VendorNumber").ToString() = info.Number AndAlso row.Item("ContactType").ToString() = info.Contacts(countInfo).MethodType AndAlso row.Item("ContactDetail").ToString() = info.Contacts(countInfo).MethodValue AndAlso row.Item("PreferEOSend").ToString() = info.Contacts(countInfo).IsPrefer Then
                        check = True
                        Exit For
                    End If
                Next countInfo
            End If
            Return check
        End Function

        Public Function DeleteVendorField(ByVal VendorNumber As String) As String
            Dim EffectRow As Integer

            Try

                With Me.MySQLParser
                    .OpenConnection()
                    .BeginTran()
                    If VendorNumber <> 0 Then
                        .TableName = "tblVendorProduct"
                        With .Columns
                            .Clear()
                            .Add("VendorNumber", VendorNumber, SqlBuilder.SQLParserDataType.spText, True)
                        End With
                        CallProcedure(VendorNumber, "Delete", "sp_VendorProduct")
                        EffectRow = .ExecuteDelete()
                        '//
                        .TableName = "tblVendorContact"
                        With .Columns
                            .Clear()
                            .Add("VendorNumber", VendorNumber, SqlBuilder.SQLParserDataType.spText, True)
                        End With
                        CallProcedure(VendorNumber, "Delete", "sp_VendorContact")
                        EffectRow = .ExecuteDelete()
                        '//
                        .TableName = "tblVendors"
                        With .Columns
                            .Clear()
                            .Add("VendorNumber", VendorNumber, SqlBuilder.SQLParserDataType.spText, True)
                        End With
                        CallProcedure(VendorNumber, "Delete", "sp_Vendors")
                        EffectRow = .ExecuteDelete()

                    End If

                End With
                If EffectRow > 0 Then
                    Me.MySQLParser.CommitTran()
                Else
                    Me.MySQLParser.RollbackTran()
                End If
            Catch ex As Exception
                EffectRow = -1
                Me.MySQLParser.RollbackTran()

            Finally
                Me.MySQLParser.CloseConnection()
            End Try

            Return EffectRow
        End Function

        Private Function InsertTempVendor(ByVal tableName As String, ByVal Status As String)

        End Function

        Public Function checkHotelFee() As Boolean
            Dim boolFee As Boolean = False
            Dim dt As New DataTable
            Dim count As Integer
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblVendors"
                With .Columns
                    .IncludeKey = False
                    .Add("HotelFee")
                End With
                dt = .ExecuteDataTable()
            End With
            If dt.Rows.Count > 0 Then
                For count = 0 To dt.Rows.Count - 1
                    If dt.Rows(count).Item("HotelFee").ToString = True Then
                        boolFee = True
                        Return boolFee
                    End If
                Next count
            End If
            Return boolFee
        End Function

        Private Sub CallProcedure(ByVal ID As String, ByVal Type As String, ByVal StoreProdType As String)
            With Me.MySQLParser
                .ExecuteStoreProcedure("exec " + StoreProdType + " '" + ID + "','" + ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName + "','" + Type + "'")
            End With
        End Sub

        Public Function GetVendorNumberByName(ByVal ClientName As String) As String
            Dim retVal As String
            Dim retObj As Object
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblVendors"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("VendorName", ClientName, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("VendorNumber")
                End With
                retObj = .ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar, CommandType.Text)
                retVal = Util.DBNullToText(retObj)
            End With
            Return retVal
        End Function

        Public Function GetTempVendorInfo(Optional ByVal VendorName As String = "", Optional ByVal dateFrom As String = "", Optional ByVal dateTo As String = "") As DataSet
            '//Vendor Contact
            Dim ContactDT As DataTable
            Dim TempContactDT As DataTable
            Dim ContactMasterDT As DataTable

            '//Vendor Products 
            Dim ProductDT As DataTable
            Dim TempProductDT As DataTable
            Dim ProductMasterDT As DataTable

            '//Vendor 
            Dim VendorDT As DataTable
            Dim TempVendorDT As DataTable
            Dim VendorMasterDT As DataTable

            Dim VendorNumber As String = ""
            Dim TempTable As DataTable
            Dim VendorNumberArr(0) As String
            Dim VendorProductArr(1) As String
            Dim VendorContactArr(1) As String
            Dim count As Integer
            Dim count2 As Integer
            Dim ds As New DataSet
            Dim foundRow() As DataRow

            VendorNumberArr(0) = "VendorNumber"
            VendorProductArr(0) = "VendorNumber"
            VendorProductArr(1) = "Name"
            VendorContactArr(0) = "VendorNumber"
            VendorContactArr(1) = "VendorContactID"

            With Me.MySQLParser
                .TableName = "Temp_tblVendors"
                With .Columns
                    .Clear()
                    If VendorName <> "" Then
                        .Add("VendorName", VendorName, SqlBuilder.SQLParserDataType.spText, True)
                    End If
                    If dateFrom = dateTo Then
                        If dateFrom <> "" And dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:990"
                            .Add("DateModification", "convert(varchar,cast('" + dateFrom + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, ">")
                            .Add("DateModification", "convert(varchar,cast('" + dateTo + " 23:59:59:990" + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, "<")
                        End If
                    Else
                        If dateFrom <> "" Then
                            .Add("DateModification", dateFrom, SqlBuilder.SQLParserDataType.spDate, True, ">")
                        End If
                        If dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:999"
                            .Add("DateModification", dateTo + " 23:59:59:990", SqlBuilder.SQLParserDataType.spText, True, "<=")
                        End If
                    End If
                    .Add("VendorNumber,InterfaceNumber,VendorName,ContactPerson,Address,City,PostalCode,State,Country,VendorType,RequireAdvanced,HotelFee,DateModification,UserName,ValueTypeChanged")
                End With
                TempVendorDT = .ExecuteDataTable(.SQLSelect + " order by DateModification Desc")


                .TableName = "tblVendors"
                With .Columns
                    .Clear()
                    If VendorName <> "" Then
                        .Add("VendorName", VendorName, SqlBuilder.SQLParserDataType.spText, True)
                    End If
                    .Add("VendorNumber,InterfaceNumber,VendorName,ContactPerson,Address,City,PostalCode,State,Country,VendorType,RequireAdvanced,HotelFee")
                End With
                VendorDT = .ExecuteDataTable()


                TempTable = TempVendorDT.DefaultView.ToTable(True, VendorNumberArr)
                VendorMasterDT = TempVendorDT.Clone()
                For count = 0 To TempTable.Rows.Count - 1
                    foundRow = VendorDT.Select("VendorNumber='" + TempTable.Rows(count).Item("VendorNumber").ToString() + "'")
                    If foundRow.Length > 0 Then
                        For count2 = 0 To foundRow.Length - 1
                            VendorMasterDT.ImportRow(foundRow(count2))
                        Next count2
                    End If
                Next
                VendorMasterDT.AcceptChanges()
                VendorMasterDT.Merge(TempVendorDT)
                VendorMasterDT.TableName = "Vendor"
                ds.Tables.Add(VendorMasterDT)


                .TableName = "Temp_tblVendorProduct v inner join tblProducts p on v.ProductID = p.Number inner join tblVendors vd on v.VendorNumber=vd.VendorNumber"
                With .Columns
                    .Clear()
                    If VendorName <> "" Then
                        .Add("vd.VendorName", VendorName, SqlBuilder.SQLParserDataType.spText, True)
                    End If

                    If dateFrom = dateTo Then
                        If dateFrom <> "" And dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:990"
                            .Add("v.DateModification", "convert(varchar,cast('" + dateFrom + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, ">")
                            .Add("v.DateModification", "convert(varchar,cast('" + dateTo + " 23:59:59:990" + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, "<")
                        End If
                    Else
                        If dateFrom <> "" Then
                            .Add("v.DateModification", dateFrom, SqlBuilder.SQLParserDataType.spDate, True, ">")
                        End If
                        If dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:999"
                            .Add("v.DateModification", dateTo + " 23:59:59:990", SqlBuilder.SQLParserDataType.spText, True, "<=")
                        End If
                    End If
                    .Add("v.VendorNumber,p.Name,v.DateModification,v.UserName,v.ValueTypeChanged")
                End With
                TempProductDT = .ExecuteDataTable(.SQLSelect + " order by DateModification Desc")

                .TableName = "tblVendorProduct v inner join tblProducts p on v.ProductID = p.Number inner join tblVendors vd on v.VendorNumber=vd.VendorNumber"
                With .Columns
                    .Clear()
                    If VendorName <> "" Then
                        .Add("vd.VendorName", VendorName, SqlBuilder.SQLParserDataType.spText, True)
                    End If
                    .Add("v.VendorNumber,p.Name")
                End With
                ProductDT = .ExecuteDataTable()

                TempTable = TempProductDT.DefaultView.ToTable(True, VendorProductArr)
                ProductMasterDT = TempProductDT.Clone()
                For count = 0 To TempTable.Rows.Count - 1
                    foundRow = ProductDT.Select("VendorNumber='" + TempTable.Rows(count).Item("VendorNumber").ToString() + "' and Name='" + TempTable.Rows(count).Item("Name").ToString() + "'")
                    If foundRow.Length > 0 Then
                        For count2 = 0 To foundRow.Length - 1
                            ProductMasterDT.ImportRow(foundRow(count2))
                        Next count2
                    End If
                Next
                ProductMasterDT.AcceptChanges()
                ProductMasterDT.Merge(TempProductDT)
                ProductMasterDT.TableName = "Product"
                ds.Tables.Add(ProductMasterDT)



                .TableName = "Temp_tblVendorContact c inner join tblVendors vd on c.VendorNumber=vd.VendorNumber"
                With .Columns
                    .Clear()
                    If VendorName <> "" Then
                        .Add("vd.VendorName", VendorName, SqlBuilder.SQLParserDataType.spText, True)
                    End If
                    If dateFrom = dateTo Then
                        If dateFrom <> "" And dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:990"
                            .Add("c.DateModification", "convert(varchar,cast('" + dateFrom + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, ">")
                            .Add("c.DateModification", "convert(varchar,cast('" + dateTo + " 23:59:59:990" + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, "<")
                        End If
                    Else
                        If dateFrom <> "" Then
                            .Add("c.DateModification", dateFrom, SqlBuilder.SQLParserDataType.spDate, True, ">")
                        End If
                        If dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:999"
                            .Add("c.DateModification", dateTo + " 23:59:59:990", SqlBuilder.SQLParserDataType.spText, True, "<=")
                        End If
                    End If
                    .Add("c.VendorContactID,c.VendorNumber,c.ContactType,c.ContactDetail,c.PreferEOSend,c.DateModification,c.UserName,c.ValueTypeChanged")
                End With
                TempContactDT = .ExecuteDataTable(.SQLSelect + " order by DateModification Desc")

                .TableName = "tblVendorContact c inner join tblVendors vd on c.VendorNumber=vd.VendorNumber"
                With .Columns
                    .Clear()
                    If VendorName <> "" Then
                        .Add("vd.VendorName", VendorName, SqlBuilder.SQLParserDataType.spText, True)
                    End If
                    .Add("c.VendorContactID,c.VendorNumber,c.ContactType,c.ContactDetail,c.PreferEOSend")
                End With
                ContactDT = .ExecuteDataTable()

                TempTable = TempContactDT.DefaultView.ToTable(True, VendorContactArr)
                ContactMasterDT = TempContactDT.Clone()
                For count = 0 To TempTable.Rows.Count - 1
                    foundRow = ContactDT.Select("VendorNumber='" + TempTable.Rows(count).Item("VendorNumber").ToString() + "' and VendorContactID='" + TempTable.Rows(count).Item("VendorContactID").ToString() + "'")
                    If foundRow.Length > 0 Then
                        For count2 = 0 To foundRow.Length - 1
                            ContactMasterDT.ImportRow(foundRow(count2))
                        Next count2
                    End If
                Next
                ContactMasterDT.AcceptChanges()
                ContactMasterDT.Merge(TempContactDT)
                ContactMasterDT.TableName = "Contact"
                ds.Tables.Add(ContactMasterDT)
            End With
            Return ds
        End Function
    End Class
End Namespace















@


1.1.1.1
log
@no message
@
text
@@
