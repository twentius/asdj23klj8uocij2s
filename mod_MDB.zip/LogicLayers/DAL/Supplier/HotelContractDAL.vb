head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.23;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.23;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic

Namespace DataAccessLayer
    Public Class HotelContractDAL
        Inherits BaseDA

        Public Function GetClient(Optional ByVal ClientID As String = "", Optional ByVal ClientNum As String = "", Optional ByVal GroupName As String = "", Optional ByVal Name As String = "", Optional ByVal ApplyStd As Boolean = True) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblClientMaster"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    If ClientID <> "" Then
                        .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spText, True)
                    End If
                    If ClientNum <> "" Then .Add("ClientNumber", "%" + ClientNum + "%", SqlBuilder.SQLParserDataType.spNum, True, "LIKE")
                    If GroupName <> "" Then .Add("GroupName", "%" + ClientNum + "%", SqlBuilder.SQLParserDataType.spText, True, "LIKE")
                    If Name <> "" Then .Add("Name", "%" + Name + "%", SqlBuilder.SQLParserDataType.spText, True, "LIKE")
                    .Add("StandardHotelDisplay", ApplyStd, SqlBuilder.SQLParserDataType.spBoolean, True)
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetClientName(Optional ByVal ClientID As String = "") As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblClientMaster"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    If ClientID <> "" Then
                        .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spText, True)
                    End If
                    
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function


        Public Function GetRateType(ByVal Type As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = Util.StandardDB("tblRateRankType")
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("Type", Type, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function


        Public Function UpdateHotelContract(ByVal info As DataInfo.HotelContractInfo) As Integer
            Dim Effectrow As Integer
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblClientHotelRankOption"

                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("ClientID", info.ID, SqlBuilder.SQLParserDataType.spNum, True)
                End With
                Effectrow = .ExecuteDelete()

                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("ClientID", info.ID, SqlBuilder.SQLParserDataType.spNum)
                    .Add("RateRankID", info.RateRankID1, SqlBuilder.SQLParserDataType.spNum)
                    .Add("SequenceNo", "1", SqlBuilder.SQLParserDataType.spNum)
                End With
                Effectrow = .ExecuteInsert()
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("ClientID", info.ID, SqlBuilder.SQLParserDataType.spNum)
                    .Add("RateRankID", info.RateRankID2, SqlBuilder.SQLParserDataType.spNum)
                    .Add("SequenceNo", "2", SqlBuilder.SQLParserDataType.spNum)
                End With
                Effectrow = .ExecuteInsert()
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("ClientID", info.ID, SqlBuilder.SQLParserDataType.spNum)
                    .Add("RateRankID", info.RateRankID3, SqlBuilder.SQLParserDataType.spNum)
                    .Add("SequenceNo", "3", SqlBuilder.SQLParserDataType.spNum)
                End With
                Effectrow = .ExecuteInsert()
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("ClientID", info.ID, SqlBuilder.SQLParserDataType.spNum)
                    .Add("RateRankID", info.RateRankID4, SqlBuilder.SQLParserDataType.spNum)
                    .Add("SequenceNo", "4", SqlBuilder.SQLParserDataType.spNum)
                End With
                Effectrow = .ExecuteInsert()
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("ClientID", info.ID, SqlBuilder.SQLParserDataType.spNum)
                    .Add("RateRankID", info.RateRankID5, SqlBuilder.SQLParserDataType.spNum)
                    .Add("SequenceNo", "5", SqlBuilder.SQLParserDataType.spNum)
                End With
                Effectrow = .ExecuteInsert()
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("ClientID", info.ID, SqlBuilder.SQLParserDataType.spNum)
                    .Add("RateRankID", info.RateRankID6, SqlBuilder.SQLParserDataType.spNum)
                    .Add("SequenceNo", "6", SqlBuilder.SQLParserDataType.spNum)
                End With
                Effectrow = .ExecuteInsert()

                .TableName = "tblClientMaster"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("ClientID", info.ID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("StandardHotelDisplay", "False")
                End With
                Effectrow = .ExecuteUpdate()
            End With
            Return Effectrow
        End Function

        Public Function UpdateHotelContract2(ByVal info As DataInfo.HotelContractInfo) As Integer
            Dim Effectrow As Integer
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblClientHotelRankOption"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("ClientID", info.ID, SqlBuilder.SQLParserDataType.spNum, True)
                End With
                Effectrow = .ExecuteDelete()

                .TableName = "tblClientMaster"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("ClientID", info.ID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("StandardHotelDisplay", "True")
                End With
                Effectrow = .ExecuteUpdate()
            End With
            Return Effectrow
        End Function

        Public Function getHotelRank(ByVal ID As String) As DataTable
            Dim dt As DataTable
            Dim oSql As String

            oSql = "SELECT c.ClientID, c.RateRankID, c.SequenceNo, h.Description, h.Type " & _
                   "FROM tblClientHotelRankOption AS c INNER JOIN " & _
                   Util.StandardDB("tblRateRankType") & " AS h ON c.RateRankID = h.RateRankID " & _
                   "WHERE c.ClientID = '" & ID & "'"

            dt = Me.MySQLParser.ExecuteDataTable(oSql)
            Return dt
        End Function

        Public Function getHotelRankID() As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblClientHotelRankOption h inner join tblClientMaster c On h.ClientID = c.ClientID"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    '  .Add("On h.ClientID = c.ClientID")
                    .Add("Distinct c.ClientID, c.Name")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function
    End Class
End Namespace

@


1.1.1.1
log
@no message
@
text
@@
