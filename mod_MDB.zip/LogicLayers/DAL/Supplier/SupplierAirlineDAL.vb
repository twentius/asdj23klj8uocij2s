head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.23;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.23;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic
Imports System.Collections.Generic

Namespace DataAccessLayer
    Public Class SupplierAirlineDAL
        Inherits BaseDA

        Public Function GetAirLinesList() As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .TableName = Util.StandardDB("tblAirlines")
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("*")
                End With
                dt = .ExecuteDataTable(.SQLSelect() + " order by AirlineDescription")
            End With
            Return dt
        End Function

        Public Function GetCWTAirlineData() As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .TableName = "tblAirlinePrefer p inner join " + Util.StandardDB("tblAirlines") + " a on p.AirlineCode=a.AirlineCode"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("ClientID", -1, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("p.*")
                    .Add("a.AirlineDescription")
                End With
                dt = .ExecuteDataTable(.SQLSelect() + " order by p.AirlinePreferID")
            End With
            Return dt
        End Function

        Public Function GetClientAirlineData(ByVal ClientID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .TableName = "tblAirlinePrefer p inner join " + Util.StandardDB("tblAirlines") + " a on p.AirlineCode=a.AirlineCode"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("p.*")
                    .Add("a.AirlineDescription")
                End With
                dt = .ExecuteDataTable(.SQLSelect() + " order by p.AirlinePreferID")
            End With
            Return dt
        End Function

        Public Function UpdatePreferedAirline(ByVal info As DataInfo.SupplierAirlineInfo) As Integer
            Dim EffectRow As Integer = 1
            Dim hvAirSearch As Boolean = False
            Try
                With Me.MySQLParser
                    .OpenConnection()
                    .BeginTran()
                    '//
                    .TableName = "tblAirSearchPrefer"
                    With .Columns
                        .Clear()
                        .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        .Add("count(*) as RecordCount")
                    End With
                    hvAirSearch = (CWTMasterDB.Util.DBNullToZero(.ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar)) > 0)
                    '//
                    .TableName = "tblAirSearchPrefer"
                    With .Columns
                        .Clear()
                        .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum, hvAirSearch)
                        .Add("AirlineSearchOption", info.PreferOption)
                    End With
                    If hvAirSearch Then
                        EffectRow = .ExecuteUpdate()
                    Else
                        EffectRow = .ExecuteInsert()
                    End If
                    '//
                    .TableName = "tblAirlinePrefer"
                    With .Columns
                        .Clear()
                        .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    End With
                    .ExecuteDelete()
                    If EffectRow > 0 Then
                        '// 
                        .TableName = "tblAirlinePrefer"
                        For i As Integer = 0 To info.RatingAirlines.Count - 1
                            With .Columns
                                .Clear()
                                .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum)
                                .Add("AirlineCode", info.RatingAirlines(i).AirlineCode)
                                .Add("AirlinePreferID", i + 1, SqlBuilder.SQLParserDataType.spNum)
                                .Add("Rating", info.RatingAirlines(i).Rating, SqlBuilder.SQLParserDataType.spNum)
                            End With
                            EffectRow = .ExecuteInsert()
                            If EffectRow <= 0 Then
                                Exit For
                            End If
                        Next
                    End If
                End With
                If EffectRow > 0 Then
                    Me.MySQLParser.CommitTran()
                Else
                    Me.MySQLParser.RollbackTran()
                End If
            Catch ex As Exception
                EffectRow = -1
                Me.MySQLParser.RollbackTran()
            Finally
                Me.MySQLParser.CloseConnection()
            End Try
            Return EffectRow
        End Function

        Public Function GetSuppPreferOpData() As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .TableName = "tblAirlinePrefer p inner join " + Util.StandardDB("tblAirlines") + " a on p.AirlineCode=a.AirlineCode"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("ClientID", -1, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("p.*")
                    .Add("a.AirlineDescription")
                End With
                dt = .ExecuteDataTable(.SQLSelect() + " order by p.AirlinePreferID")
            End With
            Return dt
        End Function

        Public Function GetSuppPrefOpByClientID(ByVal ClientID As String) As String
            Dim retVal As String
            Dim retObj As Object
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblAirSearchPrefer"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("AirlineSearchOption")
                End With
                retObj = .ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar, CommandType.Text)
                retVal = Util.DBNullToText(retObj)
            End With
            Return retVal
        End Function

        Public Function UpdateSuppPreferOp(ByVal info As DataInfo.SupplierAirlineInfo) As Integer
            Dim EffectRow As Integer = 1
            Try
                With Me.MySQLParser
                    .OpenConnection()
                    .BeginTran()
                    '//
                    .TableName = "tblAirlinePrefer"
                    With .Columns
                        .Clear()
                        .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    End With
                    .ExecuteDelete()
                    '// 
                    .TableName = "tblAirlinePrefer"
                    For i As Integer = 0 To info.RatingAirlines.Count - 1
                        With .Columns
                            .Clear()
                            .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum)
                            .Add("AirlineCode", info.RatingAirlines(i).AirlineCode)
                            .Add("AirlinePreferID", i + 1, SqlBuilder.SQLParserDataType.spNum)
                            .Add("Rating", info.RatingAirlines(i).Rating, SqlBuilder.SQLParserDataType.spNum)
                        End With
                        EffectRow = .ExecuteInsert()
                        If EffectRow <= 0 Then
                            Exit For
                        End If
                    Next
                End With
                If EffectRow > 0 Then
                    Me.MySQLParser.CommitTran()
                Else
                    Me.MySQLParser.RollbackTran()
                End If
            Catch ex As Exception
                EffectRow = -1
                Me.MySQLParser.RollbackTran()
            Finally
                Me.MySQLParser.CloseConnection()
            End Try
            Return EffectRow
        End Function

    End Class
End Namespace

@


1.1.1.1
log
@no message
@
text
@@
