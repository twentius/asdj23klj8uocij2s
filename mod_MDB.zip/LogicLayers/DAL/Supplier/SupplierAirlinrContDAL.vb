head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.23;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.23;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic
Imports System.Collections.Generic

Namespace DataAccessLayer
    Public Class SupplierAirlinrContDAL
        Inherits BaseDA

        Public Function GetClientAirContData(ByVal ClientID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .TableName = "tblClientAirContracts p inner join " + Util.StandardDB("tblAirlines") + " a on p.AirlineCode=a.AirlineCode"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("p.*")
                    .Add("a.AirlineDescription")
                End With
                dt = .ExecuteDataTable(.SQLSelect() + " order by a.AirlineDescription")
            End With
            Return dt
        End Function

        Private Function GetClientContact(ByVal ClientID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .TableName = "tblClientAirContracts"
                With .Columns
                    .Clear()
                    .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function


        Public Function UpdateClientAirCont(ByVal info As DataInfo.SupplierAirContractInfo) As Integer
            Dim EffectRow As Integer = 1
            Dim ContactDT As DataTable
            Try
                ContactDT = GetClientContact(info.ClientID)
                With Me.MySQLParser
                    .OpenConnection()
                    .BeginTran()
                    '//
                    .TableName = "tblClientAirContracts"
                    With .Columns
                        .Clear()
                        .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    End With
                    .ExecuteDelete()
                    '// 
                    .TableName = "tblClientAirContracts"
                    For i As Integer = 0 To info.AirlinesContract.Count - 1
                        With .Columns
                            .Clear()
                            .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum)
                            .Add("AirlineCode", info.AirlinesContract(i).AirlineCode)
                            .Add("FareType", info.AirlinesContract(i).FareType)
                            .Add("MasterCodeID", info.AirlinesContract(i).MasterCodeID)
                            .Add("AccountCode", info.AirlinesContract(i).AccountCode, , , , , False)
                            .Add("DefaultTourCode", info.AirlinesContract(i).DefaultTourCode)
                            .Add("DefaultVcCode", info.AirlinesContract(i).DefaultVcCode)
                            .Add("DefaultAiCode", info.AirlinesContract(i).DefaultAiCode)
                            .Add("DefaultFOPCode", info.AirlinesContract(i).DefaultFOPCode)
                            .Add("TktDesigDefault", info.AirlinesContract(i).TktDesigDefault)
                            .Add("EndosDefault", info.AirlinesContract(i).EndosDefault)
                            .Add("OSI", info.AirlinesContract(i).OSI)
                            .Add("FareOnTkt", info.AirlinesContract(i).FareOnTkt)
                            .Add("TourCode", info.AirlinesContract(i).TourCode, SqlBuilder.SQLParserDataType.spBoolean)
                            .Add("VcCode", info.AirlinesContract(i).VcCode, SqlBuilder.SQLParserDataType.spBoolean)
                            .Add("AiCode", info.AirlinesContract(i).AiCode, SqlBuilder.SQLParserDataType.spBoolean)
                            .Add("FOPCode", info.AirlinesContract(i).FOPCode, SqlBuilder.SQLParserDataType.spBoolean)
                            .Add("Endors", info.AirlinesContract(i).Endors, SqlBuilder.SQLParserDataType.spBoolean)
                            .Add("TktDesig", info.AirlinesContract(i).TktDesig, SqlBuilder.SQLParserDataType.spBoolean)
                            .Add("TMUNF", info.AirlinesContract(i).TMUNF, SqlBuilder.SQLParserDataType.spBoolean)
                            .Add("TMUASF", info.AirlinesContract(i).TMUASF, SqlBuilder.SQLParserDataType.spBoolean)
                            .Add("CheckOSI", info.AirlinesContract(i).CheckOSI, SqlBuilder.SQLParserDataType.spBoolean)
                        End With
                        EffectRow = .ExecuteInsert()
                        If EffectRow <= 0 Then
                            Exit For
                        End If
                    Next
                End With
                MatchContactsRecord(ContactDT, info)
                If EffectRow > 0 Then
                    Me.MySQLParser.CommitTran()
                Else
                    Me.MySQLParser.RollbackTran()
                End If
            Catch ex As Exception
                EffectRow = -1
                Me.MySQLParser.RollbackTran()
            Finally
                Me.MySQLParser.CloseConnection()
            End Try
            Return EffectRow
        End Function

        Private Sub MatchContactsRecord(ByVal ContactDT As DataTable, ByVal info As DataInfo.SupplierAirContractInfo)
            Dim countDT As Integer
            Dim countInfo As Integer
            Dim checkMatch As Boolean
            Dim effectRow As Integer

            If ContactDT.Rows.Count > 0 Then
                For countDT = 0 To ContactDT.Rows.Count - 1
                    checkMatch = checkContactExists(ContactDT.Rows(countDT), info)
                    If checkMatch = False Then

                        For countInfo = 0 To info.AirlinesContract.Count - 1
                            If ContactDT.Rows(countDT).Item("ClientID").ToString() = info.ClientID AndAlso countDT = countInfo Then 'AndAlso ContactDT.Rows(countDT).Item("AirlineCode").ToString() = info.AirlinesContract(countInfo).AirlineCode AndAlso ContactDT.Rows(countDT).Item("FareType").ToString() = info.AirlinesContract(countInfo).FareType AndAlso ContactDT.Rows(countInfo).Item("AccountCode").ToString() = info.AirlinesContract(countInfo).AccountCode
                                With Me.MySQLParser
                                    .TableName = "Temp_tblClientAirContracts"
                                    With .Columns
                                        .Clear()
                                        .Add("ClientID", ContactDT.Rows(countDT).Item("ClientID").ToString(), SqlBuilder.SQLParserDataType.spNum)
                                        .Add("AirlineCode", ContactDT.Rows(countDT).Item("AirlineCode").ToString())
                                        .Add("FareType", ContactDT.Rows(countDT).Item("FareType").ToString())
                                        .Add("MasterCodeID", ContactDT.Rows(countDT).Item("MasterCodeID").ToString())
                                        .Add("AccountCode", ContactDT.Rows(countDT).Item("AccountCode").ToString(), , , , , False)
                                        .Add("DefaultTourCode", ContactDT.Rows(countDT).Item("DefaultTourCode").ToString())
                                        .Add("DefaultVcCode", ContactDT.Rows(countDT).Item("DefaultVcCode").ToString())
                                        .Add("DefaultAiCode", ContactDT.Rows(countDT).Item("DefaultAiCode").ToString())
                                        .Add("DefaultFOPCode", ContactDT.Rows(countDT).Item("DefaultFOPCode").ToString())
                                        .Add("TktDesigDefault", ContactDT.Rows(countDT).Item("TktDesigDefault").ToString())
                                        .Add("EndosDefault", ContactDT.Rows(countDT).Item("EndosDefault").ToString())
                                        .Add("OSI", ContactDT.Rows(countDT).Item("OSI").ToString())
                                        .Add("FareOnTkt", ContactDT.Rows(countDT).Item("FareOnTkt").ToString())
                                        .Add("TourCode", ContactDT.Rows(countDT).Item("TourCode").ToString(), SqlBuilder.SQLParserDataType.spBoolean)
                                        .Add("VcCode", ContactDT.Rows(countDT).Item("VcCode").ToString(), SqlBuilder.SQLParserDataType.spBoolean)
                                        .Add("AiCode", ContactDT.Rows(countDT).Item("AiCode").ToString(), SqlBuilder.SQLParserDataType.spBoolean)
                                        .Add("FOPCode", ContactDT.Rows(countDT).Item("FOPCode").ToString(), SqlBuilder.SQLParserDataType.spBoolean)
                                        .Add("Endors", ContactDT.Rows(countDT).Item("Endors").ToString(), SqlBuilder.SQLParserDataType.spBoolean)
                                        .Add("TktDesig", ContactDT.Rows(countDT).Item("TktDesig").ToString(), SqlBuilder.SQLParserDataType.spBoolean)
                                        .Add("TMUNF", ContactDT.Rows(countDT).Item("TMUNF").ToString(), SqlBuilder.SQLParserDataType.spBoolean)
                                        .Add("TMUASF", ContactDT.Rows(countDT).Item("TMUASF").ToString(), SqlBuilder.SQLParserDataType.spBoolean)
                                        .Add("CheckOSI", ContactDT.Rows(countDT).Item("CheckOSI").ToString(), SqlBuilder.SQLParserDataType.spBoolean)
                                        .Add("DateModification", DateTime.Now)
                                        .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                        .Add("ValueTypeChanged", "Update")
                                    End With
                                    effectRow = .ExecuteInsert()
                                    Exit For
                                End With
                            End If
                        Next countInfo

                        If ContactDT.Rows.Count > info.AirlinesContract.Count And countDT + 1 > info.AirlinesContract.Count Then
                            With Me.MySQLParser
                                .TableName = "Temp_tblClientAirContracts"
                                With .Columns
                                    .Clear()
                                    .Add("ClientID", ContactDT.Rows(countDT).Item("ClientID").ToString(), SqlBuilder.SQLParserDataType.spNum)
                                    .Add("AirlineCode", ContactDT.Rows(countDT).Item("AirlineCode").ToString())
                                    .Add("FareType", ContactDT.Rows(countDT).Item("FareType").ToString())
                                    .Add("MasterCodeID", ContactDT.Rows(countDT).Item("MasterCodeID").ToString())
                                    .Add("AccountCode", ContactDT.Rows(countDT).Item("AccountCode").ToString(), , , , , False)
                                    .Add("DefaultTourCode", ContactDT.Rows(countDT).Item("DefaultTourCode").ToString())
                                    .Add("DefaultVcCode", ContactDT.Rows(countDT).Item("DefaultVcCode").ToString())
                                    .Add("DefaultAiCode", ContactDT.Rows(countDT).Item("DefaultAiCode").ToString())
                                    .Add("DefaultFOPCode", ContactDT.Rows(countDT).Item("DefaultFOPCode").ToString())
                                    .Add("TktDesigDefault", ContactDT.Rows(countDT).Item("TktDesigDefault").ToString())
                                    .Add("EndosDefault", ContactDT.Rows(countDT).Item("EndosDefault").ToString())
                                    .Add("OSI", ContactDT.Rows(countDT).Item("OSI").ToString())
                                    .Add("FareOnTkt", ContactDT.Rows(countDT).Item("FareOnTkt").ToString())
                                    .Add("TourCode", ContactDT.Rows(countDT).Item("TourCode").ToString(), SqlBuilder.SQLParserDataType.spBoolean)
                                    .Add("VcCode", ContactDT.Rows(countDT).Item("VcCode").ToString(), SqlBuilder.SQLParserDataType.spBoolean)
                                    .Add("AiCode", ContactDT.Rows(countDT).Item("AiCode").ToString(), SqlBuilder.SQLParserDataType.spBoolean)
                                    .Add("FOPCode", ContactDT.Rows(countDT).Item("FOPCode").ToString(), SqlBuilder.SQLParserDataType.spBoolean)
                                    .Add("Endors", ContactDT.Rows(countDT).Item("Endors").ToString(), SqlBuilder.SQLParserDataType.spBoolean)
                                    .Add("TktDesig", ContactDT.Rows(countDT).Item("TktDesig").ToString(), SqlBuilder.SQLParserDataType.spBoolean)
                                    .Add("TMUNF", ContactDT.Rows(countDT).Item("TMUNF").ToString(), SqlBuilder.SQLParserDataType.spBoolean)
                                    .Add("TMUASF", ContactDT.Rows(countDT).Item("TMUASF").ToString(), SqlBuilder.SQLParserDataType.spBoolean)
                                    .Add("CheckOSI", ContactDT.Rows(countDT).Item("CheckOSI").ToString(), SqlBuilder.SQLParserDataType.spBoolean)
                                    .Add("DateModification", DateTime.Now)
                                    .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                    .Add("ValueTypeChanged", "Delete")
                                End With
                                effectRow = .ExecuteInsert()
                            End With
                        End If
                    End If
                Next countDT
            End If

            If info.AirlinesContract.Count > ContactDT.Rows.Count Then
                For countInfo = countDT To info.AirlinesContract.Count - 1
                    With Me.MySQLParser
                        .TableName = "Temp_tblClientAirContracts"
                        With .Columns
                            .Clear()
                            .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum)
                            .Add("AirlineCode", info.AirlinesContract(countInfo).AirlineCode)
                            .Add("FareType", info.AirlinesContract(countInfo).FareType)
                            .Add("MasterCodeID", info.AirlinesContract(countInfo).MasterCodeID)
                            .Add("AccountCode", info.AirlinesContract(countInfo).AccountCode, , , , , False)
                            .Add("DefaultTourCode", info.AirlinesContract(countInfo).DefaultTourCode)
                            .Add("DefaultVcCode", info.AirlinesContract(countInfo).DefaultVcCode)
                            .Add("DefaultAiCode", info.AirlinesContract(countInfo).DefaultAiCode)
                            .Add("DefaultFOPCode", info.AirlinesContract(countInfo).DefaultFOPCode)
                            .Add("TktDesigDefault", info.AirlinesContract(countInfo).TktDesigDefault)
                            .Add("EndosDefault", info.AirlinesContract(countInfo).EndosDefault)
                            .Add("OSI", info.AirlinesContract(countInfo).OSI)
                            .Add("FareOnTkt", info.AirlinesContract(countInfo).FareOnTkt)
                            .Add("TourCode", info.AirlinesContract(countInfo).TourCode, SqlBuilder.SQLParserDataType.spBoolean)
                            .Add("VcCode", info.AirlinesContract(countInfo).VcCode, SqlBuilder.SQLParserDataType.spBoolean)
                            .Add("AiCode", info.AirlinesContract(countInfo).AiCode, SqlBuilder.SQLParserDataType.spBoolean)
                            .Add("FOPCode", info.AirlinesContract(countInfo).FOPCode, SqlBuilder.SQLParserDataType.spBoolean)
                            .Add("Endors", info.AirlinesContract(countInfo).Endors, SqlBuilder.SQLParserDataType.spBoolean)
                            .Add("TktDesig", info.AirlinesContract(countInfo).TktDesig, SqlBuilder.SQLParserDataType.spBoolean)
                            .Add("TMUNF", info.AirlinesContract(countInfo).TMUNF, SqlBuilder.SQLParserDataType.spBoolean)
                            .Add("TMUASF", info.AirlinesContract(countInfo).TMUASF, SqlBuilder.SQLParserDataType.spBoolean)
                            .Add("CheckOSI", info.AirlinesContract(countInfo).CheckOSI, SqlBuilder.SQLParserDataType.spBoolean)
                            .Add("DateModification", DateTime.Now)
                            .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                            .Add("ValueTypeChanged", "Insert")
                        End With
                        effectRow = .ExecuteInsert()
                    End With
                Next countInfo
            End If
        End Sub

        Private Function checkContactExists(ByVal row As DataRow, ByVal info As DataInfo.SupplierAirContractInfo)
            Dim check As Boolean
            Dim countInfo As Integer

            For countInfo = 0 To info.AirlinesContract.Count - 1
                If row.Item("ClientID").ToString() = info.ClientID AndAlso row.Item("AirlineCode").ToString() = info.AirlinesContract(countInfo).AirlineCode AndAlso row.Item("FareType").ToString() = info.AirlinesContract(countInfo).FareType AndAlso row.Item("MasterCodeID").ToString() = info.AirlinesContract(countInfo).MasterCodeID AndAlso row.Item("AccountCode").ToString() = info.AirlinesContract(countInfo).AccountCode AndAlso row.Item("TourCode").ToString() = info.AirlinesContract(countInfo).TourCode AndAlso row.Item("DefaultTourCode").ToString() = info.AirlinesContract(countInfo).DefaultTourCode AndAlso row.Item("VcCode").ToString() = info.AirlinesContract(countInfo).VcCode AndAlso row.Item("DefaultVcCode").ToString() = info.AirlinesContract(countInfo).DefaultVcCode AndAlso row.Item("AiCode").ToString() = info.AirlinesContract(countInfo).AiCode AndAlso row.Item("DefaultAiCode").ToString() = info.AirlinesContract(countInfo).DefaultAiCode AndAlso row.Item("FOPCode").ToString() = info.AirlinesContract(countInfo).FOPCode AndAlso row.Item("DefaultFOPCode").ToString() = info.AirlinesContract(countInfo).DefaultFOPCode AndAlso row.Item("Endors").ToString() = info.AirlinesContract(countInfo).Endors AndAlso row.Item("EndosDefault").ToString() = info.AirlinesContract(countInfo).EndosDefault AndAlso row.Item("TktDesig").ToString() = info.AirlinesContract(countInfo).TktDesig AndAlso row.Item("TktDesigDefault").ToString() = info.AirlinesContract(countInfo).TktDesigDefault AndAlso row.Item("FareOnTkt").ToString() = info.AirlinesContract(countInfo).FareOnTkt AndAlso row.Item("TMUNF").ToString() = info.AirlinesContract(countInfo).TMUNF AndAlso row.Item("TMUASF").ToString() = info.AirlinesContract(countInfo).TMUASF AndAlso row.Item("CheckOSI").ToString() = info.AirlinesContract(countInfo).CheckOSI AndAlso row.Item("OSI").ToString() = info.AirlinesContract(countInfo).OSI Then
                    check = True
                    Exit For
                End If
            Next countInfo
            Return check
        End Function

        Public Function GetClientIDByName(ByVal ClientName As String) As String
            Dim retVal As String
            Dim retObj As Object
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblClientMaster"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("Name", ClientName, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("ClientID")
                End With
                retObj = .ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar, CommandType.Text)
                retVal = Util.DBNullToText(retObj)
            End With
            Return retVal
        End Function

        Public Function GetTempAirlineContactInfo(Optional ByVal ClientName As String = "", Optional ByVal dateFrom As String = "", Optional ByVal dateTo As String = "") As DataSet
            '//Contact DT 
            Dim ContactDT As DataTable
            Dim TempContactDT As DataTable
            Dim ContactMasterDT As DataTable

            Dim ClientID As String = ""
            Dim TempTable As DataTable
            Dim ClientIDArr(0) As String
            Dim count As Integer
            Dim count2 As Integer
            Dim ds As New DataSet
            Dim foundRow() As DataRow

            ClientIDArr(0) = "Name"

            ''//Get ClientID 
            'If ClientName <> "" Then
            '    ClientID = GetClientIDByName(ClientName)
            'End If

            With Me.MySQLParser
                .TableName = "Temp_tblClientAirContracts ca inner join tblClientMaster cm on ca.ClientID=cm.ClientID inner join " + Util.StandardDB("tblAirlines") + " a on ca.AirlineCode=a.AirlineCode"         'ac inner join tblClientMaster cm on ac.ClientID = cm.ClientID
                With .Columns
                    .Clear()
                    If ClientName <> "" Then
                        .Add("cm.Name", ClientName, SqlBuilder.SQLParserDataType.spText, True)
                    End If
                    If dateFrom = dateTo Then
                        If dateFrom <> "" And dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:990"
                            .Add("DateModification", "convert(varchar,cast('" + dateFrom + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, ">")
                            .Add("DateModification", "convert(varchar,cast('" + dateTo + " 23:59:59:990" + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, "<")
                        End If
                    Else
                        If dateFrom <> "" Then
                            .Add("DateModification", dateFrom, SqlBuilder.SQLParserDataType.spDate, True, ">")
                        End If
                        If dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:999"
                            .Add("DateModification", dateTo + " 23:59:59:990", SqlBuilder.SQLParserDataType.spText, True, "<=")
                        End If
                    End If
                    .Add("cm.Name,a.AirlineDescription,case when ca.FareType = 'A' then 'All' when ca.FareType = 'P' then 'Publish Fare' when ca.FareType='S' then 'Special Fare' when ca.FareType='C' then 'LCC Corp Fare' when ca.FareType='L' then 'LCC Published Fare ' when ca.FareType='M' then 'LCC Promo Fare' end As Fare,ca.MasterCodeID,ca.AccountCode,ca.TourCode,ca.DefaultTourCode,ca.VcCode,ca.DefaultVcCode,ca.AiCode,ca.DefaultAiCode,ca.FOPCode,ca.DefaultFOPCode,ca.Endors,ca.EndosDefault,ca.TktDesig As TicketDesignator,ca.TktDesigDefault As TicketDesignatorDefault,ca.TMUNF As NetFare,ca.TMUASF As ActualSaleFare,ca.CheckOSI,ca.OSI,ca.FareOnTkt As FareOnTicket,ca.DateModification,ca.UserName,ca.ValueTypeChanged")
                    '.Add("*")
                End With
                TempContactDT = .ExecuteDataTable(.SQLSelect + " order by DateModification Desc")

                .TableName = "tblClientAirContracts ca inner join tblClientMaster cm on ca.ClientID=cm.ClientID inner join " + Util.StandardDB("tblAirlines") + " a on ca.AirlineCode=a.AirlineCode"
                With .Columns
                    .Clear()
                    If ClientName <> "" Then
                        .Add("cm.Name", ClientName, SqlBuilder.SQLParserDataType.spText, True)
                    End If
                    .Add("cm.Name,a.AirlineDescription,case when ca.FareType = 'A' then 'All' when ca.FareType = 'P' then 'Publish Fare' when ca.FareType='S' then 'Special Fare' when ca.FareType='C' then 'LCC Corp Fare' when ca.FareType='L' then 'LCC Published Fare ' when ca.FareType='M' then 'LCC Promo Fare' end As Fare,ca.MasterCodeID,ca.AccountCode,ca.TourCode,ca.DefaultTourCode,ca.VcCode,ca.DefaultVcCode,ca.AiCode,ca.DefaultAiCode,ca.FOPCode,ca.DefaultFOPCode,ca.Endors,ca.EndosDefault,ca.TktDesig As TicketDesignator,ca.TktDesigDefault As TicketDesignatorDefault,ca.TMUNF As NetFare,ca.TMUASF As ActualSaleFare,ca.CheckOSI,ca.OSI,ca.FareOnTkt As FareOnTicket")
                End With
                ContactDT = .ExecuteDataTable()

                TempTable = TempContactDT.DefaultView.ToTable(True, ClientIDArr)
                ContactMasterDT = TempContactDT.Clone()
                For count = 0 To TempTable.Rows.Count - 1
                    foundRow = ContactDT.Select("Name='" + TempTable.Rows(count).Item("Name").ToString() + "'")
                    If foundRow.Length > 0 Then
                        For count2 = 0 To foundRow.Length - 1
                            ContactMasterDT.ImportRow(foundRow(count2))
                        Next count2
                    End If
                Next
                ContactMasterDT.AcceptChanges()
                ContactMasterDT.Merge(TempContactDT)
                ContactMasterDT.TableName = "Contact"
                ds.Tables.Add(ContactMasterDT)
            End With
            Return ds
        End Function
    End Class
End Namespace

@


1.1.1.1
log
@no message
@
text
@@
