head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.23;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.23;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic
Imports System.Collections.Generic

Namespace DataAccessLayer
    Public Class AuxPricingDAL
        Inherits BaseDA

        Public Function GetProductList() As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblProducts"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("*")
                End With
                dt = .ExecuteDataTable(.SQLSelect + " order by Name")
            End With
            Return dt
        End Function

        Public Function GetVendorList(ByVal ProductID) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblVendors inner join tblVendorProduct on tblVendors.VendorNumber = tblVendorProduct.VendorNumber"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("tblVendorProduct.ProductID", ProductID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("distinct VendorName")
                End With
                dt = .ExecuteDataTable(.SQLSelect + "order by VendorName")
            End With
            Return dt
        End Function

        Public Function GetAuxPricingList(ByVal Name As String, ByVal ProductID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblAuxFee"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    If Name <> "" Then
                        .Add("FeeName", "%" + Name + "%", SqlBuilder.SQLParserDataType.spText, True, "LIKE")
                    End If
                    If ProductID <> "" Then
                        .Add("ApplytoProduct", ProductID, SqlBuilder.SQLParserDataType.spNum, True)
                    End If
                    .Add("*")
                    .Add("(select top 1 p.[Name] from tblProducts p where p.[Number]=FeeProduct) as FeeProductName")
                    .Add("isnull((select top 1 v.VendorName from tblVendors v where v.VendorNumber=FeeVendorNumber),'All') as FeeVendorName")
                    .Add("(select top 1 p.[Name] from tblProducts p where p.[Number]=ApplytoProduct) as ApplytoProductName")
                    .Add("isnull((select top 1 v.[VendorName] from tblVendors v where v.VendorNumber=ApplytoVendor),'All') as ApplytoVendorName")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function IsExistName(ByVal FeeName As String, ByVal FeeID As String, ByVal ProductID As String, ByVal VendorID As String) As Boolean
            Dim retVal As Boolean
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblAuxFee"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    If FeeID <> "" Then .Add("AuxFeeID", FeeID, SqlBuilder.SQLParserDataType.spText, True, "<>")
                    .Add("ApplytoProduct", ProductID, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("ApplytoVendor", VendorID, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("FeeName", FeeName, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("count(*) as RecordCount")
                End With
                retVal = (CWTMasterDB.Util.DBNullToZero(.ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar)) > 0)
            End With
            Return retVal
        End Function

        Public Function GetVendorNumberByName(ByVal Name As String)
            Dim dt As DataTable
            With Me.MySQLParser
                .TableName = "tblVendors"
                With .Columns
                    .Clear()
                    .Add("VendorName", Name, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("VendorNumber")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetVendorNameByNumber(ByVal Number As String)
            Dim dt As DataTable
            With Me.MySQLParser
                .TableName = "tblVendors"
                With .Columns
                    .Clear()
                    .Add("VendorNumber", Number, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("VendorName")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetFeeProductNameByID(ByVal Name As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .TableName = "tblProducts"
                With .Columns
                    .Clear()
                    .Add("Name", Name, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetAuxPricingByID(ByVal FeeID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblAuxFee"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("AuxFeeID", FeeID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("*")
                    .Add("(select top 1 p.[Name] from tblProducts p where p.[Number]=ApplytoProduct) as ApplytoProductName")
                    .Add("(select top 1 v.[VendorName] from tblVendors v where v.VendorNumber=ApplytoVendor) as ApplytoVendorName")
                    .Add("(select top 1 p.[Name] from tblProducts p where p.[Number]=FeeProduct) as FeeProductName")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function UpdateAuxPrice(ByVal info As DataInfo.AuxFeeInfo) As Integer
            Dim EffectRow As Integer
            Try
                With Me.MySQLParser
                    .TableName = "tblAuxFee"
                    With .Columns
                        .Clear()
                        If info.ID <> "" Then .Add("AuxFeeID", info.ID, SqlBuilder.SQLParserDataType.spNum, True)
                        .Add("FeeName", info.Name)
                        If info.PageMode = CWTMasterDB.TransactionMode.AddNewMode Then
                            .Add("ApplytoProduct", info.ApplyProduct, SqlBuilder.SQLParserDataType.spNum)
                            .Add("ApplytoVendor", info.ApplyVendor, SqlBuilder.SQLParserDataType.spText)
                        End If
                        .Add("FeeAmount", info.FeeAmount, SqlBuilder.SQLParserDataType.spNum)
                        .Add("FeeProduct", info.FeeProduct, SqlBuilder.SQLParserDataType.spNum)
                        .Add("FeeVendorNumber", info.FeeVendor, SqlBuilder.SQLParserDataType.spText)
                        .Add("FeeCommission", info.ComAmount, SqlBuilder.SQLParserDataType.spNum)
                    End With

                    Select Case info.PageMode
                        Case CWTMasterDB.TransactionMode.AddNewMode
                            EffectRow = .ExecuteInsert()
                            info.ID = Convert.ToInt32(GetLastID())
                            CallProcedure(info.ID, "Insert", "sp_AuxFee")
                        Case CWTMasterDB.TransactionMode.UpdateMode
                            CallProcedure(info.ID, "Update", "sp_AuxFee")
                            EffectRow = .ExecuteUpdate()
                    End Select
                End With
            Catch ex As Exception
                EffectRow = -1
            End Try
            Return EffectRow
        End Function

        Public Function DeleteFuelCharge(ByVal AuxFeeID As Integer) As Integer
            Dim EffectRow As Integer
            Try
                With Me.MySQLParser
                    .TableName = "tblAuxFee"
                    With .Columns
                        .Add("AuxFeeID", AuxFeeID, SqlBuilder.SQLParserDataType.spNum, True)
                    End With
                    CallProcedure(AuxFeeID, "Delete", "sp_AuxFee")
                    EffectRow = .ExecuteDelete()
                End With
            Catch ex As Exception
                EffectRow = -1
            End Try
            Return EffectRow
        End Function

        Private Sub CallProcedure(ByVal ID As String, ByVal Type As String, ByVal StoreProdType As String)
            With Me.MySQLParser
                .ExecuteStoreProcedure("exec " + StoreProdType + " '" + ID + "','" + ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName + "','" + Type + "'")
            End With
        End Sub

        Private Function GetLastID() As String
            Dim ID As String
            With Me.MySQLParser
                .TableName = "tblAuxFee"
                With .Columns
                    .Clear()
                    .Add("max(AuxFeeID)")
                End With
                ID = .ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar)
            End With
            Return ID
        End Function

        Public Function GetTempAuxFee(Optional ByVal FeeName As String = "", Optional ByVal dateFrom As String = "", Optional ByVal dateTo As String = "") As DataSet
            Dim AuxFeeDT As DataTable
            Dim TempAuxFeeDT As DataTable
            Dim AuxFeeMasterDT As DataTable

            Dim ds As New DataSet
            Dim TempTable As DataTable
            Dim ClientIDArr(0) As String
            Dim count As Integer
            Dim count2 As Integer
            Dim foundRow() As DataRow


            ClientIDArr(0) = "AuxFeeID"

            With Me.MySQLParser
                .TableName = "Temp_tblAuxFee a inner join tblProducts AppProduct on a.ApplyToProduct = AppProduct.Number inner join tblProducts VendorProduct on a.FeeProduct =VendorProduct.Number inner join tblVendors FeeVendor on a.FeeVendorNumber=FeeVendor.VendorNumber inner join tblVendors AppVendor on (a.ApplytoVendor=AppVendor.VendorNumber or a.ApplytoVendor='all')"
                With .Columns
                    .Clear()
                    If FeeName <> "" Then
                        .Add("a.FeeName", FeeName, SqlBuilder.SQLParserDataType.spText, True)
                    End If
                    If dateFrom = dateTo Then
                        If dateFrom <> "" And dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:990"
                            .Add("a.DateModification", "convert(varchar,cast('" + dateFrom + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, ">")
                            .Add("a.DateModification", "convert(varchar,cast('" + dateTo + " 23:59:59:990" + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, "<")
                        End If
                    Else
                        If dateFrom <> "" Then
                            .Add("a.DateModification", dateFrom, SqlBuilder.SQLParserDataType.spDate, True, ">")
                        End If
                        If dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:999"
                            .Add("a.DateModification", dateTo + " 23:59:59:990", SqlBuilder.SQLParserDataType.spText, True, "<=")
                        End If
                    End If
                    .Add("distinct a.AuxFeeID,AppProduct.[Name] As ApplyProduct,case when a.ApplytoVendor='all' then a.ApplytoVendor else AppVendor.VendorName end as ApplytoVendor,a.FeeName,a.FeeAmount,VendorProduct.[Name] As FeeProduct,FeeVendor.VendorName As FeeVendorName,a.FeeCommission,a.DateModification,a.UserName,a.ValueTypeChanged")
                End With
                TempAuxFeeDT = .ExecuteDataTable(.SQLSelect + " order by DateModification Desc")

                .TableName = "tblAuxFee a inner join tblProducts AppProduct on a.ApplyToProduct = AppProduct.Number inner join tblProducts VendorProduct on a.FeeProduct =VendorProduct.Number inner join tblVendors FeeVendor on a.FeeVendorNumber=FeeVendor.VendorNumber inner join tblVendors AppVendor on (a.ApplytoVendor=AppVendor.VendorNumber or a.ApplytoVendor='all')"
                With .Columns
                    .Clear()
                    If FeeName <> "" Then
                        .Add("a.FeeName", FeeName, SqlBuilder.SQLParserDataType.spText, True)
                    End If
                    .Add("distinct a.AuxFeeID,AppProduct.[Name] As ApplyProduct,case when a.ApplytoVendor='all' then a.ApplytoVendor else AppVendor.VendorName end as ApplytoVendor,a.FeeName,a.FeeAmount,VendorProduct.[Name] As FeeProduct,FeeVendor.VendorName As FeeVendorName,a.FeeCommission")
                End With
                AuxFeeDT = .ExecuteDataTable()

                TempTable = TempAuxFeeDT.DefaultView.ToTable(True, ClientIDArr)
                AuxFeeMasterDT = TempAuxFeeDT.Clone()
                For count = 0 To TempTable.Rows.Count - 1
                    foundRow = AuxFeeDT.Select("AuxFeeID='" + TempTable.Rows(count).Item("AuxFeeID").ToString() + "'")
                    If foundRow.Length > 0 Then
                        For count2 = 0 To foundRow.Length - 1
                            AuxFeeMasterDT.ImportRow(foundRow(count2))
                        Next count2
                    End If
                Next
                AuxFeeMasterDT.AcceptChanges()
                AuxFeeMasterDT.Merge(TempAuxFeeDT)
                AuxFeeMasterDT.TableName = "AuxFee"
                ds.Tables.Add(AuxFeeMasterDT)


            End With
            Return ds
        End Function

    End Class
End Namespace

@


1.1.1.1
log
@no message
@
text
@@
