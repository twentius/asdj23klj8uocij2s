head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.23;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.23;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic
Imports System.Collections.Generic

Namespace DataAccessLayer
    Public Class StdAirlineDAL
        Inherits BaseDA

        Public Function GetAirlineList(ByVal AirlineName As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = CWTMasterDB.Util.StandardDB("tblAirlines")
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    If AirlineName <> "" Then .Add("AirlineDescription", "%" + AirlineName + "%", SqlBuilder.SQLParserDataType.spText, True, "LIKE")
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetAirlineByCode(ByVal AirlineCode As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = CWTMasterDB.Util.StandardDB("tblAirlines")
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("AirlineCode", AirlineCode, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function IsExistCode(ByVal AirlineCode As String) As Boolean
            Dim retVal As Boolean
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = CWTMasterDB.Util.StandardDB("tblAirlines")
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("AirlineCode", AirlineCode, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("count(*) as RecordCount")
                End With
                retVal = (CWTMasterDB.Util.DBNullToZero(.ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar)) > 0)
            End With
            Return retVal
        End Function

        Public Function UpdateAirline(ByVal info As DataInfo.StdAirlineInfo) As Integer
            Dim EffectRow As Integer
            Try
                With Me.MySQLParser
                    .TableName = CWTMasterDB.Util.StandardDB("tblAirlines")
                    With .Columns
                        .Clear()
                        .Add("AirlineCode", info.AirlineCode, SqlBuilder.SQLParserDataType.spText, (info.PageMode = CWTMasterDB.TransactionMode.UpdateMode))
                        .Add("AirlineDescription", info.AirlineDescription)
                        If info.AirlineNumber <> "" Then .Add("AirlineNumber", info.AirlineNumber, SqlBuilder.SQLParserDataType.spNum)
                        .Add("Status", info.IsActive, SqlBuilder.SQLParserDataType.spBoolean)
                    End With
                    Select Case info.PageMode
                        Case CWTMasterDB.TransactionMode.AddNewMode
                            EffectRow = .ExecuteInsert()
                            CallProcedure(info.AirlineCode, "Insert", "[CWTStandardData].[dbo].sp_Airlines")
                        Case CWTMasterDB.TransactionMode.UpdateMode
                            CallProcedure(info.AirlineCode, "Update", "[CWTStandardData].[dbo].sp_Airlines")
                            EffectRow = .ExecuteUpdate()
                    End Select
                End With
            Catch ex As Exception
                EffectRow = -1
            End Try
            Return EffectRow
        End Function

        Private Sub CallProcedure(ByVal ID As String, ByVal Type As String, ByVal StoreProdType As String)
            With Me.MySQLParser
                .ExecuteStoreProcedure("exec " + StoreProdType + " '" + ID + "','" + ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName + "','" + Type + "'")
            End With
        End Sub

        Public Function GetTempAirlineInfo(Optional ByVal AirlineCode As String = "", Optional ByVal dateFrom As String = "", Optional ByVal dateTo As String = "") As DataSet
            '// Airline DT
            Dim AirlineDT As DataTable
            Dim TempAirlineDT As DataTable
            Dim AirlineMasterDT As DataTable

            Dim ClientID As String = ""
            Dim TempTable As DataTable
            Dim ClientIDArr(0) As String
            Dim count As Integer
            Dim count2 As Integer
            Dim ds As New DataSet
            Dim foundRow() As DataRow

            ClientIDArr(0) = "AirlineCode"

            With Me.MySQLParser
                .TableName = CWTMasterDB.Util.StandardDB("Temp_tblAirlines")
                With .Columns
                    .Clear()
                    If AirlineCode <> "" Then
                        .Add("AirlineCode", AirlineCode, SqlBuilder.SQLParserDataType.spText, True)
                    End If
                    If dateFrom = dateTo Then
                        If dateFrom <> "" And dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:990"
                            .Add("DateModification", "convert(varchar,cast('" + dateFrom + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, ">")
                            .Add("DateModification", "convert(varchar,cast('" + dateTo + " 23:59:59:990" + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, "<")
                        End If
                    Else
                        If dateFrom <> "" Then
                            .Add("DateModification", dateFrom, SqlBuilder.SQLParserDataType.spDate, True, ">")
                        End If
                        If dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:999"
                            .Add("DateModification", dateTo + " 23:59:59:990", SqlBuilder.SQLParserDataType.spText, True, "<=")
                        End If
                    End If
                    .Add("*")
                End With
                TempAirlineDT = .ExecuteDataTable(.SQLSelect + " order by DateModification Desc")

                .TableName = CWTMasterDB.Util.StandardDB("tblAirlines")
                With .Columns
                    .Clear()
                    If AirlineCode <> "" Then
                        .Add("AirlineCode", AirlineCode, SqlBuilder.SQLParserDataType.spText, True)
                    End If
                    If dateFrom = dateTo Then
                        If dateFrom <> "" And dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:990"
                            .Add("DateModification", "convert(varchar,cast('" + dateFrom + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, ">")
                            .Add("DateModification", "convert(varchar,cast('" + dateTo + " 23:59:59:990" + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, "<")
                        End If
                    Else
                        If dateFrom <> "" Then
                            .Add("DateModification", dateFrom, SqlBuilder.SQLParserDataType.spDate, True, ">")
                        End If
                        If dateTo <> "" Then
                            .Add("DateModification", dateTo, SqlBuilder.SQLParserDataType.spDate, True, "<")
                        End If
                    End If
                    .Add("*")
                End With
                AirlineDT = .ExecuteDataTable()

                If AirlineCode <> "" Then
                    AirlineDT.Merge(TempAirlineDT)
                    AirlineDT.TableName = "Airline"
                    ds.Tables.Add(AirlineDT)
                Else
                    TempTable = TempAirlineDT.DefaultView.ToTable(True, ClientIDArr)
                    AirlineMasterDT = TempAirlineDT.Clone()
                    For count = 0 To TempTable.Rows.Count - 1
                        foundRow = AirlineDT.Select("AirlineCode='" + TempTable.Rows(count).Item("AirlineCode").ToString() + "'")
                        If foundRow.Length > 0 Then
                            For count2 = 0 To foundRow.Length - 1
                                AirlineMasterDT.ImportRow(foundRow(count2))
                            Next count2
                        End If
                    Next
                    AirlineMasterDT.AcceptChanges()
                    AirlineMasterDT.Merge(TempAirlineDT)
                    AirlineMasterDT.TableName = "Airline"
                    ds.Tables.Add(AirlineMasterDT)
                End If
            End With
            Return ds
        End Function

    End Class
End Namespace




@


1.1.1.1
log
@no message
@
text
@@
