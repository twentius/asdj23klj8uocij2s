head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.23;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.23;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic
Imports System.Collections.Generic

Namespace DataAccessLayer
    Public Class AuxCustomFieldDAL
        Inherits BaseDA

        Public Function GetProductList() As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblProducts"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("*")
                End With
                dt = .ExecuteDataTable(.SQLSelect + " order by Name")
            End With
            Return dt
        End Function

        'Public Function GetCommandList() As DataTable
        'Dim dt As DataTable
        'With Me.MySQLParser
        '.AutoParameter = False
        '.TableName = CWTMasterDB.Util.StandardDB("tblCSP_DataType")
        'With .Columns
        '.IncludeKey = False
        '.Clear()
        '.Add("*")
        'End With
        ' dt = .ExecuteDataTable()
        ' End With
        ' Return dt
        'End Function'

        Public Function GetCommandData(ByVal FieldID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblAuxCusCtrlCmd"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("AuxCustomControlID", FieldID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("*")
                End With
                dt = .ExecuteDataTable(.SQLSelect + " order by AuxGDSCmdID")
            End With
            Return dt
        End Function

        Public Function GetEOData(ByVal FieldID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblAuxCusCtrlEO"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("AuxCustomControlID", FieldID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("*")
                End With
                dt = .ExecuteDataTable(.SQLSelect + " order by AuxEOID")
            End With
            Return dt
        End Function

        Public Function LoadDropListByID(ByVal FieldID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblAuxCusCtrlValue"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("AuxCustomControlID", FieldID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetDataByID(ByVal FieldID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblAuxCusCtrl"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("AuxCustomControlID", FieldID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("*")
                    .Add("(select top 1 p.[Name] from tblProducts p where p.[Number]=ProductNumber) as ProductName")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetAuxCustomFieldList(ByVal Name As String, ByVal ProductID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblAuxCusCtrl"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    If Name <> "" Then
                        .Add("ControlName", "%" + Name + "%", SqlBuilder.SQLParserDataType.spText, True, "LIKE")
                    End If
                    If ProductID <> "" Then
                        .Add("ProductNumber", ProductID, SqlBuilder.SQLParserDataType.spNum, True)
                    End If
                    .Add("*")
                    .Add("(select top 1 p.[Name] from tblProducts p where p.[Number]=ProductNumber) as ProductName")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetAuxCustSeqNum(ByVal ProductID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblAuxCusCtrl"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    If ProductID <> "" Then
                        .Add("ProductNumber", ProductID, SqlBuilder.SQLParserDataType.spNum, True)
                    End If
                    .Add("*")

                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetAuxCustSeqNum2(ByVal AuxCustID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblAuxCusCtrl"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    If AuxCustID <> "" Then
                        .Add("AuxCustomControlID", AuxCustID, SqlBuilder.SQLParserDataType.spNum, True)
                    End If
                    .Add("ProductNumber")

                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetAuxCustSeqNum3(ByVal AuxCustID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblAuxCusCtrl"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    If AuxCustID <> "" Then
                        .Add("AuxCustomControlID", AuxCustID, SqlBuilder.SQLParserDataType.spNum, True)
                    End If
                    .Add("SequenceNumber")

                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetRemainSeqNum(ByVal ProID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblAuxCusCtrl"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    If ProID <> "" Then
                        .Add("ProductNumber", ProID, SqlBuilder.SQLParserDataType.spNum, True)
                    End If
                    .Add("SequenceNumber")
                    .Add("AuxCustomControlID")

                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function


        Public Function GetAuxPricingByID(ByVal FeeID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblAuxFee"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("AuxFeeID", FeeID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("*")
                    .Add("(select top 1 p.[Name] from tblProducts p where p.[Number]=ApplytoProduct) as ApplytoProductName")
                    .Add("(select top 1 v.[VendorName] from tblVendors v where v.VendorNumber=ApplytoVendor) as ApplytoVendorName")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function



        Public Function UpdateSeq(ByVal Seq As String, ByVal AuxID As String) As String
            Dim EffectRow As Integer
            Try
                With Me.MySQLParser
                    .AutoParameter = False
                    .TableName = "tblAuxCusCtrl"
                    With .Columns
                        .IncludeKey = False
                        .Clear()
                        .Add("AuxCustomControlID", AuxID, SqlBuilder.SQLParserDataType.spNum, True)
                        .Add("SequenceNumber", Seq, SqlBuilder.SQLParserDataType.spNum)
                    End With
                    EffectRow = .ExecuteUpdate()
                End With



                If EffectRow > 0 Then
                    Me.MySQLParser.CommitTran()
                Else
                    Me.MySQLParser.RollbackTran()
                End If
            Catch ex As Exception
                EffectRow = -1
                Me.MySQLParser.RollbackTran()
            Finally
                Me.MySQLParser.CloseConnection()
            End Try

            Return EffectRow
        End Function

        Public Function UpdateAuxCustomField(ByVal info As DataInfo.AuxCustomFieldInfo) As Integer
            Dim EffectRow As Integer
            Dim AuxValue As DataTable
            Dim AuxCmd As DataTable
            Dim AuxEO As DataTable

            Try
                AuxValue = LoadDropListByID(info.ID)
                AuxCmd = GetCommandData(info.ID)
                AuxEO = GetEOData(info.ID)
                With Me.MySQLParser
                    .OpenConnection()
                    .BeginTran()
                    If info.PageMode = TransactionMode.UpdateMode Then
                        .TableName = "tblAuxCusCtrlValue"
                        With .Columns
                            .Clear()
                            .Add("AuxCustomControlID", info.ID, SqlBuilder.SQLParserDataType.spNum, True)
                        End With
                        .ExecuteDelete()
                        '//
                        .TableName = "tblAuxCusCtrlCmd"
                        With .Columns
                            .Clear()
                            .Add("AuxCustomControlID", info.ID, SqlBuilder.SQLParserDataType.spNum, True)
                        End With
                        .ExecuteDelete()
                        '//
                        .TableName = "tblAuxCusCtrlEO"
                        With .Columns
                            .Clear()
                            .Add("AuxCustomControlID", info.ID, SqlBuilder.SQLParserDataType.spNum, True)
                        End With
                        .ExecuteDelete()
                    End If
                    '//
                    .TableName = "tblAuxCusCtrl"
                    With .Columns
                        .Clear()
                        If info.PageMode = CWTMasterDB.TransactionMode.UpdateMode Then
                            .Add("AuxCustomControlID", info.ID, SqlBuilder.SQLParserDataType.spNum, True)
                        End If
                        .Add("ControlName", info.Name)
                        .Add("ProductNumber", info.ProductNumber)
                        .Add("Type", info.Type)
                        .Add("Location", info.Location)
                        '.Add("ValueType", info.ValueType)
                        .Add("Mandatory", info.Mandatory, SqlBuilder.SQLParserDataType.spBoolean)
                        .Add("SequenceNumber", info.SequenceNumber, SqlBuilder.SQLParserDataType.spNum)
                        If info.Type = "TB" Then
                            .Add("DefaultValue", info.DefaultValue)
                        End If
                    End With

                    Select Case info.PageMode
                        Case CWTMasterDB.TransactionMode.AddNewMode
                            EffectRow = .ExecuteInsert()
                            info.ID = .GetLastIdentity
                            CallProcedure(info.ID, "Insert", "sp_AuxCusCtrl")
                        Case CWTMasterDB.TransactionMode.UpdateMode
                            CallProcedure(info.ID, "Update", "sp_AuxCusCtrl")
                            EffectRow = .ExecuteUpdate()
                    End Select

                    '//Value
                    If EffectRow > 0 AndAlso info.Type = "CB" Then
                        .TableName = "tblAuxCusCtrlValue"
                        For i As Integer = 0 To info.DropList.Count - 1
                            With .Columns
                                .Clear()
                                .Add("AuxCustomControlID", info.ID, SqlBuilder.SQLParserDataType.spNum)
                                .Add("Value", info.DropList(i))
                            End With
                            EffectRow = .ExecuteInsert()
                            If EffectRow <= 0 Then
                                Exit For
                            End If
                        Next
                        MatchAuxCustomRecord(AuxValue, info, "AuxValue")
                    End If

                    '//Cmd
                    If EffectRow > 0 Then
                        .TableName = "tblAuxCusCtrlCmd"
                        For i As Integer = 0 To info.Command.Count - 1
                            With .Columns
                                .Clear()
                                .Add("AuxCustomControlID", info.ID, SqlBuilder.SQLParserDataType.spNum)
                                .Add("AuxGDSCmdID", i + 1, SqlBuilder.SQLParserDataType.spNum)
                                .Add("DataTypeID", info.Command(i).DataTypeID)
                                .Add("Format", info.Command(i).Format)
                            End With
                            EffectRow = .ExecuteInsert()
                            If EffectRow <= 0 Then
                                Exit For
                            End If
                        Next
                        MatchAuxCustomRecord(AuxCmd, info, "AuxCmd")
                    End If

                    '//EO
                    If EffectRow > 0 Then
                        .TableName = "tblAuxCusCtrlEO"
                        For i As Integer = 0 To info.EO.Count - 1
                            With .Columns
                                .Clear()
                                .Add("AuxCustomControlID", info.ID, SqlBuilder.SQLParserDataType.spNum)
                                .Add("AuxEOID", i + 1, SqlBuilder.SQLParserDataType.spNum)
                                .Add("Sequence", info.EO(i).Sequence, SqlBuilder.SQLParserDataType.spNum)
                                .Add("Format", info.EO(i).Format)
                            End With
                            EffectRow = .ExecuteInsert()
                            If EffectRow <= 0 Then
                                Exit For
                            End If
                        Next
                        MatchAuxCustomRecord(AuxEO, info, "AuxEO")
                    End If
                End With
                If EffectRow > 0 Then
                    Me.MySQLParser.CommitTran()
                Else
                    Me.MySQLParser.RollbackTran()
                End If
            Catch ex As Exception
                EffectRow = -1
                Me.MySQLParser.RollbackTran()
            Finally
                Me.MySQLParser.CloseConnection()
            End Try
            Return EffectRow
        End Function

        Public Function DeleteAuxCustField(ByVal AuxCustomControlID As Integer) As Integer
            Dim EffectRow As Integer

            Try

                With Me.MySQLParser
                    .OpenConnection()
                    .BeginTran()
                    If AuxCustomControlID <> 0 Then
                        .TableName = "tblAuxCusCtrlValue"
                        With .Columns
                            .Clear()
                            .Add("AuxCustomControlID", AuxCustomControlID, SqlBuilder.SQLParserDataType.spNum, True)
                        End With
                        CallProcedure(AuxCustomControlID, "Delete", "sp_AuxCusCtrlValue")
                        EffectRow = .ExecuteDelete()
                        '//
                        .TableName = "tblAuxCusCtrlCmd"
                        With .Columns
                            .Clear()
                            .Add("AuxCustomControlID", AuxCustomControlID, SqlBuilder.SQLParserDataType.spNum, True)
                        End With
                        CallProcedure(AuxCustomControlID, "Delete", "sp_AuxCusCtrlCmd")
                        EffectRow = .ExecuteDelete()
                        '//
                        .TableName = "tblAuxCusCtrlEO"
                        With .Columns
                            .Clear()
                            .Add("AuxCustomControlID", AuxCustomControlID, SqlBuilder.SQLParserDataType.spNum, True)
                        End With
                        CallProcedure(AuxCustomControlID, "Delete", "sp_AuxCusCtrlEO")
                        EffectRow = .ExecuteDelete()
                        '//
                        .TableName = "tblAuxCusCtrl"
                        With .Columns
                            .Clear()
                            .Add("AuxCustomControlID", AuxCustomControlID, SqlBuilder.SQLParserDataType.spNum, True)
                        End With
                        CallProcedure(AuxCustomControlID, "Delete", "sp_AuxCusCtrl")
                        EffectRow = .ExecuteDelete()
                    End If

                End With
                If EffectRow > 0 Then
                    Me.MySQLParser.CommitTran()
                Else
                    Me.MySQLParser.RollbackTran()
                End If
            Catch ex As Exception
                EffectRow = -1
                Me.MySQLParser.RollbackTran()

            Finally
                Me.MySQLParser.CloseConnection()
            End Try

            Return EffectRow
        End Function

        Private Sub CallProcedure(ByVal ID As String, ByVal Type As String, ByVal StoreProdType As String)
            With Me.MySQLParser
                .ExecuteStoreProcedure("exec " + StoreProdType + " '" + ID + "','" + ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName + "','" + Type + "'")
            End With
        End Sub

        Private Sub MatchAuxCustomRecord(ByVal AuxCusDT As DataTable, ByVal info As DataInfo.AuxCustomFieldInfo, ByVal Type As String)
            Dim countDT As Integer
            Dim countInfo As Integer
            Dim checkMatch As Boolean
            Dim effectRow As Integer

            If AuxCusDT.Rows.Count > 0 Then
                For countDT = 0 To AuxCusDT.Rows.Count - 1
                    checkMatch = checkAuxExists(AuxCusDT.Rows(countDT), info, Type)
                    If checkMatch = False Then

                        If Type = "AuxValue" Then
                            For countInfo = 0 To info.DropList.Count - 1
                                If AuxCusDT.Rows(countDT).Item("AuxCustomControlID").ToString() = info.ID Then
                                    With Me.MySQLParser
                                        .TableName = "Temp_tblAuxCusCtrlValue"
                                        With .Columns
                                            .Clear()
                                            .Add("AuxCustomControlID", AuxCusDT.Rows(countDT).Item("AuxCustomControlID").ToString(), SqlBuilder.SQLParserDataType.spNum)
                                            .Add("Value", AuxCusDT.Rows(countDT).Item("Value").ToString())
                                            .Add("DateModification", DateTime.Now)
                                            .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                            .Add("ValueTypeChanged", "Update")
                                        End With
                                        effectRow = .ExecuteInsert()
                                        Exit For
                                    End With
                                End If
                            Next countInfo

                            If AuxCusDT.Rows.Count > info.DropList.Count Then
                                With Me.MySQLParser
                                    .TableName = "Temp_tblAuxCusCtrlValue"
                                    With .Columns
                                        .Clear()
                                        .Add("AuxCustomControlID", AuxCusDT.Rows(countDT).Item("AuxCustomControlID").ToString(), SqlBuilder.SQLParserDataType.spNum)
                                        .Add("Value", AuxCusDT.Rows(countDT).Item("Value").ToString())
                                        .Add("DateModification", DateTime.Now)
                                        .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                        .Add("ValueTypeChanged", "Delete")
                                    End With
                                    effectRow = .ExecuteInsert()
                                End With
                            End If


                        ElseIf Type = "AuxCmd" Then
                            For countInfo = 0 To info.Command.Count - 1
                                If AuxCusDT.Rows(countDT).Item("AuxGDSCmdID").ToString() = countInfo + 1 AndAlso AuxCusDT.Rows(countDT).Item("AuxCustomControlID").ToString() = info.ID Then
                                    With Me.MySQLParser
                                        .TableName = "Temp_tblAuxCusCtrlCmd"
                                        With .Columns
                                            .Clear()
                                            .Add("AuxGDSCmdID", countInfo + 1, SqlBuilder.SQLParserDataType.spNum)
                                            .Add("AuxCustomControlID", AuxCusDT.Rows(countDT).Item("AuxCustomControlID").ToString(), SqlBuilder.SQLParserDataType.spNum)
                                            .Add("DataTypeID", AuxCusDT.Rows(countDT).Item("DataTypeID").ToString())
                                            .Add("Format", AuxCusDT.Rows(countDT).Item("Format").ToString())
                                            .Add("DateModification", DateTime.Now)
                                            .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                            .Add("ValueTypeChanged", "Update")
                                        End With
                                        effectRow = .ExecuteInsert()
                                        Exit For
                                    End With
                                End If
                            Next countInfo

                            If AuxCusDT.Rows.Count > info.Command.Count Then
                                With Me.MySQLParser
                                    .TableName = "Temp_tblAuxCusCtrlCmd"
                                    With .Columns
                                        .Clear()
                                        .Add("AuxGDSCmdID", AuxCusDT.Rows(countDT).Item("AuxGDSCmdID").ToString(), SqlBuilder.SQLParserDataType.spNum)
                                        .Add("AuxCustomControlID", AuxCusDT.Rows(countDT).Item("AuxCustomControlID").ToString(), SqlBuilder.SQLParserDataType.spNum)
                                        .Add("DataTypeID", AuxCusDT.Rows(countDT).Item("DataTypeID").ToString())
                                        .Add("Format", AuxCusDT.Rows(countDT).Item("Format").ToString())
                                        .Add("DateModification", DateTime.Now)
                                        .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                        .Add("ValueTypeChanged", "Delete")
                                    End With
                                    effectRow = .ExecuteInsert()
                                End With
                            End If

                        ElseIf Type = "AuxEO" Then
                            For countInfo = 0 To info.EO.Count - 1
                                If AuxCusDT.Rows(countDT).Item("AuxEOID").ToString() = countInfo + 1 AndAlso AuxCusDT.Rows("AuxCustomControlID").ToString() = info.ID Then
                                    With Me.MySQLParser
                                        .TableName = "Temp_tblAuxCusCtrlEO"
                                        With .Columns
                                            .Clear()
                                            .Add("AuxEOID", countInfo + 1, SqlBuilder.SQLParserDataType.spNum)
                                            .Add("AuxCustomControlID", AuxCusDT.Rows(countDT).Item("AuxCustomControlID").ToString(), SqlBuilder.SQLParserDataType.spNum)
                                            .Add("Sequence", AuxCusDT.Rows(countDT).Item("Sequence").ToString())
                                            .Add("Format", AuxCusDT.Rows(countDT).Item("Format").ToString())
                                            .Add("DateModification", DateTime.Now)
                                            .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                            .Add("ValueTypeChanged", "Update")
                                        End With
                                        effectRow = .ExecuteInsert()
                                        Exit For
                                    End With
                                End If
                            Next countInfo

                            If AuxCusDT.Rows.Count > info.EO.Count Then
                                With Me.MySQLParser
                                    .TableName = "Temp_tblAuxCusCtrlEO"
                                    With .Columns
                                        .Clear()
                                        .Add("AuxEOID", AuxCusDT.Rows(countDT).Item("AuxEOID").ToString(), SqlBuilder.SQLParserDataType.spNum)
                                        .Add("AuxCustomControlID", AuxCusDT.Rows(countDT).Item("AuxCustomControlID").ToString(), SqlBuilder.SQLParserDataType.spNum)
                                        .Add("Sequence", AuxCusDT.Rows(countDT).Item("Sequence").ToString())
                                        .Add("Format", AuxCusDT.Rows(countDT).Item("Format").ToString())
                                        .Add("DateModification", DateTime.Now)
                                        .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                        .Add("ValueTypeChanged", "Delete")
                                    End With
                                    effectRow = .ExecuteInsert()
                                End With
                            End If
                        End If
                    End If
                Next countDT
            End If


            If Type = "AuxValue" Then
                If info.DropList.Count > AuxCusDT.Rows.Count Then
                    For countInfo = AuxCusDT.Rows.Count To info.DropList.Count - 1
                        With Me.MySQLParser
                            .TableName = "Temp_tblAuxCusCtrlValue"
                            With .Columns
                                .Clear()
                                .Add("AuxCustomControlID", info.ID, SqlBuilder.SQLParserDataType.spNum)
                                .Add("Value", info.DropList(countInfo))
                                .Add("DateModification", DateTime.Now)
                                .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                .Add("ValueTypeChanged", "Insert")
                            End With
                            effectRow = .ExecuteInsert()
                        End With
                    Next countInfo
                End If
            ElseIf Type = "AuxCmd" Then
                If info.Command.Count > AuxCusDT.Rows.Count Then
                    For countInfo = countDT To info.Command.Count - 1
                        With Me.MySQLParser
                            .TableName = "Temp_tblAuxCusCtrlCmd"
                            With .Columns
                                .Clear()
                                .Add("AuxGDSCmdID", countInfo + 1, SqlBuilder.SQLParserDataType.spNum)
                                .Add("AuxCustomControlID", info.ID, SqlBuilder.SQLParserDataType.spNum)
                                .Add("DataTypeID", info.Command(countInfo).DataTypeID)
                                .Add("Format", info.Command(countInfo).Format)
                                .Add("DateModification", DateTime.Now)
                                .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                .Add("ValueTypeChanged", "Insert")
                            End With
                            effectRow = .ExecuteInsert()
                        End With
                    Next countInfo
                End If

            ElseIf Type = "AuxEO" Then
                If info.EO.Count > AuxCusDT.Rows.Count Then
                    For countInfo = countDT To info.EO.Count - 1
                        With Me.MySQLParser
                            .TableName = "Temp_tblAuxCusCtrlEO"
                            With .Columns
                                .Clear()
                                .Add("AuxEOID", countInfo + 1, SqlBuilder.SQLParserDataType.spNum)
                                .Add("AuxCustomControlID", info.ID, SqlBuilder.SQLParserDataType.spNum)
                                .Add("Sequence", info.EO(countInfo).Sequence)
                                .Add("Format", info.EO(countInfo).Format)
                                .Add("DateModification", DateTime.Now)
                                .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                .Add("ValueTypeChanged", "Insert")
                            End With
                            effectRow = .ExecuteInsert()
                        End With
                    Next countInfo
                End If
            End If
        End Sub

        Private Function checkAuxExists(ByVal row As DataRow, ByVal info As DataInfo.AuxCustomFieldInfo, ByVal Type As String) As Boolean
            Dim check As Boolean
            Dim countInfo As Integer
            If Type = "AuxValue" Then
                For countInfo = 0 To info.DropList.Count - 1
                    If row.Item("AuxCustomControlID").ToString() = info.ID AndAlso row.Item("Value").ToString() = info.DropList(countInfo) Then
                        check = True
                        Exit For
                    End If
                Next countInfo
            ElseIf Type = "AuxCmd" Then
                For countInfo = 0 To info.Command.Count - 1
                    If row.Item("AuxGDSCmdID").ToString() = countInfo + 1 AndAlso row.Item("AuxCustomControlID").ToString() = info.ID AndAlso row.Item("DataTypeID").ToString() = info.Command(countInfo).DataTypeID AndAlso row.Item("Format").ToString() = info.Command(countInfo).Format Then
                        check = True
                        Exit For
                    End If
                Next
            ElseIf Type = "AuxEO" Then
                For countInfo = 0 To info.EO.Count - 1
                    If row.Item("AuxEOID").ToString() = countInfo + 1 AndAlso row.Item("AuxCustomControlID").ToString() = info.ID AndAlso row.Item("Sequence").ToString() = info.EO(countInfo).Sequence AndAlso row.Item("Format").ToString() = info.EO(countInfo).Format Then
                        check = True
                        Exit For
                    End If
                Next countInfo
            End If
            Return check
        End Function

        Public Function GetAuxCustomIDByName(ByVal Name As String) As String
            Dim retVal As String
            Dim retObj As Object
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblAuxCusCtrl"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("ControlName", Name, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("AuxCustomControlID")
                End With
                retObj = .ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar, CommandType.Text)
                retVal = Util.DBNullToText(retObj)
            End With
            Return retVal
        End Function

        Public Function GetTempAuxCustom(Optional ByVal AuxCustomName As String = "", Optional ByVal dateFrom As String = "", Optional ByVal dateTo As String = "") As DataSet
            Dim ds As New DataSet

            Dim CtrlDT As DataTable
            Dim TempCtrlDT As DataTable
            Dim CtrlMasterDT As DataTable

            Dim CmdDT As DataTable
            Dim TempCmdDT As DataTable
            Dim CmdMasterDT As DataTable

            Dim ValueDT As DataTable
            Dim TempValueDT As DataTable
            Dim ValueMasterDT As DataTable

            Dim EODT As DataTable
            Dim TempEODT As DataTable
            Dim EOMasterDT As DataTable

            Dim ClientID As String = ""
            Dim TempTable As DataTable
            Dim CtrlIDArr(0) As String
            Dim count As Integer
            Dim count2 As Integer
            Dim foundRow() As DataRow
            CtrlIDArr(0) = "AuxCustomControlID"
            Dim AuxCustomeID As String = ""

            If AuxCustomName <> "" Then
                AuxCustomeID = GetAuxCustomIDByName(AuxCustomName)
            End If

            With Me.MySQLParser
                .TableName = "Temp_tblAuxCusCtrl"
                With .Columns
                    .Clear()
                    If AuxCustomName <> "" Then
                        .Add("ControlName", AuxCustomName, SqlBuilder.SQLParserDataType.spText, True)
                    End If
                    If dateFrom = dateTo Then
                        If dateFrom <> "" And dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:990"
                            .Add("DateModification", "convert(varchar,cast('" + dateFrom + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, ">")
                            .Add("DateModification", "convert(varchar,cast('" + dateTo + " 23:59:59:990" + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, "<")
                        End If
                    Else
                        If dateFrom <> "" Then
                            .Add("DateModification", dateFrom, SqlBuilder.SQLParserDataType.spDate, True, ">")
                        End If
                        If dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:999"
                            .Add("DateModification", dateTo + " 23:59:59:990", SqlBuilder.SQLParserDataType.spText, True, "<=")
                        End If
                    End If
                    .Add("*")
                End With
                TempCtrlDT = .ExecuteDataTable(.SQLSelect + " order by DateModification Desc")

                .TableName = "tblAuxCusCtrl"
                With .Columns
                    .Clear()
                    If AuxCustomName <> "" Then
                        .Add("ControlName", AuxCustomName, SqlBuilder.SQLParserDataType.spText, True)
                    End If
                    .Add("*")
                End With
                CtrlDT = .ExecuteDataTable()

                TempTable = TempCtrlDT.DefaultView.ToTable(True, CtrlIDArr)
                CtrlMasterDT = TempCtrlDT.Clone()
                For count = 0 To TempTable.Rows.Count - 1
                    foundRow = CtrlDT.Select("AuxCustomControlID='" + TempTable.Rows(count).Item("AuxCustomControlID").ToString() + "'")
                    If foundRow.Length > 0 Then
                        For count2 = 0 To foundRow.Length - 1
                            CtrlMasterDT.ImportRow(foundRow(count2))
                        Next count2
                    End If
                Next
                CtrlMasterDT.AcceptChanges()
                CtrlMasterDT.Merge(TempCtrlDT)
                CtrlMasterDT.TableName = "AuxCusCtrl"
                ds.Tables.Add(CtrlMasterDT)

                '//Cmd
                .TableName = "Temp_tblAuxCusCtrlCmd"
                With .Columns
                    .Clear()
                    If AuxCustomeID <> "" Then
                        .Add("AuxCustomControlID", AuxCustomeID, SqlBuilder.SQLParserDataType.spNum, True)
                    End If
                    If dateFrom = dateTo Then
                        If dateFrom <> "" And dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:990"
                            .Add("DateModification", "convert(varchar,cast('" + dateFrom + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, ">")
                            .Add("DateModification", "convert(varchar,cast('" + dateTo + " 23:59:59:990" + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, "<")
                        End If
                    Else
                        If dateFrom <> "" Then
                            .Add("DateModification", dateFrom, SqlBuilder.SQLParserDataType.spDate, True, ">")
                        End If
                        If dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:999"
                            .Add("DateModification", dateTo + " 23:59:59:990", SqlBuilder.SQLParserDataType.spText, True, "<=")
                        End If
                    End If
                    .Add("*")
                End With
                TempCmdDT = .ExecuteDataTable(.SQLSelect + " order by DateModification Desc")

                .TableName = "tblAuxCusCtrlCmd"
                With .Columns
                    .Clear()
                    If AuxCustomeID <> "" Then
                        .Add("AuxCustomControlID", AuxCustomeID, SqlBuilder.SQLParserDataType.spNum, True)
                    End If
                    .Add("*")
                End With
                CmdDT = .ExecuteDataTable()

                TempTable = TempCmdDT.DefaultView.ToTable(True, CtrlIDArr)
                CmdMasterDT = TempCmdDT.Clone()
                For count = 0 To TempTable.Rows.Count - 1
                    foundRow = CmdDT.Select("AuxCustomControlID='" + TempTable.Rows(count).Item("AuxCustomControlID").ToString() + "'")
                    If foundRow.Length > 0 Then
                        For count2 = 0 To foundRow.Length - 1
                            CmdMasterDT.ImportRow(foundRow(count2))
                        Next count2
                    End If
                Next
                CmdMasterDT.AcceptChanges()
                CmdMasterDT.Merge(TempCmdDT)
                CmdMasterDT.TableName = "AuxCusCtrlCmd"
                ds.Tables.Add(CmdMasterDT)

                '//Value
                .TableName = "Temp_tblAuxCusCtrlValue"
                With .Columns
                    .Clear()
                    If AuxCustomeID <> "" Then
                        .Add("AuxCustomControlID", AuxCustomeID, SqlBuilder.SQLParserDataType.spNum, True)
                    End If
                    If dateFrom = dateTo Then
                        If dateFrom <> "" And dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:990"
                            .Add("DateModification", "convert(varchar,cast('" + dateFrom + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, ">")
                            .Add("DateModification", "convert(varchar,cast('" + dateTo + " 23:59:59:990" + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, "<")
                        End If
                    Else
                        If dateFrom <> "" Then
                            .Add("DateModification", dateFrom, SqlBuilder.SQLParserDataType.spDate, True, ">")
                        End If
                        If dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:999"
                            .Add("DateModification", dateTo + " 23:59:59:990", SqlBuilder.SQLParserDataType.spText, True, "<=")
                        End If
                    End If
                    .Add("*")
                End With
                TempValueDT = .ExecuteDataTable(.SQLSelect + " order by DateModification Desc")

                .TableName = "tblAuxCusCtrlValue"
                With .Columns
                    .Clear()
                    If AuxCustomeID <> "" Then
                        .Add("AuxCustomControlID", AuxCustomeID, SqlBuilder.SQLParserDataType.spNum, True)
                    End If
                    .Add("*")
                End With
                ValueDT = .ExecuteDataTable()

                TempTable = TempValueDT.DefaultView.ToTable(True, CtrlIDArr)
                ValueMasterDT = TempValueDT.Clone()
                For count = 0 To TempTable.Rows.Count - 1
                    foundRow = ValueDT.Select("AuxCustomControlID='" + TempTable.Rows(count).Item("AuxCustomControlID").ToString() + "'")
                    If foundRow.Length > 0 Then
                        For count2 = 0 To foundRow.Length - 1
                            ValueMasterDT.ImportRow(foundRow(count2))
                        Next count2
                    End If
                Next
                ValueMasterDT.AcceptChanges()
                ValueMasterDT.Merge(TempValueDT)
                ValueMasterDT.TableName = "AuxCusCtrlValue"
                ds.Tables.Add(ValueMasterDT)

                '//EO
                .TableName = "Temp_tblAuxCusCtrlEO"
                With .Columns
                    .Clear()
                    If AuxCustomeID <> "" Then
                        .Add("AuxCustomControlID", AuxCustomeID, SqlBuilder.SQLParserDataType.spNum, True)
                    End If
                    If dateFrom = dateTo Then
                        If dateFrom <> "" And dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:990"
                            .Add("DateModification", "convert(varchar,cast('" + dateFrom + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, ">")
                            .Add("DateModification", "convert(varchar,cast('" + dateTo + " 23:59:59:990" + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, "<")
                        End If
                    Else
                        If dateFrom <> "" Then
                            .Add("DateModification", dateFrom, SqlBuilder.SQLParserDataType.spDate, True, ">")
                        End If
                        If dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:999"
                            .Add("DateModification", dateTo + " 23:59:59:990", SqlBuilder.SQLParserDataType.spText, True, "<=")
                        End If
                    End If
                    .Add("*")
                End With
                TempEODT = .ExecuteDataTable(.SQLSelect + " order by DateModification Desc")

                .TableName = "tblAuxCusCtrlEO"
                With .Columns
                    .Clear()
                    If AuxCustomeID <> "" Then
                        .Add("AuxCustomControlID", AuxCustomeID, SqlBuilder.SQLParserDataType.spNum, True)
                    End If
                    .Add("*")
                End With
                EODT = .ExecuteDataTable()

                TempTable = TempEODT.DefaultView.ToTable(True, CtrlIDArr)
                EOMasterDT = TempEODT.Clone()
                For count = 0 To TempTable.Rows.Count - 1
                    foundRow = EODT.Select("AuxCustomControlID='" + TempTable.Rows(count).Item("AuxCustomControlID").ToString() + "'")
                    If foundRow.Length > 0 Then
                        For count2 = 0 To foundRow.Length - 1
                            EOMasterDT.ImportRow(foundRow(count2))
                        Next count2
                    End If
                Next
                EOMasterDT.AcceptChanges()
                EOMasterDT.Merge(TempEODT)
                EOMasterDT.TableName = "AuxCusCtrlEO"
                ds.Tables.Add(EOMasterDT)
            End With
            Return ds
        End Function

    End Class

  
End Namespace







@


1.1.1.1
log
@no message
@
text
@@
