head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.23;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.23;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic

Namespace DataAccessLayer

    Public Class ClientRateDAL
        Inherits BaseDA

        Public Function GetClientRate(Optional ByVal ClientID As String = "", Optional ByVal HarpClienID As String = "", Optional ByVal isCWT As Boolean = False, Optional ByVal RateCodeID As String = "") As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblClientRateCode"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    If ClientID <> "" And HarpClienID <> "" And isCWT = False Then
                        .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        .Add("HarpClientID", HarpClienID, SqlBuilder.SQLParserDataType.spNum, True)
                        .Add("IsCWT", isCWT, SqlBuilder.SQLParserDataType.spBoolean, True)

                    ElseIf ClientID = "" And HarpClienID <> "" And isCWT = True Then
                        '.Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        .Add("RateCodeID", RateCodeID, SqlBuilder.SQLParserDataType.spNum, True)
                        .Add("IsCWT", isCWT, SqlBuilder.SQLParserDataType.spBoolean, True)

                    ElseIf ClientID = "" And isCWT = True Then
                        .Add("IsCWT", isCWT, SqlBuilder.SQLParserDataType.spBoolean, True)

                    ElseIf RateCodeID <> "" Then
                        .Add("RateCodeID", RateCodeID, SqlBuilder.SQLParserDataType.spNum, True)

                    ElseIf ClientID <> "" Then
                        .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)

                    ElseIf isCWT = False Then
                        .Add("IsCWT", isCWT, SqlBuilder.SQLParserDataType.spBoolean, True)
                    End If
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function


        Public Function GetGDS() As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = Util.StandardDB("tblGDS")
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    '.Add("AirlineCode", AirlineCode, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function


        Public Function GetClient(Optional ByVal ClientID As String = "") As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblClientMaster"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    If ClientID <> "" Then
                        .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spText, True)
                    End If
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetHarpClient(ByVal GDS As String) As DataTable
            Dim dt As DataTable
            Dim GDSStringCode As String = ""
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = Util.StandardDB("tblHotelRateCode")
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    'If GDS = "1" Then
                    '    GDSStringCode = "1G"
                    '    .Add("GDSID", GDSStringCode, SqlBuilder.SQLParserDataType.spText, True)
                    'ElseIf GDS = "2" Then
                    '    GDSStringCode = "AA"
                    '    .Add("GDSID", GDSStringCode, SqlBuilder.SQLParserDataType.spText, True)
                    'End If

                    Select Case (GDS)
                        Case "1"
                            GDSStringCode = "1G"
                        Case "2"
                            GDSStringCode = "AA"
                        Case "3"
                            GDSStringCode = "1A"
                    End Select
                    .Add("GDSID", GDSStringCode, SqlBuilder.SQLParserDataType.spText, True)

                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function FlitterHarpClientID(ByVal GDS As String, ByVal GDSRateCode As String)
            Dim dt As New DataTable
            Dim GDSStringCode As String = ""
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = Util.StandardDB("tblHotelRateCode")
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    'If GDS = "1" Then
                    '    GDSStringCode = "1G"
                    '    .Add("GDSID", GDSStringCode, SqlBuilder.SQLParserDataType.spText, True)
                    'ElseIf GDS = "2" Then
                    '    GDSStringCode = "AA"
                    '    .Add("GDSID", GDSStringCode, SqlBuilder.SQLParserDataType.spText, True)
                    'End If

                    Select Case (GDS)
                        Case "1"
                            GDSStringCode = "1G"
                        Case "2"
                            GDSStringCode = "AA"
                        Case "3"
                            GDSStringCode = "1A"
                    End Select
                    .Add("GDSID", GDSStringCode, SqlBuilder.SQLParserDataType.spText, True)


                    .Add("GDSRateCode", GDSRateCode, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("Distinct HarpClientName")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetGDSRateCodeByHarpClientName(ByVal GDSID As String) As DataTable
            Dim GDSStringCode As String = ""
            Dim dt As New DataTable

            With Me.MySQLParser
                .AutoParameter = False
                .TableName = Util.StandardDB("tblHotelRateCode")
                With .Columns
                    .Clear()
                    .IncludeKey = False

                    'If GDSID = "1" Then
                    '    GDSStringCode = "1G"
                    '    .Add("GDSID", GDSStringCode, SqlBuilder.SQLParserDataType.spText, True)
                    'ElseIf GDSID = "2" Then
                    '    GDSStringCode = "AA"
                    '    .Add("GDSID", GDSStringCode, SqlBuilder.SQLParserDataType.spText, True)
                    'End If

                    Select Case (GDSID)
                        Case "1"
                            GDSStringCode = "1G"
                        Case "2"
                            GDSStringCode = "AA"
                        Case "3"
                            GDSStringCode = "1A"
                    End Select
                    .Add("GDSID", GDSStringCode, SqlBuilder.SQLParserDataType.spText, True)


                    '.Add("HarpClientName", HarpClientName, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("Distinct GDSRateCode")
                End With
                dt = .ExecuteDataTable(.SQLSelect() + " Order By GDSRateCode ASC")
            End With
            Return dt
        End Function

        Public Function GetHarpRateCode(ByVal HarpClientName As String, ByVal GDSID As String, ByVal GDSRateCode As String)
            Dim dt As DataTable
            Dim GDSStringCode As String = ""
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = Util.StandardDB("tblHotelRateCode")
                With .Columns
                    .Clear()
                    .IncludeKey = False

                    'If GDSID = "1" Then
                    '    GDSStringCode = "1G"
                    '    .Add("GDSID", GDSStringCode, SqlBuilder.SQLParserDataType.spText, True)
                    'ElseIf GDSID = "2" Then
                    '    GDSStringCode = "AA"
                    '    .Add("GDSID", GDSStringCode, SqlBuilder.SQLParserDataType.spText, True)
                    'ElseIf GDSID = "2" Then
                    '    GDSStringCode = "1A"
                    '    .Add("GDSID", GDSStringCode, SqlBuilder.SQLParserDataType.spText, True)
                    'End If

                    Select Case (GDSID)
                        Case "1"
                            GDSStringCode = "1G"
                        Case "2"
                            GDSStringCode = "AA"
                        Case "3"
                            GDSStringCode = "1A"
                    End Select
                    .Add("GDSID", GDSStringCode, SqlBuilder.SQLParserDataType.spText, True)

                    .Add("HarpClientName", HarpClientName, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("GDSRateCode", GDSRateCode, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("Distinct HarpRateCode")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetHarpClientID(ByVal HarpClientName As String, ByVal HarpRateCode As String, ByVal GDSRateCode As String)
            Dim dt As New DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = Util.StandardDB("tblHotelRateCode")
                With .Columns
                    .Clear()
                    .IncludeKey = False
                    .Add("HarpClientName", HarpClientName, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("HarpRateCode", HarpRateCode, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("GDSRateCode", GDSRateCode, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("HarpClientID")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetRateInfoByHarpClientID(ByVal HarpClientID As String)
            Dim dt As New DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = Util.StandardDB("tblHotelRateCode")
                With .Columns
                    .Clear()
                    .IncludeKey = False
                    .Add("HarpClientID", HarpClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("HarpClientName,GDSRateCode,HarpRateCode")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetHarpClientNameByHarpClientID(ByVal HarpClientID As String)
            Dim dt As New DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = Util.StandardDB("tblHotelRateCode")
                With .Columns
                    .Clear()
                    .IncludeKey = False
                    .Add("HarpClientID", HarpClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("HarpClientName")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function InsertClientRate(ByVal info As DataInfo.ClientRateInfo()) As Integer
            Dim EffectRow As Integer
            Dim countRow As Integer
            Try
                For countRow = 0 To info.Length - 1
                    If info(countRow) IsNot Nothing AndAlso info(countRow).PageMode <> TransactionMode.ViewMode Then
                        With Me.MySQLParser
                            .OpenConnection()
                            .BeginTran()
                            .TableName = "tblClientRateCode"
                            With .Columns
                                .Clear()
                                If info(countRow).PageMode = CWTMasterDB.TransactionMode.UpdateMode Then
                                    .Add("RateCodeID", info(countRow).ID, SqlBuilder.SQLParserDataType.spNum, True)
                                End If
                                .Add("ClientID", info(countRow).ClientID, SqlBuilder.SQLParserDataType.spNum)
                                .Add("GDSID", info(countRow).GDSID, SqlBuilder.SQLParserDataType.spNum)
                                .Add("HarpClientID", info(countRow).HarpClientID, SqlBuilder.SQLParserDataType.spNum)
                                .Add("GDSRateCode", info(countRow).GDSRateCode, SqlBuilder.SQLParserDataType.spText)
                                .Add("HarpRateCode", info(countRow).HarpRateCode, SqlBuilder.SQLParserDataType.spText)
                                .Add("IsCWT", info(countRow).IsCWT, SqlBuilder.SQLParserDataType.spBoolean)
                                .Add("PNRField", info(countRow).PNRField, SqlBuilder.SQLParserDataType.spText)
                            End With
                            Select Case info(countRow).PageMode
                                Case CWTMasterDB.TransactionMode.AddNewMode
                                    EffectRow = .ExecuteInsert()
                                    info(countRow).ID = .GetLastIdentity
                                    CallProcedure(info(countRow).ID, "Insert", "sp_ClientRateCode")
                                Case CWTMasterDB.TransactionMode.UpdateMode
                                    CallProcedure(info(countRow).ID, "Update", "sp_ClientRateCode")
                                    EffectRow = .ExecuteUpdate()
                            End Select
                        End With
                    End If
                Next countRow
                
                If EffectRow > 0 Then
                    Me.MySQLParser.CommitTran()
                Else
                    Me.MySQLParser.RollbackTran()
                End If
            Catch ex As Exception
                EffectRow = -1
            End Try
            Return EffectRow

        End Function

        Public Function DeteleRateCode(ByVal RateCodeID As String) As Integer
            Dim EffectRow As Integer
            Try
                With Me.MySQLParser
                    .TableName = "tblClientRateCode"
                    With .Columns
                        .Clear()
                        .Add("RateCodeID", RateCodeID, SqlBuilder.SQLParserDataType.spNum, True)
                    End With
                    CallProcedure(RateCodeID, "Delete", "sp_ClientRateCode")
                    EffectRow = .ExecuteDelete()
                End With
            Catch ex As Exception
                EffectRow = -1
            End Try
            Return EffectRow
        End Function

        Private Sub CallProcedure(ByVal ID As String, ByVal Type As String, ByVal StoreProdType As String)
            With Me.MySQLParser
                .ExecuteStoreProcedure("exec " + StoreProdType + " '" + ID + "','" + ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName + "','" + Type + "'")
            End With
        End Sub


        Public Function SearchClientRate(ByVal groupName As String, ByVal ClientNum As String, ByVal ClientName As String, ByVal IsCWT As Boolean) As DataTable
            Dim dt As DataTable = Nothing
            Dim oSql As String
            Dim whereStatement As String = ""

            'If groupName <> "" Then
            '    whereStatement = "where GroupName=" + CWTMasterDB.Util.LimitTheString(groupName) + " "
            'End If
            If String.IsNullOrEmpty(groupName) = False Then whereStatement = whereStatement & IIf(whereStatement <> "", " or ", "Where ") & "GroupName LIKE '%" & groupName.Trim & "%'"
            If String.IsNullOrEmpty(ClientNum) = False Then whereStatement = whereStatement & IIf(whereStatement <> "", " or ", "Where ") & "ClientNumber = '" & ClientNum.Trim & "'"
            If String.IsNullOrEmpty(ClientName) = False Then whereStatement = whereStatement & IIf(whereStatement <> "", " or ", "Where ") & "Name LIKE '%" & ClientName.Trim & "%'"

            oSql = "Select TBL.ClientID,TBL.GroupName, TBL.Name, TBL.ClientNumber, SUM(TBL.hotelCount) as hotelCount From("
            oSql = oSql & "Select Distinct r.ClientID as ClientID, r.GroupName, r.Name, r.ClientNumber, 0 as hotelCount "
            oSql = oSql & "from tblClientMaster r "
            oSql = oSql & "union all "
            oSql = oSql & "Select c.ClientID as ClientID, r.GroupName, r.Name, r.ClientNumber,Count(*) as hotelCount "
            oSql = oSql & "from tblClientRateCode c Inner Join tblClientMaster r "
            oSql = oSql & "on c.ClientID = r.ClientID "
            oSql = oSql & "Where c.IsCWT=0 "
            oSql = oSql & "Group by c.ClientID, r.GroupName, r.Name, r.ClientNumber "
            oSql = oSql & ")as TBL  "

            oSql = oSql & whereStatement

            oSql = oSql & " Group BY TBL.ClientID, TBL.GroupName, TBL.Name, TBL.ClientNumber"
            dt = Me.MySQLParser.ExecuteDataTable(oSql)
            Return dt
        End Function

        Public Function SearchClientRate2() As DataTable
            Dim dt As DataTable = Nothing
            Dim oSql As String
            Dim whereStatement As String = ""

            'If groupName <> "" Then
            '    whereStatement = "where GroupName=" + CWTMasterDB.Util.LimitTheString(groupName) + " "
            'End If
            'If String.IsNullOrEmpty(groupName) = False Then whereStatement = whereStatement & IIf(whereStatement <> "", " or ", "Where ") & "GroupName LIKE '%" & groupName.Trim & "%'"
            'If String.IsNullOrEmpty(ClientNum) = False Then whereStatement = whereStatement & IIf(whereStatement <> "", " or ", "Where ") & "ClientNumber = '" & ClientNum.Trim & "'"
            'If String.IsNullOrEmpty(ClientName) = False Then whereStatement = whereStatement & IIf(whereStatement <> "", " or ", "Where ") & "Name LIKE '%" & ClientName.Trim & "%'"

            oSql = "Select count(*) as hotelCount,0 as ClientID " & _
                    "from tblClientRateCode " & _
                    "where isCWT =1 " & _
                    "Group by ClientID"

            dt = Me.MySQLParser.ExecuteDataTable(oSql)
            Return dt
        End Function

        Public Function GetClientIDByName(ByVal ClientName As String) As String
            Dim retVal As String
            Dim retObj As Object
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblClientMaster"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("Name", ClientName, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("ClientID")
                End With
                retObj = .ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar, CommandType.Text)
                retVal = Util.DBNullToText(retObj)
            End With
            Return retVal
        End Function

        Public Function GetTempClientRateCode(Optional ByVal ClientName As String = "", Optional ByVal dateFrom As String = "", Optional ByVal dateTo As String = "") As DataSet
            '//Client Rate DT
            Dim RateDT As DataTable
            Dim TempRateDT As DataTable
            Dim RateMasterDT As DataTable

            Dim ClientID As String = ""
            Dim TempTable As DataTable
            Dim ClientIDArr(0) As String
            Dim count As Integer
            Dim count2 As Integer
            Dim ds As New DataSet
            Dim foundRow() As DataRow

            '//Get ClientID 
            If ClientName <> "" And ClientName <> "isCWT" Then
                ClientID = GetClientIDByName(ClientName)
            End If

            With Me.MySQLParser
                .TableName = "Temp_tblClientRateCode c inner join" + Util.StandardDB("tblHotelRateCode") + " h on c.HarpClientID=h.HarpClientID"
                With .Columns
                    .Clear()
                    If ClientName <> "" Then
                        If ClientID <> "" Then
                            .Add("c.ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        ElseIf ClientName = "Yes" Then
                            .Add("c.isCWT", "True", SqlBuilder.SQLParserDataType.spBoolean, True)
                        Else
                            .Add("c.ClientID", "-1", SqlBuilder.SQLParserDataType.spNum, True)
                        End If
                    End If
                   
                    If dateFrom = dateTo Then
                        If dateFrom <> "" And dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:990"
                            .Add("c.DateModification", "convert(varchar,cast('" + dateFrom + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, ">")
                            .Add("c.DateModification", "convert(varchar,cast('" + dateTo + " 23:59:59:990" + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, "<")
                        End If
                    Else
                        If dateFrom <> "" Then
                            .Add("c.DateModification", dateFrom, SqlBuilder.SQLParserDataType.spDate, True, ">")
                        End If
                        If dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:999"
                            .Add("c.DateModification", dateTo + " 23:59:59:990", SqlBuilder.SQLParserDataType.spText, True, "<=")
                        End If
                    End If
                    .Add("c.RateCodeID,c.ClientID,case when c.GDSID=1 then 'Galileo' when c.GDSID=2 then 'Sabre' when c.GDSID=3 then 'Amendues' End as GDSName,h.HarpClientName,c.GDSRateCode,c.HarpRateCode,c.IsCWT,c.PNRField,c.DateModification,c.UserName,c.ValueTypeChanged")
                End With
                TempRateDT = .ExecuteDataTable(.SQLSelect + " order by DateModification Desc")

                .TableName = "tblClientRateCode c inner join" + Util.StandardDB("tblHotelRateCode") + " h on c.HarpClientID=h.HarpClientID"
                With .Columns
                    .Clear()
                    If ClientName <> "" Then
                        If ClientID <> "" Then
                            .Add("c.ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        ElseIf ClientName = "Yes" Then
                            .Add("c.isCWT", "True", SqlBuilder.SQLParserDataType.spBoolean, True)
                        Else
                            .Add("c.ClientID", "-1", SqlBuilder.SQLParserDataType.spNum, True)
                        End If
                    End If
                    .Add("c.RateCodeID,c.ClientID,case when c.GDSID=1 then 'Galileo' when c.GDSID=2 then 'Sabre' when c.GDSID=3 then 'Amendues' End as GDSName,h.HarpClientName,c.GDSRateCode,c.HarpRateCode,c.IsCWT,c.PNRField")
                End With
                RateDT = .ExecuteDataTable()

                If ClientID <> "" Then
                    ClientIDArr(0) = "ClientID"
                Else
                    ClientIDArr(0) = "RateCodeID"
                End If

                TempTable = TempRateDT.DefaultView.ToTable(True, ClientIDArr)
                RateMasterDT = TempRateDT.Clone()
                For count = 0 To TempTable.Rows.Count - 1
                    If ClientID <> "" Then
                        foundRow = RateDT.Select("ClientID='" + TempTable.Rows(count).Item("ClientID").ToString() + "'")
                    Else
                        foundRow = RateDT.Select("RateCodeID='" + TempTable.Rows(count).Item("RateCodeID").ToString() + "'")
                    End If
                    If foundRow.Length > 0 Then
                        For count2 = 0 To foundRow.Length - 1
                            RateMasterDT.ImportRow(foundRow(count2))
                        Next count2
                    End If
                Next
                RateMasterDT.AcceptChanges()
                RateMasterDT.Merge(TempRateDT)
                RateMasterDT.TableName = "Rate"
                ds.Tables.Add(RateMasterDT)
            End With
            Return ds
        End Function

    End Class
End Namespace
'@


1.1.1.1
log
@no message
@
text
@@
