head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.24;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.24;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic
Imports System.Collections.Generic

Namespace DataAccessLayer
    Public Class SupplierAirRuleDAL
        Inherits BaseDA
        Private AirInsertID As ArrayList

        Public Function GetCCList(ByVal AirlineCode As String, ByVal CCType As String) As DataTable
            Dim dt As DataTable
            Dim oSql As String = ""
            oSql = "select CCCode,CCDescription,CCCount from" + _
                    "(select *," + _
                    "(select count(*) from tblAirlineCC where airlinecode=" + Util.LimitTheString(AirlineCode) + _
                    " and CCType=" + Util.LimitTheString(CCType) + " and CCVendorCode=p.CCCode) as CCCount" + _
                    " from " + Util.StandardDB("tblPaymentType") + " p" + _
                    " where CCCode<>'IN'" + _
                    ") as CCList order by CCDescription"
            dt = Me.MySQLParser.ExecuteDataTable(oSql)
            Return dt
        End Function

        Public Function GetAirlineRuleByCode(ByVal AirlineCode As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblAirlineRule"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("AirlineCode", AirlineCode, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetAirlineByCode(ByVal AirlineCode As String) As String
            Dim retVal As String
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = CWTMasterDB.Util.StandardDB("tblAirlines")
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("AirlineCode", AirlineCode, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("AirlineDescription")
                End With
                retVal = .ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar).ToString
            End With
            Return retVal
        End Function

        Public Function GetAirComByCode(ByVal AirlineCode As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblAirlineCommission"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("AirlineCode", AirlineCode, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetRegionByID(ByVal RegionCode As String) As String
            Dim retVal As String
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = CWTMasterDB.Util.StandardDB("tblRegion")
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    If RegionCode <> "X" Then
                        .Add("RegionCode", RegionCode, SqlBuilder.SQLParserDataType.spText, True)
                        .Add("Description")
                    Else
                        .Add("*")
                        '.Add("Description")
                    End If
                   
                End With
                retVal = .ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar).ToString
            End With
            Return retVal
        End Function

        Public Function GetCountryByID(ByVal CountryCode As String) As String
            Dim retVal As String
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = CWTMasterDB.Util.StandardDB("tblCountry")
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("CountryCode", CountryCode, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("CountryName")
                End With
                retVal = .ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar).ToString
            End With
            Return retVal
        End Function

        Public Function GetCityByID(ByVal CityCode As String) As String
            Dim retVal As String
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = CWTMasterDB.Util.StandardDB("tblCity")
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("CityCode", CityCode, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("City")
                End With
                retVal = .ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar).ToString
            End With
            Return retVal
        End Function


        Public Function GetRegionByCountry(ByVal CountryCode As String) As String
            Dim retVal As String
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = CWTMasterDB.Util.StandardDB("tblCity")
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("CountryCode", CountryCode, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("RegionCode")
                End With
                retVal = .ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar).ToString
            End With
            Return retVal
        End Function

        Public Function GetRegionByCity(ByVal CityCode As String) As String
            Dim retVal As String
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = CWTMasterDB.Util.StandardDB("tblCity")
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("CityCode", CityCode, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("RegionCode")
                End With
                retVal = .ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar).ToString
            End With
            Return retVal
        End Function

        Public Function GetCountryByCity(ByVal CityCode As String) As String
            Dim retVal As String
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = CWTMasterDB.Util.StandardDB("tblCity")
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("CityCode", CityCode, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("CountryCode")
                End With
                retVal = .ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar).ToString
            End With
            Return retVal
        End Function

        Public Function GetAirlineCCDetail(ByVal AirlineCode As String, ByVal TabType As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblAirlineCC"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("AirlineCode", AirlineCode, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("TabType", TabType, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetAirlineCCDetail2(ByVal AirlineCode As String, ByVal TabType As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblAirlineCC"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("AirlineCode", AirlineCode, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("TabType", TabType, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("DISTINCT ClientID")

                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function


        Public Function GetClient() As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .TableName = "tblClientMaster"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("*")
                End With
                dt = .ExecuteDataTable(.SQLSelect() + " order by ClientID")
            End With
            Return dt
        End Function

        Public Function FindMatchRecords(ByVal ID As String, ByVal info As DataInfo.SupplierAirComInfo, ByVal oDataTable As DataTable)
            Dim count2 As Integer
            Dim bool As Boolean = False
            For count2 = 0 To oDataTable.Rows.Count - 1
                With info
                    If .AirCommID = oDataTable.Rows(count2).Item("AirCommID") Then
                        bool = True
                        Return bool
                    End If
                End With
            Next
            Return bool
        End Function

        Public Function FindDeleteRecord(ByVal ID As String, ByVal info As DataInfo.SupplierAirRuleInfo)
            Dim bool As Boolean
            Dim count As Integer
            If info.Items.Count > 0 Then
                For count = 0 To info.Items.Count - 1
                    If ID = info.Items(count).AirCommID Then
                        bool = True
                        Exit For
                    End If
                Next
            Else
                bool = False
            End If
            Return bool
        End Function
        Public Function GetAirCommission() As Integer
            Dim returnID As Integer
            Dim ID As DataTable
            With Me.MySQLParser
                .TableName = "tblAirlineCommission"
                With .Columns
                    .Clear()
                    .Add("max(AirCommID)")
                End With
                ID = .ExecuteDataTable()
            End With
            If ID.Rows.Count > 0 Then
                returnID = ID.Rows(0).Item(0)
            Else
                returnID = 0
            End If
            Return returnID
        End Function

        Public Sub CallProcedure(ByVal AirCommID As String, ByVal Type As String)
            With Me.MySQLParser
                .OpenConnection()
                .BeginTran()
                .ExecuteStoreProcedure("exec sp_AirlineCommission '" + AirCommID + "','" + ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName + "','" + Type + "'")
                .CommitTran()
            End With
        End Sub

        Public Sub CallProcedure2(ByVal AirRuleCode As String, ByVal Type As String)
            With Me.MySQLParser
                .OpenConnection()
                .BeginTran()
                .ExecuteStoreProcedure("exec sp_AirlineRule '" + AirRuleCode + "','" + ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName + "','" + Type + "'")
                .CommitTran()
            End With
        End Sub

        Public Sub FlitterAirComm(ByVal info As DataInfo.SupplierAirRuleInfo)
            Dim oDataTable As DataTable
            Dim count As Integer
            Dim count2 As Integer
            Dim CommID As Integer = 0
            Dim boolChk As Boolean
            Dim boolChk2 As Boolean
            AirInsertID = New ArrayList()
            CommID = 0
            Try
                With Me.MySQLParser
                    .TableName = "tblAirlineCommission"
                    With .Columns
                        .Clear()
                        .IncludeKey = False
                        .Add("AirlineCode", info.AirlineCode, SqlBuilder.SQLParserDataType.spText, True)
                        .Add("*")
                    End With
                    oDataTable = .ExecuteDataTable()
                End With

                CommID = GetAirCommission()
                If info.Items.Count > 0 Then
                    For count = 0 To info.Items.Count - 1
                        For count2 = 0 To oDataTable.Rows.Count - 1
                            With info
                                boolChk = Me.FindMatchRecords(info.AirlineCode, info.Items(count), oDataTable)
                                If boolChk And oDataTable.Rows(count2).Item("AirCommID") = info.Items(count).AirCommID Then

                                    If oDataTable.Rows(count2).Item(0).ToString <> .AirlineCode Or oDataTable.Rows(count2).Item("Origin").ToString() <> .Items(count).Origin Or oDataTable.Rows(count2).Item("Destination").ToString() <> .Items(count).Destination Or oDataTable.Rows(count2).Item("OriginType").ToString() <> .Items(count).OriginType Or oDataTable.Rows(count2).Item("DestType").ToString() <> .Items(count).DestinationType Or oDataTable.Rows(count2).Item("Amt").ToString() <> .Items(count).Amount.ToString("f2") Or oDataTable.Rows(count2).Item("FareType").ToString() <> .Items(count).FareType Then
                                        Me.CallProcedure(info.Items(count).AirCommID, "Update")
                                    End If
                                    Exit For
                                ElseIf boolChk = False And .Items(count).AirCommID <> "" Then
                                    CommID = CommID + 1
                                    info.Items(count).AirCommID = CommID
                                    AirInsertID.Add(CommID)
                                    Exit For
                                End If
                            End With
                        Next

                    Next
                End If

                For count = 0 To oDataTable.Rows.Count - 1
                    boolChk2 = Me.FindDeleteRecord(oDataTable.Rows(count).Item("AirCommID"), info)
                    If boolChk2 = False Then
                        Me.CallProcedure(oDataTable.Rows(count).Item("AirCommID"), "Delete")
                    End If
                Next
            Catch ex As Exception

            End Try

        End Sub

        Public Sub FlitterAirRule(ByVal info As DataInfo.SupplierAirRuleInfo)
            Dim oDataTable As New DataTable
            Try
                With Me.MySQLParser
                    .OpenConnection()
                    .BeginTran()
                    .TableName = "tblAirlineRule"
                    With .Columns
                        .Clear()
                        .IncludeKey = False
                        .Add("AirlineCode", info.AirlineCode, SqlBuilder.SQLParserDataType.spText, True)
                        .Add("*")
                    End With
                    oDataTable = .ExecuteDataTable(.SQLSelect())
                End With
            Catch ex As Exception

            Finally
                Me.MySQLParser.CloseConnection()
            End Try

            If oDataTable.Rows.Count > 0 Then
                If oDataTable.Rows(0).Item("FuelCharge") <> info.SupplierAirCC.FuelCharge Or oDataTable.Rows(0).Item("SkipAquaWaitlist") <> info.SupplierAirCC.SkipAqua Or oDataTable.Rows(0).Item("IncludeYQComm") <> info.SupplierAirCC.IncludeYQComm Then
                    CallProcedure2(info.AirlineCode, "Update")
                End If
            Else
                CallProcedure2(info.AirlineCode, "Insert")
            End If


        End Sub

        Public Sub FiltterAirlineCC(ByVal info As DataInfo.SupplierAirRuleInfo)
            Dim oDataTable As DataTable = New DataTable
            Dim countDT As Integer
            Try
                With Me.MySQLParser
                    .OpenConnection()
                    .BeginTran()
                    .TableName = "tblAirlineCC"
                    With .Columns
                        .Clear()
                        .IncludeKey = False
                        .Add("AirlineCode", info.AirlineCode, SqlBuilder.SQLParserDataType.spText, True)
                        .Add("*")
                    End With
                    oDataTable = .ExecuteDataTable(.SQLSelect())
                End With

            Catch ex As Exception

            Finally
                Me.MySQLParser.CloseConnection()
            End Try

            For countDT = 0 To oDataTable.Rows.Count - 1
                'UATP
                If oDataTable.Rows(countDT).Item("TabType") = "TabPanelCWT" Then
                    If oDataTable.Rows(countDT).Item("CCType") = "UATP" Then
                        If oDataTable.Rows(countDT).Item("CCVendorCode") = "AX" Then
                            If oDataTable.Rows(countDT).Item("PassthroughType") <> info.AxTypePassThroughUATP Or oDataTable.Rows(countDT).Item("Remark").ToString() <> info.AxRemarkUATP Then
                                InsertRecordToTempDT(oDataTable.Rows(countDT), False)
                            End If
                        ElseIf oDataTable.Rows(countDT).Item("CCVendorCode") = "DC" Then
                            If oDataTable.Rows(countDT).Item("PassthroughType") <> info.DCTypePassThroughUATP Or oDataTable.Rows(countDT).Item("Remark").ToString() <> info.DCRemarkUATP Then
                                InsertRecordToTempDT(oDataTable.Rows(countDT), False)
                            End If
                        ElseIf oDataTable.Rows(countDT).Item("CCVendorCode") = "TP" Then
                            If oDataTable.Rows(countDT).Item("PassthroughType") <> info.TPTypePassThroughUATP Or oDataTable.Rows(countDT).Item("Remark").ToString() <> info.TPRemarkUATP Then
                                InsertRecordToTempDT(oDataTable.Rows(countDT), False)
                            End If
                        ElseIf oDataTable.Rows(countDT).Item("CCVendorCode") = "CA" Then
                            If oDataTable.Rows(countDT).Item("PassthroughType") <> info.CATypePassThroughUATP Or oDataTable.Rows(countDT).Item("Remark").ToString() <> info.CARemarkUATP Then
                                InsertRecordToTempDT(oDataTable.Rows(countDT), False)
                            End If
                        ElseIf oDataTable.Rows(countDT).Item("CCVendorCode") = "VI" Then
                            If oDataTable.Rows(countDT).Item("PassthroughType") <> info.VITypePassThroughUATP Or oDataTable.Rows(countDT).Item("Remark").ToString() <> info.VIRemarkUATP Then
                                InsertRecordToTempDT(oDataTable.Rows(countDT), False)
                            End If
                        End If
                        'NRCC Part
                    ElseIf oDataTable.Rows(countDT).Item("CCType") = "NRCC" Then
                        If oDataTable.Rows(countDT).Item("CCVendorCode") = "AX" Then
                            If oDataTable.Rows(countDT).Item("PassthroughType") <> info.AxTypePassThroughNRCC Or oDataTable.Rows(countDT).Item("Remark").ToString() <> info.AxRemarkNRCC Then
                                InsertRecordToTempDT(oDataTable.Rows(countDT), False)
                            End If
                        ElseIf oDataTable.Rows(countDT).Item("CCVendorCode") = "DC" Then
                            If oDataTable.Rows(countDT).Item("PassthroughType") <> info.DCTypePassThroughNRCC Or oDataTable.Rows(countDT).Item("Remark").ToString() <> info.DCRemarkNRCC Then
                                InsertRecordToTempDT(oDataTable.Rows(countDT), False)
                            End If
                        ElseIf oDataTable.Rows(countDT).Item("CCVendorCode") = "TP" Then
                            If oDataTable.Rows(countDT).Item("PassthroughType") <> info.TPTypePassThroughNRCC Or oDataTable.Rows(countDT).Item("Remark").ToString() <> info.TPRemarkNRCC Then
                                InsertRecordToTempDT(oDataTable.Rows(countDT), False)
                            End If
                        ElseIf oDataTable.Rows(countDT).Item("CCVendorCode") = "CA" Then
                            If oDataTable.Rows(countDT).Item("PassthroughType") <> info.CATypePassThroughNRCC Or oDataTable.Rows(countDT).Item("Remark").ToString() <> info.CARemarkNRCC Then
                                InsertRecordToTempDT(oDataTable.Rows(countDT), False)
                            End If
                        ElseIf oDataTable.Rows(countDT).Item("CCVendorCode") = "VI" Then
                            If oDataTable.Rows(countDT).Item("PassthroughType") <> info.VITypePassThroughNRCC Or oDataTable.Rows(countDT).Item("Remark").ToString() <> info.VIRemarkNRCC Then
                                InsertRecordToTempDT(oDataTable.Rows(countDT), False)
                            End If
                        End If
                    End If

                ElseIf oDataTable.Rows(countDT).Item("TabType") = "TabPanelClient" Then
                    If CheckClientIDCC(oDataTable.Rows(countDT), info) = True Then
                        If CheckClientCC(oDataTable.Rows(countDT), info) = False Then
                            InsertRecordToTempDT(oDataTable.Rows(countDT), True)
                        End If
                    Else 'delete
                        InsertRecordToTempDT(oDataTable.Rows(countDT), True, True)
                    End If
                End If
            Next countDT

            For countInfo As Integer = 0 To info.ClientItem.Count - 1
                If CheckCllientIDInfoCC(oDataTable, info.ClientItem(countInfo).CL_ClientID) = False Then
                    InsertRecordInfoToTempDT(info.AirlineCode, info.ClientItem(countInfo).TabTypeCL, info.ClientItem(countInfo).CCType, info.ClientItem(countInfo).passThrough, info.ClientItem(countInfo).vendorCode, info.ClientItem(countInfo).RemarkID, info.ClientItem(countInfo).CL_ClientID)
                End If
            Next countInfo
        End Sub

        Public Function CheckClientCC(ByVal row As DataRow, ByVal info As DataInfo.SupplierAirRuleInfo) As Boolean
            Dim checkMatch As Boolean = False
            Dim countInfo As Integer

            For countInfo = 0 To info.ClientItem.Count - 1
                If row.Item("CCType").ToString() = info.ClientItem.Item(countInfo).CCType And row.Item("PassthroughType").ToString() = info.ClientItem.Item(countInfo).passThrough And row.Item("CCVendorCode").ToString() = info.ClientItem.Item(countInfo).vendorCode Then
                    checkMatch = True
                    Exit For
                End If
            Next countInfo
            Return checkMatch
        End Function

        Public Function CheckCllientIDInfoCC(ByVal dtCC As DataTable, ByVal ClientID As String) As Boolean
            Dim checkMatch As Boolean = False
            Dim countDT As Integer

            For countDT = 0 To dtCC.Rows.Count - 1
                If dtCC.Rows(countDT).Item("ClientID").ToString() = ClientID Then
                    checkMatch = True
                    Exit For
                End If
            Next countDT

            Return checkMatch
        End Function

        Public Function CheckClientIDCC(ByVal row As DataRow, ByVal info As DataInfo.SupplierAirRuleInfo) As Boolean
            Dim checkMatch As Boolean = False
            Dim countInfo As Integer

            For countInfo = 0 To info.ClientItem.Count - 1
                If row.Item("ClientID") = info.ClientItem.Item(countInfo).CL_ClientID Then
                    checkMatch = True
                    Exit For
                End If
            Next countInfo
            Return checkMatch
        End Function
        Public Sub InsertRecordToTempDT(ByVal row As DataRow, ByVal ClientData As Boolean, Optional ByVal delete As Boolean = False)
            Dim EffectRow As Integer
            Try
                With Me.MySQLParser
                    .OpenConnection()
                    .BeginTran()
                    .TableName = "Temp_tblAirlineCC"
                    With .Columns
                        .Clear()
                        '.Add("ID", row.Item(0).ToString(), SqlBuilder.SQLParserDataType.spNum)
                        .Add("AirlineCode", row.Item(1).ToString(), SqlBuilder.SQLParserDataType.spText)
                        .Add("TabType", row.Item(2).ToString(), SqlBuilder.SQLParserDataType.spText)
                        .Add("CCType", row.Item(3).ToString(), SqlBuilder.SQLParserDataType.spText)
                        .Add("PassthroughType", row.Item(4).ToString(), SqlBuilder.SQLParserDataType.spText)
                        .Add("CCVendorCode", row.Item(5).ToString(), SqlBuilder.SQLParserDataType.spText)
                        .Add("Remark", row.Item(6).ToString(), SqlBuilder.SQLParserDataType.spText)

                        If ClientData Then
                            .Add("ClientID", row.Item(7), SqlBuilder.SQLParserDataType.spNum)
                        End If
                        .Add("DateModification", DateTime.Now)
                        .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                        If delete Then
                            .Add("ValueTypeChanged", "Delete")
                        Else
                            .Add("ValueTypeChanged", "Update")
                        End If

                    End With
                    EffectRow = .ExecuteInsert()
                End With

                If EffectRow > 0 Then
                    Me.MySQLParser.CommitTran()
                Else
                    Me.MySQLParser.RollbackTran()
                End If


            Catch ex As Exception
                Me.MySQLParser.RollbackTran()
            Finally
                Me.MySQLParser.CloseConnection()
            End Try
        End Sub

        Public Sub InsertRecordInfoToTempDT(ByVal ACode As String, ByVal TabType As String, ByVal CCType As String, ByVal PassThru As String, ByVal CCVendor As String, ByVal Remark As String, ByVal ClientID As String)
            Dim EffectRow As Integer
            Try
                With Me.MySQLParser
                    .OpenConnection()
                    .BeginTran()
                    .TableName = "Temp_tblAirlineCC"
                    With .Columns
                        .Clear()
                        .Add("AirlineCode", ACode, SqlBuilder.SQLParserDataType.spText)
                        .Add("TabType", TabType, SqlBuilder.SQLParserDataType.spText)
                        .Add("CCType", CCType, SqlBuilder.SQLParserDataType.spText)
                        .Add("PassthroughType", PassThru, SqlBuilder.SQLParserDataType.spText)
                        .Add("CCVendorCode", CCVendor, SqlBuilder.SQLParserDataType.spText)
                        .Add("Remark", Remark, SqlBuilder.SQLParserDataType.spText)
                        .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum)
                        .Add("DateModification", DateTime.Now)
                        .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                        .Add("ValueTypeChanged", "Insert")
                    End With
                    EffectRow = .ExecuteInsert()
                End With

                If EffectRow > 0 Then
                    Me.MySQLParser.CommitTran()
                Else
                    Me.MySQLParser.RollbackTran()
                End If


            Catch ex As Exception
                Me.MySQLParser.RollbackTran()
            Finally
                Me.MySQLParser.CloseConnection()
            End Try
        End Sub

        Public Sub InsertNewRecord()
            Dim count As Integer
            If AirInsertID.Count > 0 Then
                For count = 0 To AirInsertID.Count - 1
                    Me.CallProcedure(AirInsertID(count), "Insert")
                Next
            End If
        End Sub

        Public Function UpdateAirRule(ByVal info As DataInfo.SupplierAirRuleInfo, ByVal chkClientData As Boolean) As Integer
            Dim EffectRow As Integer = 1
            Dim tempObj As Object
            Dim RecordCount As Integer
            FlitterAirComm(info)
            FlitterAirRule(info)
            FiltterAirlineCC(info)
            Try
                With Me.MySQLParser
                    .OpenConnection()
                    .BeginTran()
                    .TableName = "tblAirlineRule"
                    With .Columns
                        .Clear()
                        .Add("AirlineCode", info.AirlineCode, SqlBuilder.SQLParserDataType.spText, True)
                        .Add("count(*) as RecordCount")
                    End With
                    tempObj = .ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar, CommandType.Text)
                    RecordCount = Util.DBNullToZero(tempObj)
                    If RecordCount > 0 Then
                        info.PageMode = TransactionMode.UpdateMode
                        '//
                        .TableName = "tblAirlineCommission"
                        With .Columns
                            .Clear()
                            .Add("AirlineCode", info.AirlineCode, SqlBuilder.SQLParserDataType.spText, True)
                        End With
                        .ExecuteDelete()
                        '//
                        .TableName = "tblAirlineCC"
                        With .Columns
                            .Clear()
                            .Add("AirlineCode", info.AirlineCode, SqlBuilder.SQLParserDataType.spText, True)
                        End With
                        .ExecuteDelete()
                    Else
                        info.PageMode = TransactionMode.AddNewMode
                    End If
                    '//
                    .TableName = "tblAirlineRule"
                    With .Columns
                        .Clear()
                        .Add("AirlineCode", info.AirlineCode, SqlBuilder.SQLParserDataType.spText, (info.PageMode = TransactionMode.UpdateMode))
                        .Add("FuelCharge", info.SupplierAirCC.FuelCharge, SqlBuilder.SQLParserDataType.spNum)
                        .Add("SkipAquaWaitlist", info.SupplierAirCC.SkipAqua, SqlBuilder.SQLParserDataType.spBoolean)
                        .Add("IncludeYQComm", info.SupplierAirCC.IncludeYQComm, SqlBuilder.SQLParserDataType.spBoolean)
                    End With
                    If info.PageMode = TransactionMode.AddNewMode Then
                        EffectRow = .ExecuteInsert()
                    Else
                        EffectRow = .ExecuteUpdate()
                    End If
                    '//
                    'If EffectRow > 0 Then
                    '    .TableName = "tblAirlineCC"
                    '    For i As Integer = 0 To info.SupplierAirCC.PUBFareCards.Count - 1
                    '        With .Columns
                    '            .Clear()
                    '            .Add("AirlineCode", info.AirlineCode)
                    '            .Add("CCType", "NRCC")
                    '            .Add("CCVendorCode", info.SupplierAirCC.PUBFareCards(i))
                    '        End With
                    '        EffectRow = .ExecuteInsert()
                    '        If EffectRow <= 0 Then
                    '            Exit For
                    '        End If
                    '    Next
                    'End If
                    'If EffectRow > 0 Then
                    '    For i As Integer = 0 To info.SupplierAirCC.SpecialFareCards.Count - 1
                    '        With .Columns
                    '            .Clear()
                    '            .Add("AirlineCode", info.AirlineCode)
                    '            .Add("CCType", "BSP")
                    '            .Add("CCVendorCode", info.SupplierAirCC.SpecialFareCards(i))
                    '        End With
                    '        EffectRow = .ExecuteInsert()
                    '        If EffectRow <= 0 Then
                    '            Exit For
                    '        End If
                    '    Next
                    'End If
                    'If EffectRow > 0 Then
                    '    For i As Integer = 0 To info.SupplierAirCC.CCCFCards.Count - 1
                    '        With .Columns
                    '            .Clear()
                    '            .Add("AirlineCode", info.AirlineCode)
                    '            .Add("CCType", "CCCF")
                    '            .Add("CCVendorCode", info.SupplierAirCC.CCCFCards(i))
                    '        End With
                    '        EffectRow = .ExecuteInsert()
                    '        If EffectRow <= 0 Then
                    '            Exit For
                    '        End 
                    '    Next
                    'End If

                    If chkClientData = True Then
                        If EffectRow > 0 Then
                            .TableName = "tblAirlineCC"
                            For i As Integer = 0 To info.ClientItem.Count - 1
                                With .Columns
                                    .Clear()
                                    .Add("AirlineCode", info.AirlineCode, SqlBuilder.SQLParserDataType.spText)
                                    .Add("TabType", info.ClientItem.Item(i).TabTypeCL, SqlBuilder.SQLParserDataType.spText)
                                    .Add("CCType", info.ClientItem.Item(i).CCType, SqlBuilder.SQLParserDataType.spText)
                                    .Add("PassthroughType", info.ClientItem.Item(i).passThrough, SqlBuilder.SQLParserDataType.spText)
                                    .Add("CCVendorCode", info.ClientItem.Item(i).vendorCode, SqlBuilder.SQLParserDataType.spText)
                                    .Add("Remark", info.ClientItem.Item(i).RemarkID, SqlBuilder.SQLParserDataType.spText)
                                    .Add("ClientID", info.ClientItem.Item(i).CL_ClientID, SqlBuilder.SQLParserDataType.spNum)
                                End With
                                EffectRow = .ExecuteInsert()
                                If EffectRow <= 0 Then
                                    Exit For
                                End If
                            Next
                        End If

                        'If EffectRow > 0 Then
                        '    .TableName = "tblAirlineCC"
                        '    With .Columns
                        '        .Clear()
                        '        .Add("AirlineCode", info.AirlineCode, SqlBuilder.SQLParserDataType.spText)
                        '        .Add("TabType", info.TabTypeCL, SqlBuilder.SQLParserDataType.spText)
                        '        .Add("CCType", "UATP", SqlBuilder.SQLParserDataType.spText)
                        '        .Add("PassthroughType", info.AxTypePassThroughUATP_CL, SqlBuilder.SQLParserDataType.spText)
                        '        .Add("CCVendorCode", info.AxCCardUATP_CL, SqlBuilder.SQLParserDataType.spText)
                        '        .Add("Remark", info.AxRemarkUATP_CL, SqlBuilder.SQLParserDataType.spText)
                        '        .Add("ClientID", info.CL_ClientID, SqlBuilder.SQLParserDataType.spNum)
                        '    End With
                        '    EffectRow = .ExecuteInsert()
                        '    '//
                        '    With .Columns
                        '        .Clear()
                        '        .Add("AirlineCode", info.AirlineCode, SqlBuilder.SQLParserDataType.spText)
                        '        .Add("TabType", info.TabTypeCL, SqlBuilder.SQLParserDataType.spText)
                        '        .Add("CCType", "NRCC", SqlBuilder.SQLParserDataType.spText)
                        '        .Add("PassthroughType", info.AxTypePassThroughNRCC_CL, SqlBuilder.SQLParserDataType.spText)
                        '        .Add("CCVendorCode", info.AxCCardNRCC_CL, SqlBuilder.SQLParserDataType.spText)
                        '        .Add("Remark", info.AxRemarkNRCC_CL, SqlBuilder.SQLParserDataType.spText)
                        '        .Add("ClientID", info.CL_ClientID, SqlBuilder.SQLParserDataType.spNum)
                        '    End With
                        '    EffectRow = .ExecuteInsert()
                        '    '//
                        '    With .Columns
                        '        .Clear()
                        '        .Add("AirlineCode", info.AirlineCode, SqlBuilder.SQLParserDataType.spText)
                        '        .Add("TabType", info.TabTypeCL, SqlBuilder.SQLParserDataType.spText)
                        '        .Add("CCType", "UATP", SqlBuilder.SQLParserDataType.spText)
                        '        .Add("PassthroughType", info.DCTypePassThroughUATP_CL, SqlBuilder.SQLParserDataType.spText)
                        '        .Add("CCVendorCode", info.DCCCardUATP_CL, SqlBuilder.SQLParserDataType.spText)
                        '        .Add("Remark", info.DCRemarkUATP_CL, SqlBuilder.SQLParserDataType.spText)
                        '        .Add("ClientID", info.CL_ClientID, SqlBuilder.SQLParserDataType.spNum)
                        '    End With
                        '    EffectRow = .ExecuteInsert()
                        '    '//
                        '    With .Columns
                        '        .Clear()
                        '        .Add("AirlineCode", info.AirlineCode, SqlBuilder.SQLParserDataType.spText)
                        '        .Add("TabType", info.TabTypeCL, SqlBuilder.SQLParserDataType.spText)
                        '        .Add("CCType", "NRCC", SqlBuilder.SQLParserDataType.spText)
                        '        .Add("PassthroughType", info.DCTypePassThroughNRCC_CL, SqlBuilder.SQLParserDataType.spText)
                        '        .Add("CCVendorCode", info.DCCCardNRCC_CL, SqlBuilder.SQLParserDataType.spText)
                        '        .Add("Remark", info.DCRemarkNRCC_CL, SqlBuilder.SQLParserDataType.spText)
                        '        .Add("ClientID", info.CL_ClientID, SqlBuilder.SQLParserDataType.spNum)
                        '    End With
                        '    EffectRow = .ExecuteInsert()
                        '    '//
                        '    With .Columns
                        '        .Clear()
                        '        .Add("AirlineCode", info.AirlineCode, SqlBuilder.SQLParserDataType.spText)
                        '        .Add("TabType", info.TabTypeCL, SqlBuilder.SQLParserDataType.spText)
                        '        .Add("CCType", "UATP", SqlBuilder.SQLParserDataType.spText)
                        '        .Add("PassthroughType", info.TPTypePassThroughUATP_CL, SqlBuilder.SQLParserDataType.spText)
                        '        .Add("CCVendorCode", info.TPCCardUATP_CL, SqlBuilder.SQLParserDataType.spText)
                        '        .Add("Remark", info.TPRemarkUATP_CL, SqlBuilder.SQLParserDataType.spText)
                        '        .Add("ClientID", info.CL_ClientID, SqlBuilder.SQLParserDataType.spNum)
                        '    End With
                        '    EffectRow = .ExecuteInsert()
                        '    '//
                        '    With .Columns
                        '        .Clear()
                        '        .Add("AirlineCode", info.AirlineCode, SqlBuilder.SQLParserDataType.spText)
                        '        .Add("TabType", info.TabTypeCL, SqlBuilder.SQLParserDataType.spText)
                        '        .Add("CCType", "NRCC", SqlBuilder.SQLParserDataType.spText)
                        '        .Add("PassthroughType", info.TPTypePassThroughNRCC_CL, SqlBuilder.SQLParserDataType.spText)
                        '        .Add("CCVendorCode", info.TPCCardNRCC_CL, SqlBuilder.SQLParserDataType.spText)
                        '        .Add("Remark", info.TPRemarkNRCC_CL, SqlBuilder.SQLParserDataType.spText)
                        '        .Add("ClientID", info.CL_ClientID, SqlBuilder.SQLParserDataType.spNum)
                        '    End With
                        '    EffectRow = .ExecuteInsert()
                        '    '//
                        '    With .Columns
                        '        .Clear()
                        '        .Add("AirlineCode", info.AirlineCode, SqlBuilder.SQLParserDataType.spText)
                        '        .Add("TabType", info.TabTypeCL, SqlBuilder.SQLParserDataType.spText)
                        '        .Add("CCType", "UATP", SqlBuilder.SQLParserDataType.spText)
                        '        .Add("PassthroughType", info.CATypePassThroughUATP_CL, SqlBuilder.SQLParserDataType.spText)
                        '        .Add("CCVendorCode", info.CACCardUATP_CL, SqlBuilder.SQLParserDataType.spText)
                        '        .Add("Remark", info.CARemarkUATP_CL, SqlBuilder.SQLParserDataType.spText)
                        '        .Add("ClientID", info.CL_ClientID, SqlBuilder.SQLParserDataType.spNum)
                        '    End With
                        '    EffectRow = .ExecuteInsert()
                        '    '//
                        '    With .Columns
                        '        .Clear()
                        '        .Add("AirlineCode", info.AirlineCode, SqlBuilder.SQLParserDataType.spText)
                        '        .Add("TabType", info.TabTypeCL, SqlBuilder.SQLParserDataType.spText)
                        '        .Add("CCType", "NRCC", SqlBuilder.SQLParserDataType.spText)
                        '        .Add("PassthroughType", info.CATypePassThroughNRCC_CL, SqlBuilder.SQLParserDataType.spText)
                        '        .Add("CCVendorCode", info.CACCardNRCC_CL, SqlBuilder.SQLParserDataType.spText)
                        '        .Add("Remark", info.CARemarkNRCC_CL, SqlBuilder.SQLParserDataType.spText)
                        '        .Add("ClientID", info.CL_ClientID, SqlBuilder.SQLParserDataType.spNum)
                        '    End With
                        '    EffectRow = .ExecuteInsert()
                        '    '//
                        '    With .Columns
                        '        .Clear()
                        '        .Add("AirlineCode", info.AirlineCode, SqlBuilder.SQLParserDataType.spText)
                        '        .Add("TabType", info.TabTypeCL, SqlBuilder.SQLParserDataType.spText)
                        '        .Add("CCType", "UATP", SqlBuilder.SQLParserDataType.spText)
                        '        .Add("PassthroughType", info.VITypePassThroughUATP_CL, SqlBuilder.SQLParserDataType.spText)
                        '        .Add("CCVendorCode", info.VICCardUATP_CL, SqlBuilder.SQLParserDataType.spText)
                        '        .Add("Remark", info.VIRemarkUATP_CL, SqlBuilder.SQLParserDataType.spText)
                        '        .Add("ClientID", info.CL_ClientID, SqlBuilder.SQLParserDataType.spNum)
                        '    End With
                        '    EffectRow = .ExecuteInsert()
                        '    '//
                        '    With .Columns
                        '        .Clear()
                        '        .Add("AirlineCode", info.AirlineCode, SqlBuilder.SQLParserDataType.spText)
                        '        .Add("TabType", info.TabTypeCL, SqlBuilder.SQLParserDataType.spText)
                        '        .Add("CCType", "NRCC", SqlBuilder.SQLParserDataType.spText)
                        '        .Add("PassthroughType", info.VITypePassThroughNRCC_CL, SqlBuilder.SQLParserDataType.spText)
                        '        .Add("CCVendorCode", info.VICCardNRCC_CL, SqlBuilder.SQLParserDataType.spText)
                        '        .Add("Remark", info.VIRemarkNRCC_CL, SqlBuilder.SQLParserDataType.spText)
                        '        .Add("ClientID", info.CL_ClientID, SqlBuilder.SQLParserDataType.spNum)
                        '    End With
                        '    EffectRow = .ExecuteInsert()
                        '    '//

                        'End If
                    End If



                    If EffectRow > 0 Then

                        .TableName = "tblAirlineCC"
                        '//
                        With .Columns
                            .Clear()
                            .Add("AirlineCode", info.AirlineCode, SqlBuilder.SQLParserDataType.spText)
                            .Add("TabType", info.TabTypeCWT, SqlBuilder.SQLParserDataType.spText)
                            .Add("CCType", "UATP", SqlBuilder.SQLParserDataType.spText)
                            .Add("PassthroughType", info.AxTypePassThroughUATP, SqlBuilder.SQLParserDataType.spText)
                            .Add("CCVendorCode", info.AxCCardUATP, SqlBuilder.SQLParserDataType.spText)
                            .Add("Remark", info.AxRemarkUATP, SqlBuilder.SQLParserDataType.spText)
                        End With
                        EffectRow = .ExecuteInsert()
                        '//
                        With .Columns
                            .Clear()
                            .Add("AirlineCode", info.AirlineCode, SqlBuilder.SQLParserDataType.spText)
                            .Add("TabType", info.TabTypeCWT, SqlBuilder.SQLParserDataType.spText)
                            .Add("CCType", "NRCC")
                            .Add("PassthroughType", info.AxTypePassThroughNRCC, SqlBuilder.SQLParserDataType.spText)
                            .Add("CCVendorCode", info.AxCCardNRCC, SqlBuilder.SQLParserDataType.spText)
                            .Add("Remark", info.AxRemarkNRCC, SqlBuilder.SQLParserDataType.spText)
                        End With
                        EffectRow = .ExecuteInsert()
                        '//
                        With .Columns
                            .Clear()
                            .Add("AirlineCode", info.AirlineCode, SqlBuilder.SQLParserDataType.spText)
                            .Add("TabType", info.TabTypeCWT, SqlBuilder.SQLParserDataType.spText)
                            .Add("CCType", "UATP")
                            .Add("PassthroughType", info.DCTypePassThroughUATP, SqlBuilder.SQLParserDataType.spText)
                            .Add("CCVendorCode", info.DCCCardUATP, SqlBuilder.SQLParserDataType.spText)
                            .Add("Remark", info.DCRemarkUATP, SqlBuilder.SQLParserDataType.spText)
                        End With
                        EffectRow = .ExecuteInsert()
                        '//
                        With .Columns
                            .Clear()
                            .Add("AirlineCode", info.AirlineCode, SqlBuilder.SQLParserDataType.spText)
                            .Add("TabType", info.TabTypeCWT, SqlBuilder.SQLParserDataType.spText)
                            .Add("CCType", "NRCC")
                            .Add("PassthroughType", info.DCTypePassThroughNRCC, SqlBuilder.SQLParserDataType.spText)
                            .Add("CCVendorCode", info.DCCCardNRCC, SqlBuilder.SQLParserDataType.spText)
                            .Add("Remark", info.DCRemarkNRCC, SqlBuilder.SQLParserDataType.spText)
                        End With
                        EffectRow = .ExecuteInsert()
                        '//
                        With .Columns
                            .Clear()
                            .Add("AirlineCode", info.AirlineCode, SqlBuilder.SQLParserDataType.spText)
                            .Add("TabType", info.TabTypeCWT, SqlBuilder.SQLParserDataType.spText)
                            .Add("CCType", "UATP")
                            .Add("PassthroughType", info.TPTypePassThroughUATP, SqlBuilder.SQLParserDataType.spText)
                            .Add("CCVendorCode", info.TPCCardUATP, SqlBuilder.SQLParserDataType.spText)
                            .Add("Remark", info.TPRemarkUATP, SqlBuilder.SQLParserDataType.spText)
                        End With
                        EffectRow = .ExecuteInsert()
                        '//
                        With .Columns
                            .Clear()
                            .Add("AirlineCode", info.AirlineCode, SqlBuilder.SQLParserDataType.spText)
                            .Add("TabType", info.TabTypeCWT, SqlBuilder.SQLParserDataType.spText)
                            .Add("CCType", "NRCC")
                            .Add("PassthroughType", info.TPTypePassThroughNRCC, SqlBuilder.SQLParserDataType.spText)
                            .Add("CCVendorCode", info.TPCCardNRCC, SqlBuilder.SQLParserDataType.spText)
                            .Add("Remark", info.TPRemarkNRCC, SqlBuilder.SQLParserDataType.spText)
                        End With
                        EffectRow = .ExecuteInsert()
                        '//
                        With .Columns
                            .Clear()
                            .Add("AirlineCode", info.AirlineCode, SqlBuilder.SQLParserDataType.spText)
                            .Add("TabType", info.TabTypeCWT, SqlBuilder.SQLParserDataType.spText)
                            .Add("CCType", "UATP")
                            .Add("PassthroughType", info.CATypePassThroughUATP, SqlBuilder.SQLParserDataType.spText)
                            .Add("CCVendorCode", info.CACCardUATP, SqlBuilder.SQLParserDataType.spText)
                            .Add("Remark", info.CARemarkUATP, SqlBuilder.SQLParserDataType.spText)
                        End With
                        EffectRow = .ExecuteInsert()
                        '//
                        With .Columns
                            .Clear()
                            .Add("AirlineCode", info.AirlineCode, SqlBuilder.SQLParserDataType.spText)
                            .Add("TabType", info.TabTypeCWT, SqlBuilder.SQLParserDataType.spText)
                            .Add("CCType", "NRCC")
                            .Add("PassthroughType", info.CATypePassThroughNRCC, SqlBuilder.SQLParserDataType.spText)
                            .Add("CCVendorCode", info.CACCardNRCC, SqlBuilder.SQLParserDataType.spText)
                            .Add("Remark", info.CARemarkNRCC, SqlBuilder.SQLParserDataType.spText)
                        End With
                        EffectRow = .ExecuteInsert()
                        '//
                        With .Columns
                            .Clear()
                            .Add("AirlineCode", info.AirlineCode, SqlBuilder.SQLParserDataType.spText)
                            .Add("TabType", info.TabTypeCWT, SqlBuilder.SQLParserDataType.spText)
                            .Add("CCType", "UATP")
                            .Add("PassthroughType", info.VITypePassThroughUATP, SqlBuilder.SQLParserDataType.spText)
                            .Add("CCVendorCode", info.VICCardUATP, SqlBuilder.SQLParserDataType.spText)
                            .Add("Remark", info.VIRemarkUATP, SqlBuilder.SQLParserDataType.spText)
                        End With
                        EffectRow = .ExecuteInsert()
                        '//
                        With .Columns
                            .Clear()
                            .Add("AirlineCode", info.AirlineCode, SqlBuilder.SQLParserDataType.spText)
                            .Add("TabType", info.TabTypeCWT, SqlBuilder.SQLParserDataType.spText)
                            .Add("CCType", "NRCC", SqlBuilder.SQLParserDataType.spText)
                            .Add("PassthroughType", info.VITypePassThroughNRCC, SqlBuilder.SQLParserDataType.spText)
                            .Add("CCVendorCode", info.VICCardNRCC, SqlBuilder.SQLParserDataType.spText)
                            .Add("Remark", info.VIRemarkNRCC, SqlBuilder.SQLParserDataType.spText)
                        End With
                        EffectRow = .ExecuteInsert()
                        '//
                    End If
                    '//
                    If EffectRow > 0 Then
                        .TableName = "tblAirlineCommission"
                        For i As Integer = 0 To info.Items.Count - 1
                            With .Columns
                                .Clear()
                                .Add("AirlineCode", info.AirlineCode)
                                .Add("Origin", info.Items(i).Origin, , , , , False)
                                .Add("Destination", info.Items(i).Destination, , , , , False)
                                .Add("OriginType", info.Items(i).OriginType)
                                .Add("DestType", info.Items(i).DestinationType)
                                .Add("CommType", info.Items(i).FeeType)
                                .Add("FareType", info.Items(i).FareType)
                                .Add("Amt", info.Items(i).Amount, SqlBuilder.SQLParserDataType.spNum)
                                .Add("AirCommID", info.Items(i).AirCommID)
                            End With
                            EffectRow = .ExecuteInsert()
                            If EffectRow <= 0 Then
                                Exit For
                            End If
                        Next
                    End If
                End With

                If EffectRow > 0 Then
                    Me.MySQLParser.CommitTran()
                Else
                    Me.MySQLParser.RollbackTran()
                End If
                InsertNewRecord()
            Catch ex As Exception
                EffectRow = -1
                Me.MySQLParser.RollbackTran()
            Finally
                Me.MySQLParser.CloseConnection()
            End Try
            Return EffectRow
        End Function


        Public Function GetTempAirlineComm() As DataTable
            Dim dt As DataTable
            Dim dt2 As DataTable
            Dim resultTable As DataTable
            Dim TempTable As DataTable
            Dim foundRow() As DataRow
            Dim count As Integer
            Dim ArrString(0) As String
            ArrString(0) = "AirCommID"

            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "Temp_tblAirlineCommission"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("*")
                End With
                dt = .ExecuteDataTable(.SQLSelect + " order by DateModification Desc")
                .TableName = "tblAirlineCommission"
                With .Columns
                    .Clear()
                    .IncludeKey = False
                    .Add("Distinct *")
                End With
                dt2 = .ExecuteDataTable()
            End With

            TempTable = dt.DefaultView.ToTable(True, ArrString)
            resultTable = dt.Clone()
            For count = 0 To TempTable.Rows.Count - 1
                foundRow = dt2.Select("AirCommID = '" + TempTable.Rows(count).Item("AirCommID").ToString() + "'")
                If foundRow.Length > 0 Then
                    resultTable.ImportRow(foundRow(0))
                End If
            Next
            resultTable.AcceptChanges()
            resultTable.Merge(dt)
            Return resultTable
        End Function

        Public Function GetTempAirlineCommByAirlineCode(ByVal Code As String, ByVal DateFrom As String, ByVal DateTo As String)
            Dim dt As DataTable
            Dim dt2 As DataTable
            Dim resultTable As DataTable
            Dim TempTable As DataTable
            Dim foundRow() As DataRow
            Dim count As Integer
            Dim ArrString(0) As String
            ArrString(0) = "AirCommID"

            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "Temp_tblAirlineCommission"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    If Code <> "" Then
                        .Add("AirlineCode", Code, SqlBuilder.SQLParserDataType.spText, True)
                    End If
                    If DateFrom = DateTo Then
                        If DateFrom <> "" And DateTo <> "" Then
                            DateTo = DateTo + " 23:59:59:997"
                            .Add("DateModification", "convert(varchar,cast('" + DateFrom + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, ">")
                            .Add("DateModification", "convert(varchar,cast('" + DateTo + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, "<")
                        End If
                    Else
                        If DateFrom <> "" Then
                            .Add("DateModification", DateFrom, SqlBuilder.SQLParserDataType.spDate, True, ">")
                        End If
                        If DateTo <> "" Then
                            DateTo = DateTo + " 23:59:59:999"
                            .Add("DateModification", DateTo, SqlBuilder.SQLParserDataType.spText, True, "<=")
                        End If
                    End If
                    .Add("*")
                End With

                dt = .ExecuteDataTable(.SQLSelect + " order by DateModification Desc")
                .TableName = "tblAirlineCommission"
                With .Columns
                    .Clear()
                    .IncludeKey = False
                    If Code <> "" Then
                        .Add("AirlineCode", Code, SqlBuilder.SQLParserDataType.spText, True)
                    End If
                    .Add("Distinct *")
                End With
                dt2 = .ExecuteDataTable()
            End With

            TempTable = dt.DefaultView.ToTable(True, ArrString)
            resultTable = dt.Clone()
            For count = 0 To TempTable.Rows.Count - 1
                foundRow = dt2.Select("AirCommID = '" + TempTable.Rows(count).Item("AirCommID").ToString() + "'")
                If foundRow.Length > 0 Then
                    resultTable.ImportRow(foundRow(0))
                End If
            Next
            resultTable.AcceptChanges()
            resultTable.Merge(dt)
            Return resultTable
        End Function

        Public Function GetTempAirlineRule()
            Dim dt As DataTable
            Dim dt2 As DataTable
            Dim resultTable As DataTable
            Dim TempTable As DataTable
            Dim foundRow() As DataRow
            Dim count As Integer
            Dim ArrString(0) As String
            ArrString(0) = "AirlineCode"

            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "Temp_tblAirlineRule"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("*")
                End With
                dt = .ExecuteDataTable(.SQLSelect + " order by DateModification Desc")
                .TableName = "tblAirlineRule"
                With .Columns
                    .Clear()
                    .IncludeKey = False
                    .Add("Distinct *")
                End With
                dt2 = .ExecuteDataTable()
            End With

            TempTable = dt.DefaultView.ToTable(True, ArrString)
            resultTable = dt.Clone()
            For count = 0 To TempTable.Rows.Count - 1
                foundRow = dt2.Select("AirlineCode = '" + TempTable.Rows(count).Item("AirlineCode").ToString() + "'")
                If foundRow.Length > 0 Then
                    resultTable.ImportRow(foundRow(0))
                End If
            Next
            resultTable.AcceptChanges()
            resultTable.Merge(dt)
            Return resultTable
        End Function

        Public Function GetTempAirlineRuleByAirlineCode(ByVal Code As String, ByVal DateFrom As String, ByVal DateTo As String)
            Dim dt As DataTable
            Dim dt2 As DataTable
            Dim resultTable As DataTable
            Dim TempTable As DataTable
            Dim foundRow() As DataRow
            Dim count As Integer
            Dim ArrString(0) As String
            ArrString(0) = "AirlineCode"

            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "Temp_tblAirlineRule"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    If Code <> "" Then
                        .Add("AirlineCode", Code, SqlBuilder.SQLParserDataType.spText, True)
                    End If
                    If DateFrom = DateTo Then
                        If DateFrom <> "" And DateTo <> "" Then
                            DateTo = DateTo + " 23:59:59:997"
                            .Add("DateModification", "convert(varchar,cast('" + DateFrom + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, ">")
                            .Add("DateModification", "convert(varchar,cast('" + DateTo + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, "<")
                        End If
                    Else
                        If DateFrom <> "" Then
                            .Add("DateModification", DateFrom, SqlBuilder.SQLParserDataType.spDate, True, ">")
                        End If
                        If DateTo <> "" Then
                            DateTo = DateTo + " 23:59:59:999"
                            .Add("DateModification", DateTo, SqlBuilder.SQLParserDataType.spText, True, "<=")
                        End If
                    End If
                    .Add("*")
                End With

                dt = .ExecuteDataTable(.SQLSelect + " order by DateModification Desc")
                .TableName = "tblAirlineRule"
                With .Columns
                    .Clear()
                    .IncludeKey = False
                    If Code <> "" Then
                        .Add("AirlineCode", Code, SqlBuilder.SQLParserDataType.spText, True)
                    End If
                    .Add("Distinct *")
                End With
                dt2 = .ExecuteDataTable()
            End With

            TempTable = dt.DefaultView.ToTable(True, ArrString)
            resultTable = dt.Clone()
            For count = 0 To TempTable.Rows.Count - 1
                foundRow = dt2.Select("AirlineCode = '" + TempTable.Rows(count).Item("AirlineCode").ToString() + "'")
                If foundRow.Length > 0 Then
                    resultTable.ImportRow(foundRow(0))
                End If
            Next
            resultTable.AcceptChanges()
            resultTable.Merge(dt)
            Return resultTable
        End Function

        Public Function GetTempAirlineCCByAirlineCode(Optional ByVal Code As String = "", Optional ByVal DateFrom As String = "", Optional ByVal DateTo As String = "")
            Dim dt As DataTable
            Dim dt2 As DataTable
            Dim resultTable As DataTable
            Dim TempTable As DataTable
            Dim foundRow() As DataRow
            Dim count As Integer
            Dim ArrString(3) As String
            ArrString(0) = "AirlineCode"
            ArrString(1) = "TabType"
            ArrString(2) = "CCType"
            ArrString(3) = "CCVendorCode"


            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "Temp_tblAirlineCC ac inner join tblClientMaster cm on ac.ClientID = cm.ClientID"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    If Code <> "" Then
                        .Add("ac.AirlineCode", Code, SqlBuilder.SQLParserDataType.spText, True)
                    End If
                    If DateFrom = DateTo Then
                        If DateFrom <> "" And DateTo <> "" Then
                            DateTo = DateTo + " 23:59:59:997"
                            .Add("DateModification", "convert(varchar,cast('" + DateFrom + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, ">")
                            .Add("DateModification", "convert(varchar,cast('" + DateTo + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, "<")
                        End If
                    Else
                        If DateFrom <> "" Then
                            .Add("DateModification", DateFrom, SqlBuilder.SQLParserDataType.spDate, True, ">")
                        End If
                        If DateTo <> "" Then
                            DateTo = DateTo + " 23:59:59:999"
                            .Add("DateModification", DateTo, SqlBuilder.SQLParserDataType.spText, True, "<=")
                        End If
                    End If
                    .Add("ac.AirlineCode,ac.TabType,ac.CCType,ac.PassthroughType,ac.CCVendorCode,ac.Remark,cm.Name,ac.DateModification,ac.UserName,ac.ValueTypeChanged")
                End With

                dt = .ExecuteDataTable(.SQLSelect + " order by DateModification Desc")
                .TableName = "tblAirlineCC ac inner join tblClientMaster cm on ac.ClientID = cm.ClientID"
                With .Columns
                    .Clear()
                    .IncludeKey = False
                    If Code <> "" Then
                        .Add("ac.AirlineCode", Code, SqlBuilder.SQLParserDataType.spText, True)
                    End If
                    .Add("ac.AirlineCode,ac.TabType,ac.CCType,ac.PassthroughType,ac.CCVendorCode,ac.Remark,cm.Name")
                End With
                dt2 = .ExecuteDataTable()
            End With

            TempTable = dt.DefaultView.ToTable(True, ArrString)
            resultTable = dt.Clone()
            For count = 0 To TempTable.Rows.Count - 1
                foundRow = dt2.Select("AirlineCode = '" + TempTable.Rows(count).Item("AirlineCode").ToString() + "' and TabType='" + TempTable.Rows(count).Item("TabType").ToString() + "' and CCType ='" + TempTable.Rows(count).Item("CCType").ToString() + "' and CCVendorCode='" + TempTable.Rows(count).Item("CCVendorCode").ToString() + "'")
                If foundRow.Length > 0 Then
                    resultTable.ImportRow(foundRow(0))
                End If
            Next
            resultTable.AcceptChanges()
            resultTable.Merge(dt)
            Return resultTable
        End Function

    End Class
End Namespace


















@


1.1.1.1
log
@no message
@
text
@@
