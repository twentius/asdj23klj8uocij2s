head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.22;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.22;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic
Imports System.Collections.Generic

Namespace DataAccessLayer
    Public Class LineDefDAL
        Inherits BaseDA

        Public Function GetGDSList() As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = CWTMasterDB.Util.StandardDB("tblGDS")
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetLineDefList(ByVal LineDefName As String, ByVal GDS As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = CWTMasterDB.Util.StandardDB("tblCSP_LineDefMaster") + " d " + _
                             "inner join (select MAX(VersionNumber) as VersionNumber,LineDefMasterID from " + CWTMasterDB.Util.StandardDB("tblCSP_LineDefVersion") + " group by LineDefMasterID) f on d.LineDefMasterID=f.LineDefMasterID " + _
                             "inner join " + CWTMasterDB.Util.StandardDB("tblCSP_LineDefVersion") + " v on f.LineDefMasterID=v.LineDefMasterID and f.VersionNumber=v.VersionNumber"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    If LineDefName <> "" Then .Add("d.LineDefName", "%" + LineDefName + "%", SqlBuilder.SQLParserDataType.spText, True, "LIKE")
                    .Add("d.*")
                    .Add("v.VersionNumber")
                    .Add("v.Active")
                End With
                dt = .ExecuteDataTable(.SQLSelect + " order by d.LineDefMasterID")
            End With
            Return dt
        End Function

        Public Function GetDataTypeList() As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = CWTMasterDB.Util.StandardDB("tblCSP_SchemaType")
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetDataCategoryList(ByVal TypeID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = CWTMasterDB.Util.StandardDB("tblCSP_SchemaCategory")
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("SchemaTypeID", TypeID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetDataSchemaList(ByVal CatID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = CWTMasterDB.Util.StandardDB("tblCSP_Schema")
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("SchemaCatID", CatID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetCommandList() As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = CWTMasterDB.Util.StandardDB("tblCSP_DataType")
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetLineNumber() As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = CWTMasterDB.Util.StandardDB("tblCSP_LineDefTemplate")
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function GetLineDefByID(ByVal MasterID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = CWTMasterDB.Util.StandardDB("tblCSP_LineDefMaster") + " d inner join " + CWTMasterDB.Util.StandardDB("tblCSP_LineDefVersion") + " v on d.LineDefMasterID=v.LineDefMasterID"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("d.LineDefMasterID", MasterID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("d.*")
                    .Add("v.LineDefVersionID")
                    .Add("v.VersionNumber")
                    .Add("v.AlertEmail")
                    .Add("v.Active")
                End With
                dt = .ExecuteDataTable(.SQLSelect + " order by VersionNumber DESC")
            End With
            Return dt
        End Function

        Public Function GetLienDefDetailByID(ByVal MasterID As String, ByVal PageIndex As String) As DataTable
            Dim dt As DataTable
            Dim oSql As String = ""
            oSql = "exec " + CWTMasterDB.Util.StandardDB("sp_CSP_GetLineDefDetail") + " " + MasterID + "," + PageIndex
            With Me.MySQLParser
                dt = .ExecuteDataTable(oSql)
            End With
            Return dt
        End Function

        Private Function GetLastInsertMasterID() As String
            Dim MasterID As String
            With Me.MySQLParser
                .TableName = CWTMasterDB.Util.StandardDB("tblCSP_LineDefMaster")
                With .Columns
                    .Clear()
                    .Add("max(LineDefMasterID)")
                End With
                MasterID = .ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar)
            End With
            Return MasterID
        End Function

        Public Function UpdateLineDefMaster(ByVal info As DataInfo.LineDefInfo) As Integer
            Dim EffectRow As Integer
            Dim VersionNo As String = ""
            Try
                With Me.MySQLParser
                    If info.PageMode = CWTMasterDB.TransactionMode.AddNewMode Then
                        .TableName = CWTMasterDB.Util.StandardDB("tblCSP_LineDefMaster")
                        With .Columns
                            .Clear()
                            .Add("GDSNumber", info.GDS)
                            .Add("LineDefName", info.LineDefName)
                        End With
                        EffectRow = .ExecuteInsert()
                        info.MasterID = GetLastInsertMasterID()
                        CallProcedure(info.MasterID, "", "Insert", "sp_CSP_LineDefMaster")
                        VersionNo = .GetNextRunning("LineDefVersionNo", info.MasterID)
                    Else
                        VersionNo = info.VersionNumber
                    End If
                    '//
                    .TableName = CWTMasterDB.Util.StandardDB("tblCSP_LineDefVersion")
                    With .Columns
                        .Clear()
                        .Add("LineDefMasterID", info.MasterID, SqlBuilder.SQLParserDataType.spNum, (info.PageMode = CWTMasterDB.TransactionMode.UpdateMode))
                        .Add("VersionNumber", VersionNo, SqlBuilder.SQLParserDataType.spNum, (info.PageMode = CWTMasterDB.TransactionMode.UpdateMode))
                        .Add("AlertEmail", info.AlertEmail)
                        .Add("Active", info.Active, SqlBuilder.SQLParserDataType.spBoolean)
                        .Add("UpdatedBy", info.UserID)
                        .Add("UpdatedDate", "getdate()", SqlBuilder.SQLParserDataType.spFunction)
                    End With
                    If info.PageMode = CWTMasterDB.TransactionMode.AddNewMode Then
                        EffectRow = .ExecuteInsert()
                        CallProcedure(info.MasterID, VersionNo, "Insert", "sp_CSP_LineDefVersion")
                    Else
                        CallProcedure(info.MasterID, VersionNo, "Update", "sp_CSP_LineDefVersion")
                        EffectRow = .ExecuteUpdate()
                    End If
                    '//
                End With
                If EffectRow > 0 Then
                    Me.MySQLParser.CommitTran()
                Else
                    Me.MySQLParser.RollbackTran()
                End If
            Catch ex As Exception
                EffectRow = -1
                Me.MySQLParser.RollbackTran()
            Finally
                Me.MySQLParser.CloseConnection()
            End Try
            Return EffectRow
        End Function

        Public Function UpdateLineDetail(ByVal info As DataInfo.LineDefInfo) As Integer
            Dim EffectRow As Integer = 1
            Dim StRecord As Integer
            Dim EndRecord As Integer
            Dim CWTLineDT As DataTable
            Try
                CWTLineDT = GetLineDefDT(info.VersionID)
                With Me.MySQLParser
                    '.OpenConnection()
                    '.BeginTran()
                    .TableName = CWTMasterDB.Util.StandardDB("tblCSP_LineDef")
                    '//
                    StRecord = ((info.CurrentPage - 1) * 40) + 1
                    EndRecord = StRecord + 39
                    With .Columns
                        .Clear()
                        .Add("LineNumber", StRecord.ToString, SqlBuilder.SQLParserDataType.spFunction, True, ">=")
                        .Add("LineNumber", EndRecord.ToString, SqlBuilder.SQLParserDataType.spFunction, True, "<=")
                        .Add("LineDefVersionID", info.VersionID, SqlBuilder.SQLParserDataType.spNum, True)
                    End With
                    .ExecuteDelete()
                    For i As Integer = 0 To info.Lines.Count - 1
                        With .Columns
                            .Clear()
                            '.Add("LineDefVersionID", info.VersionID, SqlBuilder.SQLParserDataType.spNum, IsUpdate)
                            .Add("LineDefVersionID", info.VersionID, SqlBuilder.SQLParserDataType.spNum)
                            .Add("LineNumber", info.Lines(i).LineNumber, SqlBuilder.SQLParserDataType.spNum)
                            .Add("MoveType", info.Lines(i).MoveType)
                            .Add("SecondaryInd", info.Lines(i).SecondInd)
                            .Add("TertiaryInd", info.Lines(i).ThirdInd)
                            .Add("DataTypeValue", info.Lines(i).Command)
                            .Add("Qualifier", info.Lines(i).Qualifier)
                            .Add("FormatString", info.Lines(i).FormatString, SqlBuilder.SQLParserDataType.spText, False, , True)
                            .Add("Remark", info.Lines(i).Remark)
                        End With
                        EffectRow = .ExecuteInsert()
                        If EffectRow <= 0 Then
                            Exit For
                        End If
                    Next
                End With
                MatchCWTLineDefRecord(CWTLineDT, info)
                If EffectRow > 0 Then
                    Me.MySQLParser.CommitTran()
                Else
                    Me.MySQLParser.RollbackTran()
                End If
            Catch ex As Exception
                EffectRow = -1
                Me.MySQLParser.RollbackTran()
            Finally
                Me.MySQLParser.CloseConnection()
            End Try
            Return EffectRow
        End Function

        Private Sub MatchCWTLineDefRecord(ByVal CWTLineDT As DataTable, ByVal info As DataInfo.LineDefInfo)
            Dim countDT As Integer
            Dim countInfo As Integer
            Dim checkMatch As Boolean
            Dim effectRow As Integer

            If CWTLineDT.Rows.Count > 0 Then
                For countDT = 0 To CWTLineDT.Rows.Count - 1
                    checkMatch = CheckCWTLineExists(CWTLineDT.Rows(countDT), info)
                    If checkMatch = False Then

                        For countInfo = 0 To info.Lines.Count - 1
                            If CWTLineDT.Rows(countDT).Item("LineDefVersionID").ToString() = info.VersionID AndAlso CWTLineDT.Rows(countDT).Item("LineNumber").ToString() = info.Lines(countInfo).LineNumber Then
                                With Me.MySQLParser
                                    .TableName = CWTMasterDB.Util.StandardDB("Temp_tblCSP_LineDef")
                                    With .Columns
                                        .Clear()
                                        .Add("LineDefID", CWTLineDT.Rows(countDT).Item("LineDefID").ToString(), SqlBuilder.SQLParserDataType.spNum)
                                        .Add("LineDefVersionID", CWTLineDT.Rows(countDT).Item("LineDefVersionID").ToString(), SqlBuilder.SQLParserDataType.spNum)
                                        .Add("LineNumber", CWTLineDT.Rows(countDT).Item("LineNumber").ToString(), SqlBuilder.SQLParserDataType.spNum)
                                        .Add("MoveType", CWTLineDT.Rows(countDT).Item("MoveType").ToString())
                                        .Add("SecondaryInd", CWTLineDT.Rows(countDT).Item("SecondaryInd").ToString())
                                        .Add("TertiaryInd", CWTLineDT.Rows(countDT).Item("TertiaryInd").ToString())
                                        .Add("DataTypeValue", CWTLineDT.Rows(countDT).Item("DataTypeValue").ToString())
                                        .Add("Qualifier", CWTLineDT.Rows(countDT).Item("Qualifier").ToString())
                                        .Add("FormatString", CWTLineDT.Rows(countDT).Item("FormatString").ToString())
                                        .Add("Remark", CWTLineDT.Rows(countDT).Item("Remark").ToString())
                                        .Add("DateModification", DateTime.Now)
                                        .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                        .Add("ValueTypeChanged", "Update")
                                    End With
                                    effectRow = .ExecuteInsert()
                                    Exit For
                                End With
                            End If
                        Next countInfo

                        If CWTLineDT.Rows.Count > info.Lines.Count Then
                            With Me.MySQLParser
                                .TableName = CWTMasterDB.Util.StandardDB("Temp_tblCSP_LineDef")
                                With .Columns
                                    .Clear()
                                    .Add("LineDefID", CWTLineDT.Rows(countDT).Item("LineDefID").ToString(), SqlBuilder.SQLParserDataType.spNum)
                                    .Add("LineDefVersionID", CWTLineDT.Rows(countDT).Item("LineDefVersionID").ToString(), SqlBuilder.SQLParserDataType.spNum)
                                    .Add("LineNumber", CWTLineDT.Rows(countDT).Item("LineNumber").ToString(), SqlBuilder.SQLParserDataType.spNum)
                                    .Add("MoveType", CWTLineDT.Rows(countDT).Item("MoveType").ToString())
                                    .Add("SecondaryInd", CWTLineDT.Rows(countDT).Item("SecondaryInd").ToString())
                                    .Add("TertiaryInd", CWTLineDT.Rows(countDT).Item("TertiaryInd").ToString())
                                    .Add("DataTypeValue", CWTLineDT.Rows(countDT).Item("DataTypeValue").ToString())
                                    .Add("Qualifier", CWTLineDT.Rows(countDT).Item("Qualifier").ToString())
                                    .Add("FormatString", CWTLineDT.Rows(countDT).Item("FormatString").ToString())
                                    .Add("Remark", CWTLineDT.Rows(countDT).Item("Remark").ToString())
                                    .Add("DateModification", DateTime.Now)
                                    .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                    .Add("ValueTypeChanged", "Delete")
                                End With
                                effectRow = .ExecuteInsert()
                            End With
                        End If
                    End If
                Next countDT
            End If

            If info.Lines.Count > CWTLineDT.Rows.Count Then
                For countInfo = countDT To info.Lines.Count - 1
                    With Me.MySQLParser
                        .TableName = CWTMasterDB.Util.StandardDB("Temp_tblCSP_LineDef")
                        With .Columns
                            .Clear()
                            '.Add("LineDefID", )
                            .Add("LineDefVersionID", info.VersionID, SqlBuilder.SQLParserDataType.spNum)
                            .Add("LineNumber", info.Lines(countInfo).LineNumber, SqlBuilder.SQLParserDataType.spNum)
                            .Add("MoveType", info.Lines(countInfo).MoveType)
                            .Add("SecondaryInd", info.Lines(countInfo).SecondInd)
                            .Add("TertiaryInd", info.Lines(countInfo).ThirdInd)
                            .Add("DataTypeValue", info.Lines(countInfo).Command)
                            .Add("Qualifier", info.Lines(countInfo).Qualifier)
                            .Add("FormatString", info.Lines(countInfo).FormatString)
                            .Add("Remark", info.Lines(countInfo).Remark)
                            .Add("DateModification", DateTime.Now)
                            .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                            .Add("ValueTypeChanged", "Insert")
                        End With
                    End With
                Next
            End If
        End Sub

        Private Function CheckCWTLineExists(ByVal row As DataRow, ByVal info As DataInfo.LineDefInfo) As Boolean
            Dim check As Boolean
            Dim countInfo As Integer
            For countInfo = 0 To info.Lines.Count - 1
                If row.Item("LineDefVersionID").ToString() = info.VersionID AndAlso row.Item("LineNumber").ToString() = info.Lines(countInfo).LineNumber AndAlso row.Item("MoveType").ToString() = info.Lines(countInfo).MoveType AndAlso row.Item("SecondaryInd").ToString() = info.Lines(countInfo).SecondInd AndAlso row.Item("TertiaryInd").ToString() = info.Lines(countInfo).ThirdInd AndAlso row.Item("DataTypeValue").ToString() = info.Lines(countInfo).Command AndAlso row.Item("Qualifier").ToString() = info.Lines(countInfo).Qualifier AndAlso row.Item("FormatString").ToString() = info.Lines(countInfo).FormatString AndAlso row.Item("Remark").ToString() = info.Lines(countInfo).Remark Then
                    check = True
                    Exit For
                End If
            Next countInfo
            Return check
        End Function

        Private Function GetLineDefDT(ByVal LineDefVersion As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .TableName = CWTMasterDB.Util.StandardDB("tblCSP_LineDef")
                With .Columns
                    .Clear()
                    .Add("LineDefVersionID", LineDefVersion, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("*")
                End With
                dt = .ExecuteDataTable()
            End With
            Return dt
        End Function

        Public Function CreateNewVersion(ByVal MasterID As String, ByVal VersionID As String, ByVal VersionNumber As String, ByVal UserID As String) As Integer
            Dim EffectRow As Integer = 1
            Dim oSql As String = ""
            'Dim OldVersion As String
            Dim NewVersion As String
            Try
                With Me.MySQLParser
                    '// Get Lastest Version
                    'oSql = "select MAX(VersionNumber) from " + CWTMasterDB.Util.StandardDB("tblCSP_LineDefVersion") + " where LineDefMasterID=" + MasterID
                    'OldVersion = .ExecuteCommand(oSql, SqlBuilder.SQLParserExecuteType.ExecuteScalar)
                    '// Make running
                    NewVersion = .GetNextRunning("LineDefVersionNo", MasterID)
                    '// Cloning
                    oSql = "exec " + CWTMasterDB.Util.StandardDB("sp_CSP_CreateNewVersion_History") + " " + MasterID + "," _
                           + VersionID + "," _
                           + VersionNumber + "," _
                           + NewVersion + "," _
                           + CWTMasterDB.Util.LimitTheString(UserID)
                    .ExecuteCommand(oSql, SqlBuilder.SQLParserExecuteType.ExecuteNonQuery)
                    CallProcedure(MasterID, VersionNumber, "Update", "sp_CSP_LineDefVersion")
                End With
                Me.MySQLParser.CommitTran()
            Catch ex As Exception
                EffectRow = -1
                Me.MySQLParser.RollbackTran()
            Finally
                Me.MySQLParser.CloseConnection()
            End Try
            Return EffectRow
        End Function

        Public Function GetLineDefMasterList() As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = CWTMasterDB.Util.StandardDB("tblCSP_LineDefMaster")
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("*")
                End With
                dt = .ExecuteDataTable(.SQLSelect + " Order by LineDefName")
            End With
            Return dt
        End Function

        Public Function GetGDSMappingByClientID(ByVal KeyID As String, ByVal ClientID As String) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = CWTMasterDB.Util.StandardDB("tblCSP_LineDefClientMapping")
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("ConfigInstanceKeyID", KeyID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("*")
                End With
                dt = .ExecuteDataTable(.SQLSelect + " Order by MappingID")
            End With
            Return dt
        End Function

        Public Function UpdateGDSMapping(ByVal info As DataInfo.GDSMappingClientInfo) As Integer
            Dim EffectRow As Integer = 1
            Dim oDataTable As DataTable
            Dim GDSMapDT As DataTable
            Dim MappingID As String
            Try
                MappingID = GetLastMappingID()
                GDSMapDT = GetGDSMappingByClientID(info.ConfigInstanceKeyID, info.ClientID)
                With Me.MySQLParser
                    '.OpenConnection()
                    '.BeginTran()
                    .TableName = CWTMasterDB.Util.StandardDB("tblCSP_LineDefClientMapping")
                    '//
                    With .Columns
                        .Clear()
                        .Add("ConfigInstanceKeyID", info.ConfigInstanceKeyID, SqlBuilder.SQLParserDataType.spNum, True)
                        .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                    End With
                    .ExecuteDelete()


                    For i As Integer = 0 To info.Profiles.Count - 1
                        If info.Profiles(i).ProfilePCC = "" OrElse info.Profiles(i).ProfileName = "" Then
                            Continue For
                        End If
                        oDataTable = Me.CheckDuplicate(info.Profiles(i).ProfilePCC, info.Profiles(i).ProfileName, info.ConfigInstanceKeyID)

                        If oDataTable IsNot Nothing AndAlso oDataTable.Rows.Count > 0 Then
                            EffectRow = -50
                            Me.MySQLParser.RollbackTran()

                            Exit Try

                        Else
                            With .Columns
                                .Clear()
                                '.Add("MappingID", i + 1, SqlBuilder.SQLParserDataType.spNum)
                                .Add("ConfigInstanceKeyID", info.ConfigInstanceKeyID, SqlBuilder.SQLParserDataType.spNum)
                                .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum)
                                .Add("DummyBar", info.DummyBar, SqlBuilder.SQLParserDataType.spText)
                                .Add("ProfilePCC", info.Profiles(i).ProfilePCC)
                                .Add("ProfileName", info.Profiles(i).ProfileName)
                                .Add("LineDefMasterID", info.Profiles(i).LineDefID)
                                .Add("Preferred", info.Profiles(i).Preferred)
                            End With
                            EffectRow = .ExecuteInsert()
                            If EffectRow <= 0 Then
                                Exit For
                            End If
                        End If
                    Next
                End With
                MatchLineDefRecord(GDSMapDT, info, MappingID)
                If EffectRow > 0 Then
                    Me.MySQLParser.CommitTran()
                Else
                    Me.MySQLParser.RollbackTran()
                End If
            Catch ex As Exception
                EffectRow = -1
                Me.MySQLParser.RollbackTran()
            Finally
                Me.MySQLParser.CloseConnection()
            End Try
            Return EffectRow

        End Function

        Private Sub CallProcedure(ByVal MasterID As String, ByVal VersionNumber As String, ByVal Type As String, ByVal StoreProdType As String)
            With Me.MySQLParser
                If StoreProdType = "sp_CSP_LineDefVersion" Then
                    .ExecuteStoreProcedure("exec " + CWTMasterDB.Util.StandardDBForStoredProcedure(StoreProdType) + " '" + MasterID + "','" + VersionNumber + "','" + ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName + "','" + Type + "'")
                Else
                    .ExecuteStoreProcedure("exec " + CWTMasterDB.Util.StandardDBForStoredProcedure(StoreProdType) + " '" + MasterID + "','" + ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName + "','" + Type + "'")
                End If

            End With
        End Sub

        Public Function CheckDuplicate(ByVal profilePCC As String, ByVal profileName As String, ByVal configID As Integer) As DataTable
            Dim dt As DataTable
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = CWTMasterDB.Util.StandardDB("tblCSP_LineDefClientMapping")
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("ConfigInstanceKeyID", configID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("ProfilePCC", profilePCC, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("ProfileName", profileName, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("*")
                End With
                dt = .ExecuteDataTable(.SQLSelect + " Order by MappingID")
            End With
            Return dt
        End Function

        Private Sub MatchLineDefRecord(ByVal ClientLineDefDT As DataTable, ByVal info As DataInfo.GDSMappingClientInfo, ByVal MappingID As String)
            Dim countDT As Integer
            Dim countInfo As Integer
            Dim checkMatch As Boolean
            Dim effectRow As Integer

            If ClientLineDefDT.Rows.Count > 0 Then
                For countDT = 0 To ClientLineDefDT.Rows.Count - 1
                    checkMatch = CheckLineDefExists(ClientLineDefDT.Rows(countDT), info)
                    If checkMatch = False Then
                        For countInfo = 0 To info.Profiles.Count - 1
                            If ClientLineDefDT.Rows(countDT).Item("ConfigInstanceKeyID").ToString() = info.ConfigInstanceKeyID AndAlso ClientLineDefDT.Rows(countInfo).Item("ClientID").ToString() = info.ClientID Then
                                With Me.MySQLParser
                                    .TableName = CWTMasterDB.Util.StandardDB("Temp_tblCSP_LineDefClientMapping")
                                    With .Columns
                                        .Clear()
                                        .Add("MappingID", ClientLineDefDT.Rows(countDT).Item("MappingID").ToString(), SqlBuilder.SQLParserDataType.spNum)
                                        .Add("ConfigInstanceKeyID", ClientLineDefDT.Rows(countDT).Item("ConfigInstanceKeyID").ToString(), SqlBuilder.SQLParserDataType.spNum)
                                        .Add("ClientID", ClientLineDefDT.Rows(countDT).Item("ClientID").ToString(), SqlBuilder.SQLParserDataType.spNum)
                                        .Add("DummyBar", ClientLineDefDT.Rows(countDT).Item("DummyBar").ToString())
                                        .Add("LineDefMasterID", ClientLineDefDT.Rows(countDT).Item("LineDefMasterID").ToString(), SqlBuilder.SQLParserDataType.spNum)
                                        .Add("ProfilePCC", ClientLineDefDT.Rows(countDT).Item("ProfilePCC").ToString())
                                        .Add("ProfileName", ClientLineDefDT.Rows(countDT).Item("ProfileName").ToString())
                                        .Add("Preferred", ClientLineDefDT.Rows(countDT).Item("Preferred").ToString())
                                        .Add("DateModification", DateTime.Now)
                                        .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                        If ClientLineDefDT.Rows(countDT).Item("ProfilePCC").ToString() <> "" And info.Profiles(countDT).ProfilePCC = "" And ClientLineDefDT.Rows(countDT).Item("ProfileName").ToString() <> "" And info.Profiles(countDT).ProfileName = "" Then
                                            .Add("ValueTypeChanged", "Delete")
                                        Else  'And ClientLineDefDT.Rows(countDT).Item("ProfilePCC").ToString() <> info.Profiles(countInfo).ProfilePCC And info.Profiles(countInfo).ProfilePCC <> "" And ClientLineDefDT.Rows(countDT).Item("ProfileName").ToString() <> info.Profiles(countInfo).ProfileName And info.Profiles(countInfo).ProfileName <> ""
                                            .Add("ValueTypeChanged", "Update")
                                        End If
                                    End With
                                    effectRow = .ExecuteInsert()
                                    Exit For
                                End With
                            End If
                        Next countInfo
                    End If
                Next countDT
            End If

            If info.Profiles.Count > countDT Then
                MappingID = MappingID + countDT
                For countInfo = countDT To info.Profiles.Count - 1
                    If info.Profiles(countInfo).ProfilePCC <> "" AndAlso info.Profiles(countInfo).ProfileName <> "" Then
                        With Me.MySQLParser
                            .TableName = CWTMasterDB.Util.StandardDB("Temp_tblCSP_LineDefClientMapping")
                            With .Columns
                                .Clear()
                                MappingID = MappingID + 1
                                .Add("MappingID", MappingID, SqlBuilder.SQLParserDataType.spNum)
                                .Add("ConfigInstanceKeyID", info.ConfigInstanceKeyID, SqlBuilder.SQLParserDataType.spNum)
                                .Add("ClientID", info.ClientID, SqlBuilder.SQLParserDataType.spNum)
                                .Add("DummyBar", info.DummyBar)
                                .Add("LineDefMasterID", info.Profiles(countInfo).LineDefID)
                                .Add("ProfilePCC", info.Profiles(countInfo).ProfilePCC)
                                .Add("ProfileName", info.Profiles(countInfo).ProfileName)
                                .Add("Preferred", info.Profiles(countInfo).Preferred)
                                .Add("DateModification", DateTime.Now)
                                .Add("UserName", ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
                                .Add("ValueTypeChanged", "Insert")
                            End With
                            effectRow = .ExecuteInsert()
                        End With
                    End If
                Next countInfo
            End If
        End Sub

        Private Function GetLastMappingID()
            Dim MappingID As String
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = CWTMasterDB.Util.StandardDB("tblCSP_LineDefClientMapping")
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("max(MappingID)")
                End With
                MappingID = .ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar, CommandType.Text)
            End With
            Return MappingID
        End Function

        Private Function CheckLineDefExists(ByVal row As DataRow, ByVal info As DataInfo.GDSMappingClientInfo) As Boolean
            Dim check As Boolean
            Dim countInfo As Integer

            For countInfo = 0 To info.Profiles.Count - 1
                If row.Item("ConfigInstanceKeyID").ToString() = info.ConfigInstanceKeyID AndAlso row.Item("DummyBar").ToString() = info.DummyBar AndAlso row.Item("ClientID").ToString() = info.ClientID AndAlso row.Item("LineDefMasterID").ToString() = info.Profiles(countInfo).LineDefID AndAlso row.Item("ProfilePCC").ToString() = info.Profiles(countInfo).ProfilePCC AndAlso row.Item("ProfileName").ToString() = info.Profiles(countInfo).ProfileName AndAlso row.Item("Preferred").ToString() = info.Profiles(countInfo).Preferred Then
                    check = True
                    Exit For
                End If
            Next countInfo
            Return check
        End Function

        Public Function GetLineMasterIDByName(ByVal Name As String) As String
            Dim retVal As String
            Dim retObj As Object
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = CWTMasterDB.Util.StandardDB("tblCSP_LineDefMaster")
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("LineDefName", Name, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("LineDefMasterID")
                End With
                retObj = .ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar, CommandType.Text)
                retVal = Util.DBNullToText(retObj)
            End With
            Return retVal
        End Function

        Public Function GetTempLineDef(Optional ByVal LineDefName As String = "", Optional ByVal dateFrom As String = "", Optional ByVal dateTo As String = "") As DataSet
            Dim ds As New DataSet

            Dim LineMDT As DataTable
            Dim TempLineMDT As DataTable
            Dim LineMMasterDT As DataTable

            Dim LineVDT As DataTable
            Dim TempLineVDT As DataTable
            Dim LineVMasterDT As DataTable

            Dim LineDefDT As DataTable
            Dim TempLineDefDT As DataTable
            Dim LineDefMasterDT As DataTable

            Dim LineMasterID As String = ""
            Dim TempTable As DataTable
            Dim LineIDArr(0) As String
            Dim LineVIDArr(0) As String
            Dim LineDefArr(1) As String

            Dim count As Integer
            Dim count2 As Integer
            Dim foundRow() As DataRow

            LineIDArr(0) = "LineDefMasterID"
            LineVIDArr(0) = "LineDefMasterID"
            'LineVIDArr(1) = "LineDefVersionID"
            LineDefArr(0) = "LineDefVersionID"
            LineDefArr(1) = "LineNumber"
            If LineDefName <> "" Then
                LineMasterID = GetLineMasterIDByName(LineDefName)
            End If

            With Me.MySQLParser
                .TableName = CWTMasterDB.Util.StandardDB("Temp_tblCSP_LineDefMaster")
                With .Columns
                    .Clear()
                    If LineDefName <> "" Then
                        .Add("LineDefName", LineDefName, SqlBuilder.SQLParserDataType.spText, True)
                    End If
                    If dateFrom = dateTo Then
                        If dateFrom <> "" And dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:990"
                            .Add("DateModification", "convert(varchar,cast('" + dateFrom + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, ">")
                            .Add("DateModification", "convert(varchar,cast('" + dateTo + " 23:59:59:990" + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, "<")
                        End If
                    Else
                        If dateFrom <> "" Then
                            .Add("DateModification", dateFrom, SqlBuilder.SQLParserDataType.spDate, True, ">")
                        End If
                        If dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:990"
                            .Add("DateModification", dateTo + " 23:59:59:990", SqlBuilder.SQLParserDataType.spText, True, "<=")
                        End If
                    End If
                    .Add("*")
                End With
                TempLineMDT = .ExecuteDataTable(.SQLSelect + " order by DateModification Desc")

                .TableName = CWTMasterDB.Util.StandardDB("tblCSP_LineDefMaster")
                With .Columns
                    .Clear()
                    If LineDefName <> "" Then
                        .Add("LineDefName", LineDefName, SqlBuilder.SQLParserDataType.spText, True)
                    End If
                    .Add("*")
                End With
                LineMDT = .ExecuteDataTable()

                TempTable = TempLineMDT.DefaultView.ToTable(True, LineIDArr)
                LineMMasterDT = TempLineMDT.Clone()
                For count = 0 To TempTable.Rows.Count - 1
                    foundRow = LineMDT.Select("LineDefMasterID='" + TempTable.Rows(count).Item("LineDefMasterID").ToString() + "'")
                    If foundRow.Length > 0 Then
                        For count2 = 0 To foundRow.Length - 1
                            LineMMasterDT.ImportRow(foundRow(count2))
                        Next count2
                    End If
                Next
                LineMMasterDT.AcceptChanges()
                LineMMasterDT.Merge(TempLineMDT)
                LineMMasterDT.TableName = "LineDefMaster"
                ds.Tables.Add(LineMMasterDT)


                .TableName = CWTMasterDB.Util.StandardDB("Temp_tblCSP_LineDefVersion")
                With .Columns
                    .Clear()
                    If LineMasterID <> "" Then
                        .Add("LineDefMasterID", LineMasterID, SqlBuilder.SQLParserDataType.spNum, True)
                    End If
                    If dateFrom = dateTo Then
                        If dateFrom <> "" And dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:990"
                            .Add("DateModification", "convert(varchar,cast('" + dateFrom + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, ">")
                            .Add("DateModification", "convert(varchar,cast('" + dateTo + " 23:59:59:990" + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, "<")
                        End If
                    Else
                        If dateFrom <> "" Then
                            .Add("DateModification", dateFrom, SqlBuilder.SQLParserDataType.spDate, True, ">")
                        End If
                        If dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:990"
                            .Add("DateModification", dateTo + " 23:59:59:990", SqlBuilder.SQLParserDataType.spText, True, "<=")
                        End If
                    End If
                    .Add("*")
                End With
                TempLineVDT = .ExecuteDataTable(.SQLSelect + " order by DateModification Desc")

                .TableName = CWTMasterDB.Util.StandardDB("tblCSP_LineDefVersion") + " t1 inner join (select LineDefMasterID,Max(VersionNumber) As MaxNumber from" + CWTMasterDB.Util.StandardDB("tblCSP_LineDefVersion") + " Group by LineDefMasterID) grouptt on t1.LineDefMasterID= grouptt.LineDefMasterID and grouptt.MaxNumber=t1.VersionNumber"
                With .Columns
                    .Clear()
                    If LineMasterID <> "" Then
                        .Add("t1.LineDefMasterID", LineMasterID, SqlBuilder.SQLParserDataType.spNum, True)
                    End If
                    .Add("*")
                End With
                LineVDT = .ExecuteDataTable()

                TempTable = TempLineVDT.DefaultView.ToTable(True, LineVIDArr)
                LineVMasterDT = TempLineVDT.Clone()
                For count = 0 To TempTable.Rows.Count - 1
                    foundRow = LineVDT.Select("LineDefMasterID='" + TempTable.Rows(count).Item("LineDefMasterID").ToString() + "'") '+ "' and LineDefVersionID='" + TempTable.Rows(count).Item("LineDefVersionID").ToString() + "'
                    If foundRow.Length > 0 Then
                        For count2 = 0 To foundRow.Length - 1
                            LineVMasterDT.ImportRow(foundRow(count2))
                        Next count2
                    End If
                Next
                LineVMasterDT.AcceptChanges()
                LineVMasterDT.Merge(TempLineVDT)
                LineVMasterDT.TableName = "LineDefVersion"
                ds.Tables.Add(LineVMasterDT)


                '//Line Def
                .TableName = CWTMasterDB.Util.StandardDB("Temp_tblCSP_LineDef") + " d inner join " + CWTMasterDB.Util.StandardDB("tblCSP_LineDefVersion") + " v on d.LineDefVersionID = v.LineDefVersionID inner join " + CWTMasterDB.Util.StandardDB("tblCSP_DataType") + " dt on dt.DataTypeValue = d.DataTypeValue"
                With .Columns
                    .Clear()
                    If LineMasterID <> "" Then
                        .Add("v.LineDefMasterID", LineMasterID, SqlBuilder.SQLParserDataType.spNum, True)
                    End If
                    If dateFrom = dateTo Then
                        If dateFrom <> "" And dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:990"
                            .Add("d.DateModification", "convert(varchar,cast('" + dateFrom + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, ">")
                            .Add("d.DateModification", "convert(varchar,cast('" + dateTo + " 23:59:59:990" + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, "<")
                        End If
                    Else
                        If dateFrom <> "" Then
                            .Add("d.DateModification", dateFrom, SqlBuilder.SQLParserDataType.spDate, True, ">")
                        End If
                        If dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:990"
                            .Add("d.DateModification", dateTo + " 23:59:59:990", SqlBuilder.SQLParserDataType.spText, True, "<=")
                        End If
                    End If
                    .Add("d.LineDefID,d.LineDefVersionID,d.LineNumber,d.MoveType,d.SecondaryInd,dt.GDSFormat,d.Qualifier,d.FormatString,d.DateModification,d.UserName,d.ValueTypeChanged")
                End With
                TempLineDefDT = .ExecuteDataTable(.SQLSelect + " order by DateModification Desc")


                .TableName = CWTMasterDB.Util.StandardDB("tblCSP_LineDef") + " d inner join " + CWTMasterDB.Util.StandardDB("tblCSP_LineDefVersion") + " v on d.LineDefVersionID = v.LineDefVersionID inner join " + CWTMasterDB.Util.StandardDB("tblCSP_DataType") + " dt on dt.DataTypeValue = d.DataTypeValue"
                With .Columns
                    .Clear()
                    If LineMasterID <> "" Then
                        .Add("v.LineDefMasterID", LineMasterID, SqlBuilder.SQLParserDataType.spNum, True)
                    End If
                    .Add("d.LineDefID,d.LineDefVersionID,d.LineNumber,d.MoveType,d.SecondaryInd,dt.GDSFormat,d.Qualifier,d.FormatString")
                End With
                LineDefDT = .ExecuteDataTable()

                TempTable = TempLineDefDT.DefaultView.ToTable(True, LineDefArr)
                LineDefMasterDT = TempLineDefDT.Clone()
                For count = 0 To TempTable.Rows.Count - 1
                    foundRow = LineDefDT.Select("LineDefVersionID='" + TempTable.Rows(count).Item("LineDefVersionID").ToString() + "' and LineNumber='" + TempTable.Rows(count).Item("LineNumber").ToString() + "'")
                    If foundRow.Length > 0 Then
                        For count2 = 0 To foundRow.Length - 1
                            LineDefMasterDT.ImportRow(foundRow(count2))
                        Next count2
                    End If
                Next
                LineDefMasterDT.AcceptChanges()
                LineDefMasterDT.Merge(TempLineDefDT)
                LineDefMasterDT.TableName = "LineDef"
                ds.Tables.Add(LineDefMasterDT)

            End With
            Return ds
        End Function

        Public Function GetTempGDSMapping(Optional ByVal ClientName As String = "", Optional ByVal dateFrom As String = "", Optional ByVal dateTo As String = "") As DataSet
            '//GDS Mapping
            Dim GDSDT As DataTable
            Dim TempGDSDT As DataTable
            Dim GDSMasterDT As DataTable

            Dim ClientID As String = ""
            Dim TempTable As DataTable
            Dim ClientIDArr(0) As String
            Dim count As Integer
            Dim count2 As Integer
            Dim ds As New DataSet
            Dim foundRow() As DataRow

            ClientIDArr(0) = "ClientID"

            '//Get ClientID 
            If ClientName <> "" Then
                ClientID = GetClientIDByName(ClientName)
            End If
            With Me.MySQLParser
                .TableName = CWTMasterDB.Util.StandardDB("Temp_tblCSP_LineDefClientMapping")
                With .Columns
                    .Clear()
                    If ClientName <> "" Then
                        If ClientID <> "" Then
                            .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        Else
                            .Add("ClientID", "-1", SqlBuilder.SQLParserDataType.spNum, True)
                        End If
                    End If
                    If dateFrom = dateTo Then
                        If dateFrom <> "" And dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:990"
                            .Add("DateModification", "convert(varchar,cast('" + dateFrom + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, ">")
                            .Add("DateModification", "convert(varchar,cast('" + dateTo + " 23:59:59:990" + "' As datetime),121)", SqlBuilder.SQLParserDataType.spFunction, True, "<")
                        End If
                    Else
                        If dateFrom <> "" Then
                            .Add("DateModification", dateFrom, SqlBuilder.SQLParserDataType.spDate, True, ">")
                        End If
                        If dateTo <> "" Then
                            'dateTo = dateTo + " 23:59:59:990"
                            .Add("DateModification", dateTo + " 23:59:59:990", SqlBuilder.SQLParserDataType.spText, True, "<=")
                        End If
                    End If
                    .Add("ConfigInstanceKeyID", ServiceLogicLayer.DACSLL.CurrentKeyID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("*")
                End With
                TempGDSDT = .ExecuteDataTable(.SQLSelect + " order by DateModification Desc")

                .TableName = CWTMasterDB.Util.StandardDB("tblCSP_LineDefClientMapping")
                With .Columns
                    .Clear()
                    If ClientName <> "" Then
                        If ClientID <> "" Then
                            .Add("ClientID", ClientID, SqlBuilder.SQLParserDataType.spNum, True)
                        Else
                            .Add("ClientID", "-1", SqlBuilder.SQLParserDataType.spNum, True)
                        End If
                    End If
                    .Add("ConfigInstanceKeyID", ServiceLogicLayer.DACSLL.CurrentKeyID, SqlBuilder.SQLParserDataType.spNum, True)
                    .Add("*")
                End With
                GDSDT = .ExecuteDataTable()


                TempTable = TempGDSDT.DefaultView.ToTable(True, ClientIDArr)
                GDSMasterDT = TempGDSDT.Clone()
                For count = 0 To TempTable.Rows.Count - 1
                    foundRow = GDSDT.Select("ClientID='" + TempTable.Rows(count).Item("ClientID").ToString() + "'")
                    If foundRow.Length > 0 Then
                        For count2 = 0 To foundRow.Length - 1
                            GDSMasterDT.ImportRow(foundRow(count2))
                        Next count2
                    End If
                Next
                GDSMasterDT.AcceptChanges()
                GDSMasterDT.Merge(TempGDSDT)
                GDSMasterDT.TableName = "GDS"
                ds.Tables.Add(GDSMasterDT)
            End With
            Return ds
        End Function

        Public Function GetClientIDByName(ByVal ClientName As String) As String
            Dim retVal As String
            Dim retObj As Object
            With Me.MySQLParser
                .AutoParameter = False
                .TableName = "tblClientMaster"
                With .Columns
                    .IncludeKey = False
                    .Clear()
                    .Add("Name", ClientName, SqlBuilder.SQLParserDataType.spText, True)
                    .Add("ClientID")
                End With
                retObj = .ExecuteCommand(.SQLSelect, SqlBuilder.SQLParserExecuteType.ExecuteScalar, CommandType.Text)
                retVal = Util.DBNullToText(retObj)
            End With
            Return retVal
        End Function
    End Class
End Namespace


@


1.1.1.1
log
@no message
@
text
@@
