head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.04.58;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.04.58;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Public Partial Class TestLinkedDB
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Private Sub Button1_Click1(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim oSql As String = ""
        oSql = "select TOP 10 * from " + Util.TravComDB("Profiles")
        Dim dt As New DataTable()
        Dim conn As String
        conn = "Data Source=10.180.27.10;Initial Catalog=CWTMasterDB;Persist Security Info=True;User ID=cwtmaster;Password=cwtmaster123;"
        Dim MySQLParser As New SqlBuilder.SQLParser(conn)
        With MySQLParser
            dt = .ExecuteDataTable(oSql)
        End With
        With Me.GridView1
            .AutoGenerateColumns = True
            .DataSource = dt
            .DataBind()
        End With
    End Sub

End Class@


1.1.1.1
log
@no message
@
text
@@
