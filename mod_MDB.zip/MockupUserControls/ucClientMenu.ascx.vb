head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.24;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.24;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@
Partial Class MockupUserControls_ucClientMenu
    Inherits BaseUserControl

    Private BLL1 As BusinessLogicLayer.StaffBLL
    Private BLL2 As New BusinessLogicLayer.tblFunctionBLL()



    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load


        Dim userName As String
        Dim oDatatable As DataTable
        Dim oDataTable2 As DataTable
        Dim BLL1 As New BusinessLogicLayer.StaffBLL()
        Static roleID As String
        Dim parentId1, parentId2, parentId3, parentId4, parentId5, parentId6, parentId7, parentId8, parentId9 As String


        


        '    For i As Integer = 0 To Me.MenuCWT.Items.Count - 1
        '        If Me.MenuCWT.Items(i).Text = "User" Then
        '            Me.MenuCWT.Items.Remove(Me.MenuCWT.Items(i))
        '            Exit For
        '        Else
        '            Continue For
        '        End If
        '    Next






        If ServiceLogicLayer.CompanySLL.CurrentCompany Is Nothing OrElse ServiceLogicLayer.CompanySLL.CurrentCompany = "" Then
            Me.NavMenuClientNoneSelect.Visible = True
            Me.NavMenuClient.Visible = False
        Else
            Me.NavMenuClientNoneSelect.Visible = False
            Me.NavMenuClient.Visible = True
            Call Me.FilterMenu()

            userName = ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName
            oDatatable = BLL1.GetUserByID(userName)
            If oDatatable.Rows.Count > 0 Then
                roleID = oDatatable.Rows(0).Item("RoleID").ToString
            End If

            oDataTable2 = Me.BLL2.GetUserRole(roleID)
            If oDataTable2.Rows.Count > 0 Then
                For k As Integer = 0 To oDataTable2.Rows.Count - 1
                    If oDataTable2.Rows(k).Item("functionGroup") = "1" Then
                        If oDataTable2.Rows(k).Item("Permission") = "N" Then
                            If oDataTable2.Rows(k).Item("ParentID").ToString = "2" Then
                                Continue For
                            Else
                                If oDataTable2.Rows(k).Item("ParentID").ToString = "IF" Then
                                    parentId1 = "Information"
                                    Call Me.RemoveMenu(oDataTable2.Rows(k).Item("functionName").ToString, parentId1)

                                ElseIf oDataTable2.Rows(k).Item("ParentID").ToString = "BO" Then
                                    parentId2 = "Back Office"
                                    Call Me.RemoveMenu(oDataTable2.Rows(k).Item("functionName").ToString, parentId2)

                                ElseIf oDataTable2.Rows(k).Item("ParentID").ToString = "RPT" Then
                                    parentId3 = "Reporting"
                                    Call Me.RemoveMenu(oDataTable2.Rows(k).Item("functionName").ToString, parentId3)

                                ElseIf oDataTable2.Rows(k).Item("ParentID").ToString = "PA" Then
                                    parentId4 = "Policy - Air"
                                    Call Me.RemoveMenu(oDataTable2.Rows(k).Item("functionName").ToString, parentId4)

                                ElseIf oDataTable2.Rows(k).Item("ParentID").ToString = "PH" Then
                                    parentId5 = "Policy - Hotel"
                                    Call Me.RemoveMenu(oDataTable2.Rows(k).Item("functionName").ToString, parentId5)

                                ElseIf oDataTable2.Rows(k).Item("ParentID").ToString = "PC" Then
                                    parentId6 = "Policy - Car"
                                    Call Me.RemoveMenu(oDataTable2.Rows(k).Item("functionName").ToString, parentId6)

                                ElseIf oDataTable2.Rows(k).Item("ParentID").ToString = "PAUX" Then
                                    parentId7 = "Policy - Aux"
                                    Call Me.RemoveMenu(oDataTable2.Rows(k).Item("functionName").ToString, parentId7)

                                ElseIf oDataTable2.Rows(k).Item("ParentID").ToString = "PR" Then
                                    parentId8 = "Pricing"
                                    Call Me.RemoveMenu(oDataTable2.Rows(k).Item("functionName").ToString, parentId8)

                                ElseIf oDataTable2.Rows(k).Item("ParentID").ToString = "GN" Then
                                    parentId9 = "General"
                                    Call Me.RemoveMenu(oDataTable2.Rows(k).Item("functionName").ToString, parentId9)
                                End If



                                'Call Me.RemoveMenu(oDataTable2.Rows(k).Item("functionName").ToString)
                            End If

                        End If
                    End If

                Next

            End If

        End If
    End Sub

    Private Sub RemoveMenu(ByVal functionName As String, ByVal parentID As String)
        Dim iMenu As MenuItem
        iMenu = Me.NavMenuClient.FindItem(parentID + "/" + functionName)
        iMenu.Enabled = False

    End Sub

    Private Sub FilterMenu()
        Dim BLL = New BusinessLogicLayer.CompanyReportBLL()
        Dim iMenu As MenuItem
        iMenu = Me.NavMenuClient.FindItem("Reporting/Client Reporting")
        If Not BLL.GetClientDefineReport(Me.CurrentClientID) Then
            iMenu.Enabled = False
        Else
            iMenu.Enabled = True
        End If
        '//
        iMenu = Me.NavMenuClient.FindItem("Reporting/ReasonCode")
        If Not BLL.GetStandardReport(Me.CurrentClientID) Then
            iMenu.Enabled = False
        Else
            iMenu.Enabled = True
        End If
    End Sub

End Class
@


1.1.1.1
log
@no message
@
text
@@
