head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.24;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.24;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@
Partial Class MockupUserControls_ucCWTMenu
    Inherits System.Web.UI.UserControl

    Private BLL As BusinessLogicLayer.StaffBLL
    Private BLL2 As New BusinessLogicLayer.tblFunctionBLL()

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If (Not Page.IsPostBack) Then
            Dim userName As String
            Dim oDatatable As DataTable
            Dim oDataTable2 As DataTable
            Dim BLL As New BusinessLogicLayer.StaffBLL()
            Static roleID As String


            userName = ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName
            oDatatable = BLL.GetUserByID(userName)
            If oDatatable.Rows.Count > 0 Then
                roleID = oDatatable.Rows(0).Item("RoleID").ToString
            End If

            oDataTable2 = Me.BLL2.GetUserRole(roleID)
            If oDataTable2.Rows.Count > 0 Then
                For k As Integer = 0 To oDataTable2.Rows.Count - 1
                    If oDataTable2.Rows(k).Item("functionGroup") = "0" Then
                        If oDataTable2.Rows(k).Item("Permission") = "N" Then
                            Call Me.RemoveMenu(oDataTable2.Rows(k).Item("functionName").ToString)
                        End If
                    End If

                Next

            End If



            '    For i As Integer = 0 To Me.MenuCWT.Items.Count - 1
            '        If Me.MenuCWT.Items(i).Text = "User" Then
            '            Me.MenuCWT.Items.Remove(Me.MenuCWT.Items(i))
            '            Exit For
            '        Else
            '            Continue For
            '        End If
            '    Next

           

        End If
    End Sub

    Private Sub RemoveMenu(ByVal name As String)

        Dim menuItem As String

        menuItem = name
        For i As Integer = 0 To Me.MenuCWT.Items.Count - 1
            If Me.MenuCWT.Items(i).Text.ToUpper = menuItem.ToUpper Then
                Me.MenuCWT.Items.Remove(Me.MenuCWT.Items(i))
                Exit For
            Else
                Continue For
            End If
        Next

    End Sub

End Class
@


1.1.1.1
log
@no message
@
text
@@
