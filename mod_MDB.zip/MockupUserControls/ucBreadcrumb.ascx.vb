head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.24;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.24;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Partial Public Class ucBreadcrumb
    Inherits BaseUserControl

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Call Me.LoadLinkList()
            If Me.GetFunctionGroup = Util.TabNameType.ClientData Then
                If ServiceLogicLayer.CompanySLL.CurrentCompany Is Nothing OrElse ServiceLogicLayer.CompanySLL.CurrentCompany = "" Then
                    Me.litSelectedCompany.Text = ""
                Else
                    Dim CompanyName As String
                    Dim BLL As New BusinessLogicLayer.CompanyBLL()
                    CompanyName = BLL.GetClientNameByID(Me.CurrentClientID)
                    Me.litSelectedCompany.Text = "<b>Current company:</b> <a href='CompanyUpdateManager.aspx'>" + CompanyName + "</a>"
                End If
            End If
        End If
    End Sub

    Private Sub LoadLinkList()
        Dim BLL As New BusinessLogicLayer.tblFunctionBLL()
        Dim oDataTable As DataTable
        Dim FunctionID As Integer
        Dim url As String
        Dim wmode As String = ""
        url = Util.GetCurrentURL()
        FunctionID = BLL.GetFunctionIDByUrl(url)
        If Me.Request("wmode") IsNot Nothing Then
            wmode = Me.Request("wmode")
        End If
        oDataTable = BLL.GetLinkList(FunctionID, wmode)
        With Me.rptBreadcrumb
            .DataSource = oDataTable
            .DataBind()
        End With
    End Sub

    Private Sub rptBreadcrumb_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.RepeaterItemEventArgs) Handles rptBreadcrumb.ItemDataBound
        If e.Item.ItemType <> ListItemType.Item AndAlso e.Item.ItemType <> ListItemType.AlternatingItem Then
            Exit Sub
        End If
        Dim href As CWTCustomControls.CWTHyperLink
        Dim lbl As CWTCustomControls.CWTLabel
        href = e.Item.FindControl("hrefLink")
        lbl = e.Item.FindControl("lbLink")
        If DataBinder.Eval(e.Item.DataItem, "LinkURL") = "" Then
            href.Visible = False
            lbl.Visible = True
        Else
            href.Visible = True
            lbl.Visible = False
        End If
    End Sub

End Class@


1.1.1.1
log
@no message
@
text
@@
