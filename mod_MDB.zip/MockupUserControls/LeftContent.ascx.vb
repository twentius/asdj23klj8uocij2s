head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.24;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.24;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@
Partial Class MockupUserControls_LeftContent
    Inherits BaseUserControl

    Public ReadOnly Property MenuTab() As Util.TabNameType
        Get
            Return Me.GetFunctionGroup
        End Get
    End Property

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If ServiceLogicLayer.ProfilerSLL.CurrentProfile Is Nothing Then
            Response.Redirect(Util.GetAppConfig("RootPath") + "/Login.aspx", True)
            Exit Sub
        End If
        Me.lblUserName.Text = ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName
        Call Me.LoadMenu()
    End Sub

    Private Sub LoadMenu()
        Select Case Me.MenuTab
            Case Util.TabNameType.ClientData
                Me.UcCWTMenu1.Visible = False
                Me.UcClientMenu1.Visible = True
                'Me.NavMenuSupplier.Visible = False
                'Me.NavMenuStandard.Visible = False
            Case Util.TabNameType.Supplier
                Me.UcCWTMenu1.Visible = False
                Me.UcClientMenu1.Visible = False
                'Me.NavMenuSupplier.Visible = True
                'Me.NavMenuStandard.Visible = False
            Case Util.TabNameType.StandardData
                Me.UcCWTMenu1.Visible = False
                Me.UcClientMenu1.Visible = False
                'Me.NavMenuSupplier.Visible = False
                'Me.NavMenuStandard.Visible = True
            Case Else
                Me.UcCWTMenu1.Visible = True
                Me.UcClientMenu1.Visible = False
                'Me.NavMenuSupplier.Visible = False
                'Me.NavMenuStandard.Visible = False
        End Select
    End Sub

End Class
@


1.1.1.1
log
@no message
@
text
@@
