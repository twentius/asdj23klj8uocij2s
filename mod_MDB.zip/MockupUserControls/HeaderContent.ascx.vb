head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.24;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.24;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@
Partial Class MockupUserControls_HeaderContent
    Inherits System.Web.UI.UserControl

    Public Property NoMenu() As Boolean
        Get
            Dim retVal As Boolean = False
            If Me.ViewState("NoMenu") IsNot Nothing Then
                retVal = Me.ViewState("NoMenu")
            End If
            Return retVal
        End Get
        Set(ByVal value As Boolean)
            Me.ViewState("NoMenu") = value
        End Set
    End Property

End Class
@


1.1.1.1
log
@no message
@
text
@@
