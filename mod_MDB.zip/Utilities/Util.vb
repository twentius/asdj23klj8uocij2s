head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.55;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.55;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports Microsoft.VisualBasic
Imports System.Globalization

Public Class Util

    Public Enum TabNameType
        CWTData
        ClientData
        Supplier
        StandardData
    End Enum

    Public Shared Function GetAppConfig(ByVal key As String) As String
        Dim retVal As String
        retVal = ConfigurationManager.AppSettings.Item(key)
        Return retVal
    End Function

    Public Shared Function DBNullToZero(ByVal data As Object) As Double
        Dim retVal As Double = 0
        If IsNumeric(data) Then
            retVal = CDbl(data)
        End If
        Return retVal
    End Function

    Public Shared Function DBNullToFalse(ByVal data As Object) As Boolean
        Dim retVal As Boolean = False
        If data Is Nothing OrElse IsDBNull(data) Then
            retVal = False
        Else
            retVal = CBool(data)
        End If
        Return retVal
    End Function

    Public Shared Function getDateEng(ByVal input As String, Optional ByVal HaveTime As Boolean = False) As String
        Dim dt As Date = Convert.ToDateTime(input)
        Dim ci As New CultureInfo("en-US")
        If (HaveTime) Then
            Return dt.ToString("dd/MM/yyyy HH:mm:ss", ci)
        Else
            Return dt.ToString("dd/MM/yyyy", ci)
        End If
    End Function

    Public Shared Function LimitTheString(ByVal SomeString As String) As String
        Return "'" & (SomeString & "").Replace("'", "''") & "'"
    End Function

    Public Shared Function TravComDB(ByVal TableName As String) As String
        Dim retVal As String = ""
        Dim svr As String = GetAppConfig("TravComSvr")
        If svr = ServiceLogicLayer.DACSLL.CurrentServer Then
            retVal = "[" + GetAppConfig("TravComDatabase") + "].[" + GetAppConfig("TravComDBUsrName") + "].[" + TableName + "]"
        Else
            retVal = "[" + svr + "].[" + GetAppConfig("TravComDatabase") + "].[" + GetAppConfig("TravComDBUsrName") + "].[" + TableName + "]"
        End If
        Return retVal
    End Function

    Public Shared Function TravComDB2(ByVal TableName As String) As String
        Dim retVal As String = ""
        Dim svr As String = GetAppConfig("TravComSvr") '"SWSNG1XSQL01" '
        If svr = ServiceLogicLayer.DACSLL.CurrentServer Then
            retVal = "[" + GetAppConfig("TravComDatabase2") + "].[" + GetAppConfig("TravComDBUsrName") + "].[" + TableName + "]"
        Else
            retVal = "[" + svr + "].[" + GetAppConfig("TravComDatabase2") + "].[" + GetAppConfig("TravComDBUsrName") + "].[" + TableName + "]"
        End If
        Return retVal
    End Function


    Public Shared Function TravComDB3(ByVal TableName As String) As String
        Dim retVal As String = ""
        Dim svr As String = GetAppConfig("TravComSvr")
        If svr = ServiceLogicLayer.DACSLL.CurrentServer Then
            retVal = "[" + GetAppConfig("TravComDatabase3") + "].[" + GetAppConfig("TravComDBUsrName") + "].[" + TableName + "]"
        Else
            retVal = "[" + svr + "].[" + GetAppConfig("TravComDatabase3") + "].[" + GetAppConfig("TravComDBUsrName") + "].[" + TableName + "]"
        End If
        Return retVal
    End Function

    Public Shared Function StandardDB(ByVal TableName As String) As String
        Dim retVal As String = ""
        Dim svr As String = GetAppConfig("StdSvr")
        If svr = ServiceLogicLayer.DACSLL.CurrentServer Then
            retVal = "[" + GetAppConfig("StdDatabase") + "].[" + GetAppConfig("StdDBUsrName") + "].[" + TableName + "]"
        Else
            retVal = "[" + svr + "].[" + GetAppConfig("StdDatabase") + "].[" + GetAppConfig("StdDBUsrName") + "].[" + TableName + "]"
        End If
        Return retVal
    End Function

    Public Shared Function StandardDBForStoredProcedure(ByVal SP As String) As String
        Dim retVal As String = ""
        Dim svr As String = GetAppConfig("StdSvr")
        If svr = ServiceLogicLayer.DACSLL.CurrentServer Then
            retVal = "[" + GetAppConfig("StdDatabase") + "].[" + GetAppConfig("StdDBUsrName") + "].[" + SP + "]"
        Else
            retVal = "[" + svr + "].[" + GetAppConfig("StdDatabase") + "].[" + GetAppConfig("StdDBUsrName") + "].[" + SP + "]"
        End If
        Return retVal
    End Function

    Public Shared Function DBNullToText(ByVal data As Object, Optional ByVal NullText As String = "", Optional ByVal ReplaceEmpty As Boolean = True) As String
        Dim retVal As String = ""
        If data Is Nothing OrElse (ReplaceEmpty AndAlso data.ToString = String.Empty) Then
            retVal = NullText
        Else
            retVal = data.ToString
        End If
        Return retVal
    End Function

    Public Shared Function CreateConnection(ByVal svr As String, ByVal db As String, ByVal usr As String, ByVal pwd As String) As String
        Dim pwdMaster As New Securities.DataEncryption()
        Dim cn As String = ""
        Dim dcPwd As String = ""
        dcPwd = pwdMaster.DecryptText(pwd)
        cn = CWTMasterDB.Util.GetAppConfig("ConnectionString")
        cn = cn.Replace("[SVR_NAME]", svr)
        cn = cn.Replace("[DB_NAME]", db)
        cn = cn.Replace("[USR_NAME]", usr)
        cn = cn.Replace("[USR_PWD]", dcPwd)
        Return cn
    End Function

    Public Shared Function GetCurrentURL() As String
        Dim url As String
        url = HttpContext.Current.Request.ServerVariables("SCRIPT_NAME").Replace(CWTMasterDB.Util.GetAppConfig("RootPath"), "")
        Return url
    End Function

    Public Shared Function GetCurrentIP() As String
        Dim url As String
        url = HttpContext.Current.Request.ServerVariables("REMOTE_ADDR")
        Return url
    End Function

#Region "ClientScript - Javascript"
    Public Enum ClientScriptRegistType
        RegScriptBlock
        RegStartUpBlock
    End Enum
    Public Enum MsgType
        TRANS_SUCCESS
        TRANS_ERROR
    End Enum
    Public Shared Sub RegClientScript(ByVal JsScript As String, ByVal ScriptName As String, Optional ByVal RegistType As ClientScriptRegistType = ClientScriptRegistType.RegScriptBlock)
        Dim CSManager As ClientScriptManager
        Dim oJSBuilder As New System.Text.StringBuilder()
        Dim oExePage As Page = CType(HttpContext.Current.Handler, Page)
        '//  Check Running Page 
        If oExePage Is Nothing Then
            Exit Sub
        End If
        With oJSBuilder
            .AppendLine(JsScript)
        End With
        CSManager = oExePage.ClientScript
        With CSManager
            Select Case RegistType
                Case ClientScriptRegistType.RegScriptBlock
                    If Not .IsClientScriptBlockRegistered(ScriptName) Then
                        .RegisterClientScriptBlock(oExePage.GetType, ScriptName, JsScript.ToString(), True)
                    End If
                Case ClientScriptRegistType.RegStartUpBlock
                    If Not .IsStartupScriptRegistered(ScriptName) Then
                        .RegisterStartupScript(oExePage.GetType, ScriptName, JsScript.ToString(), True)
                    End If
            End Select
        End With
    End Sub

    Public Shared Function JSEncode(ByVal Text As String) As String
        Dim ReturnValue As String = ""
        If Text <> "" Then
            ReturnValue = Replace(Text, "'", "\'")
            ReturnValue = ReturnValue.Replace("\", "\\")
        End If
        Return ReturnValue
    End Function

    Public Shared Sub AlertBox(ByVal msg As String, Optional ByVal RedirectAfterAlert As Boolean = False, Optional ByVal RedirectURL As String = "")
        Dim ClientScript As New System.Text.StringBuilder
        ClientScript.AppendLine("alert('" + JSEncode(msg) + "');")
        If RedirectAfterAlert Then
            ClientScript.AppendLine("location.href='" + RedirectURL + "';")
        End If
        Call RegClientScript(ClientScript.ToString, "MSGBOX_SCRIPT", ClientScriptRegistType.RegStartUpBlock)
    End Sub
    Public Shared Sub AlertBox(ByVal type As MsgType, ByVal msg As String, Optional ByVal RedirectAfterAlert As Boolean = False, Optional ByVal RedirectURL As String = "")
        msg = GetAppConfig(type.ToString) + msg
        Dim ClientScript As New System.Text.StringBuilder
        ClientScript.AppendLine("alert('" + JSEncode(msg) + "');")
        If RedirectAfterAlert Then
            ClientScript.AppendLine("location.href='" + RedirectURL + "';")
        End If
        Call RegClientScript(ClientScript.ToString, "MSGBOX_SCRIPT", ClientScriptRegistType.RegStartUpBlock)
    End Sub
#End Region

End Class
@


1.1.1.1
log
@no message
@
text
@@
