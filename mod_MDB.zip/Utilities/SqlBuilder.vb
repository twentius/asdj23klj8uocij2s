head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.55;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.55;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports System.ComponentModel
Imports System.Data.SqlClient

Namespace SqlBuilder
    Public Enum SQLParserDataType
        spText
        spNum
        spBoolean
        spDate
        spFunction
        spTime
    End Enum

    Public Enum SQLParserExecuteType
        ExecuteNonQuery
        ExecuteScalar
    End Enum

    <DefaultProperty("Name")> _
    Public Class Column
        Private _Name As String = ""
        Private _Value As String
        Private _IsKey As Boolean = False
        Private _Type As Int32
        Private _Operator As String = "="
        Private _DataType As SQLParserDataType = SQLParserDataType.spText
        Private _AllowHTML As Boolean = False
        Private _TextEmptyIsNull As Boolean = True

        Public Property Name() As String
            Get
                Return _Name
            End Get
            Set(ByVal Value As String)
                _Name = Value
            End Set
        End Property

        Public Property DataType() As SQLParserDataType
            Get
                Return _DataType
            End Get
            Set(ByVal Value As SQLParserDataType)
                _DataType = Value
            End Set
        End Property

        Public Property IsKey() As Boolean
            Get
                Return _IsKey
            End Get
            Set(ByVal Value As Boolean)
                _IsKey = Value
            End Set
        End Property

        Public Property Value() As String
            Get
                Return _Value & ""
            End Get
            Set(ByVal oValue As String)
                _Value = oValue
            End Set
        End Property

        Public Property SqlOperator() As String
            Get
                If Me._Operator = "" Then
                    Me._Operator = "="
                End If
                Return Me._Operator
            End Get
            Set(ByVal value As String)
                Me._Operator = value
            End Set
        End Property

        Public Property AllowHTML() As Boolean
            Get
                Return _AllowHTML
            End Get
            Set(ByVal Value As Boolean)
                _AllowHTML = Value
            End Set
        End Property

        Public Property TextEmptyIsNull() As Boolean
            Get
                Return _TextEmptyIsNull
            End Get
            Set(ByVal Value As Boolean)
                _TextEmptyIsNull = Value
            End Set
        End Property

        Public ReadOnly Property SQLValue() As String
            Get
                Dim tmpValue As String = CStr(Value & "")
                Select Case DataType
                    Case SQLParserDataType.spNum
                        If tmpValue.Length = 0 Then
                            Return "Null"
                        Else
                            If IsNumeric(tmpValue) Then
                                Return tmpValue.Replace(",", String.Empty)
                            Else
                                Throw New System.Exception(tmpValue.ToString() & " type miss match")
                            End If
                        End If
                    Case SQLParserDataType.spBoolean
                        If tmpValue.Length = 0 Then
                            Diagnostics.Debug.WriteLine("tmpValue.length=0")
                            Return "0"
                        Else
                            If tmpValue.ToLower = "true" Then
                                Return "1"
                            Else
                                If tmpValue.ToLower = "false" Then
                                    Return "0"
                                Else
                                    If CBool(tmpValue) Then
                                        Return "1"
                                    Else
                                        Return "0"
                                    End If
                                End If
                            End If
                        End If
                    Case SQLParserDataType.spDate
                        If IsDate(Value) Then
                            Return LimitTheDate(Format(CDate(Value), "dd/MMM/yyyy"))
                        Else
                            Return "Null"
                        End If
                    Case SQLParserDataType.spText
                        If (tmpValue & "").Length = 0 And Me._TextEmptyIsNull Then
                            Return "Null"
                        Else
                            If Not Me.AllowHTML Then
                                '// Add by M - 13 Aug 2008 for HTML reason
                                tmpValue = tmpValue.Replace("<", "&lt;")
                                tmpValue = tmpValue.Replace(">", "&gt;")
                            End If
                            '//
                            Return LimitTheString(CStr(tmpValue))
                        End If
                    Case SQLParserDataType.spFunction
                        Return Convert.ToString(tmpValue)
                    Case SQLParserDataType.spTime
                        If IsDate(Value) Then
                            Return String.Concat("'", CStr(Value).Split(" ")(1), "'")
                        Else
                            Return "Null"
                        End If
                    Case Else
                        Return LimitTheString(CStr(tmpValue))
                End Select
            End Get
        End Property

        Public Function LimitTheString(ByVal SomeString As String) As String
            Return "'" & (SomeString & "").Replace("'", "''") & "'"
        End Function
        Public Function LimitTheNumber(ByVal SomeString As String, Optional ByVal ReturnZero As Boolean = True) As String
            Dim strDefalutReturn As String = ""
            If ReturnZero Then
                strDefalutReturn = "0"
            End If
            If (SomeString & "").Length = 0 Then
                Return strDefalutReturn
            Else
                If IsNumeric(SomeString) Then
                    Return SomeString.Replace(",", String.Empty)
                Else
                    Return strDefalutReturn
                End If
            End If
        End Function
        Public Function LimitTheDate(ByVal SomeString As String) As String
            'Return "TO_DATE(" & LimitTheString(SomeString) & ",'dd/mon/yyyy')"
            If IsDate(SomeString) Then
                Return LimitTheString(Format(CDate(SomeString), "MM/dd/yyyy"))
            Else
                Return LimitTheString(SomeString)
            End If
        End Function
        Public Function LimitTheBoolean(ByVal Bool As Object) As String
            Dim strDefalutReturn As String = ""
            If TypeOf (Bool) Is Boolean Then
                If Bool Then
                    strDefalutReturn = "T"
                Else
                    strDefalutReturn = "F"
                End If
            Else
                strDefalutReturn = Bool.ToString()
            End If
            Return strDefalutReturn
        End Function
    End Class

    <Serializable()> Public Class Columns
        Inherits System.Collections.CollectionBase

        Private _includeKey As Boolean = True

        Public Overloads Function Add(ByVal oColumn As Column) As Column
            List.Add(oColumn)
            Return oColumn
        End Function

        Public Overloads Function Add(ByVal strName As String) As Column
            Return Add(strName, "")
        End Function

        Public Overloads Function Add(ByVal strName As String, ByVal objValue As Object, Optional ByVal DataType As SQLParserDataType = SQLParserDataType.spText, Optional ByVal IsKeyColumn As Boolean = False, Optional ByVal SqlOperator As String = "", Optional ByVal AllowHTML As Boolean = False, Optional ByVal TextEmptyIsNull As Boolean = True) As Column
            Dim oColumn As New Column()
            oColumn.Name = strName
            oColumn.Value = objValue
            oColumn.DataType = DataType
            oColumn.IsKey = IsKeyColumn
            oColumn.SqlOperator = SqlOperator
            oColumn.AllowHTML = AllowHTML
            oColumn.TextEmptyIsNull = TextEmptyIsNull
            List.Add(oColumn)
            Return oColumn
        End Function

        Public Sub Remove(ByVal index As Integer)
            If index > Count - 1 Or index < 0 Then
                'No item 2 remove
            Else
                List.RemoveAt(index)
            End If
        End Sub

        Public Property IncludeKey() As Boolean
            Get
                Return _includeKey
            End Get
            Set(ByVal Value As Boolean)
                _includeKey = Value
            End Set
        End Property

        Public ReadOnly Property Item(ByVal index As Integer) As Column
            Get
                Return CType(List.Item(index), Column)
            End Get
        End Property

        Public ReadOnly Property ListName() As String
            Get
                Dim strBuffer As String = ""
                Dim iCount As Integer
                For iCount = 0 To List.Count - 1
                    If (IncludeKey And Item(iCount).IsKey) Or Not (Item(iCount).IsKey) Then
                        strBuffer += ", " & Item(iCount).Name
                    End If
                Next
                Return Microsoft.VisualBasic.Mid(strBuffer, 2)
            End Get
        End Property

        Public ReadOnly Property ListSQLValue() As String
            Get
                Dim strBuffer As String = ""
                Dim iCount As Integer
                For iCount = 0 To List.Count - 1
                    If (IncludeKey And Item(iCount).IsKey) Or Not (Item(iCount).IsKey) Then
                        strBuffer += ", " & Item(iCount).SQLValue
                    End If
                Next
                Return Microsoft.VisualBasic.Mid(strBuffer, 2)
            End Get
        End Property

        Public ReadOnly Property ListBoth() As String
            Get
                Dim strOperator As String = "="
                Dim strBuffer As String = ""
                Dim iCount As Integer
                For iCount = 0 To List.Count - 1
                    If (IncludeKey And Item(iCount).IsKey) Or Not (Item(iCount).IsKey) Then
                        If (IncludeKey And Item(iCount).IsKey) AndAlso Item(iCount).SqlOperator <> "" Then
                            strOperator = Item(iCount).SqlOperator
                        End If
                        strBuffer += ", " & Item(iCount).Name & " " & strOperator & " " & Item(iCount).SQLValue
                    End If
                Next
                Return Microsoft.VisualBasic.Mid(strBuffer, 2)
            End Get
        End Property
    End Class

    Public Class SQLParser
        Private _Columns As New Columns()
        Private _TableName As String = ""
        Private _AutoParameter As Boolean = False
        Private _Connection As SqlConnection
        Private _oTransaction As SqlTransaction
        Public ConnectionString As String = ""
        Public _RollBackWhenError As Boolean = False

        Public Property ItemTransaction() As SqlTransaction
            Get
                Return _oTransaction
            End Get
            Set(ByVal Value As SqlTransaction)
                _oTransaction = Value
            End Set
        End Property

        Public ReadOnly Property Columns() As Columns
            Get
                Return CType(_Columns, Columns)
            End Get
        End Property

        Public Property TableName() As String
            Get
                Return _TableName
            End Get
            Set(ByVal Value As String)
                _TableName = Value
            End Set
        End Property

        Public Property AutoParameter() As Boolean
            Get
                Return _AutoParameter
            End Get
            Set(ByVal Value As Boolean)
                _AutoParameter = Value
            End Set
        End Property

        Public Property RollBackWhenError() As Boolean
            Get
                Return _RollBackWhenError
            End Get
            Set(ByVal Value As Boolean)
                _RollBackWhenError = Value
            End Set
        End Property

        Public Sub New()
            '_Connection = New SqlConnection()
        End Sub

        Public Sub New(ByVal ConnectionString As String)
            '_Connection = New SqlConnection(ConnectionString)
            Me.ConnectionString = ConnectionString
        End Sub

        Public ReadOnly Property SQLSelect() As String
            Get
                If AutoParameter Then
                    Columns.IncludeKey = True
                End If
                Dim strTemp1 As String = "select " + Columns.ListName + " from " + TableName & " WHERE "
                Dim strTemp2 As String = ""
                Dim oColumn As Column
                For Each oColumn In Columns
                    If oColumn.IsKey Then
                        If oColumn.SqlOperator = "In" Then
                            strTemp2 &= "and " & oColumn.Name & " " & oColumn.SqlOperator & "( " & oColumn.SQLValue & ") "
                        Else
                            strTemp2 &= "and " & oColumn.Name & " " & oColumn.SqlOperator & " " & oColumn.SQLValue & " "
                        End If

                    End If
                Next
                If strTemp2 <> "" Then
                    strTemp1 = strTemp1 & Mid(strTemp2, 4)
                Else
                    strTemp1 = strTemp1.Replace(" WHERE ", "")
                End If
                'System.Diagnostics.Debug.WriteLine("+++SQLParser.SQLUpdate:" & strTemp1)
                Return strTemp1
            End Get
        End Property

        Public ReadOnly Property SQLInsert() As String
            Get
                If AutoParameter Then
                    Columns.IncludeKey = True
                End If
                Dim strTemp As String = "INSERT INTO " & TableName & "(" & Columns.ListName & ") VALUES (" & Columns.ListSQLValue & ")"
                'System.Diagnostics.Debug.WriteLine("+++SQLParser.SQLInsert:" & strTemp)
                Return strTemp
            End Get
        End Property

        Public ReadOnly Property SQLUpdate() As String
            Get
                If AutoParameter Then
                    Columns.IncludeKey = False
                End If
                Dim strTemp1 As String = "UPDATE " & TableName & " SET " & Columns.ListBoth & " WHERE "
                Dim strTemp2 As String = ""
                Dim oColumn As Column
                For Each oColumn In Columns
                    If oColumn.IsKey Then
                        strTemp2 &= "and " & oColumn.Name & " " & oColumn.SqlOperator & " " & oColumn.SQLValue & " "
                    End If
                Next
                strTemp1 = strTemp1 & Mid(strTemp2, 4)
                'System.Diagnostics.Debug.WriteLine("+++SQLParser.SQLUpdate:" & strTemp1)
                Return strTemp1
            End Get
        End Property

        Public ReadOnly Property SQLDelete() As String
            Get
                Dim strTemp1 As String = "DELETE FROM " & TableName & " WHERE "
                Dim strTemp2 As String = ""
                Dim oColumn As Column
                For Each oColumn In Columns
                    If oColumn.IsKey = True Then
                        strTemp2 &= "and " & oColumn.Name & " " & oColumn.SqlOperator & " " & oColumn.SQLValue & " "
                        'Else
                        '	If oColumn.Value <> "" Then
                        '		strTemp2 &= "and " & oColumn.Name & "=" & oColumn.SQLValue & " "
                        '	End If
                    End If
                Next
                strTemp1 = strTemp1 & Mid(strTemp2, 4)
                'System.Diagnostics.Debug.WriteLine("+++SQLParser.SQLDelete:" & strTemp1)
                Return strTemp1
            End Get
        End Property

        Public ReadOnly Property SQLDeleteAll() As String
            Get
                Dim strTemp1 As String = "DELETE FROM " & TableName
                Return strTemp1
            End Get
        End Property

        Public Function ExecuteInsert() As Integer
            Return ExecuteCommand(SQLInsert)
        End Function

        Public Function ExecuteUpdate() As Integer
            Return ExecuteCommand(SQLUpdate)
        End Function

        Public Function ExecuteDelete() As Integer
            Return ExecuteCommand(SQLDelete)
        End Function

        Public Function ExecuteDeleteAll() As Integer
            Return ExecuteCommand(SQLDeleteAll)
        End Function

        Public Sub ExecuteStoreProcedure(ByVal strSQL As String)
            Dim oCommand As New SqlCommand
            Dim HaveConnection As Boolean = True
            Dim ReturnValue As Object = Nothing
            'Dim SPParam() As String = param.Split(New Char() {","c})
            'Dim para As String
            If Not Me.ItemTransaction Is Nothing Then
                With oCommand
                    .Connection = Me.ItemTransaction.Connection
                    .Transaction = Me.ItemTransaction
                    .CommandText = strSQL
                    Try
                        ReturnValue = .ExecuteNonQuery()
                    Catch ExecException As Exception
                        If Me.RollBackWhenError Then
                            Me.ItemTransaction.Rollback()
                        End If
                        Throw New Exception(ExecException.Message & vbCrLf & vbCrLf & strSQL)
                    End Try
                End With
            Else
                If Me._Connection Is Nothing Then
                    Me._Connection = New SqlConnection(Me.ConnectionString)
                    HaveConnection = False
                End If
                With Me._Connection
                    .Open()
                End With
                oCommand = Me._Connection.CreateCommand()

                With oCommand
                    .CommandText = strSQL
                    Try
                        ReturnValue = .ExecuteNonQuery()
                    Catch ExecException As Exception
                        If Me.RollBackWhenError Then
                            Me.ItemTransaction.Rollback()
                            Throw New Exception(ExecException.Message & vbCrLf & vbCrLf & strSQL)
                        End If
                    Finally
                        'If Not HaveConnection Then
                        With Me._Connection
                            If .State = ConnectionState.Open Then
                                .Close()
                            End If
                        End With
                        'End If

                    End Try
                End With
            End If


        End Sub

        Public Function ExecuteCommand(ByVal strSQL As String, Optional ByVal ExecuteType As SQLParserExecuteType = SQLParserExecuteType.ExecuteNonQuery, Optional ByVal CommandExeType As CommandType = CommandType.Text) As Object
            Dim oCommand As New SqlCommand
            Dim CanInsertLog As Boolean = True
            Dim ReturnValue As Object = Nothing
            Dim HaveConnection As Boolean = True
            If Not Me.ItemTransaction Is Nothing Then
                'oCommand = Me.ItemTransaction.Connection.CreateCommand()
                With oCommand
                    .Connection = Me.ItemTransaction.Connection
                    .Transaction = Me.ItemTransaction
                    .CommandType = CommandExeType 'CommandType.Text
                    .CommandText = strSQL
                    Try
                        Select Case ExecuteType
                            Case SQLParserExecuteType.ExecuteNonQuery
                                ReturnValue = .ExecuteNonQuery()
                            Case SQLParserExecuteType.ExecuteScalar
                                ReturnValue = .ExecuteScalar()
                        End Select
                    Catch ExecException As Exception
                        If Me.RollBackWhenError Then
                            Me.ItemTransaction.Rollback()
                        End If
                        Throw New Exception(ExecException.Message & vbCrLf & vbCrLf & strSQL)
                    End Try
                End With
            Else
                If Me._Connection Is Nothing Then
                    Me._Connection = New SqlConnection(Me.ConnectionString)
                    HaveConnection = False
                End If
                With Me._Connection
                    .Open()
                End With
                oCommand = Me._Connection.CreateCommand()

                With oCommand
                    .CommandType = CommandExeType 'CommandType.Text
                    .CommandText = strSQL
                    Try
                        Select Case ExecuteType
                            Case SQLParserExecuteType.ExecuteNonQuery
                                ReturnValue = .ExecuteNonQuery()
                            Case SQLParserExecuteType.ExecuteScalar
                                ReturnValue = .ExecuteScalar()
                        End Select
                    Catch ExecException As Exception
                        Throw New Exception(ExecException.Message & vbCrLf & vbCrLf & strSQL)
                    Finally
                        'If Not HaveConnection Then
                        With Me._Connection
                            If .State = ConnectionState.Open Then
                                .Close()
                            End If
                        End With
                        'End If

                    End Try
                End With
            End If
            Return ReturnValue
        End Function

        Public Function ExecuteDataTable() As DataTable
            Return ExecuteDataTable(Me.SQLSelect())
        End Function
        Public Function ExecuteDataTable(ByVal oSql As String) As DataTable
            Dim dt As New DataTable
            Dim da As New SqlDataAdapter
            Dim CanExe As Boolean = True
            Dim oCommand As New SqlCommand
            If Not Me.ItemTransaction Is Nothing Then
                Try
                    'oCommand = Me.ItemTransaction.Connection.CreateCommand()
                    With oCommand
                        .Connection = Me.ItemTransaction.Connection
                        .Transaction = Me.ItemTransaction
                        .CommandType = CommandType.Text
                        .CommandText = oSql
                    End With
                    da.SelectCommand = oCommand
                    da.Fill(dt)
                Catch ex As Exception
                    CanExe = False
                    dt = New DataTable()
                End Try
            Else
                Try
                    If Me._Connection Is Nothing Then
                        Me._Connection = New SqlConnection(Me.ConnectionString)
                    End If
                    With Me._Connection
                        .Open()
                    End With
                    oCommand = Me._Connection.CreateCommand()
                    With oCommand
                        .CommandType = CommandType.Text
                        .CommandText = oSql
                    End With
                    da.SelectCommand = oCommand
                    da.Fill(dt)
                Catch ex As Exception
                    CanExe = False
                    dt = New DataTable()
                Finally
                    With Me._Connection
                        If .State = ConnectionState.Open Then
                            .Close()
                        End If
                    End With
                End Try
            End If
            Return dt
        End Function

        Public Function GetLastIdentity() As String
            Dim oSql As String = "SELECT @@@@IDENTITY AS 'Identity'"
            Return Me.ExecuteCommand(oSql, SQLParserExecuteType.ExecuteScalar).ToString
        End Function

        Public Function GetNextRunning(ByVal RunningName As String, Optional ByVal Keyname As String = "") As String
            Dim retVal As String = ""
            Dim oDataTable As DataTable
            Dim r As DataRow
            Dim FormatString As String
            Dim Pattern As String
            Dim CurrentRunning As Integer = 0
            Dim spName As String = "sp_System_GetRunning"
            Dim oSql As String = "exec " + CWTMasterDB.Util.StandardDB(spName) + " " + CWTMasterDB.Util.LimitTheString(RunningName) + "," + CWTMasterDB.Util.LimitTheString(Keyname)
            oDataTable = Me.ExecuteDataTable(oSql)
            If oDataTable IsNot Nothing AndAlso oDataTable.Rows.Count > 0 Then
                r = oDataTable.Rows(0)
                CurrentRunning = CWTMasterDB.Util.DBNullToZero(r("CurrentRunning"))
                FormatString = r("FormatString").ToString
                Pattern = r("Pattern").ToString
                retVal = Format(CurrentRunning, FormatString)
                retVal = retVal.Replace("$", Pattern)
            End If
            Return retVal
        End Function

        Public Sub OpenConnection()
            If Me._Connection Is Nothing OrElse Me._Connection.State = ConnectionState.Closed Then
                Me._Connection = New SqlConnection(Me.ConnectionString)
                With Me._Connection
                    .Open()
                End With
            End If
        End Sub

        Public Sub CloseConnection()
            If Me._Connection IsNot Nothing AndAlso Me._Connection.State = ConnectionState.Open Then
                If Me._oTransaction IsNot Nothing Then
                    Me._oTransaction = Nothing
                End If
                With Me._Connection
                    .Close()
                End With
            End If
        End Sub

        Public Sub BeginTran()
            Me._oTransaction = Me._Connection.BeginTransaction()
        End Sub

        Public Sub CommitTran()
            If Me._oTransaction IsNot Nothing Then
                Me._oTransaction.Commit()
            End If
        End Sub

        Public Sub RollbackTran()
            If Me._oTransaction IsNot Nothing Then
                Me._oTransaction.Rollback()
            End If
        End Sub

    End Class
End Namespace
@


1.1.1.1
log
@no message
@
text
@@
