head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.04.58;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.04.58;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@
Partial Class Test
    Inherits System.Web.UI.Page

    Private _tbl As String = ""
    Private _tbl2 As String = ""
    Private _tbl3 As String = ""
    Private _ol As Boolean = False
    Private _OnDup As Boolean = False

    Public Function GetTableName(ByVal tbl As String) As String
        If _tbl <> tbl Then
            _tbl = tbl
            _OnDup = False
            Return _tbl
        Else
            _OnDup = True
            Return ""
        End If
    End Function

    Public Function GetTableName2(ByVal tbl As String) As String
        If _tbl2 <> tbl Then
            _tbl2 = tbl
            Return _tbl2
        Else
            Return ""
        End If
    End Function

    Public Function GetTableName3(ByVal tbl As String) As String
        If _tbl3 <> tbl Then
            _tbl3 = tbl
            Return "block"
        Else
            Return "none"
        End If
    End Function

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim oSql As String = "select TableName,Colname,Remarks,Datatype,isnull(cast(prec as nvarchar(10)),'')+isnull(','+cast(scale as nvarchar(10)),'') as Length,Nullable,Primarykey from vDataDict where TableName not like '%no use' order by TableName,PrimaryKey DESC"
        Dim x As New BaseDA()
        Dim oDatatable As DataTable
        oDatatable = x.MySQLParser.ExecuteDataTable(oSql)
        With Me.Repeater1
            .DataSource = oDatatable
            .DataBind()
        End With
    End Sub

    Protected Sub Repeater1_DataBinding(ByVal sender As Object, ByVal e As System.EventArgs) Handles Repeater1.DataBinding

    End Sub

    Protected Sub Repeater1_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.RepeaterItemEventArgs) Handles Repeater1.ItemDataBound
        'If e.Item.ItemType <> ListItemType.Item Then
        '    Exit Sub
        'End If
        'If _OnDup Then
        '    Exit Sub
        'End If
        'Dim x As PlaceHolder
        'x = e.Item.FindControl("xxx")
        'If x Is Nothing Then
        '    Exit Sub
        'End If
        'Dim g As New xxx
        'g.tblName = DataBinder.Eval(e.Item.DataItem, "TableName")
        'g.LoadControl("tset.ascx")
        'g.Attributes.Add("tblName", DataBinder.Eval(e.Item.DataItem, "TableName"))
        'x.Controls.Add(g)
    End Sub

End Class
@


1.1.1.1
log
@no message
@
text
@@
