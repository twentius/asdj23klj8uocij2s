head	1.2;
access;
symbols
	arelease:1.1.1.1
	avendor:1.1.1;
locks; strict;
comment	@# @;


1.2
date	2014.08.13.03.54.06;	author UJXI098;	state Exp;
branches;
next	1.1;
deltatype	text;
permissions	666;
commitid	13e453eae15d0000;
kopt	kv;
filename	@Login.aspx.vb@;

1.1
date	2013.04.15.02.04.58;	author ujxa393;	state Exp;
branches
	1.1.1.1;
next	;
deltatype	text;
permissions	666;

1.1.1.1
date	2013.04.15.02.04.58;	author ujxa393;	state Exp;
branches;
next	;
deltatype	text;
permissions	666;


desc
@@


1.2
log
@check the user if AUAS or CWT domain
@
text
@Imports System.DirectoryServices
Imports System.DirectoryServices.DirectoryEntry
Imports System.DirectoryServices.DirectorySearcher
Imports System.DirectoryServices.SearchResultCollection
Imports System.DirectoryServices.SearchResult
Imports System.DirectoryServices.ResultPropertyCollection
Imports System.DirectoryServices.PropertyValueCollection


Partial Class Login
    Inherits System.Web.UI.Page
    'Inherits BasePage
    Dim allLogs As String

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Me.lblError.Text = ""
            Me.lblError.Visible = False
            Call Me.LoadServer()
        End If

    End Sub

    Private Function AuthenUser() As Boolean

        Dim usrPWD As String
        Dim usrName As String

        Dim nat As Object
        Dim retVal As Boolean = False
        Dim BLL As New BusinessLogicLayer.StaffBLL()
        usrName = Me.txtUserName.Text
        usrPWD = Me.txtPassword.Text

        If BLL.IsExistUser(usrName) Then
            Try
                allLogs = allLogs & "userdomain: AUASCARLSON" & vbCrLf
                Me.Session("_dirEntry") = New DirectoryEntry(CWTMasterDB.Util.GetAppConfig("ADServerNameAUAS"), usrName, usrPWD)
                nat = CType(Me.Session("_dirEntry"), DirectoryEntry).NativeObject
                retVal = True
            Catch
                Try
                    allLogs = allLogs & "userdomain: CWT" & vbCrLf
                    Me.Session("_dirEntry") = New DirectoryEntry(CWTMasterDB.Util.GetAppConfig("ADServerNameCWT"), usrName, usrPWD)
                    nat = CType(Me.Session("_dirEntry"), DirectoryEntry).NativeObject
                    retVal = True
                Catch ex As Exception
                    retVal = False
                    allLogs = allLogs & ex.ToString & vbCrLf
                End Try
            End Try
        End If
        Return retVal
    End Function


    Private Sub SignOn()
        Call Me.PrepareConnection()
        If Me.AuthenUser() Then
            Try
                ServiceLogicLayer.ProfilerSLL.LogOnProfile(Me.txtUserName.Text)
                Response.Redirect("Default.aspx", True)
                lblError2.Text = allLogs
            Catch ex As Exception
                allLogs = allLogs & ex.ToString & vbCrLf
                lblError2.Text = allLogs
            End Try
        Else
            Me.lblError.Text = "incorrect log in or password"
            Me.lblError.Visible = True
        End If
    End Sub

    Private Sub LoadServer()
        Dim oDataTable As DataTable
        Dim ServerBLL As New BusinessLogicLayer.DatabaseBLL()
        oDataTable = ServerBLL.GetServer()
        With Me.ddlCountry
            .DataTextField = "DisplayTxt"
            .DataValueField = "KeyID"
            .DataSource = oDataTable
            .DataBind()
        End With
    End Sub

    Private Sub PrepareConnection()
        Dim oDataTable As DataTable
        Dim svr As String
        Dim db As String
        Dim usr As String
        Dim pwd As String
        Dim key As String
        Dim KeyID As String
        Dim ServerBLL As New BusinessLogicLayer.DatabaseBLL()
        key = Me.ddlCountry.SelectedValue
        oDataTable = ServerBLL.GetConnectionInfo(key)
        Session("CONN_KeyID") = key
        If oDataTable IsNot Nothing AndAlso oDataTable.Rows.Count > 0 Then
            KeyID = oDataTable.Rows(0).Item("KeyID").ToString
            svr = oDataTable.Rows(0).Item("ServerID").ToString
            db = oDataTable.Rows(0).Item("DBName").ToString
            usr = oDataTable.Rows(0).Item("UserName").ToString
            pwd = oDataTable.Rows(0).Item("Password").ToString
            Call ServiceLogicLayer.DACSLL.SetConfigKeyID(KeyID)
            Call ServiceLogicLayer.DACSLL.SetConnection(svr, db, usr, pwd)
        End If
    End Sub

    Protected Sub btnLogin_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnLogin.Click
        Try
            Call Me.SignOn()
            lblError2.Text = allLogs
        Catch ex As Exception

        End Try
    End Sub

End Class
@


1.1
log
@Initial revision
@
text
@d9 1
d13 1
d29 1
a31 1
     
a34 2


a35 2
            'Dim dirEntry As New DirectoryEntry(CWTMasterDB.Util.GetAppConfig("ADServerName"), usrName, usrPWD)
            Me.Session("_dirEntry") = New DirectoryEntry(CWTMasterDB.Util.GetAppConfig("ADServerName"), usrName, usrPWD)
d37 2
a38 1
                Dim nat As Object
a39 2
                'nat = dirEntry.NativeObject
                'System.Diagnostics.Debug.Print(UserExists("cwtadmin").ToString)
d42 9
a50 1

a53 1
        'Return True
d56 1
d60 8
a67 2
            ServiceLogicLayer.ProfilerSLL.LogOnProfile(Me.txtUserName.Text)
            Response.Redirect("Default.aspx", True)
d112 1
@


1.1.1.1
log
@no message
@
text
@@
