head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.04.58;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.04.58;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@
Partial Class tset
    Inherits xxx


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Me.tblName = "" Then
            Me.l.Visible = False
            Me.h.Visible = False
            Exit Sub
        End If
        Dim oSql As String = ""
        Dim x As New BaseDA()
        oSql = "sp_MShelpindex N'" + Me.tblName + "', null, 1"
        Dim oDataTable As DataTable
        oDataTable = x.MySQLParser.ExecuteDataTable(oSql)
        Me.GridView1.AutoGenerateColumns = True
        Me.GridView1.DataSource = oDataTable
        Me.GridView1.DataBind()
        Me.l.Text = "<br><br><b>Indexes</b><br>"
        Me.l.Visible = True
        Me.h.Text = "<hr size=1 color=black style='border:black dashed thin 1px;'>"
        Me.h.Visible = True
    End Sub

End Class

Public Class xxx
    Inherits System.Web.UI.UserControl


    Public Property tblName() As String
        Get
            Return Me.ViewState("tblName").ToString()
        End Get
        Set(ByVal value As String)
            Me.ViewState("tblName") = value
        End Set
    End Property

End Class
@


1.1.1.1
log
@no message
@
text
@@
