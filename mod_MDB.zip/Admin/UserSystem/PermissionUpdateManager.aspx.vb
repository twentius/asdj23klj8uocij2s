head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.04.58;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.04.58;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Partial Class Admin_UserSystem_PermissionUpdateManager
    Inherits BasePage

#Region "Properties"
    Public ReadOnly Property RoleID() As String
        Get
            Return Convert.ToString(Request.QueryString("roleid"))
        End Get
    End Property
    Public Property dtData1() As DataTable
        Get
            Return ViewState("dt")
        End Get
        Set(ByVal value As DataTable)
            ViewState("dt") = value
        End Set
    End Property
    Public Property dtData2() As DataTable
        Get
            Return ViewState("dt")
        End Get
        Set(ByVal value As DataTable)
            ViewState("dt") = value
        End Set
    End Property
    Public Property dtData3() As DataTable
        Get
            Return ViewState("dt")
        End Get
        Set(ByVal value As DataTable)
            ViewState("dt") = value
        End Set
    End Property

    Private Property IsError() As Boolean
        Get
            Dim retVal As Boolean
            If Me.ViewState("_IsError") IsNot Nothing Then
                retVal = CBool(Me.ViewState("_IsError"))
            End If
            Return retVal
        End Get
        Set(ByVal value As Boolean)
            Me.ViewState("_IsError") = value
        End Set
    End Property
#End Region

#Region "Global Variables"
    Private BLLFunction As BusinessLogicLayer.tblFunctionBLL
    Private BllRole As BusinessLogicLayer.StaffRoleBLL
    Private BLL2 As BusinessLogicLayer.StaffBLL
    Private BLL3 As BusinessLogicLayer.tblFunctionBLL
#End Region

#Region "Page Load Event"
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Me.BLLFunction = New BusinessLogicLayer.tblFunctionBLL
        Me.BllRole = New BusinessLogicLayer.StaffRoleBLL
        Me.BLL2 = New BusinessLogicLayer.StaffBLL()
        Me.BLL3 = New BusinessLogicLayer.tblFunctionBLL()
        If (Not Page.IsPostBack) Then
            Call LoadInitialData()
        Else
            ' Call DataBindingGrid(True)
        End If
        Call Me.AccessControl("Role")

    End Sub
#End Region

    Private Sub AccessControl(ByVal title As String)

        Dim userName As String
        Dim oDatatable As DataTable
        Dim oDataTable2 As DataTable

        Static roleID As String

        userName = ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName
        oDatatable = Me.BLL2.GetUserByID(userName)

        If oDatatable.Rows.Count > 0 Then
            roleID = oDatatable.Rows(0).Item("RoleID").ToString
        End If

        oDataTable2 = Me.BLL3.GetUserRole(roleID)
        If oDataTable2.Rows.Count > 0 Then
            For k As Integer = 0 To oDataTable2.Rows.Count - 1
                If oDataTable2.Rows(k).Item("functionGroup") = "0" Then
                    If oDataTable2.Rows(k).Item("Permission") = "V" Then
                        If oDataTable2.Rows(k).Item("functionName").ToString = title Then
                            Call Me.toggleControl()

                        End If
                    End If
                End If

            Next

        End If


    End Sub

    Private Sub toggleControl()
        Dim ddlPermission1 As CWTCustomControls.CWTDropDownList
        Dim ddlPermission2 As CWTCustomControls.CWTDropDownList
        Dim ddlPermission3 As CWTCustomControls.CWTDropDownList


        Me.btnTrans1.SaveButton.Enabled = False
        Me.btnTrans2.SaveButton.Enabled = False

        For i As Integer = 0 To Me.gdData.Rows.Count - 1
            ddlPermission1 = Me.gdData.Rows(i).FindControl("ddlPermission")
            ddlPermission1.Enabled = False
        Next

        For i As Integer = 0 To Me.gdClient.Rows.Count - 1
            ddlPermission2 = Me.gdClient.Rows(i).FindControl("ddlPermission")
            ddlPermission2.Enabled = False
        Next

        For i As Integer = 0 To Me.gdSupplier.Rows.Count - 1
            ddlPermission3 = Me.gdSupplier.Rows(i).FindControl("ddlPermission")
            ddlPermission3.Enabled = False
        Next
    End Sub

#Region "Grid Event"
    Private Sub DataBindingGrid()
        'If (HaveData) Then
        '    gdData.DataSource = Me.dtData1
        '    gdData.DataBind()
        'Else

        Dim oDataTable As DataTable
        'Dim oDataTable2 As New DataTable
        Dim dt As New DataTable
        dt = getSchemaTable1()
        oDataTable = Me.BLLFunction.GetUserRole(Me.RoleID)

        For i As Integer = 0 To oDataTable.Rows.Count - 1
            Dim rTemp As DataRow
            If oDataTable.Rows(i).Item("FunctionGroup") = "0" Then
                rTemp = dt.NewRow()
                rTemp("FunctionID") = oDataTable.Rows(i).Item("FunctionID").ToString
                rTemp("FunctionName") = oDataTable.Rows(i).Item("FunctionName").ToString
                rTemp("OrderNo") = oDataTable.Rows(i).Item("OrderNo").ToString
                rTemp("FunctionGroup") = oDataTable.Rows(i).Item("FunctionGroup").ToString
                rTemp("RoleID") = oDataTable.Rows(i).Item("RoleID").ToString
                rTemp("Role") = oDataTable.Rows(i).Item("Role").ToString
                rTemp("Permission") = oDataTable.Rows(i).Item("Permission").ToString
                dt.Rows.Add(rTemp)
            End If
        Next

        gdData.DataSource = dt
        gdData.DataBind()
        'Me.dtData1 = dt
        With Me.pgControl1
            .GridID = Me.gdData.UniqueID
            .SetBindGrid()
        End With

        'End If        
    End Sub

    Private Sub DataBindingGrid2(Optional ByVal HaveData As Boolean = False)
        '    If (HaveData) Then
        '        gdClient.DataSource = Me.dtData2
        '        gdClient.DataBind()
        '    Else
        Dim oDataTable As DataTable
        'Dim oDataTable2 As New DataTable
        Dim dt As New DataTable
        dt = getSchemaTable2()
        oDataTable = Me.BLLFunction.GetUserRole(Me.RoleID)

        For i As Integer = 0 To oDataTable.Rows.Count - 1
            Dim rTemp As DataRow
            If oDataTable.Rows(i).Item("FunctionGroup") = "1" Then
                If oDataTable.Rows(i).Item("ParentID").ToString = "2" Then
                    Continue For
                End If
                rTemp = dt.NewRow()
                rTemp("FunctionID") = oDataTable.Rows(i).Item("FunctionID").ToString
                rTemp("FunctionName") = oDataTable.Rows(i).Item("FunctionName").ToString
                rTemp("OrderNo") = oDataTable.Rows(i).Item("OrderNo").ToString
                rTemp("FunctionGroup") = oDataTable.Rows(i).Item("FunctionGroup").ToString
                rTemp("RoleID") = oDataTable.Rows(i).Item("RoleID").ToString
                rTemp("Role") = oDataTable.Rows(i).Item("Role").ToString
                rTemp("Permission") = oDataTable.Rows(i).Item("Permission").ToString
                dt.Rows.Add(rTemp)
            End If
        Next

        gdClient.DataSource = dt
        gdClient.DataBind()
        '        Me.dtData2 = dt
        'End If

        With Me.pgControl2
            .GridID = Me.gdClient.UniqueID
            .SetBindGrid()
        End With
    End Sub

    Private Sub DataBindingGrid3(Optional ByVal HaveData As Boolean = False)
        '    If (HaveData) Then
        '        gdSupplier.DataSource = Me.dtData3
        '        gdSupplier.DataBind()
        '    Else
        Dim oDataTable As DataTable
        'Dim oDataTable2 As New DataTable
        Dim dt As New DataTable
        dt = getSchemaTable3()
        oDataTable = Me.BLLFunction.GetUserRole(Me.RoleID)

        For i As Integer = 0 To oDataTable.Rows.Count - 1
            Dim rTemp As DataRow
            If oDataTable.Rows(i).Item("FunctionGroup") = "2" Then
                rTemp = dt.NewRow()
                rTemp("FunctionID") = oDataTable.Rows(i).Item("FunctionID").ToString
                rTemp("FunctionName") = oDataTable.Rows(i).Item("FunctionName").ToString
                rTemp("OrderNo") = oDataTable.Rows(i).Item("OrderNo").ToString
                rTemp("FunctionGroup") = oDataTable.Rows(i).Item("FunctionGroup").ToString
                rTemp("RoleID") = oDataTable.Rows(i).Item("RoleID").ToString
                rTemp("Role") = oDataTable.Rows(i).Item("Role").ToString
                rTemp("Permission") = oDataTable.Rows(i).Item("Permission").ToString
                dt.Rows.Add(rTemp)
            End If
        Next

        gdSupplier.DataSource = dt
        gdSupplier.DataBind()
        '        Me.dtData3 = dt
        '    End IfS
        With Me.pgControl3
            .GridID = Me.gdSupplier.UniqueID
            .SetBindGrid()
        End With
    End Sub

    Protected Sub gdData_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gdData.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim ddl As CWTCustomControls.CWTDropDownList
            Dim asd As HiddenField = CType(e.Row.FindControl("hidPermID"), HiddenField)
            Dim oDataTable As DataTable

            ddl = e.Row.FindControl("ddlPermission")

            Dim p As String
            p = DataBinder.Eval(e.Row.DataItem, "Permission").ToString()
            oDataTable = Me.BLLFunction.GetPermission()
            With ddl
                .DataTextField = "PermissionValue"
                .DataValueField = "PermissionID"
                .DataSource = oDataTable
                .DataBind()


                If p = "" Then
                    .SelectedValue = "N"
                Else
                    .SelectedValue = p
                End If
            End With
        End If
    End Sub


    Protected Sub gdClient_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gdClient.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim ddl As CWTCustomControls.CWTDropDownList
            Dim asd As HiddenField = CType(e.Row.FindControl("hidPermID"), HiddenField)
            Dim oDataTable As DataTable

            ddl = e.Row.FindControl("ddlPermission")

            Dim p As String
            p = DataBinder.Eval(e.Row.DataItem, "Permission").ToString()
            oDataTable = Me.BLLFunction.GetPermission()
            With ddl
                .DataTextField = "PermissionValue"
                .DataValueField = "PermissionID"
                .DataSource = oDataTable
                .DataBind()


                If p = "" Then
                    .SelectedValue = "N"
                Else
                    .SelectedValue = p
                End If
            End With
        End If
    End Sub

    Protected Sub gdSupplier_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gdSupplier.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim ddl As CWTCustomControls.CWTDropDownList
            Dim asd As HiddenField = CType(e.Row.FindControl("hidPermID"), HiddenField)
            Dim oDataTable As DataTable

            ddl = e.Row.FindControl("ddlPermission")

            Dim p As String
            p = DataBinder.Eval(e.Row.DataItem, "Permission").ToString()
            oDataTable = Me.BLLFunction.GetPermission()
            With ddl
                .DataTextField = "PermissionValue"
                .DataValueField = "PermissionID"
                .DataSource = oDataTable
                .DataBind()


                If p = "" Then
                    .SelectedValue = "N"
                Else
                    .SelectedValue = p
                End If
            End With
        End If
    End Sub
#End Region

#Region "Controls Event"
    Private Sub UpdatePermission()
        Dim dt As New DataTable
        Dim info As New DataInfo.PermissionServiceInfo()
        Dim pg, pg2, pg3 As DataInfo.PermissionInfo
        Dim ddl, ddl2, ddl3 As CWTCustomControls.CWTDropDownList
        Dim lbl, lbl2, lbl3 As CWTCustomControls.CWTLabel
        'Dim info As DataInfo.PermissionInfo()
        'dt = getSchemaTable1()
        With info
            .RoleID = Me.RoleID
            For i As Integer = 0 To Me.gdData.Rows.Count - 1
                pg = New DataInfo.PermissionInfo()
                lbl = Me.gdData.Rows(i).FindControl("lblFunctionID")
                ddl = Me.gdData.Rows(i).FindControl("ddlPermission")
                With pg
                    .functionID = lbl.Text
                    .permission = ddl.SelectedValue
                End With
                .PermissionList.Add(pg)
            Next
            For k As Integer = 0 To Me.gdClient.Rows.Count - 1
                pg2 = New DataInfo.PermissionInfo()
                lbl2 = Me.gdClient.Rows(k).FindControl("lblFunctionID")
                ddl2 = Me.gdClient.Rows(k).FindControl("ddlPermission")
                With pg2
                    .functionID = lbl2.Text
                    .permission = ddl2.SelectedValue
                End With
                .PermissionList.Add(pg2)
            Next
            For k As Integer = 0 To Me.gdSupplier.Rows.Count - 1
                pg3 = New DataInfo.PermissionInfo()
                lbl3 = Me.gdSupplier.Rows(k).FindControl("lblFunctionID")
                ddl3 = Me.gdSupplier.Rows(k).FindControl("ddlPermission")
                With pg3
                    .functionID = lbl3.Text
                    .permission = ddl3.SelectedValue
                End With
                .PermissionList.Add(pg3)
            Next
        End With

        If Me.BLLFunction.SaveData(info) > 0 Then
            Me.lblMsgBox.Text = Util.GetAppConfig(Util.MsgType.TRANS_SUCCESS.ToString)
            Me.lblMsgBox.ForeColor = Drawing.Color.Green
            Me.IsError = False
            Me.ajaxMsgBox.Show()
        Else
            Me.lblMsgBox.Text = Util.GetAppConfig(Util.MsgType.TRANS_ERROR.ToString)
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.IsError = True
            Me.ajaxMsgBox.Show()
        End If
        'Call DataBindingGrid()
        'Util.AlertBox("Save Completed", False, "PermissionUpdateManager.aspx?roleid=" + Me.RoleID)
    End Sub

    Private Sub CancelPage()
        Response.Redirect("RoleManager.aspx")
    End Sub

    Protected Sub btnTrans1_OnSave(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans1.OnSave
        Call Me.UpdatePermission()
    End Sub
    Protected Sub btnTrans1_OnCancel(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans1.OnCancel
        Call Me.CancelPage()
    End Sub

    Protected Sub btnTrans2_OnSave(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans2.OnSave
        Call Me.UpdatePermission()
    End Sub
    Protected Sub btnTrans2_OnCancel(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans2.OnCancel
        Call Me.CancelPage()
    End Sub
#End Region

#Region "Methods"
    Private Sub LoadData()
        Dim oDataTable As DataTable
        oDataTable = Me.BllRole.GetUserRoleByRoleID(Me.RoleID)
        If oDataTable IsNot Nothing AndAlso oDataTable.Rows.Count > 0 Then
            Me.txtRoleName.Text = "Role: " + oDataTable.Rows(0).Item("Role").ToString()
        End If
    End Sub
    Private Sub LoadInitialData()
        LoadData()
        DataBindingGrid()
        DataBindingGrid2()
        DataBindingGrid3()
    End Sub
    Private Function getSchemaTable() As DataTable
        Dim dt As New DataTable()
        dt.Columns.Add("FunctionID")
        dt.Columns.Add("Permission")
        Return dt
    End Function

    Private Function getSchemaTable1() As DataTable
        Dim dt1 As New DataTable()
        dt1.Columns.Add("FunctionID")
        dt1.Columns.Add("FunctionName")
        dt1.Columns.Add("OrderNo")
        dt1.Columns.Add("FunctionGroup")
        dt1.Columns.Add("ParentID")
        dt1.Columns.Add("RoleID")
        dt1.Columns.Add("Role")
        dt1.Columns.Add("Permission")
        Return dt1
    End Function

    Private Function getSchemaTable2() As DataTable
        Dim dt2 As New DataTable()
        dt2.Columns.Add("FunctionID")
        dt2.Columns.Add("FunctionName")
        dt2.Columns.Add("OrderNo")
        dt2.Columns.Add("FunctionGroup")
        dt2.Columns.Add("ParentID")
        dt2.Columns.Add("RoleID")
        dt2.Columns.Add("Role")
        dt2.Columns.Add("Permission")
        Return dt2
    End Function

    Private Function getSchemaTable3() As DataTable
        Dim dt3 As New DataTable()
        dt3.Columns.Add("FunctionID")
        dt3.Columns.Add("FunctionName")
        dt3.Columns.Add("OrderNo")
        dt3.Columns.Add("FunctionGroup")
        dt3.Columns.Add("ParentID")
        dt3.Columns.Add("RoleID")
        dt3.Columns.Add("Role")
        dt3.Columns.Add("Permission")
        Return dt3
    End Function
#End Region

    Protected Sub btnClose_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Me.ajaxMsgBox.Hide()
        If Not Me.IsError Then
            Response.Redirect("RoleManager.aspx")
        End If
    End Sub

End Class
@


1.1.1.1
log
@no message
@
text
@@
