head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.04.58;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.04.58;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@
Partial Class Admin_UserSystem_ProfileUpdate
    Inherits BasePage

#Region "Page Properties & Variables"
    Private BLL As BusinessLogicLayer.StaffBLL

    Private Property IsErrorBefore() As Boolean
        Get
            Dim retVal As Boolean
            If Me.ViewState("_IsErrorBefore") IsNot Nothing Then
                retVal = CBool(Me.ViewState("_IsErrorBefore"))
            End If
            Return retVal
        End Get
        Set(ByVal value As Boolean)
            Me.ViewState("_IsErrorBefore") = value
        End Set
    End Property

    Private Property IsError() As Boolean
        Get
            Dim retVal As Boolean
            If Me.ViewState("_IsError") IsNot Nothing Then
                retVal = CBool(Me.ViewState("_IsError"))
            End If
            Return retVal
        End Get
        Set(ByVal value As Boolean)
            Me.ViewState("_IsError") = value
        End Set
    End Property
#End Region

#Region "Page Event Handlers & Methods"
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.BLL = New BusinessLogicLayer.StaffBLL()
        If Not IsPostBack Then
            Call Me.ToggleArea(True)
            Call Me.LoadDropDownList()
            Call Me.LoadData()
            Call Me.InitializeControls()
        End If
        '//
        If Me.IsErrorBefore Then
            Me.lblError.Visible = False
        End If
    End Sub

    Private Sub InitializeControls()

    End Sub

    Private Sub ToggleArea(ByVal IsPreRegist As Boolean)
        Me.divRegistArea.Visible = IsPreRegist
    End Sub
#End Region

#Region "Data Binding"
    'Private Sub LoadCountry()
    '    With Me.ddlCountry
    '        .Items.Add(New ListItem("Singapore", "SG"))
    '        .Items.Add(New ListItem("Hongkong", "HK"))
    '        .SelectedValue = "SG"
    '        Call Me.LoadDepartment(.SelectedValue)
    '    End With
    'End Sub
    Private Sub LoadTitle()
        With Me.ddlTitle
            .Items.Add(New ListItem("Mr.", "Mr."))
            .Items.Add(New ListItem("Miss", "Miss"))
            .Items.Add(New ListItem("Mrs", "Mrs"))
        End With
    End Sub
    'Private Sub LoadDepartment(ByVal Country As String)
    '    Dim DivBLL As New BusinessLogicLayer.DivisionBLL()
    '    Dim oDataTable As DataTable
    '    oDataTable = DivBLL.GetDivisionByCountry(Country)
    '    With ddlDepartment
    '        .DataTextField = "DivName"
    '        .DataValueField = "DivID"
    '        .DataSource = oDataTable
    '        .DataBind()
    '        If .Items.Count <= 0 Then
    '            .Items.Add(New ListItem("- No Department found -"))
    '        End If
    '    End With
    'End Sub

    Private Sub LoadDropDownList()
        'Call Me.LoadCountry()
        Call Me.LoadTitle()
    End Sub

    Private Sub LoadData()
        Dim oDataTable As DataTable
        Dim oRow As DataRow
        oDataTable = Me.BLL.GetUserByID(ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName)
        If oDataTable IsNot Nothing AndAlso oDataTable.Rows.Count > 0 Then
            oRow = oDataTable.Rows(0)
            Me.txtFirstName.Text = oRow("FirstName").ToString()
            Me.txtLastName.Text = oRow("LastName").ToString()
            Me.txtPhoneNo.Text = oRow("PhoneNumber").ToString()
            Me.txtHPNo.Text = oRow("MobileNumber").ToString()
            Me.txtEmail.Text = oRow("EmailAddress").ToString()
            Me.txtRemark.Text = oRow("Remark").ToString()
            If Not IsDBNull(oRow("Title")) Then
                Me.ddlTitle.SelectedValue = oRow("Title").ToString()
            End If
        End If
    End Sub
#End Region

#Region "Page Validations"
    Private Function ValidateForm() As Boolean
        Dim retVal As Boolean = True
        Dim msg As String = ""
        '// Check Exist User
        If Me.BLL.IsExistUser(ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName) Then
            retVal = False
            msg += "User exist in database."
            Me.IsErrorBefore = True
        End If
        If msg <> "" Then
            Me.lblError.Text = msg
            Me.lblError.Visible = True
        End If
        Return retVal
    End Function
#End Region

#Region "Data Transaction"
    Private Sub UpdateUser()
        Dim Info As New DataInfo.UserInfo()
        With Info
            .PageMode = CWTMasterDB.TransactionMode.UpdateMode
            .UserName = ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName
            .Title = Me.ddlTitle.SelectedValue
            .FirstName = Me.txtFirstName.Text
            .LastName = Me.txtLastName.Text
            .Phone = Me.txtPhoneNo.Text
            .Mobile = Me.txtHPNo.Text
            '.AltPhone = Me.txtAltPhoneCode.Text + "-" + Me.txtAltPhoneNo.Text
            '.DivID = Me.ddlDepartment.SelectedValue
            '.Country = Me.ddlCountry.SelectedValue
            .Email = Me.txtEmail.Text
            '.JobTitle = Me.txtJobTitle.Text
            .Remark = Me.txtRemark.Text
        End With
        '// Validation
        If Not ValidateForm() Then
            Exit Sub
        End If
        '//
        If Me.BLL.UpdateUser(Info) > 0 Then
            Me.lblMsgBox.Text = Util.GetAppConfig(Util.MsgType.TRANS_SUCCESS.ToString)
            Me.lblMsgBox.ForeColor = Drawing.Color.Green
            Me.IsError = False
            Me.ajaxMsgBox.Show()
        Else
            Me.lblMsgBox.Text = Util.GetAppConfig(Util.MsgType.TRANS_ERROR.ToString) + "Cannot update profile at this time. "
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.IsError = True
            Me.ajaxMsgBox.Show()
        End If
    End Sub
#End Region

#Region "Page Control Event Handlers"
    Protected Sub btnClose_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Me.ajaxMsgBox.Hide()
        If Not Me.IsError Then
            Response.Redirect(Util.GetAppConfig("RootPath") + "/Default.aspx")
        End If
    End Sub

    Protected Sub btnTrans_OnSave(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans.OnSave
        Call Me.UpdateUser()
    End Sub

    Protected Sub btnTrans_OnCancel(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans.OnCancel
        Response.Redirect(Util.GetAppConfig("RootPath") + "/Default.aspx")
    End Sub

    'Protected Sub ddlCountry_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlCountry.SelectedIndexChanged
    '    Call Me.LoadDepartment(Me.ddlCountry.SelectedValue)
    'End Sub
#End Region

End Class
@


1.1.1.1
log
@no message
@
text
@@
