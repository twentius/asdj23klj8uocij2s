head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.04.58;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.04.58;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@
Partial Class Admin_UserSystem_ChangeEmail
    Inherits BasePage

    Private BLL As BusinessLogicLayer.StaffBLL

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.BLL = New BusinessLogicLayer.StaffBLL()
        If Not IsPostBack Then
            Me.btnTrans.SaveButton.Text = "Change"
        End If
        Me.btnTrans.CancelButton.Attributes.Add("onclick", "return CloseWindow();")
    End Sub

    Private Sub SaveData()
        Dim usrPwd As String
        Dim encPwd As String
        Dim usrName As String = ""
        Dim PasswordManager As New Securities.DataEncryption()
        usrName = ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName
        usrPwd = Me.BLL.GetDataColumnByID("Password", usrName)
        encPwd = PasswordManager.EncryptText(Me.txtPassword.Text)
        If String.Compare(usrPwd, encPwd) = 0 Then
            If Me.BLL.ChangeEmail(usrName, Me.txtEmail.Text) > 0 Then
                Call Me.CloseWindows()
            Else
                Call Util.AlertBox("Cannot change email at this moment.")
            End If
        Else
            Call Util.AlertBox("Confirm password is incorrect.")
        End If
    End Sub

    Private Sub CloseWindows()
        Call Util.RegClientScript("CloseWindow();", "ChangeUserPassword_CloseWin", Util.ClientScriptRegistType.RegStartUpBlock)
    End Sub

    Protected Sub btnTrans_OnSave(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans.OnSave
        Call Me.SaveData()
    End Sub

End Class
@


1.1.1.1
log
@no message
@
text
@@
