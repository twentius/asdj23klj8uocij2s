head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.04.58;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.04.58;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports BusinessLogicLayer

Partial Class Admin_UserSystem_RoleManager
    Inherits BasePage

    Private BLL As BusinessLogicLayer.StaffRoleBLL
    Private BLL2 As BusinessLogicLayer.StaffBLL
    Private BLL3 As BusinessLogicLayer.tblFunctionBLL

    Protected Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init
    End Sub

    'Protected Sub Page_ReadPermissionInfo(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.ReadPermissionInfo
    '    Call Me.InitControlsPermission()
    'End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.BLL = New BusinessLogicLayer.StaffRoleBLL()
        Me.BLL2 = New BusinessLogicLayer.StaffBLL()
        Me.BLL3 = New BusinessLogicLayer.tblFunctionBLL()

        Call Me.LoadDataGrid()
        If Not IsPostBack Then
        Else

        End If
        Call Me.AccessControl("Role")
    End Sub

    Private Sub InitControlsPermission()
        Me.hrefAdd.PermissionInfo = Me.usrInfo
    End Sub


    Private Sub AccessControl(ByVal title As String)

        Dim userName As String
        Dim oDatatable As DataTable
        Dim oDataTable2 As DataTable

        Static roleID As String

        userName = ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName
        oDatatable = Me.BLL2.GetUserByID(userName)

        If oDatatable.Rows.Count > 0 Then
            roleID = oDatatable.Rows(0).Item("RoleID").ToString
        End If

        oDataTable2 = Me.BLL3.GetUserRole(roleID)
        If oDataTable2.Rows.Count > 0 Then
            For k As Integer = 0 To oDataTable2.Rows.Count - 1
                If oDataTable2.Rows(k).Item("functionGroup") = "0" Then
                    If oDataTable2.Rows(k).Item("Permission") = "V" Then
                        If oDataTable2.Rows(k).Item("functionName").ToString = title Then
                            Call Me.toggleControl()

                        End If
                    End If
                End If

            Next

        End If


    End Sub

    Private Sub toggleControl()
        Dim btnDelete As CWTCustomControls.CWTLinkButton


        Me.hrefAdd.Enabled = False

        For i As Integer = 0 To Me.gdData.Rows.Count - 1
            btnDelete = Me.gdData.Rows(i).FindControl("hrefDelete")
            btnDelete.Enabled = False

        Next
    End Sub

    Private Sub LoadDataGrid()
        Dim oDataTable As DataTable
        oDataTable = Me.BLL.GetUserRole()
        With Me.gdData
            .DataSource = oDataTable
            .DataBind()
        End With
        With Me.pgControl
            .GridID = Me.gdData.UniqueID
            .SetBindGrid()
        End With
    End Sub

    Private Sub DeleteRole(ByVal RoleID As String)
        Me.BLL.DeleteRoleByRoleID(RoleID)
    End Sub

    Public Sub gdData_Command(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.CommandEventArgs)
        Select Case e.CommandName
            Case "DeleteRole"
                Call Me.DeleteRole(Util.DBNullToZero(e.CommandArgument))
        End Select
        Call Me.LoadDataGrid()
    End Sub

    Protected Sub gdData_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gdData.RowDataBound
        Dim cwtPer As CWTCustomControls.CWTHyperLink
        Dim cwtHref As CWTCustomControls.CWTHyperLink
        Dim cwtLinkBtn As CWTCustomControls.CWTLinkButton
        cwtPer = TryCast(e.Row.FindControl("hrefPer"), CWTCustomControls.CWTHyperLink)
        cwtHref = TryCast(e.Row.FindControl("hrefEdit"), CWTCustomControls.CWTHyperLink)
        cwtLinkBtn = TryCast(e.Row.FindControl("hrefDelete"), CWTCustomControls.CWTLinkButton)
        If cwtHref IsNot Nothing Then
            If DataBinder.Eval(e.Row.DataItem, "Role").ToString.ToLower = "admin" Then
                cwtHref.Visible = False
                cwtPer.Visible = False
            Else
                cwtHref.PermissionInfo = Me.usrInfo
                cwtPer.PermissionInfo = Me.usrInfo
            End If
        End If
        If cwtLinkBtn IsNot Nothing Then
            If DataBinder.Eval(e.Row.DataItem, "Role").ToString.ToLower = "admin" Then
                cwtLinkBtn.Visible = False
            Else
                cwtLinkBtn.PermissionInfo = Me.usrInfo
                cwtLinkBtn.Attributes.Add("onclick", "return confirm('All users in this role will inactive after delete, continue?');")
            End If
        End If
    End Sub

    Protected Sub gdData_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles gdData.SelectedIndexChanged

    End Sub

End Class
@


1.1.1.1
log
@no message
@
text
@@
