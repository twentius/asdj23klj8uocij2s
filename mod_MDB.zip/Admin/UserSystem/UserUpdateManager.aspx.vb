head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.04.58;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.04.58;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports System.DirectoryServices
Imports System.DirectoryServices.DirectoryEntry
Imports System.DirectoryServices.DirectorySearcher
Imports System.DirectoryServices.SearchResultCollection
Imports System.DirectoryServices.SearchResult
Imports System.DirectoryServices.ResultPropertyCollection
Imports System.DirectoryServices.PropertyValueCollection

Partial Class Admin_UserSystem_UserUpdateManager
    Inherits BasePage

#Region "Page Properties & Variables"
    Private BLL As BusinessLogicLayer.StaffBLL
    Private BLL2 As BusinessLogicLayer.StaffBLL
    Private BLL3 As BusinessLogicLayer.tblFunctionBLL


    Private Property IsErrorBefore() As Boolean
        Get
            Dim retVal As Boolean
            If Me.ViewState("_IsErrorBefore") IsNot Nothing Then
                retVal = CBool(Me.ViewState("_IsErrorBefore"))
            End If
            Return retVal
        End Get
        Set(ByVal value As Boolean)
            Me.ViewState("_IsErrorBefore") = value
        End Set
    End Property

    Private Property IsError() As Boolean
        Get
            Dim retVal As Boolean
            If Me.ViewState("_IsError") IsNot Nothing Then
                retVal = CBool(Me.ViewState("_IsError"))
            End If
            Return retVal
        End Get
        Set(ByVal value As Boolean)
            Me.ViewState("_IsError") = value
        End Set
    End Property

    Public Property RecordID() As String
        Get
            Dim retVal As String = ""
            If Me.ViewState("_RecordID") IsNot Nothing Then
                retVal = Me.ViewState("_RecordID").ToString()
            End If
            Return retVal
        End Get
        Set(ByVal value As String)
            Me.ViewState("_RecordID") = value
        End Set
    End Property
#End Region

#Region "Page Event Handlers & Methods"
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.BLL = New BusinessLogicLayer.StaffBLL()
        Me.BLL2 = New BusinessLogicLayer.StaffBLL()
        Me.BLL3 = New BusinessLogicLayer.tblFunctionBLL()
        If Not IsPostBack Then
            If Me.Request("mode") Is Nothing Then
                Response.Redirect(Util.GetAppConfig("RootPath") + "/Default.aspx", True)
            End If
            Call Me.ToggleArea(True)
            Call Me.LoadDropDownList()
            Select Case Me.Request("mode").ToString()
                Case "add"
                    Me.CurrentPageMode = CWTMasterDB.TransactionMode.AddNewMode
                    Me.btnGetInfo.Visible = True
                Case "edit"
                    Me.CurrentPageMode = CWTMasterDB.TransactionMode.UpdateMode
                    Me.RecordID = Me.Request("id").ToString()
                    Call Me.LoadData()
                    Me.btnGetInfo.Visible = False
                    Call Me.AccessControl("User")
            End Select
            Call Me.InitializeControls()
        End If
        '//
        If Me.IsErrorBefore Then
            Me.lblError.Visible = False
        End If
    End Sub

    Private Sub InitializeControls()
        Try
            Me.txtUserName.ReadOnly = Not (Me.CurrentPageMode = CWTMasterDB.TransactionMode.AddNewMode)
            If Me.txtUserName.ReadOnly Then
                Me.txtUserName.Style.Add("border-width", "0px")
            Else
                Me.txtUserName.Style.Remove("border-width")
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub ToggleArea(ByVal IsPreRegist As Boolean)
        Me.divRegistArea.Visible = IsPreRegist
        Me.divWelcomeArea.Visible = Not IsPreRegist
    End Sub

    Private Sub AccessControl(ByVal title As String)

        Dim userName As String
        Dim oDatatable As DataTable
        Dim oDataTable2 As DataTable

        Static roleID As String

        userName = ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName
        oDatatable = Me.BLL2.GetUserByID(userName)

        If oDatatable.Rows.Count > 0 Then
            roleID = oDatatable.Rows(0).Item("RoleID").ToString
        End If

        oDataTable2 = Me.BLL3.GetUserRole(roleID)
        If oDataTable2.Rows.Count > 0 Then
            For k As Integer = 0 To oDataTable2.Rows.Count - 1
                If oDataTable2.Rows(k).Item("functionGroup") = "0" Then
                    If oDataTable2.Rows(k).Item("Permission") = "V" Then
                        If oDataTable2.Rows(k).Item("functionName").ToString = title Then
                            Call Me.toggleControl()

                        End If
                    End If
                End If

            Next

        End If


    End Sub

    Private Sub toggleControl()

        Me.txtUserName.ReadOnly = True
        Me.ddlTitle.Enabled = False
        Me.txtFirstName.ReadOnly = True
        Me.txtLastName.ReadOnly = True
        '//
        Me.txtPhoneCode.ReadOnly = True
        Me.txtHPCode.ReadOnly = True
        Me.txtAltPhoneCode.ReadOnly = True
        '//
        Me.txtPhoneNo.ReadOnly = True
        Me.txtHPNo.ReadOnly = True
        Me.txtAltPhone.ReadOnly = True
        Me.ddlDepartment.Enabled = False
        '.Country = Me.ddlCountry.SelectedValue
        Me.txtEmail.ReadOnly = True
        Me.ddlRole.Enabled = False
        Me.txtJobTitle.ReadOnly = True
        Me.txtRemark.ReadOnly = True
        Me.chkStatus.Enabled = False
        Me.btnTrans.SaveButton.Enabled = False
    End Sub

#End Region

#Region "Data Binding"
    'Private Sub LoadCountry()
    '    With Me.ddlCountry
    '        .Items.Add(New ListItem("Singapore", "SG"))
    '        .Items.Add(New ListItem("Hongkong", "HK"))
    '        .SelectedValue = "SG"
    '        Call Me.LoadDepartment(.SelectedValue)
    '    End With
    'End Sub
    Private Sub LoadStdDepartment()
        Dim oDataTable As DataTable
        oDataTable = Me.BLL.GetDepartment()
        With Me.ddlDepartment
            .DataTextField = "Name"
            .DataValueField = "Code"
            .DataSource = oDataTable
            .DataBind()
        End With
    End Sub

    Private Sub LoadTitle()
        With Me.ddlTitle
            .Items.Add(New ListItem("Mr.", "Mr."))
            .Items.Add(New ListItem("Miss", "Miss"))
            .Items.Add(New ListItem("Mrs", "Mrs"))
        End With
    End Sub
    Private Sub LoadRole()
        Dim RoleBLL As New BusinessLogicLayer.StaffRoleBLL()
        Dim oDataTable As DataTable
        oDataTable = RoleBLL.GetUserRole()
        With Me.ddlRole
            .DataTextField = "Role"
            .DataValueField = "RoleID"
            .DataSource = oDataTable
            .DataBind()
            If .Items.Count <= 0 Then
                .Items.Add(New ListItem("- No Role found -"))
            Else
                .Items.Insert(0, New ListItem("- Not Set -", ""))
            End If
        End With
    End Sub
    'Private Sub LoadDepartment(ByVal Country As String)
    '    Dim DivBLL As New BusinessLogicLayer.DivisionBLL()
    '    Dim oDataTable As DataTable
    '    oDataTable = DivBLL.GetDivisionByCountry(Country)
    '    With ddlDepartment
    '        .DataTextField = "DivName"
    '        .DataValueField = "DivID"
    '        .DataSource = oDataTable
    '        .DataBind()
    '        If .Items.Count <= 0 Then
    '            .Items.Add(New ListItem("- No Department found -"))
    '        End If
    '    End With
    'End Sub

    Private Sub LoadDropDownList()
        'Call Me.LoadCountry()
        Call Me.LoadStdDepartment()
        Call Me.LoadTitle()
        Call Me.LoadRole()
    End Sub

    Private Sub LoadData()
        Dim oDataTable As DataTable
        Dim oRow As DataRow
        oDataTable = Me.BLL.GetUserByID(Me.RecordID)
        If oDataTable IsNot Nothing AndAlso oDataTable.Rows.Count > 0 Then
            oRow = oDataTable.Rows(0)
            Me.txtUserName.Text = oRow("AdminUserID").ToString()
            Me.txtFirstName.Text = oRow("FirstName").ToString()
            Me.txtLastName.Text = oRow("LastName").ToString()
            Me.txtJobTitle.Text = oRow("JobTitle").ToString()
            Me.txtPhoneCode.Text = oRow("PhoneLocalCode").ToString()
            Me.txtPhoneNo.Text = oRow("PhoneNumber").ToString()
            Me.txtHPCode.Text = oRow("MobileLocalCode").ToString()
            Me.txtHPNo.Text = oRow("MobileNumber").ToString()
            Me.txtEmail.Text = oRow("EmailAddress").ToString()
            Me.txtRemark.Text = oRow("Remark").ToString()
            Me.txtAltPhoneCode.Text = oRow("AlternateLocalCode").ToString()
            Me.txtAltPhone.Text = oRow("AlternatePhone").ToString()
            If Not IsDBNull(oRow("Title")) Then
                Me.ddlTitle.SelectedValue = oRow("Title").ToString()
            End If
            If Not IsDBNull(oRow("Title")) Then
                Me.ddlDepartment.SelectedValue = oRow("Department").ToString()
            End If
            If Not IsDBNull(oRow("RoleID")) Then
                Me.ddlRole.SelectedValue = oRow("RoleID").ToString()
            End If
            Me.chkStatus.Checked = CBool(oRow("Status"))
        End If
    End Sub
#End Region

#Region "Page Validations"
    Private Function ValidateForm() As Boolean
        Dim retVal As Boolean = True
        Dim msg As String = ""
        Dim usr As String = Me.txtUserName.Text
        '// Check Exist User
        If Me.RecordID = "" AndAlso Me.BLL.IsExistUser(usr) Then
            retVal = False
            msg += "User exist in database."
            Me.IsErrorBefore = True
        End If
        If Not Me.IsErrorBefore AndAlso Not Me.UserExists(usr) Then
            retVal = False
            msg += "User is not exist in active directory."
            Me.IsErrorBefore = True
        End If
        If msg <> "" Then
            Me.lblError.Text = msg
            Me.lblError.Visible = True
        End If
        Me.IsErrorBefore = False
        Return retVal
    End Function
#End Region

#Region "Data Transaction"
    Private Sub UpdateUser()
        Dim Info As New DataInfo.UserInfo()
        With Info
            .PageMode = Me.CurrentPageMode
            .UserName = Me.txtUserName.Text
            .Title = Me.ddlTitle.SelectedValue
            .FirstName = Me.txtFirstName.Text
            .LastName = Me.txtLastName.Text
            '//
            .PhoneCode = Me.txtPhoneCode.Text
            .MobileCode = Me.txtHPCode.Text
            .AltPhoneCode = Me.txtAltPhoneCode.Text
            '//
            .Phone = Me.txtPhoneNo.Text
            .Mobile = Me.txtHPNo.Text
            .AltPhone = Me.txtAltPhone.Text
            .DivID = Me.ddlDepartment.SelectedValue
            '.Country = Me.ddlCountry.SelectedValue
            .Email = Me.txtEmail.Text
            .RoleID = Me.ddlRole.SelectedValue
            .JobTitle = Me.txtJobTitle.Text
            .Remark = Me.txtRemark.Text
            .Status = Me.chkStatus.Checked
        End With
        '// Validation
        'If Not ValidateForm() Then
        '    Exit Sub
        'End If
        '//
        If Me.BLL.UpdateUser(Info) > 0 Then
            Me.lblMsgBox.Text = Util.GetAppConfig(Util.MsgType.TRANS_SUCCESS.ToString)
            Me.lblMsgBox.ForeColor = Drawing.Color.Green
            Me.IsError = False
            Me.ajaxMsgBox.Show()
        Else
            Me.lblMsgBox.Text = Util.GetAppConfig(Util.MsgType.TRANS_ERROR.ToString)
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.IsError = True
            Me.ajaxMsgBox.Show()
        End If
    End Sub
#End Region

#Region "Page Control Event Handlers"
    Protected Sub btnGetInfo_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnGetInfo.Click
        Call Me.GetADInfo(Me.txtUserName.Text)
    End Sub

    Protected Sub btnTrans_OnSave(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans.OnSave
        Call Me.UpdateUser()
    End Sub

    Protected Sub btnTrans_OnCancel(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans.OnCancel
        Response.Redirect("UserManager.aspx")
    End Sub

    Protected Sub btnClose_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Me.ajaxMsgBox.Hide()
        If Not Me.IsError Then
            Response.Redirect("UserManager.aspx")
        End If
    End Sub

    'Protected Sub ddlCountry_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlCountry.SelectedIndexChanged
    '    Call Me.LoadDepartment(Me.ddlCountry.SelectedValue)
    'End Sub
#End Region

#Region "Misc"
    Public Sub GetADInfo(ByVal UserName As String)
        Dim de As DirectoryEntry = CType(Me.Session("_dirEntry"), DirectoryEntry)
        Dim deSearch As New DirectorySearcher()
        Try
            With deSearch
                .SearchRoot = de
                deSearch.Filter = "(&(objectClass=user) (SAMAccountName=" + UserName + "))"
                .PropertiesToLoad.Add("givenName") '; // user's first name
                .PropertiesToLoad.Add("sn") '; // user's surname
                .PropertiesToLoad.Add("mail") '; // user's surname
                .PropertiesToLoad.Add("title")
            End With


            Dim results As SearchResult = deSearch.FindOne()

            Me.txtFirstName.Text = Util.DBNullToText(results.Properties("givenname").Item(0))
            Me.txtLastName.Text = Util.DBNullToText(results.Properties("sn").Item(0))
            Me.txtEmail.Text = Util.DBNullToText(results.Properties("mail").Item(0))
            Me.txtJobTitle.Text = Util.DBNullToText(results.Properties("title").Item(0))



        Catch ex As Exception
            Me.lblMsgBox.Text = "Cannot get any information from system or user does not exist."
            Me.lblMsgBox.ForeColor = Drawing.Color.Red
            Me.IsError = True
            Me.ajaxMsgBox.Show()
        End Try
    End Sub

    Public Function UserExists(ByVal UserName As String) As Boolean
        Dim de As DirectoryEntry = CType(Me.Session("_dirEntry"), DirectoryEntry)
        Dim deSearch As New DirectorySearcher()
        deSearch.SearchRoot = de
        deSearch.Filter = "(&(objectClass=user) (SAMAccountName=" + UserName + "))"
        Dim results As SearchResultCollection = deSearch.FindAll()
        If results.Count = 0 Then
            Return False
        Else
            Return True
        End If
    End Function
#End Region

End Class
@


1.1.1.1
log
@no message
@
text
@@
