head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.04.58;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.04.58;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports System.Web.Services
Imports System.Web.Script.Services

Partial Class Admin_UserSystem_UserManager
    Inherits BasePage

    Private BLL As BusinessLogicLayer.StaffBLL
    Private BLL2 As BusinessLogicLayer.StaffBLL
    Private BLL3 As BusinessLogicLayer.tblFunctionBLL

    Protected Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init
    End Sub

    'Protected Sub Page_ReadPermissionInfo(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.ReadPermissionInfo
    '    Call Me.InitControlsPermission()
    'End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.BLL = New BusinessLogicLayer.StaffBLL()
        Me.BLL2 = New BusinessLogicLayer.StaffBLL()
        Me.BLL3 = New BusinessLogicLayer.tblFunctionBLL()
        If Not IsPostBack Then
            With Me.gdData
                .DataSource = New DataTable()
                .DataBind()
            End With

        Else
            Call Me.LoadDataGrid()
        End If
        Call Me.AccessControl("User")
    End Sub

    Private Sub InitControlsPermission()
        Me.hrefAdd.PermissionInfo = Me.usrInfo
    End Sub


    Private Sub AccessControl(ByVal title As String)

        Dim userName As String
        Dim oDatatable As DataTable
        Dim oDataTable2 As DataTable

        Static roleID As String

        userName = ServiceLogicLayer.ProfilerSLL.CurrentProfile.UserName
        oDatatable = Me.BLL2.GetUserByID(userName)

        If oDatatable.Rows.Count > 0 Then
            roleID = oDatatable.Rows(0).Item("RoleID").ToString
        End If

        oDataTable2 = Me.BLL3.GetUserRole(roleID)
        If oDataTable2.Rows.Count > 0 Then
            For k As Integer = 0 To oDataTable2.Rows.Count - 1
                If oDataTable2.Rows(k).Item("functionGroup") = "0" Then
                    If oDataTable2.Rows(k).Item("Permission") = "V" Then
                        If oDataTable2.Rows(k).Item("functionName").ToString = title Then
                            Call Me.toggleControl()

                        End If
                    End If
                End If

            Next

        End If


    End Sub


    Private Sub toggleControl()
        Me.hrefAdd.Enabled = False
    End Sub
    Private Sub LoadDataGrid()
        Dim oDataTable As DataTable
        oDataTable = Me.BLL.GetUserList(Me.txtFirstName.Text, Me.txtLastName.Text, Me.chkIncludeInActive.Checked)
        With Me.gdData
            .DataSource = oDataTable
            .DataBind()
        End With
        With Me.pgControl
            .GridID = Me.gdData.UniqueID
            .SetBindGrid()
        End With
    End Sub

    Protected Sub btnSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSearch.Click
        Call Me.LoadDataGrid()
        Call Me.AccessControl("User")
    End Sub

#Region "Webservices Methods"
    <WebMethod(), ScriptMethod()> _
    Public Shared Function GetFirstName(ByVal prefixText As String, ByVal count As Integer) As String()
        Dim CompBLL As New BusinessLogicLayer.StaffBLL()
        Return CompBLL.GetFirstName(prefixText)
    End Function

    <WebMethod(), ScriptMethod()> _
    Public Shared Function GetLastName(ByVal prefixText As String, ByVal count As Integer) As String()
        Dim CompBLL As New BusinessLogicLayer.StaffBLL()
        Return CompBLL.GetLastName(prefixText)
    End Function
#End Region

End Class
@


1.1.1.1
log
@no message
@
text
@@
