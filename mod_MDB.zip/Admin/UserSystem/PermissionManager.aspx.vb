head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.04.58;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.04.58;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@
Partial Class Admin_UserSystem_PermissionManager
    Inherits BasePage
    Private BLL As BusinessLogicLayer.StaffRoleBLL

    Protected Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init
    End Sub
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.BLL = New BusinessLogicLayer.StaffRoleBLL()
        Call Me.LoadDataGrid()
        If Not IsPostBack Then
        Else

        End If
    End Sub
    Private Sub LoadDataGrid()
        Dim oDataTable As DataTable
        oDataTable = Me.BLL.GetUserRole()
        With Me.gdData
            .DataSource = oDataTable
            .DataBind()
        End With
    End Sub

    Private Sub DeleteRole(ByVal RoleID As String)
        Me.BLL.DeleteRoleByRoleID(RoleID)
    End Sub

    Public Sub gdData_Command(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.CommandEventArgs)
        Select Case e.CommandName
            Case "DeleteRole"
                Call Me.DeleteRole(Util.DBNullToZero(e.CommandArgument))
        End Select
        Call Me.LoadDataGrid()
    End Sub

    Protected Sub gdData_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gdData.RowDataBound
        Dim cwtHref As CWTCustomControls.CWTHyperLink
        Dim cwtLinkBtn As CWTCustomControls.CWTLinkButton
        cwtHref = TryCast(e.Row.FindControl("hrefEdit"), CWTCustomControls.CWTHyperLink)
        cwtLinkBtn = TryCast(e.Row.FindControl("hrefDelete"), CWTCustomControls.CWTLinkButton)
        If cwtHref IsNot Nothing Then
            cwtHref.PermissionInfo = Me.usrInfo
        End If
        If cwtLinkBtn IsNot Nothing Then
            cwtLinkBtn.PermissionInfo = Me.usrInfo
            cwtLinkBtn.Attributes.Add("onclick", "return confirm('All users in this role will inactive after delete, continue?');")
        End If
    End Sub

End Class
@


1.1.1.1
log
@no message
@
text
@@
