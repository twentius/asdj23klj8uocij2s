head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.04.58;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.04.58;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@
Partial Class Admin_UserSystem_RoleUpdateManager
    Inherits BasePage

    Private BLL As BusinessLogicLayer.StaffRoleBLL

    Public Property RecordID() As String
        Get
            Dim retVal As String = ""
            If Me.ViewState("_RecordID") IsNot Nothing Then
                retVal = Me.ViewState("_RecordID").ToString
            End If
            Return retVal
        End Get
        Set(ByVal value As String)
            Me.ViewState("_RecordID") = value
        End Set
    End Property

    Public ReadOnly Property RequestID() As String
        Get
            Dim retVal As String = ""
            If Me.Request("id") IsNot Nothing Then
                retVal = Me.Request("id")
            End If
            Return retVal
        End Get
    End Property

    Public ReadOnly Property RequestMode() As String
        Get
            Dim retVal As String = ""
            If Me.Request("mode") IsNot Nothing Then
                retVal = Me.Request("mode")
            End If
            Return retVal
        End Get
    End Property

    'Protected Sub Page_ReadPermissionInfo(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.ReadPermissionInfo
    '    Call Me.InitControlsPermission()
    'End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.BLL = New BusinessLogicLayer.StaffRoleBLL()
        If Not IsPostBack Then
            Select Case Me.RequestMode.ToLower()
                Case "add"
                    Me.CurrentPageMode = CWTMasterDB.TransactionMode.AddNewMode
                    Call Me.LoadNewData()
                    Me.lblTitle.Text = "Add new role"
                Case "edit"
                    Me.CurrentPageMode = CWTMasterDB.TransactionMode.UpdateMode
                    Me.RecordID = Me.RequestID
                    Call Me.LoadData()
                    Me.lblTitle.Text = "Update role"
                Case Else
                    Me.CurrentPageMode = CWTMasterDB.TransactionMode.ViewMode
                    Call Me.LoadData()
                    Me.lblTitle.Text = "View role"
            End Select
            Me.btnTrans.PageActionMode = Me.CurrentPageMode
            Me.btnTrans.CancelButton.Attributes.Add("onclick", "return CloseWindow();")
            Me.InitControlsPermission()
        End If
    End Sub

    Private Sub InitControlsPermission()
        Me.lblTitle.PermissionInfo = Me.usrInfo
        Me.txtRoleName.PermissionInfo = Me.usrInfo
        Me.btnTrans.PermissionInfo = Me.usrInfo
    End Sub

    Private Sub LoadNewData()
        Me.txtRoleName.Text = ""
    End Sub

    Private Sub LoadData()
        Dim oDataTable As DataTable
        oDataTable = Me.BLL.GetUserRoleByRoleID(Me.RecordID)
        If oDataTable IsNot Nothing AndAlso oDataTable.Rows.Count > 0 Then
            Me.txtRoleName.Text = oDataTable.Rows(0).Item("Role").ToString()
        End If
    End Sub

    Private Sub SaveData()
        Select Case Me.CurrentPageMode
            Case CWTMasterDB.TransactionMode.AddNewMode
                If Me.BLL.InsertRole(Me.txtRoleName.Text) > 0 Then
                    Call Me.CloseWindows()
                End If
            Case CWTMasterDB.TransactionMode.UpdateMode
                If Me.BLL.UpdateRoleByRoleID(Me.RecordID, Me.txtRoleName.Text) > 0 Then
                    Call Me.CloseWindows()
                End If
            Case Else
                Exit Sub
        End Select
    End Sub

    Private Sub CloseWindows()
        Call Util.RegClientScript("CloseWindow();", "RoleUpdateManager_CloseWin", Util.ClientScriptRegistType.RegStartUpBlock)
    End Sub

    Protected Sub btnTrans_OnSave(ByVal sender As Object, ByVal e As CWTCustomControls.CWTButtonSetEventArgs) Handles btnTrans.OnSave
        Call Me.SaveData()
    End Sub

End Class
@


1.1.1.1
log
@no message
@
text
@@
