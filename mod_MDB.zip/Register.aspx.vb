head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.04.58;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.04.58;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Partial Class Register
    Inherits BasePage

    Private BLL As BusinessLogicLayer.StaffBLL

    Private Property IsErrorBefore() As Boolean
        Get
            Dim retVal As Boolean
            If Me.ViewState("_IsErrorBefore") IsNot Nothing Then
                retVal = CBool(Me.ViewState("_IsErrorBefore"))
            End If
            Return retVal
        End Get
        Set(ByVal value As Boolean)
            Me.ViewState("_IsErrorBefore") = value
        End Set
    End Property

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Me.BLL = New BusinessLogicLayer.StaffBLL()
            Call Me.ToggleArea(True)
            Call Me.LoadDropDownList()
        End If
        '//
        If Me.IsErrorBefore Then
            Me.lblError.Visible = False
        End If
    End Sub

    Private Sub ToggleArea(ByVal IsPreRegist As Boolean)
        Me.divRegistArea.Visible = IsPreRegist
        Me.divWelcomeArea.Visible = Not IsPreRegist
    End Sub

    'Private Sub LoadCountry()
    '    With Me.ddlCountry
    '        .Items.Add(New ListItem("Singapore", "SG"))
    '        .Items.Add(New ListItem("Hongkong", "HK"))
    '        .SelectedValue = "SG"
    '        Call Me.LoadDepartment(.SelectedValue)
    '    End With
    'End Sub
    Private Sub LoadTitle()
        With Me.ddlTitle
            .Items.Add(New ListItem("Mr.", "Mr."))
            .Items.Add(New ListItem("Miss", "Miss"))
            .Items.Add(New ListItem("Mrs", "Mrs"))
        End With
    End Sub
    'Private Sub LoadDepartment(ByVal Country As String)
    '    Dim DivBLL As New BusinessLogicLayer.DivisionBLL()
    '    Dim oDataTable As DataTable
    '    oDataTable = DivBLL.GetDivisionByCountry(Country)
    '    With ddlDepartment
    '        .DataTextField = "DivName"
    '        .DataValueField = "DivID"
    '        .DataSource = oDataTable
    '        .DataBind()
    '        If .Items.Count <= 0 Then
    '            .Items.Add(New ListItem("- No Department found -"))
    '        End If
    '    End With
    'End Sub

    Private Sub LoadDropDownList()
        'Call Me.LoadCountry()
        Call Me.LoadTitle()
    End Sub

    Private Function ValidateForm() As Boolean
        Dim retVal As Boolean = True
        Dim msg As String = ""
        '// Check Exist User
        If Me.BLL.IsExistUser(Me.txtEmail.Text) Then
            retVal = False
            msg += "User exist in database."
            Me.IsErrorBefore = True
        End If
        If msg <> "" Then
            Me.lblError.Text = msg
            Me.lblError.Visible = True
        End If
        Return retVal
    End Function

    Private Sub RegistUser()
        Dim Info As New DataInfo.UserInfo()
        With Info
            .UserName = Me.txtEmail.Text
            .Title = Me.ddlTitle.SelectedValue
            .FirstName = Me.txtFirstName.Text
            .LastName = Me.txtLastName.Text
            .Phone = Me.txtPhoneCode.Text + "-" + Me.txtPhoneNo.Text
            .Mobile = Me.txtHPCode.Text + "-" + Me.txtHPNo.Text
            .AltPhone = Me.txtAltPhoneCode.Text + "-" + Me.txtAltPhoneNo.Text
            .DivID = Me.ddlDepartment.SelectedValue
            .Country = Me.ddlCountry.SelectedValue
            .Email = Me.txtEmail.Text
            .JobTitle = Me.txtJobTitle.Text
            .Remark = Me.txtRemark.Text
            .Password = Me.txtPassword.Text
        End With
        '// Validation
        If Not ValidateForm() Then
            Exit Sub
        End If
        '//
        If Me.BLL.UpdateUser(Info) > 0 Then
            Call Me.ToggleArea(False)
        Else
            Call CWTMasterDB.Util.AlertBox("Cannot regist at this time. Kindly contact administrator.")
        End If
    End Sub

    Protected Sub btnRegist_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnRegist.Click
        Call Me.RegistUser()
    End Sub

    Protected Sub ddlCountry_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlCountry.SelectedIndexChanged
        'Call Me.LoadDepartment(Me.ddlCountry.SelectedValue)
    End Sub

    Protected Sub LinkButton1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton1.Click

    End Sub

    Protected Sub LinkButton1_Command(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.CommandEventArgs) Handles LinkButton1.Command

    End Sub
End Class





@


1.1.1.1
log
@no message
@
text
@@
