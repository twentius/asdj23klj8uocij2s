head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.00;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.00;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Text
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls


<ToolboxData("<{0}:CWTDropDownList runat=server></{0}:CWTDropDownList>")> _
Public Class CWTListBox
    Inherits ListBox

    Private _ControlRequiredLevel As UserLevelControl = UserLevelControl.None

    <Bindable(True), Localizable(True), Category("Permission Info")> _
    Public Property ControlRequiredLevel() As UserLevelControl
        Get
            Return Me._ControlRequiredLevel
        End Get
        Set(ByVal value As UserLevelControl)
            Me._ControlRequiredLevel = value
        End Set
    End Property

    Public Overrides Property Enabled() As Boolean
        Get
            Dim retVal As Boolean = MyBase.Enabled
            If Me.PermissionInfo IsNot Nothing AndAlso Me.PermissionInfo.AuthenRequired Then
                retVal = (Me.ControlRequiredLevel <= Me.PermissionInfo.UserLevel)
            End If
            Return retVal
        End Get
        Set(ByVal value As Boolean)
            MyBase.Enabled = value
        End Set
    End Property

    <Browsable(False)> _
    Public Property PermissionInfo() As CWTPermissionInfo
        Get
            Dim retVal As CWTPermissionInfo = Nothing
            If Me.ViewState("_PermissionInfo") IsNot Nothing Then
                retVal = CType(Me.ViewState("_PermissionInfo"), CWTPermissionInfo)
            End If
            Return retVal
        End Get
        Set(ByVal value As CWTPermissionInfo)
            Me.ViewState("_PermissionInfo") = value
        End Set
    End Property

    Protected Overrides Sub Render(ByVal writer As System.Web.UI.HtmlTextWriter)
        Dim CanRender As Boolean = True
        If Me.PermissionInfo IsNot Nothing AndAlso Me.PermissionInfo.AuthenRequired Then
            CanRender = (Me.ControlRequiredLevel <= Me.PermissionInfo.UserLevel)
        End If
        Me.Enabled = (Me.Enabled AndAlso CanRender)
        MyBase.Render(writer)
    End Sub

End Class
@


1.1.1.1
log
@no message
@
text
@@
