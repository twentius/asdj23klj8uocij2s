head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.00;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.00;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Text
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls


<DefaultProperty("Text"), ToolboxData("<{0}:CWTPagingControl runat=server></{0}:CWTPagingControl>")> _
Public Class CWTPagingControl
    Inherits WebControl

    Private _Table As Table
    Public Property PageDataTable() As DataTable
        Get
            Return Me.ViewState("_PageDataTable")
        End Get
        Set(ByVal value As DataTable)
            Me.ViewState("_PageDataTable") = value
        End Set
    End Property

    Private _lblTotalPage As Literal
    Private _lblPageOf As Literal

    Private _FirstPageButton As LinkButton
    Private _LastPageButton As LinkButton
    'Private _PrevPageButton As Button
    'Private _NextPageButton As Button
    Private _Href1 As LinkButton
    Private _Href2 As LinkButton
    Private _Href3 As LinkButton
    Private _Href4 As LinkButton
    Private _Href5 As LinkButton
    Private _PagedDataSource As PagedDataSource

    <Browsable(False)> _
    Public ReadOnly Property FirstPageButton() As LinkButton
        Get
            Return Me._FirstPageButton
        End Get
    End Property
    <Browsable(False)> _
    Public ReadOnly Property LastPageButton() As LinkButton
        Get
            Return Me._LastPageButton
        End Get
    End Property
    '<Browsable(False)> _
    'Public ReadOnly Property PrevPageButton() As Button
    '    Get
    '        Return Me._PrevPageButton
    '    End Get
    'End Property
    '<Browsable(False)> _
    'Public ReadOnly Property NextPageButton() As Button
    '    Get
    '        Return Me._NextPageButton
    '    End Get
    'End Property
    <Browsable(False)> _
    Public ReadOnly Property Href1() As LinkButton
        Get
            Return Me._Href1
        End Get
    End Property
    <Browsable(False)> _
    Public ReadOnly Property Href2() As LinkButton
        Get
            Return Me._Href2
        End Get
    End Property
    <Browsable(False)> _
    Public ReadOnly Property Href3() As LinkButton
        Get
            Return Me._Href3
        End Get
    End Property
    <Browsable(False)> _
    Public ReadOnly Property Href4() As LinkButton
        Get
            Return Me._Href4
        End Get
    End Property
    <Browsable(False)> _
    Public ReadOnly Property Href5() As LinkButton
        Get
            Return Me._Href5
        End Get
    End Property

    Public Property CurrentPage() As Integer
        Get
            Return Me.ViewState("_Page")
        End Get
        Set(ByVal value As Integer)
            Me.ViewState("_Page") = value
        End Set
    End Property

    Public Property CellCssClass() As String
        Get
            Return Me.ViewState("_CellCssClass")
        End Get
        Set(ByVal value As String)
            Me.ViewState("_CellCssClass") = value
        End Set
    End Property

    <Category("Nest Control Settings")> _
    Public Property GridID() As String
        Get
            Dim retVal As String = ""
            If Me.ViewState("_GridID") IsNot Nothing Then
                retVal = Me.ViewState("_GridID").ToString()
            End If
            Return retVal
        End Get
        Set(ByVal value As String)
            Me.ViewState("_GridID") = value
        End Set
    End Property

    Private Enum ClickType
        P1 = 1
        P2 = 2
        P3 = 3
        P4 = 4
        P5 = 5
        PFirst = 10
        PLast = 99
    End Enum

    Public Enum PagingAlignment
        Left
        Middle
        Right
    End Enum

    Public Sub New()
        Call Me.AddChildControls()
    End Sub

    Private Sub AddChildControls()
        Dim tr As TableRow
        Dim tc As TableCell
        Me._Table = New Table()

        With Me._Table
            .CellPadding = 3
            .CellSpacing = 0
        End With

        Me._lblTotalPage = New Literal()
        Me._lblPageOf = New Literal()

        Me._FirstPageButton = New LinkButton()
        Me._LastPageButton = New LinkButton()
        'Me._NextPageButton = New Button()
        'Me._PrevPageButton = New Button()
        Me._Href1 = New LinkButton()
        Me._Href2 = New LinkButton()
        Me._Href3 = New LinkButton()
        Me._Href4 = New LinkButton()
        Me._Href5 = New LinkButton()
        '//
        Me._FirstPageButton.Text = "<<"
        Me._LastPageButton.Text = ">>"
        'Me._PrevPageButton.Text = "Back"
        'Me._NextPageButton.Text = "Next"
        '//
        'Dim dt As New Table()
        'Dim r As TableRow
        'Dim c As TableCell
        'r = New TableRow()
        'c = New TableCell()
        '//
        Me._Href1.CommandArgument = ClickType.P1
        Me._Href2.CommandArgument = ClickType.P2
        Me._Href3.CommandArgument = ClickType.P3
        Me._Href4.CommandArgument = ClickType.P4
        Me._Href5.CommandArgument = ClickType.P5
        Me._FirstPageButton.CommandArgument = ClickType.PFirst
        Me._LastPageButton.CommandArgument = ClickType.PLast
        '//
        Me._Href1.CommandName = "paging"
        Me._Href2.CommandName = "paging"
        Me._Href3.CommandName = "paging"
        Me._Href4.CommandName = "paging"
        Me._Href5.CommandName = "paging"
        Me._FirstPageButton.CommandName = "paging"
        Me._LastPageButton.CommandName = "paging"
        '//
        AddHandler _Href1.Command, AddressOf OnLinkCommand
        AddHandler _Href2.Command, AddressOf OnLinkCommand
        AddHandler _Href3.Command, AddressOf OnLinkCommand
        AddHandler _Href4.Command, AddressOf OnLinkCommand
        AddHandler _Href5.Command, AddressOf OnLinkCommand
        AddHandler _FirstPageButton.Command, AddressOf OnLinkCommand
        AddHandler _LastPageButton.Command, AddressOf OnLinkCommand
        'Me.Controls.Add(New LiteralControl("&nbsp;"))
        'Me.Controls.Add(Me._NextPageButton)
        'Me.Controls.Add(New LiteralControl("&nbsp;"))
        'Me.Controls.Add(Me._PrevPageButton)

        tr = New TableRow()
        tc = New TableCell()
        tc.HorizontalAlign = HorizontalAlign.Left
        tc.Controls.Add(Me._lblTotalPage)
        tr.Controls.Add(tc)
        tc = New TableCell()
        tc.HorizontalAlign = HorizontalAlign.Right
        'tc.Controls.Add(Me._lblPageOf)
        'tc.Controls.Add(New LiteralControl(vbNewLine))
        tc.Controls.Add(Me._FirstPageButton)
        tc.Controls.Add(New LiteralControl(vbNewLine))
        tc.Controls.Add(Me._Href1)
        tc.Controls.Add(New LiteralControl(vbNewLine))
        tc.Controls.Add(Me._Href2)
        tc.Controls.Add(New LiteralControl(vbNewLine))
        tc.Controls.Add(Me._Href3)
        tc.Controls.Add(New LiteralControl(vbNewLine))
        tc.Controls.Add(Me._Href4)
        tc.Controls.Add(New LiteralControl(vbNewLine))
        tc.Controls.Add(Me._Href5)
        tc.Controls.Add(New LiteralControl(vbNewLine))
        tc.Controls.Add(Me._LastPageButton)
        tr.Controls.Add(tc)
        Me._Table.Rows.Add(tr)

        Me.Controls.Add(Me._Table)

        'Me.Controls.Add(Me._FirstPageButton)
        'Me.Controls.Add(New LiteralControl(vbNewLine))
        'Me.Controls.Add(Me._Href1)
        'Me.Controls.Add(New LiteralControl(vbNewLine))
        'Me.Controls.Add(Me._Href2)
        'Me.Controls.Add(New LiteralControl(vbNewLine))
        'Me.Controls.Add(Me._Href3)
        'Me.Controls.Add(New LiteralControl(vbNewLine))
        'Me.Controls.Add(Me._Href4)
        'Me.Controls.Add(New LiteralControl(vbNewLine))
        'Me.Controls.Add(Me._Href5)
        'Me.Controls.Add(New LiteralControl(vbNewLine))
        'Me.Controls.Add(Me._LastPageButton)
        ''//
    End Sub

    Public Sub SetBindGrid(Optional ByVal page As Integer = 1)
        Dim gv As GridView
        Dim ds As DataTable
        Dim pageCount As Integer
        gv = TryCast(Me.Page.FindControl(Me.GridID), GridView)
        If gv Is Nothing Then
            Me.Visible = False
            Exit Sub
        End If
        If gv.DataSource IsNot Nothing AndAlso gv.DataSource.GetType Is GetType(PagedDataSource) Then
            Me._PagedDataSource = CType(gv.DataSource, PagedDataSource)
            ds = CType(Me._PagedDataSource.DataSource, DataView).Table
            Me.PageDataTable = ds
        Else
            If gv.DataSource IsNot Nothing Then
                ds = CType(gv.DataSource, DataTable)
                Me.PageDataTable = ds
            Else
                ds = Me.PageDataTable
            End If
            Me._PagedDataSource = New PagedDataSource()
        End If
        If ds Is Nothing OrElse ds.Rows.Count < 0 Then
            Me.Visible = False
            Exit Sub
        End If
        With Me._PagedDataSource
            .DataSource = ds.DefaultView
            .PageSize = gv.PageSize
            If (ds.Rows.Count Mod .PageSize) <> 0 Then
                pageCount = (ds.Rows.Count \ .PageSize) + 1
            Else
                pageCount = (ds.Rows.Count \ .PageSize)
            End If
            If page <= 0 OrElse page > pageCount Then
                If page = -1 Then
                    Me.CurrentPage = pageCount
                Else
                    Me.CurrentPage = 1
                End If
            Else
                Me.CurrentPage = page
            End If
            .CurrentPageIndex = Me.CurrentPage - 1
        End With
        With gv
            .DataSource = Me._PagedDataSource
            .PageIndex = Me.CurrentPage - 1
            .DataBind()
        End With
        'Me._Table.Width = gv.Width
        'Me._Table.MergeStyle(gv.PagerStyle)
        'Call Me.RenderPaging(Me._PagedDataSource.PageCount)
        Call Me.SetPage()
    End Sub

    Private Sub RenderPaging(ByVal MaxPage As Integer)
        Dim StLoop As Integer = 1
        Dim EndLoop As Integer = 1
        If Me.CurrentPage >= MaxPage Then
            StLoop = MaxPage - 4
        Else
            StLoop = Me.CurrentPage - ((Me.CurrentPage Mod 5) - 1)
        End If
        If StLoop > 0 And StLoop <= MaxPage Then
            Me._Href1.Text = StLoop.ToString
            Me._Href1.Visible = True
        Else
            Me._Href1.Visible = False
        End If
        If StLoop + 1 > 0 And StLoop + 1 <= MaxPage Then
            Me._Href2.Text = (StLoop + 1).ToString
            Me._Href2.Visible = True
        Else
            Me._Href2.Visible = False
        End If
        If StLoop + 2 > 0 And StLoop + 2 <= MaxPage Then
            Me._Href3.Text = (StLoop + 2).ToString
            Me._Href3.Visible = True
        Else
            Me._Href3.Visible = False
        End If
        If StLoop + 3 > 0 And StLoop + 3 <= MaxPage Then
            Me._Href4.Text = (StLoop + 3).ToString
            Me._Href4.Visible = True
        Else
            Me._Href4.Visible = False
        End If
        If StLoop + 4 > 0 And StLoop + 4 <= MaxPage Then
            Me._Href5.Text = (StLoop + 4).ToString
            Me._Href5.Visible = True
        Else
            Me._Href5.Visible = False
        End If
        'If Me.CurrentPage <= 1 Then
        '    Me.FirstPageButton.Visible = False
        'End If
        'If Me.CurrentPage = MaxPage Then
        '    Me.LastPageButton.Visible = False
        'End If
        '//
        Dim NumberOfData As Integer
        Dim NumberInPage As Integer
        'Dim NumberInCurrentPage As Integer
        Dim PageCount As Integer
        NumberOfData = Me._PagedDataSource.Count
        NumberInPage = Me._PagedDataSource.PageSize
        PageCount = (NumberOfData / NumberInPage) + 1
        'If NumberOfData < NumberInPage OrElse (Me._PagedDataSource.IsLastPage AndAlso NumberOfData < (NumberInPage * Me.CurrentPage)) Then
        '    NumberInCurrentPage = NumberOfData - (NumberInPage * (Me.CurrentPage - 1))
        'Else
        '    NumberInCurrentPage = NumberInPage
        'End If
        'Me._lblTotalPage.Text = "Total " + NumberInCurrentPage.ToString + " of " + (Me._PagedDataSource.PageSize * ).ToString + " Records"
        'Me._lblPageOf.Text = "Page " + Me.CurrentPage.ToString + " of " + Me._PagedDataSource.Count.ToString + ""
        Dim stR As Integer
        Dim EndR As Integer

        stR = ((Me.CurrentPage - 1) * NumberInPage) + 1
        If (Me.CurrentPage * NumberInPage) > NumberOfData Then
            EndR = NumberOfData
        Else
            EndR = (Me.CurrentPage * NumberInPage)
        End If
        Me._lblTotalPage.Text = stR.ToString + "-" + EndR.ToString + " of " + MaxPage.ToString + "/Total " + NumberOfData.ToString + " records"
        'Me._lblPageOf.Text = "Page " + Me.CurrentPage.ToString + " of " + PageCount.ToString + ""
        Me.FirstPageButton.Visible = (PageCount > 1)
        Me.LastPageButton.Visible = (PageCount > 1)
        Me.Visible = (PageCount > 1)
    End Sub

    Private Sub OnLinkCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.CommandEventArgs)
        Select Case e.CommandName
            Case "paging"
                Dim type As ClickType = CInt(e.CommandArgument)
                Select Case type
                    Case ClickType.P1
                        Call Me.SetBindGrid(CInt(Me._Href1.Text))
                    Case ClickType.P2
                        Call Me.SetBindGrid(CInt(Me._Href2.Text))
                    Case ClickType.P3
                        Call Me.SetBindGrid(CInt(Me._Href3.Text))
                    Case ClickType.P4
                        Call Me.SetBindGrid(CInt(Me._Href4.Text))
                    Case ClickType.P5
                        Call Me.SetBindGrid(CInt(Me._Href5.Text))
                    Case ClickType.PFirst
                        Call Me.SetBindGrid(1)
                    Case ClickType.PLast
                        Call Me.SetBindGrid(-1)
                End Select
        End Select
    End Sub

    Protected Overrides Sub Render(ByVal writer As System.Web.UI.HtmlTextWriter)
        'If Me._PagedDataSource IsNot Nothing Then Call Me.RenderPaging(Me._PagedDataSource.PageCount)
        Me._Table.MergeStyle(Me.ControlStyle)
        If Me.CssClass <> "" Then Me._Table.Rows(0).CssClass = Me.CellCssClass
        MyBase.Render(writer)
    End Sub

    Private Sub SetPage()
        Dim NumberOfData As Integer
        Dim NumberInPage As Integer
        'Dim NumberInCurrentPage As Integer
        Dim PageCount As Integer
        If Me._PagedDataSource Is Nothing Then
            Me.FirstPageButton.Visible = False
            Me.LastPageButton.Visible = False
            Exit Sub
        End If
        NumberOfData = Me._PagedDataSource.DataSourceCount
        NumberInPage = Me._PagedDataSource.PageSize
        If (NumberOfData Mod NumberInPage) <> 0 Then
            PageCount = (NumberOfData \ NumberInPage) + 1
        Else
            PageCount = (NumberOfData \ NumberInPage)
        End If

        If Me._PagedDataSource IsNot Nothing Then Call Me.RenderPaging(PageCount)
    End Sub

    Private Sub CWTPagingControl_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Call Me.SetPage()
    End Sub

End Class
@


1.1.1.1
log
@no message
@
text
@@
