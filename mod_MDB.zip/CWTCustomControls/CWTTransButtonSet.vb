head     1.1;
branch   1.1.1;
access   ;
symbols 
	arelease:1.1.1.1
	avendor:1.1.1;
locks    ; strict;
comment  @# @;


1.1
date     2013.04.15.02.06.00;  author ujxa393;  state Exp;
branches 1.1.1.1;
next     ;
deltatype   text;
permissions	666;

1.1.1.1
date     2013.04.15.02.06.00;  author ujxa393;  state Exp;
branches ;
next     ;
permissions	666;


desc
@@



1.1
log
@Initial revision
@
text
@Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Text
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls


<ToolboxData("<{0}:CWTTransButtonSet runat=server></{0}:CWTTransButtonSet>")> _
Public Class CWTTransButtonSet
    Inherits WebControl

    Private _SaveButton As CWTButton
    Private _SaveNextButton As CWTButton
    Private _DeleteButton As CWTButton
    Private _CancelButton As CWTButton

    Public Event OnSave(ByVal sender As Object, ByVal e As CWTButtonSetEventArgs)
    Public Event OnSaveNext(ByVal sender As Object, ByVal e As CWTButtonSetEventArgs)
    Public Event OnDelete(ByVal sender As Object, ByVal e As CWTButtonSetEventArgs)
    Public Event OnCancel(ByVal sender As Object, ByVal e As CWTButtonSetEventArgs)

    <Bindable(True), Category("Child Control Settings"), Localizable(True)> _
    Public Property ButtonCssClass() As String
        Get
            Dim retVal As String = ""
            If Me.ViewState("_ButtonCssClass") IsNot Nothing Then
                retVal = Me.ViewState("_ButtonCssClass").ToString()
            End If
            Return retVal
        End Get
        Set(ByVal value As String)
            Me.ViewState("_ButtonCssClass") = value
        End Set
    End Property

    <Browsable(False)> _
    Public ReadOnly Property SaveButton() As CWTButton
        Get
            Return Me._SaveButton
        End Get
    End Property

    <Browsable(False)> _
    Public ReadOnly Property DeleteButton() As CWTButton
        Get
            Return Me._DeleteButton
        End Get
    End Property

    <Browsable(False)> _
    Public ReadOnly Property CancelButton() As CWTButton
        Get
            Return Me._CancelButton
        End Get
    End Property

    <Category("Button Settings")> _
    Public Property ShowDeleteButton() As Boolean
        Get
            Dim retVal As Boolean = True
            If Me.ViewState("_ShowDeleteButton") IsNot Nothing Then
                retVal = Me.ViewState("_ShowDeleteButton")
            End If
            Return retVal
        End Get
        Set(ByVal value As Boolean)
            Me.ViewState("_ShowDeleteButton") = value
        End Set
    End Property
    <Category("Button Settings")> _
    Public Property ShowSaveNextButton() As Boolean
        Get
            Dim retVal As Boolean = True
            If Me.ViewState("_ShowDeleteButton") IsNot Nothing Then
                retVal = Me.ViewState("_ShowSaveNextButton")
            End If
            Return retVal
        End Get
        Set(ByVal value As Boolean)
            Me.ViewState("_ShowSaveNextButton") = value
        End Set
    End Property

    <Bindable(True), Category("Page Settings"), Localizable(True)> _
   Public Property PageActionMode() As TransactionMode
        Get
            Dim retVal As TransactionMode = TransactionMode.ViewMode
            If Me.ViewState("_PageActionMode") IsNot Nothing Then
                retVal = Me.ViewState("_PageActionMode")
            End If
            Return retVal
        End Get

        Set(ByVal Value As TransactionMode)
            Me.ViewState("_PageActionMode") = Value
        End Set
    End Property

    Public Property PermissionInfo() As CWTPermissionInfo
        Get
            Dim retVal As CWTPermissionInfo = Nothing
            If Me.ViewState("_PermissionInfo") IsNot Nothing Then
                retVal = CType(Me.ViewState("_PermissionInfo"), CWTPermissionInfo)
            End If
            Return retVal
        End Get
        Set(ByVal value As CWTPermissionInfo)
            Me.ViewState("_PermissionInfo") = value
        End Set
    End Property

    Public Property ValidationGroup() As String
        Get
            Return Me.ViewState("_ValidationGroup")
        End Get
        Set(ByVal value As String)
            Me.ViewState("_ValidationGroup") = value
        End Set
    End Property

    Public Property CausesValidation() As Boolean
        Get
            Return Me.ViewState("_CausesValidation")
        End Get
        Set(ByVal value As Boolean)
            Me.ViewState("_CausesValidation") = value
        End Set
    End Property

    Public Sub New()
        Call Me.AddChildControls()
        Me.CausesValidation = True
    End Sub

    Private Sub AddChildControls()
        MyBase.CreateChildControls()
        Me._SaveButton = New CWTButton()
        Me._SaveNextButton = New CWTButton()
        Me._DeleteButton = New CWTButton()
        Me._CancelButton = New CWTButton()
        '//
        With Me._DeleteButton
            .Text = " Delete "
            Me.ShowDeleteButton = True
        End With
        With Me._SaveButton
            .Text = " Save "
        End With
        With Me._SaveNextButton
            .Text = " Save & Next "
            .Visible = False
            Me.ShowSaveNextButton = False
        End With
        With Me._CancelButton
            .Text = " Cancel "
            .CausesValidation = False
        End With
        '//
        '//
        Me.Controls.Add(New LiteralControl("<table width='100%'><tr><td>"))
        Me.Controls.Add(Me._DeleteButton)
        Me.Controls.Add(New LiteralControl("&nbsp; &nbsp;"))
        Me.Controls.Add(Me._SaveButton)
        Me.Controls.Add(New LiteralControl("&nbsp;"))
        Me.Controls.Add(Me._SaveNextButton)
        Me.Controls.Add(New LiteralControl("&nbsp;"))
        Me.Controls.Add(Me._CancelButton)
        Me.Controls.Add(New LiteralControl("</tr></table>"))
        AddHandler Me._SaveButton.Click, AddressOf OnUpdateClick
        AddHandler Me._SaveNextButton.Click, AddressOf OnUpdateNextClick
        AddHandler Me._DeleteButton.Click, AddressOf OnDeleteClick
        AddHandler Me._CancelButton.Click, AddressOf OnCancelClick
    End Sub

    Protected Overrides Sub Render(ByVal writer As System.Web.UI.HtmlTextWriter)
        If Me.PermissionInfo IsNot Nothing AndAlso Me.PermissionInfo.AuthenRequired Then
            Select Case Me.PageActionMode
                Case TransactionMode.UpdateMode
                    Me._SaveButton.Visible = (Me.PermissionInfo.UserLevel >= UserLevelControl.FullFunctional)
                    Me._SaveNextButton.Visible = (Me.PermissionInfo.UserLevel >= UserLevelControl.FullFunctional) AndAlso Me.ShowSaveNextButton
                    Me._DeleteButton.Visible = (Me.PermissionInfo.UserLevel >= UserLevelControl.FullFunctional) AndAlso Me.ShowDeleteButton
                Case TransactionMode.AddNewMode
                    Me._SaveButton.Visible = (Me.PermissionInfo.UserLevel >= UserLevelControl.FullFunctional)
                    Me._SaveNextButton.Visible = (Me.PermissionInfo.UserLevel >= UserLevelControl.FullFunctional) AndAlso Me.ShowSaveNextButton
                    Me._DeleteButton.Visible = (Me.PermissionInfo.UserLevel >= UserLevelControl.FullFunctional) AndAlso Me.ShowDeleteButton
                Case TransactionMode.ViewMode
                    Me._SaveButton.Visible = False
                    Me._SaveNextButton.Visible = False
                    Me._DeleteButton.Visible = False
            End Select
            Me._CancelButton.Visible = True
        Else
            Me._DeleteButton.Visible = Me.ShowDeleteButton
            Me._SaveNextButton.Visible = Me.ShowSaveNextButton
        End If
        Me._SaveButton.CssClass = Me.ButtonCssClass
        Me._SaveNextButton.CssClass = Me.ButtonCssClass
        Me._DeleteButton.CssClass = Me.ButtonCssClass
        Me._CancelButton.CssClass = Me.ButtonCssClass

        Me._SaveButton.ValidationGroup = Me.ValidationGroup
        Me._SaveNextButton.ValidationGroup = Me.ValidationGroup
        Me._SaveButton.CausesValidation = Me.CausesValidation
        Me._SaveNextButton.CausesValidation = Me.CausesValidation

        MyBase.Render(writer)
    End Sub

    Private Sub OnUpdateClick(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim eArgs As CWTButtonSetEventArgs
        Dim bEvent As Boolean
        Select Case Me.PageActionMode
            Case TransactionMode.UpdateMode
                bEvent = (Me.PermissionInfo.UserLevel >= UserLevelControl.FullFunctional)
            Case TransactionMode.AddNewMode
                bEvent = (Me.PermissionInfo.UserLevel >= UserLevelControl.FullFunctional)
            Case TransactionMode.ViewMode
                bEvent = False
        End Select
        eArgs = New CWTButtonSetEventArgs(Me.PageActionMode, bEvent)
        RaiseEvent OnSave(sender, eArgs)
    End Sub

    Private Sub OnUpdateNextClick(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim eArgs As CWTButtonSetEventArgs
        Dim bEvent As Boolean
        Select Case Me.PageActionMode
            Case TransactionMode.UpdateMode
                bEvent = (Me.PermissionInfo.UserLevel >= UserLevelControl.FullFunctional)
            Case TransactionMode.AddNewMode
                bEvent = (Me.PermissionInfo.UserLevel >= UserLevelControl.FullFunctional)
            Case TransactionMode.ViewMode
                bEvent = False
        End Select
        eArgs = New CWTButtonSetEventArgs(Me.PageActionMode, bEvent)
        RaiseEvent OnSaveNext(sender, eArgs)
    End Sub

    Private Sub OnDeleteClick(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim eArgs As CWTButtonSetEventArgs
        Dim bEvent As Boolean
        Select Case Me.PageActionMode
            Case TransactionMode.UpdateMode, TransactionMode.AddNewMode
                bEvent = (Me.PermissionInfo.UserLevel >= UserLevelControl.FullFunctional)
            Case TransactionMode.ViewMode
                bEvent = False
        End Select
        eArgs = New CWTButtonSetEventArgs(Me.PageActionMode, bEvent)
        RaiseEvent OnDelete(sender, eArgs)
    End Sub

    Private Sub OnCancelClick(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim eArgs As CWTButtonSetEventArgs
        Dim bEvent As Boolean = True
        eArgs = New CWTButtonSetEventArgs(Me.PageActionMode, bEvent)
        RaiseEvent OnCancel(sender, eArgs)
    End Sub

End Class

Public Class CWTButtonSetEventArgs

    Public BubbleEvent As Boolean
    Public PageActionMode As TransactionMode

    Public Sub New(ByVal ActionMode As TransactionMode, ByVal BubbleEvnt As Boolean)
        Me.PageActionMode = PageActionMode
        Me.BubbleEvent = BubbleEvnt
    End Sub

End Class


@


1.1.1.1
log
@no message
@
text
@@
